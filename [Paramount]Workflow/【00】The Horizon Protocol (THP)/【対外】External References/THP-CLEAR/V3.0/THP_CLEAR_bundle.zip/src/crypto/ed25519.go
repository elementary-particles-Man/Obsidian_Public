package crypto

import (
	"crypto/ed25519"
	"crypto/rand"
	"errors"
	"fmt"
)

// GenerateEd25519 returns a freshly generated public/private key pair.
func GenerateEd25519() (ed25519.PublicKey, ed25519.PrivateKey, error) {
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, nil, err
	}
	return pub, priv, nil
}

// SignEd25519 signs the message using the provided private key.
func SignEd25519(private ed25519.PrivateKey, msg []byte) ([]byte, error) {
	if len(private) != ed25519.PrivateKeySize {
		return nil, fmt.Errorf("ed25519 sign: private key must be %d bytes", ed25519.PrivateKeySize)
	}
	signature := ed25519.Sign(private, msg)
	return signature, nil
}

// VerifyEd25519 validates signature against message and public key.
func VerifyEd25519(public ed25519.PublicKey, msg, signature []byte) error {
	if len(public) != ed25519.PublicKeySize {
		return fmt.Errorf("ed25519 verify: public key must be %d bytes", ed25519.PublicKeySize)
	}
	if len(signature) != ed25519.SignatureSize {
		return fmt.Errorf("ed25519 verify: signature must be %d bytes", ed25519.SignatureSize)
	}
	if !ed25519.Verify(public, msg, signature) {
		return errors.New("ed25519 verify: invalid signature")
	}
	return nil
}
