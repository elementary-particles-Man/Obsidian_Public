package crypto

import "golang.org/x/crypto/sha3"

// SHA3_256 computes SHA3-256 over the concatenation of the provided byte slices.
func SHA3_256(parts ...[]byte) [32]byte {
	hash := sha3.New256()
	for _, part := range parts {
		if part != nil {
			hash.Write(part)
		}
	}
	var out [32]byte
	copy(out[:], hash.Sum(nil))
	return out
}
