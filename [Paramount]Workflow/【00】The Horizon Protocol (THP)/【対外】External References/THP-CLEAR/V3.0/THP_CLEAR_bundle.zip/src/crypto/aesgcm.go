package crypto

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"errors"
	"fmt"
)

const (
	// AES256KeySize is the fixed key length in bytes.
	AES256KeySize = 32
	// AESGCMIVSize is the IV length mandated by the directives.
	AESGCMIVSize = 12
	// AESGCMTagSize is the authentication tag length.
	AESGCMTagSize = 16
)

// AES256GCM offers a minimal wrapper for AES-256-GCM with detached tag handling.
type AES256GCM struct {
	key [AES256KeySize]byte
}

// NewAES256GCM constructs the wrapper from a 32-byte key.
func NewAES256GCM(key []byte) (*AES256GCM, error) {
	if len(key) != AES256KeySize {
		return nil, fmt.Errorf("aes256gcm: key must be %d bytes", AES256KeySize)
	}
	var k [AES256KeySize]byte
	copy(k[:], key)
	return &AES256GCM{key: k}, nil
}

// Encrypt seals plaintext with optional AAD and returns IV, ciphertext, and detached tag.
func (a *AES256GCM) Encrypt(plaintext, aad []byte) (iv [AESGCMIVSize]byte, ciphertext []byte, tag [AESGCMTagSize]byte, err error) {
	if a == nil {
		err = errors.New("aes256gcm: nil context")
		return
	}
	block, err := aes.NewCipher(a.key[:])
	if err != nil {
		return
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return
	}
	if _, err = rand.Read(iv[:]); err != nil {
		return
	}
	out := gcm.Seal(nil, iv[:], plaintext, aad)
	if len(out) < AESGCMTagSize {
		err = errors.New("aes256gcm: truncated output")
		return
	}
	tagOffset := len(out) - AESGCMTagSize
	copy(tag[:], out[tagOffset:])
	ciphertext = make([]byte, tagOffset)
	copy(ciphertext, out[:tagOffset])
	return
}

// EncryptWithIV performs encryption using the provided IV (must be 12 bytes).
func (a *AES256GCM) EncryptWithIV(plaintext, aad, iv []byte) (ciphertext []byte, tag [AESGCMTagSize]byte, err error) {
	if len(iv) != AESGCMIVSize {
		err = fmt.Errorf("aes256gcm: iv must be %d bytes", AESGCMIVSize)
		return
	}
	var fixedIV [AESGCMIVSize]byte
	copy(fixedIV[:], iv)
	_, ciphertext, tag, err = a.EncryptWithFixedIV(plaintext, aad, fixedIV)
	return
}

// EncryptWithFixedIV encrypts using an IV that is already in array form.
func (a *AES256GCM) EncryptWithFixedIV(plaintext, aad []byte, iv [AESGCMIVSize]byte) (outIV [AESGCMIVSize]byte, ciphertext []byte, tag [AESGCMTagSize]byte, err error) {
	if a == nil {
		err = errors.New("aes256gcm: nil context")
		return
	}
	block, err := aes.NewCipher(a.key[:])
	if err != nil {
		return
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return
	}
	out := gcm.Seal(nil, iv[:], plaintext, aad)
	if len(out) < AESGCMTagSize {
		err = errors.New("aes256gcm: truncated output")
		return
	}
	tagOffset := len(out) - AESGCMTagSize
	copy(tag[:], out[tagOffset:])
	ciphertext = make([]byte, tagOffset)
	copy(ciphertext, out[:tagOffset])
	outIV = iv
	return
}

// Decrypt opens ciphertext with detached tag and returns plaintext.
func (a *AES256GCM) Decrypt(iv [AESGCMIVSize]byte, ciphertext, aad []byte, tag [AESGCMTagSize]byte) ([]byte, error) {
	if a == nil {
		return nil, errors.New("aes256gcm: nil context")
	}
	block, err := aes.NewCipher(a.key[:])
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	combined := append([]byte{}, ciphertext...)
	combined = append(combined, tag[:]...)
	return gcm.Open(nil, iv[:], combined, aad)
}

// KeyBytes returns a copy of the wrapped key material.
func (a *AES256GCM) KeyBytes() [AES256KeySize]byte {
	return a.key
}
