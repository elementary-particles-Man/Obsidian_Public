package crypto

import (
	"bytes"
	"crypto/ed25519"
	"crypto/rand"
	"testing"
)

func TestAES256GCMEncryptDecrypt(t *testing.T) {
	key := make([]byte, AES256KeySize)
	if _, err := rand.Read(key); err != nil {
		t.Fatalf("rand: %v", err)
	}
	aesgcm, err := NewAES256GCM(key)
	if err != nil {
		t.Fatalf("new aes: %v", err)
	}

	plain := make([]byte, 320)
	for i := 0; i < len(plain); i++ {
		plain[i] = byte(i)
	}
	aad := []byte("aad-test")

	iv, ciphertext, tag, err := aesgcm.Encrypt(plain, aad)
	if err != nil {
		t.Fatalf("encrypt: %v", err)
	}
	if len(ciphertext) != len(plain) {
		t.Fatalf("ciphertext size mismatch: %d", len(ciphertext))
	}

	recovered, err := aesgcm.Decrypt(iv, ciphertext, aad, tag)
	if err != nil {
		t.Fatalf("decrypt: %v", err)
	}
	if !bytes.Equal(recovered, plain) {
		t.Fatalf("plaintext mismatch after decrypt")
	}
}

func TestISETransform(t *testing.T) {
	key := make([]byte, ISEKeySize)
	if _, err := rand.Read(key); err != nil {
		t.Fatalf("rand: %v", err)
	}

	ise, err := NewISE(key)
	if err != nil {
		t.Fatalf("new ise: %v", err)
	}

	plain := make([]byte, 512)
	for i := range plain {
		plain[i] = byte(i)
	}
	cipher := ise.Transform(plain)
	if bytes.Equal(cipher, plain) {
		t.Fatalf("cipher should differ from plain")
	}

	recovered := ise.Transform(cipher)
	if !bytes.Equal(recovered, plain) {
		t.Fatalf("ise roundtrip mismatch")
	}
}

func TestSHA3_256(t *testing.T) {
	a := []byte("foo")
	b := []byte("bar")
	h1 := SHA3_256(a, b)
	h2 := SHA3_256([]byte("foo"), []byte("bar"))
	if h1 != h2 {
		t.Fatalf("sha3 deterministic mismatch")
	}
}

func TestEd25519Wrap(t *testing.T) {
	pub, priv, err := GenerateEd25519()
	if err != nil {
		t.Fatalf("generate: %v", err)
	}
	msg := []byte("message")
	sig, err := SignEd25519(priv, msg)
	if err != nil {
		t.Fatalf("sign: %v", err)
	}
	if err := VerifyEd25519(pub, msg, sig); err != nil {
		t.Fatalf("verify: %v", err)
	}

	if err := VerifyEd25519(pub, []byte("tampered"), sig); err == nil {
		t.Fatalf("verify should fail on tampered message")
	}

	if err := VerifyEd25519(ed25519.PublicKey(make([]byte, ed25519.PublicKeySize)), msg, sig); err == nil {
		t.Fatalf("verify should fail with wrong pub key")
	}
}
