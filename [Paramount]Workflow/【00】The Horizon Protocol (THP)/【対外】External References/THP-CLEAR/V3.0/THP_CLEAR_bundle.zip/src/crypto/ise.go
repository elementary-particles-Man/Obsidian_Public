package crypto

import (
	"encoding/binary"
	"errors"
)

const (
	// ISEKeySize is the mandated raw key size.
	ISEKeySize = 32
)

// ISE provides a reversible byte-wise transform derived from the 32-byte key.
type ISE struct {
	key [ISEKeySize]byte
}

// NewISE constructs a new encoder using the provided raw key.
func NewISE(key []byte) (*ISE, error) {
	if len(key) != ISEKeySize {
		return nil, errors.New("ise: key must be 32 bytes")
	}
	var k [ISEKeySize]byte
	copy(k[:], key)
	return &ISE{key: k}, nil
}

// Transform returns a copy of input with the ISE keystream applied.
// The operation is its own inverse and can be used for sealing/unsealing.
func (i *ISE) Transform(input []byte) []byte {
	if i == nil {
		return nil
	}
	out := make([]byte, len(input))
	copy(out, input)
	i.TransformInPlace(out)
	return out
}

// TransformInPlace applies the keystream to the provided buffer.
func (i *ISE) TransformInPlace(buf []byte) {
	if i == nil {
		return
	}
	stream := newISEStream(i.key)
	for idx := range buf {
		buf[idx] ^= stream.next()
	}
}

// KeyBytes returns the raw key material.
func (i *ISE) KeyBytes() [ISEKeySize]byte {
	return i.key
}

type iseStream struct {
	state [4]uint64
	tick  uint64
}

func newISEStream(key [ISEKeySize]byte) *iseStream {
	return &iseStream{
		state: [4]uint64{
			binary.BigEndian.Uint64(key[0:8]),
			binary.BigEndian.Uint64(key[8:16]),
			binary.BigEndian.Uint64(key[16:24]),
			binary.BigEndian.Uint64(key[24:32]),
		},
		tick: 0x9E3779B97F4A7C15,
	}
}

func (s *iseStream) next() byte {
	index := s.tick & 0x3
	x := s.state[index]
	x ^= x << 7
	x ^= x >> 9
	x ^= x << 8
	x += s.tick + 0xA0761D6478BD642F
	s.state[index] = x

	shift := (s.tick >> 2) & 0x3F
	out := byte((x >> shift) & 0xFF)
	s.tick += 0x9E3779B97F4A7C15
	return out
}
