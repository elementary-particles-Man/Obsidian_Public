package tpm

import (
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"sync"
)

const keyLen = 32
const counterBytes = 8

// ErrSignatureExport is returned when callers attempt to export TPM signatures.
var ErrSignatureExport = errors.New("tpm: signature export prohibited")

// HandlerV2 simulates a TPM-backed session interface for replication flows.
type HandlerV2 struct {
	mu            sync.Mutex
	lastZeroized  bool
	sessionCursor uint64
}

func NewHandlerV2() *HandlerV2 {
	return &HandlerV2{}
}

// Decrypt reconstructs plaintext from a TPM sealed payload.
func (h *HandlerV2) Decrypt(payload []byte, key []byte) ([]byte, error) {
	if len(key) != keyLen {
		return nil, errors.New("tpm: invalid key length")
	}
	if len(payload) < counterBytes {
		return nil, errors.New("tpm: payload truncated")
	}
	h.mu.Lock()
	counter := binary.LittleEndian.Uint64(payload[:counterBytes])
	mask := deriveMask(key, counter)
	h.lastZeroized = false
	h.mu.Unlock()

	body := payload[counterBytes:]
	plain := make([]byte, len(body))
	for i := range body {
		plain[i] = body[i] ^ mask[i%len(mask)]
	}
	zeroize(mask[:])
	return plain, nil
}

// ISEEncrypt executes the TPM reseal path, zeroing plaintext after sealing.
func (h *HandlerV2) ISEEncrypt(plain []byte, key []byte) ([]byte, error) {
	if len(key) != keyLen {
		return nil, errors.New("tpm: invalid key length")
	}
	if plain == nil {
		return nil, errors.New("tpm: plaintext missing")
	}
	h.mu.Lock()
	h.sessionCursor++
	counter := h.sessionCursor
	mask := deriveMask(key, counter)
	h.mu.Unlock()

	out := make([]byte, len(plain)+counterBytes)
	binary.LittleEndian.PutUint64(out[:counterBytes], counter)
	for i := range plain {
		out[counterBytes+i] = plain[i] ^ mask[i%len(mask)]
	}
	zeroize(mask[:])
	zeroize(plain)
	h.mu.Lock()
	h.lastZeroized = isZero(plain)
	h.mu.Unlock()
	return out, nil
}

// ExportSignature is intentionally unsupported for TPM-backed keys.
func (h *HandlerV2) ExportSignature() ([]byte, error) {
	return nil, ErrSignatureExport
}

// LastZeroized reports whether the previous TPM session observed a zeroized buffer.
func (h *HandlerV2) LastZeroized() bool {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.lastZeroized
}

func deriveMask(key []byte, counter uint64) [sha256.Size]byte {
	var seed [keyLen + counterBytes]byte
	copy(seed[:keyLen], key[:keyLen])
	binary.LittleEndian.PutUint64(seed[keyLen:], counter)
	return sha256.Sum256(seed[:])
}

func zeroize(buf []byte) {
	if buf == nil {
		return
	}
	for i := range buf {
		buf[i] = 0
	}
}

func isZero(buf []byte) bool {
	for _, b := range buf {
		if b != 0 {
			return false
		}
	}
	return true
}
