package kmsproto

import (
	"crypto/ed25519"
	"errors"
	"fmt"
)

// Signature is a single signer output with an identifier.
type Signature struct {
	KeyID string `json:"kid"`
	Sig   []byte `json:"sig"`
}

// SigBundle is a collection of signatures issued by the KMS quorum.
type SigBundle []Signature

// Verify checks that at least threshold signatures inside the bundle validate
// against the provided message and public key ring.
func (b SigBundle) Verify(message []byte, pubKeys map[string]ed25519.PublicKey, threshold int) error {
	if threshold <= 0 {
		return errors.New("threshold must be positive")
	}
	var good int
	for _, sig := range b {
		pub, ok := pubKeys[sig.KeyID]
		if !ok {
			continue
		}
		if len(sig.Sig) != ed25519.SignatureSize {
			continue
		}
		if ed25519.Verify(pub, message, sig.Sig) {
			good++
		}
	}
	if good < threshold {
		return fmt.Errorf("sigbundle: verified %d signatures, need %d", good, threshold)
	}
	return nil
}

// Contains reports whether the bundle contains the given signer ID.
func (b SigBundle) Contains(kid string) bool {
	for _, sig := range b {
		if sig.KeyID == kid {
			return true
		}
	}
	return false
}
