//go:build !windows

package kmsclient

func loadRustLibrary() error {
	return nil
}
