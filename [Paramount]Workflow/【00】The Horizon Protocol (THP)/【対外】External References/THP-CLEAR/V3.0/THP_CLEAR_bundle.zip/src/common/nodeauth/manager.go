package nodeauth

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/json"
	"errors"
	"sync"
	"time"

	"github.com/google/uuid"

	"thp-clear/src/MQ/encryptor"
	"thp-clear/src/common/audit"
	"thp-clear/src/common/kmsclient"
	"thp-clear/src/common/kmsproto"
)

// Manager coordinates key acquisition and ticket verification for a node.
type Manager struct {
	nodeID  string
	store   *Store
	ring    *encryptor.KeyRing
	client  kmsclient.Client
	keyType string

	maxRetry int
	backoff  []time.Duration

	mu            sync.Mutex
	blockedUntil  time.Time
	warnBackoff   time.Duration
	blockDuration time.Duration
	lastWarnUntil time.Time
	pubKeys       map[string]ed25519.PublicKey
	threshold     int
	metrics       MetricsRecorder
	audit         *audit.JSONL
}

// ManagerConfig carries runtime configuration.
type ManagerConfig struct {
	NodeID        string
	KeyType       string
	MaxRetry      int
	Backoff       []time.Duration
	WarnBackoff   time.Duration
	BlockDuration time.Duration
	PublicKeys    map[string]ed25519.PublicKey
	Threshold     int
	Metrics       MetricsRecorder
	Audit         *audit.JSONL
}

// NewManager builds a manager.
func NewManager(store *Store, ring *encryptor.KeyRing, client kmsclient.Client, cfg ManagerConfig) (*Manager, error) {
	if cfg.MaxRetry <= 0 {
		cfg.MaxRetry = 2
	}
	if len(cfg.Backoff) == 0 {
		cfg.Backoff = []time.Duration{time.Second, 5 * time.Second}
	}
	if cfg.KeyType == "" {
		cfg.KeyType = "transport"
	}
	if cfg.WarnBackoff == 0 {
		cfg.WarnBackoff = 60 * time.Second
	}
	if cfg.BlockDuration == 0 {
		cfg.BlockDuration = 60 * time.Second
	}
	if cfg.PublicKeys == nil || len(cfg.PublicKeys) == 0 {
		return nil, errors.New("kms public keys must be provided")
	}
	if cfg.Threshold <= 0 {
		cfg.Threshold = 2
	}
	metrics := cfg.Metrics
	if metrics == nil {
		metrics = nopNodeMetrics{}
	}
	return &Manager{
		nodeID:        cfg.NodeID,
		store:         store,
		ring:          ring,
		client:        client,
		keyType:       cfg.KeyType,
		maxRetry:      cfg.MaxRetry,
		backoff:       cfg.Backoff,
		warnBackoff:   cfg.WarnBackoff,
		blockDuration: cfg.BlockDuration,
		blockedUntil:  time.Time{},
		lastWarnUntil: time.Time{},
		pubKeys:       cfg.PublicKeys,
		threshold:     cfg.Threshold,
		metrics:       metrics,
		audit:         cfg.Audit,
	}, nil
}

// EnsureEpoch acquires key material for the target epoch if missing.
func (m *Manager) EnsureEpoch(ctx context.Context, epoch uint64) error {
	if m.isBlocked() {
		m.metrics.RecordKeyFetch("blocked")
		m.logEvent("key_fetch", map[string]interface{}{
			"status": "blocked",
			"epoch":  epoch,
		})
		return errors.New("key manager is temporarily blocked by spy alert")
	}
	cur, err := m.ring.Current()
	if err == nil && cur.Version == epoch {
		return nil
	}

	var lastReason string
	var lastMeta kmsclient.Metadata
	var lastReqID string
	for attempt := 0; attempt < m.maxRetry; attempt++ {
		if attempt > 0 && attempt-1 < len(m.backoff) {
			select {
			case <-time.After(m.backoff[attempt-1]):
			case <-ctx.Done():
				return ctx.Err()
			}
		}

		req := kmsproto.KeyRequest{
			Type:      "KeyRequest",
			NodeID:    m.nodeID,
			ReqID:     uuid.NewString(),
			KeyType:   m.keyType,
			Timestamp: time.Now().Unix(),
			NodeNonce: randomBytes(16),
		}
		lastReqID = req.ReqID

		challenge, challengeMeta, err := m.client.RequestChallenges(ctx, req)
		if err != nil {
			lastReason = "request_fail"
			lastMeta = challengeMeta
			continue
		}
		if err := m.verifyChallenge(challenge); err != nil {
			lastReason = "challenge_sig"
			m.metrics.RecordTicketFail(lastReason)
			lastMeta = challengeMeta
			continue
		}

		responses, session, err := m.store.BuildResponses(challenge)
		if err != nil {
			lastReason = "build_response"
			lastMeta = challengeMeta
			continue
		}

		result, resultMeta, err := m.client.SubmitResponses(ctx, *responses)
		mergedMeta := mergeMetadata(challengeMeta, resultMeta)
		if err != nil {
			lastReason = "submit_fail"
			lastMeta = mergedMeta
			continue
		}
		if err := m.verifyKeyResult(result); err != nil {
			lastReason = "result_sig"
			m.metrics.RecordTicketFail(lastReason)
			lastMeta = mergedMeta
			continue
		}
		if err := m.verifyTicketSignature(result.Ticket); err != nil {
			lastReason = "ticket_sig"
			m.metrics.RecordTicketFail(lastReason)
			lastMeta = mergedMeta
			continue
		}
		if err := session.VerifyTicket(result.Ticket, result.Payload); err != nil {
			lastReason = "ticket_mac"
			m.metrics.RecordTicketFail(lastReason)
			lastMeta = mergedMeta
			continue
		}
		if result.Status != "OK" {
			lastReason = "decoy"
			m.metrics.RecordTicketFail(lastReason)
			lastMeta = mergedMeta
			continue
		}
		material, err := payloadToMaterial(result.Payload)
		if err != nil {
			lastReason = "material"
			m.metrics.RecordTicketFail(lastReason)
			lastMeta = mergedMeta
			continue
		}
		m.ring.Apply(material)
		m.metrics.RecordKeyFetch("success")
		usedPrev := material.Version < epoch
		m.logEvent("key_fetch", map[string]interface{}{
			"status":                   "success",
			"session_id":               req.ReqID,
			"kms_endpoint":             mergedMeta.Primary,
			"key_version":              material.Version,
			"attempt":                  attempt + 1,
			"epoch":                    epoch,
			"used_prev":                usedPrev,
			"kids":                     bundleKids(result.SigBundle),
			"quorum_members":           mergedMeta.Members,
			"quorum_primary":           mergedMeta.Primary,
			"quorum_primary_index":     mergedMeta.PrimaryIndex,
			"failover_count":           mergedMeta.FailoverCount,
			"kms_attempts":             mergedMeta.Attempts,
			"challenge_failover_count": mergedMeta.ChallengeFailovers,
			"challenge_latency_ms":     durationMillis(mergedMeta.ChallengeLatency),
			"submit_latency_ms":        durationMillis(mergedMeta.SubmitLatency),
		})
		return nil
	}

	m.metrics.RecordKeyFetch("failure")
	m.logEvent("key_fetch", map[string]interface{}{
		"status":                   "failure",
		"session_id":               lastReqID,
		"kms_endpoint":             lastMeta.Primary,
		"epoch":                    epoch,
		"attempts":                 m.maxRetry,
		"reason":                   lastReason,
		"quorum_members":           lastMeta.Members,
		"quorum_primary":           lastMeta.Primary,
		"quorum_primary_index":     lastMeta.PrimaryIndex,
		"failover_count":           lastMeta.FailoverCount,
		"kms_attempts":             lastMeta.Attempts,
		"challenge_failover_count": lastMeta.ChallengeFailovers,
		"challenge_latency_ms":     durationMillis(lastMeta.ChallengeLatency),
		"submit_latency_ms":        durationMillis(lastMeta.SubmitLatency),
	})
	return errors.New("failed to acquire key material")
}

// HandleSpyAlert applies backoff or block semantics.
func (m *Manager) HandleSpyAlert(alert *kmsproto.SpyAlert) {
	if alert == nil {
		return
	}
	if err := m.verifySpyAlert(alert); err != nil {
		m.metrics.RecordSpyAlert("invalid")
		m.logEvent("spy_alert_invalid", map[string]interface{}{
			"error": err.Error(),
		})
		return
	}
	m.metrics.RecordSpyAlert(alert.Level)
	m.logEvent("spy_alert", map[string]interface{}{
		"level":         alert.Level,
		"req_id":        alert.ReqID,
		"failed_rounds": alert.FailedRounds,
		"kids":          bundleKids(alert.SigBundle),
	})
	m.mu.Lock()
	defer m.mu.Unlock()

	switch alert.Level {
	case "block":
		m.blockedUntil = time.Now().Add(m.blockDuration)
	case "warn":
		if time.Now().Before(m.lastWarnUntil) {
			return
		}
		m.lastWarnUntil = time.Now().Add(m.warnBackoff)
	}
}

func (m *Manager) isBlocked() bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	if time.Now().Before(m.blockedUntil) {
		return true
	}
	if time.Now().Before(m.lastWarnUntil) {
		return true
	}
	return false
}

func (m *Manager) verifyChallenge(ch *kmsproto.ChallengeSet) error {
	if ch == nil {
		return errors.New("challenge is nil")
	}
	copy := *ch
	copy.SigBundle = nil
	data, err := json.Marshal(copy)
	if err != nil {
		return err
	}
	return m.verifyBundle(data, ch.SigBundle)
}

func (m *Manager) verifyKeyResult(result *kmsproto.KeyResult) error {
	if result == nil {
		return errors.New("key result is nil")
	}
	copy := *result
	copy.SigBundle = nil
	if result.Ticket != nil {
		t := *result.Ticket
		copy.Ticket = &t
	}
	data, err := json.Marshal(copy)
	if err != nil {
		return err
	}
	return m.verifyBundle(data, result.SigBundle)
}

func (m *Manager) verifyTicketSignature(ticket *kmsproto.KeyTicket) error {
	if ticket == nil {
		return errors.New("ticket is nil")
	}
	copy := *ticket
	copy.TicketSig = nil
	data, err := json.Marshal(copy)
	if err != nil {
		return err
	}
	return m.verifyBundle(data, ticket.TicketSig)
}

func (m *Manager) verifySpyAlert(alert *kmsproto.SpyAlert) error {
	copy := *alert
	copy.SigBundle = nil
	data, err := json.Marshal(copy)
	if err != nil {
		return err
	}
	return m.verifyBundle(data, alert.SigBundle)
}

func (m *Manager) verifyBundle(data []byte, bundle kmsproto.SigBundle) error {
	if len(bundle) == 0 {
		return errors.New("signature bundle empty")
	}
	return bundle.Verify(data, m.pubKeys, m.threshold)
}

func (m *Manager) logEvent(event string, fields map[string]interface{}) {
	if m.audit == nil {
		return
	}
	if fields == nil {
		fields = make(map[string]interface{})
	}
	fields["event"] = event
	fields["node"] = m.nodeID
	fields["ts"] = time.Now().UTC()
	_ = m.audit.Write(fields)
}

func bundleKids(bundle kmsproto.SigBundle) []string {
	if len(bundle) == 0 {
		return nil
	}
	kids := make([]string, 0, len(bundle))
	for _, sig := range bundle {
		kids = append(kids, sig.KeyID)
	}
	return kids
}

func durationMillis(d time.Duration) float64 {
	if d <= 0 {
		return 0
	}
	return float64(d) / float64(time.Millisecond)
}

func mergeMetadata(a, b kmsclient.Metadata) kmsclient.Metadata {
	members := b.Members
	if len(members) == 0 {
		members = a.Members
	}
	primary := b.Primary
	if primary == "" {
		primary = a.Primary
	}
	primaryIdx := b.PrimaryIndex
	if primaryIdx < 0 {
		primaryIdx = a.PrimaryIndex
	}
	if primary == "" {
		primaryIdx = -1
	}
	challengeLatency := a.ChallengeLatency
	if challengeLatency == 0 {
		challengeLatency = b.ChallengeLatency
	}
	submitLatency := a.SubmitLatency
	if submitLatency == 0 {
		submitLatency = b.SubmitLatency
	}
	return kmsclient.Metadata{
		Members:            append([]string(nil), members...),
		Primary:            primary,
		PrimaryIndex:       primaryIdx,
		FailoverCount:      a.FailoverCount + b.FailoverCount,
		Attempts:           a.Attempts + b.Attempts,
		ChallengeFailovers: a.ChallengeFailovers + b.ChallengeFailovers,
		ChallengeLatency:   challengeLatency,
		SubmitLatency:      submitLatency,
	}
}

func payloadToMaterial(payload *kmsproto.KeyMaterialPayload) (encryptor.KeyMaterial, error) {
	var mat encryptor.KeyMaterial
	if payload == nil {
		return mat, errors.New("payload is nil")
	}
	if len(payload.Key) < 40 {
		return mat, errors.New("key material too short")
	}
	mat.Version = payload.Epoch
	copy(mat.ISEKey[:], payload.Key[:8])
	copy(mat.AESKey[:], payload.Key[8:40])
	return mat, nil
}

func randomBytes(n int) []byte {
	buf := make([]byte, n)
	_, _ = rand.Read(buf)
	return buf
}
