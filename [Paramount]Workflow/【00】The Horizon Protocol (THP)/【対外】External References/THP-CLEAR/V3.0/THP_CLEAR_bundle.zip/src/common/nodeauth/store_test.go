package nodeauth

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"fmt"
	"testing"
	"time"

	"thp-clear/src/common/kmsproto"
	"thp-clear/src/kms"
)

func TestStoreBuildResponsesAndVerifyTicket(t *testing.T) {
	signers := makeSigners(t, 3)
	issuer := &testIssuer{}
	svc, err := kms.NewService(kms.Config{
		Rounds:          4,
		RealRatio:       1.0,
		Signers:         signers,
		KeyIssuer:       issuer,
		Random:          &deterministicReader{},
		Threshold:       2,
		FailureWindow:   time.Minute,
		BlockAfterFails: 2,
	})
	if err != nil {
		t.Fatalf("NewService: %v", err)
	}

	nodeID := "WN-21"
	digest := make([]byte, 32)
	if _, err := rand.Read(digest); err != nil {
		t.Fatalf("rand: %v", err)
	}
	commitID := "c-wn21"
	if err := svc.RegisterCommit(nodeID, commitID, digest); err != nil {
		t.Fatalf("RegisterCommit: %v", err)
	}

	store := NewStore(nodeID, []CommitEntry{{ID: commitID, Digest: digest}})
	store.SetRandom(&deterministicReader{})

	req := kmsproto.KeyRequest{Type: "KeyRequest", NodeID: nodeID, ReqID: "req-ok", KeyType: "ISE", Timestamp: time.Now().Unix()}
	challenges, err := svc.GenerateChallenges(context.Background(), req)
	if err != nil {
		t.Fatalf("GenerateChallenges: %v", err)
	}

	resp, session, err := store.BuildResponses(challenges)
	if err != nil {
		t.Fatalf("BuildResponses: %v", err)
	}

	result, alert, err := svc.VerifyAndIssue(context.Background(), *resp)
	if err != nil {
		t.Fatalf("VerifyAndIssue: %v", err)
	}
	if alert != nil {
		t.Fatalf("unexpected alert: %+v", alert)
	}
	if err := session.VerifyTicket(result.Ticket, result.Payload); err != nil {
		t.Fatalf("VerifyTicket: %v", err)
	}

	// Create a decoy scenario by tampering a new response.
	req2 := kmsproto.KeyRequest{Type: "KeyRequest", NodeID: nodeID, ReqID: "req-decoy", KeyType: "ISE", Timestamp: time.Now().Unix()}
	challenges2, err := svc.GenerateChallenges(context.Background(), req2)
	if err != nil {
		t.Fatalf("GenerateChallenges decoy: %v", err)
	}
	resp2, session2, err := store.BuildResponses(challenges2)
	if err != nil {
		t.Fatalf("BuildResponses decoy: %v", err)
	}
	if len(resp2.Responses) == 0 {
		t.Fatalf("expected at least one response")
	}
	resp2.Responses[0].Response = []byte("tampered")
	resp2.Responses[0].Decline = false

	result2, alert2, err := svc.VerifyAndIssue(context.Background(), *resp2)
	if err != nil {
		t.Fatalf("VerifyAndIssue decoy: %v", err)
	}
	if result2.Status != "DECOY" {
		t.Fatalf("expected decoy status, got %s", result2.Status)
	}
	if alert2 == nil {
		t.Fatalf("expected alert on decoy")
	}
	if err := session2.VerifyTicket(result2.Ticket, result2.Payload); err == nil {
		t.Fatalf("expected ticket verification to fail for decoy")
	}
}

type testIssuer struct{}

func (t *testIssuer) IssueReal(ctx context.Context, nodeID, keyType string) (*kmsproto.KeyMaterialPayload, error) {
	return &kmsproto.KeyMaterialPayload{
		Type:  keyType,
		Key:   []byte("real-material"),
		Epoch: 777,
		KeyID: fmt.Sprintf("K:%s:777", keyType),
	}, nil
}

func (t *testIssuer) IssueDecoy(ctx context.Context, nodeID, keyType string) (*kmsproto.KeyMaterialPayload, error) {
	return &kmsproto.KeyMaterialPayload{
		Type:  keyType,
		Key:   []byte("decoy"),
		Epoch: 777,
		KeyID: fmt.Sprintf("K:%s:decoy", keyType),
	}, nil
}

func makeSigners(t *testing.T, n int) []kms.Signer {
	t.Helper()
	var out []kms.Signer
	for i := 0; i < n; i++ {
		pub, priv, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			t.Fatalf("GenerateKey: %v", err)
		}
		out = append(out, &testSigner{
			id:  fmt.Sprintf("kms-%d", i),
			pub: pub,
			sk:  priv,
		})
	}
	return out
}

type testSigner struct {
	id  string
	pub ed25519.PublicKey
	sk  ed25519.PrivateKey
}

func (t *testSigner) KeyID() string                { return t.id }
func (t *testSigner) PublicKey() ed25519.PublicKey { return t.pub }
func (t *testSigner) Sign(msg []byte) ([]byte, error) {
	return ed25519.Sign(t.sk, msg), nil
}

type deterministicReader struct {
	counter byte
}

func (d *deterministicReader) Read(p []byte) (int, error) {
	for i := range p {
		p[i] = d.counter
		d.counter++
	}
	return len(p), nil
}
