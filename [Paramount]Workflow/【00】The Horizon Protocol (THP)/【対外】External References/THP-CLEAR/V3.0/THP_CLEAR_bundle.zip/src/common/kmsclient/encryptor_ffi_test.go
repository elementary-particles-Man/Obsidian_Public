package kmsclient

import (
	"bytes"
	"testing"
)

func TestRustSealAndOpenRoundTrip(t *testing.T) {
	plain := []byte("hello rust ffi")

	env, err := sealWithRust(plain, true)
	if err != nil {
		t.Fatalf("sealWithRust: %v", err)
	}

	recovered, err := openWithRust(env)
	if err != nil {
		t.Fatalf("openWithRust: %v", err)
	}
	if !bytes.Equal(plain, recovered) {
		t.Fatalf("plaintext mismatch: %q vs %q", plain, recovered)
	}
}
