package kmsproto

import (
	"crypto/ed25519"
	"crypto/rand"
	"testing"
)

func TestSigBundleVerify(t *testing.T) {
	pubKeys := make(map[string]ed25519.PublicKey)
	var bundle SigBundle
	for i := 0; i < 3; i++ {
		pub, priv, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			t.Fatalf("generate key: %v", err)
		}
		keyID := string(rune('A' + i))
		pubKeys[keyID] = pub
		sig := ed25519.Sign(priv, []byte("message"))
		bundle = append(bundle, Signature{KeyID: keyID, Sig: sig})
	}
	if err := bundle.Verify([]byte("message"), pubKeys, 2); err != nil {
		t.Fatalf("verify failed: %v", err)
	}
	if err := bundle.Verify([]byte("message"), pubKeys, 4); err == nil {
		t.Fatalf("expected failure when threshold not met")
	}
}
