package kmscrypto

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/binary"

	"thp-clear/src/common/kmsproto"
)

// ComputeHint derives the hint value embedded in each challenge round.
func ComputeHint(kind kmsproto.ChallengeKind, commit, kmsNonce, param, rndKMS []byte) []byte {
	h := hmac.New(sha256.New, commit)
	h.Write([]byte(kind))
	h.Write(kmsNonce)
	h.Write(param)
	h.Write(rndKMS)
	return h.Sum(nil)
}

// ComputeRoundMAC calculates the expected MAC for a challenge response.
func ComputeRoundMAC(kind kmsproto.ChallengeKind, commit, kmsNonce, param, rndKMS, rndNode []byte) []byte {
	h := hmac.New(sha256.New, commit)
	h.Write([]byte("round"))
	h.Write([]byte(kind))
	h.Write(kmsNonce)
	h.Write(param)
	h.Write(rndKMS)
	h.Write(rndNode)
	return h.Sum(nil)
}

// ComputeTicketMAC generates the ticket MAC for a given commit+key pair.
func ComputeTicketMAC(commit []byte, payload *kmsproto.KeyMaterialPayload, kmsNonce []byte, reqID string) []byte {
	h := hmac.New(sha256.New, commit)
	h.Write([]byte(payload.KeyID))
	h.Write(payload.Key)
	var epochBuf [8]byte
	binary.BigEndian.PutUint64(epochBuf[:], payload.Epoch)
	h.Write(epochBuf[:])
	h.Write(kmsNonce)
	h.Write([]byte(reqID))
	return h.Sum(nil)
}
