package common

import "errors"

var (
	ErrQueueFull     = errors.New("queue: over 90% - stop intake, reroute")
	ErrDiskNearFull  = errors.New("db: disk usage <5% free - intake stopped")
	ErrSigMismatch   = errors.New("mismatch: vendor signature")
	ErrEvmNotFinal   = errors.New("evm: not finalized")
	ErrIdempotentDup = errors.New("duplicate idempotency key")
)
