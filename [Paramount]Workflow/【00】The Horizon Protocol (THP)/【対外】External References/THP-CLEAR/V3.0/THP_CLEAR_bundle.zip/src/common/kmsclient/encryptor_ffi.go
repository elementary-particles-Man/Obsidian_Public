package kmsclient

/*
#cgo windows LDFLAGS: -L../../../rust/core/target/debug -l:clear_encryptor.dll.lib
#cgo !windows LDFLAGS: -L../../../rust/core/target/debug -lclear_encryptor
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

typedef struct {
    uint8_t* ptr;
    size_t len;
    size_t capacity;
} FfiVec;

typedef struct {
    uint64_t key_version;
    uint32_t seq_id;
    uint8_t order_forward;
    uint8_t order_used_forward;
    FfiVec nonce;
    FfiVec ciphertext;
    uint8_t plain_hash[32];
    uint8_t cipher_hash[32];
    FfiVec commit_signature;
    FfiVec operational_signature;
} FfiEnvelope;

bool clear_encryptor_init(void);
int clear_encryptor_seal(const uint8_t* data, size_t len, bool initial, FfiEnvelope** out_env);
void clear_encryptor_free_envelope(FfiEnvelope* env);
int clear_encryptor_open(const FfiEnvelope* env, FfiVec** out_plain);
void clear_encryptor_free_vec(FfiVec* vec);
*/
import "C"

import (
	"errors"
	"fmt"
	"sync"
	"unsafe"

	"thp-clear/src/common/crypto"
)

var (
	onceInit sync.Once
	initErr  error
	onceLoad sync.Once
	loadErr  error
)

func ensureRustEncryptor() error {
	onceLoad.Do(func() {
		loadErr = loadRustLibrary()
	})
	if loadErr != nil {
		return loadErr
	}
	onceInit.Do(func() {
		if ok := C.clear_encryptor_init(); !ok {
			initErr = errors.New("clear-encryptor: initialization failed")
		}
	})
	return initErr
}

func sealWithRust(data []byte, initial bool) (crypto.Envelope, error) {
	if err := ensureRustEncryptor(); err != nil {
		return crypto.Envelope{}, err
	}

	var envPtr *C.FfiEnvelope
	var dataPtr *C.uint8_t

	if len(data) > 0 {
		dataPtr = (*C.uint8_t)(unsafe.Pointer(&data[0]))
	}

	code := C.clear_encryptor_seal(
		dataPtr,
		C.size_t(len(data)),
		C.bool(initial),
		(**C.FfiEnvelope)(unsafe.Pointer(&envPtr)),
	)
	if code != 0 {
		return crypto.Envelope{}, fmt.Errorf("clear_encryptor_seal failed with code %d", int(code))
	}
	if envPtr == nil {
		return crypto.Envelope{}, errors.New("clear-encryptor: returned empty envelope pointer")
	}
	defer C.clear_encryptor_free_envelope(envPtr)

	env := convertEnvelope(envPtr)
	return env, nil
}

func convertEnvelope(env *C.FfiEnvelope) crypto.Envelope {
	return crypto.Envelope{
		KeyVersion:           uint64(env.key_version),
		SeqID:                uint32(env.seq_id),
		OrderForward:         env.order_forward != 0,
		OrderUsedForward:     env.order_used_forward != 0,
		Nonce:                goBytes(env.nonce),
		Ciphertext:           goBytes(env.ciphertext),
		PlainHash:            goFixedBytes((*C.uint8_t)(unsafe.Pointer(&env.plain_hash[0])), 32),
		CipherHash:           goFixedBytes((*C.uint8_t)(unsafe.Pointer(&env.cipher_hash[0])), 32),
		CommitSignature:      goBytes(env.commit_signature),
		OperationalSignature: goBytes(env.operational_signature),
	}
}

func goBytes(vec C.FfiVec) []byte {
	if vec.ptr == nil || vec.len == 0 {
		return nil
	}
	return C.GoBytes(unsafe.Pointer(vec.ptr), C.int(vec.len))
}

func goFixedBytes(ptr *C.uint8_t, length int) []byte {
	if ptr == nil || length == 0 {
		return nil
	}
	return C.GoBytes(unsafe.Pointer(ptr), C.int(length))
}

func DecryptEnvelope(env crypto.Envelope) ([]byte, error) {
	return openWithRust(env)
}

func openWithRust(env crypto.Envelope) ([]byte, error) {
	if err := ensureRustEncryptor(); err != nil {
		return nil, err
	}

	cEnv, release, err := toCEnvelope(env)
	if err != nil {
		return nil, err
	}
	defer release()

	var plainPtr *C.FfiVec
	code := C.clear_encryptor_open(
		(*C.FfiEnvelope)(unsafe.Pointer(&cEnv)),
		(**C.FfiVec)(unsafe.Pointer(&plainPtr)),
	)
	if code != 0 {
		return nil, fmt.Errorf("clear_encryptor_open failed with code %d", int(code))
	}
	if plainPtr == nil {
		return nil, errors.New("clear-encryptor: returned empty plaintext pointer")
	}
	defer C.clear_encryptor_free_vec(plainPtr)

	plain := goBytes(*plainPtr)
	return plain, nil
}

func toCEnvelope(env crypto.Envelope) (C.FfiEnvelope, func(), error) {
	cEnv := C.FfiEnvelope{
		key_version:        C.uint64_t(env.KeyVersion),
		seq_id:             C.uint32_t(env.SeqID),
		order_forward:      boolToCUint8(env.OrderForward),
		order_used_forward: boolToCUint8(env.OrderUsedForward),
	}

	var cleanups []func()
	addCleanup := func(fn func()) {
		if fn != nil {
			cleanups = append(cleanups, fn)
		}
	}

	vec, release, err := allocFfiVec(env.Nonce)
	if err != nil {
		runCleanups(cleanups)
		return C.FfiEnvelope{}, nil, err
	}
	cEnv.nonce = vec
	addCleanup(release)

	vec, release, err = allocFfiVec(env.Ciphertext)
	if err != nil {
		runCleanups(cleanups)
		return C.FfiEnvelope{}, nil, err
	}
	cEnv.ciphertext = vec
	addCleanup(release)

	vec, release, err = allocFfiVec(env.CommitSignature)
	if err != nil {
		runCleanups(cleanups)
		return C.FfiEnvelope{}, nil, err
	}
	cEnv.commit_signature = vec
	addCleanup(release)

	vec, release, err = allocFfiVec(env.OperationalSignature)
	if err != nil {
		runCleanups(cleanups)
		return C.FfiEnvelope{}, nil, err
	}
	cEnv.operational_signature = vec
	addCleanup(release)

	if err := copyIntoCArrayChecked(cEnv.plain_hash[:], env.PlainHash, 32); err != nil {
		runCleanups(cleanups)
		return C.FfiEnvelope{}, nil, err
	}
	if err := copyIntoCArrayChecked(cEnv.cipher_hash[:], env.CipherHash, 32); err != nil {
		runCleanups(cleanups)
		return C.FfiEnvelope{}, nil, err
	}

	return cEnv, func() { runCleanups(cleanups) }, nil
}

func boolToCUint8(v bool) C.uint8_t {
	if v {
		return 1
	}
	return 0
}

func copyIntoCArray(dst []C.uint8_t, src []byte) {
	if len(src) == 0 || len(dst) == 0 {
		return
	}
	n := len(src)
	if n > len(dst) {
		n = len(dst)
	}
	slice := unsafe.Slice((*byte)(unsafe.Pointer(&dst[0])), len(dst))
	copy(slice, src[:n])
	if n < len(dst) {
		for i := n; i < len(dst); i++ {
			slice[i] = 0
		}
	}
}

func copyIntoCArrayChecked(dst []C.uint8_t, src []byte, expected int) error {
	if len(src) != expected {
		return fmt.Errorf("clear-encryptor: expected %d bytes (got %d)", expected, len(src))
	}
	copyIntoCArray(dst, src)
	return nil
}

func allocFfiVec(data []byte) (C.FfiVec, func(), error) {
	if len(data) == 0 {
		return C.FfiVec{}, nil, nil
	}
	ptr := C.CBytes(data)
	if ptr == nil {
		return C.FfiVec{}, nil, errors.New("clear-encryptor: allocation failed")
	}
	vec := C.FfiVec{
		ptr:      (*C.uint8_t)(ptr),
		len:      C.size_t(len(data)),
		capacity: C.size_t(len(data)),
	}
	cleanup := func() {
		C.free(ptr)
	}
	return vec, cleanup, nil
}

func runCleanups(cleanups []func()) {
	for i := len(cleanups) - 1; i >= 0; i-- {
		cleanups[i]()
	}
}
