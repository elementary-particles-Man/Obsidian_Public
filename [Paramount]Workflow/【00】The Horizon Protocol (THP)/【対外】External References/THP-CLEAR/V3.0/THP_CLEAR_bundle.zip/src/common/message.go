package common

type UseTag string

const (
	UseTagF UseTag = "F"
	UseTagM UseTag = "M"
	UseTagE UseTag = "E"
)

type TransferMsg struct {
	RailID         string `json:"rail_id"`
	ChainID        int64  `json:"chain_id"`
	Contract       string `json:"contract"`
	TxHash         string `json:"tx_hash"`
	BlockNum       uint64 `json:"block"`
	From           string `json:"from"`
	To             string `json:"to"`
	Amount         string `json:"amount"`
	UseTag         UseTag `json:"use_tag"`
	VendorSig      string `json:"vendor_sig"`
	SeenAtUnix     int64  `json:"seen_at_unix"`
	IdempotencyKey string `json:"idempotency_key"`
}
