//go:build windows

package kmsclient

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
)

var loadedRustDLL *syscall.DLL

func loadRustLibrary() error {
	if loadedRustDLL != nil {
		return nil
	}

	if path, err := resolveRustDLLPath(); err == nil {
		dll, err := syscall.LoadDLL(path)
		if err != nil {
			return fmt.Errorf("clear-encryptor: load dll %q: %w", path, err)
		}
		loadedRustDLL = dll
		return nil
	}

	dll, err := syscall.LoadDLL("clear_encryptor.dll")
	if err != nil {
		return fmt.Errorf("clear-encryptor: load dll via system search path: %w", err)
	}
	loadedRustDLL = dll
	return nil
}

func resolveRustDLLPath() (string, error) {
	if hint, ok := os.LookupEnv("CLEAR_ENCRYPTOR_DLL"); ok && hint != "" {
		if _, err := os.Stat(hint); err == nil {
			return hint, nil
		} else {
			return "", fmt.Errorf("clear-encryptor: CLEAR_ENCRYPTOR_DLL=%q invalid: %w", hint, err)
		}
	}

	_, file, _, ok := runtime.Caller(0)
	if !ok {
		return "", errors.New("clear-encryptor: cannot resolve caller path")
	}

	base := filepath.Dir(file)
	root := filepath.Clean(filepath.Join(base, "..", "..", ".."))

	candidates := []string{
		filepath.Join(root, "rust", "core", "target", "debug", "clear_encryptor.dll"),
		filepath.Join(root, "rust", "core", "target", "release", "clear_encryptor.dll"),
	}

	for _, candidate := range candidates {
		if _, err := os.Stat(candidate); err == nil {
			return candidate, nil
		}
	}

	return "", fmt.Errorf(
		"clear-encryptor: dll not found (checked %s)",
		strings.Join(candidates, ", "),
	)
}
