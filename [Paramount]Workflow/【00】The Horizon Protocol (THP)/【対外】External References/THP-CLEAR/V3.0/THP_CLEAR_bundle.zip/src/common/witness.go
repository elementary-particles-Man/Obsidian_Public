package common

type WitnessRecord struct {
	RailID     string `json:"rail_id"`
	TxHash     string `json:"tx_hash"`
	BlockNum   uint64 `json:"block"`
	Amount     string `json:"amount"`
	UseTag     UseTag `json:"use_tag"`
	From       string `json:"from"`
	To         string `json:"to"`
	VendorSig  string `json:"vendor_sig"`
	EvmProofOK bool   `json:"evm_proof_ok"`
	SigOK      bool   `json:"sig_ok"`
	ISESig     string `json:"ise_sig"`
	CreatedAt  int64  `json:"created_at_unix"`
}
