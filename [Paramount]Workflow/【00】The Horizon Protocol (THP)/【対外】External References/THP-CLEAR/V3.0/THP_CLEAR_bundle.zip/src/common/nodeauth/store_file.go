package nodeauth

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"os"
)

// CommitFile represents the persisted register store.
type CommitFile struct {
	NodeID  string          `json:"node_id"`
	Commits []CommitPayload `json:"commits"`
}

// CommitPayload mirrors the on-disk entry.
type CommitPayload struct {
	ID     string `json:"id"`
	Digest string `json:"digest"`
}

// LoadCommitFile loads commit entries from disk.
func LoadCommitFile(path string) (string, []CommitEntry, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", nil, err
	}
	var file CommitFile
	if err := json.Unmarshal(data, &file); err != nil {
		return "", nil, err
	}
	if file.NodeID == "" {
		return "", nil, errors.New("node_id missing in commit file")
	}
	entries := make([]CommitEntry, 0, len(file.Commits))
	for _, c := range file.Commits {
		if c.ID == "" || c.Digest == "" {
			return "", nil, errors.New("invalid commit entry")
		}
		digest, err := base64.StdEncoding.DecodeString(c.Digest)
		if err != nil {
			return "", nil, err
		}
		entries = append(entries, CommitEntry{ID: c.ID, Digest: digest})
	}
	return file.NodeID, entries, nil
}
