package crypto

// Envelope は Rust 実装の clear-encryptor が生成するメタデータを保持します。
// ISE → gzip → AES-GCM で暗号化された結果に加え、整合性検証用ハッシュと署名を含みます。
type Envelope struct {
	// KeyVersion は使用した鍵バージョンです。
	KeyVersion uint64 `json:"key_version"`

	// SeqID は ISE から決定されるシーケンス ID。
	SeqID uint32 `json:"seq_id"`

	// OrderForward / OrderUsedForward は ISE の順方向フラグと実際に使用したオーダー情報。
	OrderForward     bool `json:"order_forward"`
	OrderUsedForward bool `json:"order_used_forward"`

	// Nonce は AES-GCM で使用する 12byte の IV。
	Nonce []byte `json:"nonce"`

	// Ciphertext は ISE + gzip 後のデータを AES-GCM で暗号化した結果です。
	Ciphertext []byte `json:"ciphertext"`

	// PlainHash / CipherHash は平文・暗号文の SHA-256。
	PlainHash  []byte `json:"plain_hash"`
	CipherHash []byte `json:"cipher_hash"`

	// CommitSignature / OperationalSignature は HMAC-SHA256 による署名。
	CommitSignature      []byte `json:"commit_signature"`
	OperationalSignature []byte `json:"operational_signature"`
}
