package kmsclient

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"thp-clear/src/common/kmsproto"
)

const defaultMultiTimeout = 2 * time.Second

// Hooks allows callers to wire metrics around multi-endpoint behaviour.
type Hooks struct {
	IncInflight             func()
	DecInflight             func()
	RecordChallengeFailover func()
	RecordSubmitRetry       func()
	RecordQuorumMet         func()
	RecordQuorumFail        func()
	SetSessionsInUse        func(int)
}

// MultiOption customises multiClient behaviour.
type MultiOption func(*multiClient)

// WithHTTPClient overrides the HTTP client used for outbound requests.
func WithHTTPClient(httpClient *http.Client) MultiOption {
	return func(m *multiClient) {
		m.http = httpClient
	}
}

// WithHooks wires optional metrics hooks.
func WithHooks(h Hooks) MultiOption {
	return func(m *multiClient) {
		m.hooks = h
	}
}

// WithRequestTimeout overrides the default per-request timeout.
func WithRequestTimeout(d time.Duration) MultiOption {
	return func(m *multiClient) {
		m.timeout = d
	}
}

// WithSessionTTL overrides the default session time-to-live for pending submissions.
func WithSessionTTL(d time.Duration) MultiOption {
	return func(m *multiClient) {
		m.sessionTTL = d
	}
}

// WithMaxSessions caps the number of pending sessions tracked before evicting.
func WithMaxSessions(n int) MultiOption {
	return func(m *multiClient) {
		m.maxSessions = n
	}
}

// NewMulti creates a client that queries multiple KMS endpoints and waits for quorum responses.
func NewMulti(urls []string, quorum int, opts ...MultiOption) Client {
	mc := &multiClient{
		urls:        dedupe(urls),
		quorum:      quorum,
		timeout:     defaultMultiTimeout,
		sessionTTL:  30 * time.Second,
		maxSessions: 1024,
		sessions:    make(map[string]sessionRecord),
	}
	for _, opt := range opts {
		opt(mc)
	}
	if len(mc.urls) == 0 {
		panic("kmsclient: urls must not be empty")
	}
	if mc.quorum <= 0 {
		mc.quorum = 2
	}
	if mc.quorum > len(mc.urls) {
		mc.quorum = len(mc.urls)
	}
	if mc.http == nil {
		mc.http = &http.Client{Timeout: mc.timeout}
	} else if mc.timeout > 0 {
		mc.http.Timeout = mc.timeout
	}
	return mc
}

type multiClient struct {
	urls        []string
	quorum      int
	http        *http.Client
	hooks       Hooks
	timeout     time.Duration
	rr          uint32
	sessionTTL  time.Duration
	maxSessions int

	sessMu   sync.Mutex
	sessions map[string]sessionRecord
}

type sessionInfo struct {
	idx int
	url string
}

type sessionRecord struct {
	info             sessionInfo
	created          time.Time
	challengeLatency time.Duration
	failovers        int
}

func (m *multiClient) RequestChallenges(ctx context.Context, req kmsproto.KeyRequest) (*kmsproto.ChallengeSet, Metadata, error) {
	raw, meta, err := m.requestChallenge(ctx, req)
	if err != nil {
		return nil, meta, err
	}
	var out kmsproto.ChallengeSet
	if err := json.Unmarshal(raw, &out); err != nil {
		return nil, meta, err
	}
	return &out, meta, nil
}

func (m *multiClient) SubmitResponses(ctx context.Context, resp kmsproto.ChallengeResponse) (*kmsproto.KeyResult, Metadata, error) {
	raw, meta, err := m.submitResponse(ctx, resp)
	if err != nil {
		return nil, meta, err
	}
	var out kmsproto.KeyResult
	if err := json.Unmarshal(raw, &out); err != nil {
		return nil, meta, err
	}
	return &out, meta, nil
}

func (m *multiClient) requestChallenge(ctx context.Context, req kmsproto.KeyRequest) ([]byte, Metadata, error) {
	body, err := json.Marshal(req)
	if err != nil {
		return nil, Metadata{}, err
	}
	startTime := time.Now()
	failures := 0
	start := int(atomic.AddUint32(&m.rr, 1)) % len(m.urls)
	var selected sessionInfo
	var payload []byte
	for attempt := 0; attempt < len(m.urls); attempt++ {
		idx := (start + attempt) % len(m.urls)
		url := m.urls[idx]
		if m.hooks.IncInflight != nil {
			m.hooks.IncInflight()
		}
		payload, err = m.issueOnce(ctx, url, "/keys/request", body)
		if m.hooks.DecInflight != nil {
			m.hooks.DecInflight()
		}
		if err != nil {
			failures++
			if m.hooks.RecordChallengeFailover != nil {
				m.hooks.RecordChallengeFailover()
			}
			continue
		}
		selected = sessionInfo{idx: idx, url: url}
		break
	}

	if payload == nil {
		if m.hooks.RecordQuorumFail != nil {
			m.hooks.RecordQuorumFail()
		}
		return nil, Metadata{
			FailoverCount:      failures,
			Attempts:           failures,
			ChallengeFailovers: failures,
		}, fmt.Errorf("kms quorum not met: success=0 fail=%d need=1", failures)
	}

	chLatency := time.Since(startTime)
	m.storeSession(req.ReqID, selected, chLatency, failures)
	if m.hooks.RecordQuorumMet != nil {
		m.hooks.RecordQuorumMet()
	}
	meta := Metadata{
		Members:            []string{selected.url},
		Primary:            selected.url,
		PrimaryIndex:       selected.idx,
		FailoverCount:      failures,
		Attempts:           failures + 1,
		ChallengeFailovers: failures,
		ChallengeLatency:   chLatency,
	}
	return payload, meta, nil
}

func (m *multiClient) submitResponse(ctx context.Context, resp kmsproto.ChallengeResponse) ([]byte, Metadata, error) {
	rec, ok := m.loadSession(resp.ReqID)
	if !ok {
		if m.hooks.RecordSubmitRetry != nil {
			m.hooks.RecordSubmitRetry()
		}
		return nil, Metadata{Attempts: 1}, errors.New("kmsclient: session not found or expired for request")
	}
	info := rec.info
	body, err := json.Marshal(resp)
	if err != nil {
		return nil, Metadata{}, err
	}
	start := time.Now()
	if m.hooks.IncInflight != nil {
		m.hooks.IncInflight()
	}
	payload, err := m.issueOnce(ctx, info.url, "/keys/respond", body)
	if m.hooks.DecInflight != nil {
		m.hooks.DecInflight()
	}
	meta := Metadata{
		Members:            []string{info.url},
		Primary:            info.url,
		PrimaryIndex:       info.idx,
		FailoverCount:      0,
		Attempts:           1,
		ChallengeLatency:   rec.challengeLatency,
		SubmitLatency:      time.Since(start),
		ChallengeFailovers: rec.failovers, // need field
	}
	if err != nil {
		if m.hooks.RecordSubmitRetry != nil {
			m.hooks.RecordSubmitRetry()
		}
		return nil, meta, err
	}
	return payload, meta, nil
}

func (m *multiClient) issueOnce(ctx context.Context, url, path string, body []byte) ([]byte, error) {
	var cancel func()
	reqCtx := ctx
	if m.timeout > 0 {
		reqCtx, cancel = context.WithTimeout(ctx, m.timeout)
		defer cancel()
	}
	req, err := http.NewRequestWithContext(reqCtx, http.MethodPost, url+path, bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	resp, err := m.http.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	payload, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("kms error: %s", bytes.TrimSpace(payload))
	}
	return payload, nil
}

func (m *multiClient) storeSession(id string, info sessionInfo, latency time.Duration, failovers int) {
	if id == "" {
		return
	}
	now := time.Now()
	m.sessMu.Lock()
	defer m.sessMu.Unlock()
	m.pruneSessionsLocked(now)
	if m.maxSessions > 0 && len(m.sessions) >= m.maxSessions {
		m.evictOldestLocked()
	}
	m.sessions[id] = sessionRecord{info: info, created: now, challengeLatency: latency, failovers: failovers}
	m.updateSessionGaugeLocked()
}

func (m *multiClient) loadSession(id string) (sessionRecord, bool) {
	if id == "" {
		return sessionRecord{}, false
	}
	now := time.Now()
	m.sessMu.Lock()
	defer m.sessMu.Unlock()
	m.pruneSessionsLocked(now)
	rec, ok := m.sessions[id]
	if !ok {
		m.updateSessionGaugeLocked()
		return sessionRecord{}, false
	}
	if m.sessionTTL > 0 && now.Sub(rec.created) > m.sessionTTL {
		delete(m.sessions, id)
		m.updateSessionGaugeLocked()
		return sessionRecord{}, false
	}
	delete(m.sessions, id)
	m.updateSessionGaugeLocked()
	return rec, true
}

func (m *multiClient) pruneSessionsLocked(now time.Time) {
	if m.sessionTTL <= 0 {
		return
	}
	cutoff := now.Add(-m.sessionTTL)
	for id, rec := range m.sessions {
		if rec.created.Before(cutoff) {
			delete(m.sessions, id)
		}
	}
}

func (m *multiClient) evictOldestLocked() {
	var oldestKey string
	var oldestTime time.Time
	first := true
	for id, rec := range m.sessions {
		if first || rec.created.Before(oldestTime) {
			first = false
			oldestKey = id
			oldestTime = rec.created
		}
	}
	if oldestKey != "" {
		delete(m.sessions, oldestKey)
	}
}

func (m *multiClient) updateSessionGaugeLocked() {
	if m.hooks.SetSessionsInUse != nil {
		m.hooks.SetSessionsInUse(len(m.sessions))
	}
}

func (m *multiClient) Close() error { return nil }

func dedupe(in []string) []string {
	seen := make(map[string]struct{}, len(in))
	out := make([]string, 0, len(in))
	for _, raw := range in {
		trimmed := strings.TrimSuffix(strings.TrimSpace(raw), "/")
		if trimmed == "" {
			continue
		}
		if _, ok := seen[trimmed]; ok {
			continue
		}
		seen[trimmed] = struct{}{}
		out = append(out, trimmed)
	}
	return out
}
