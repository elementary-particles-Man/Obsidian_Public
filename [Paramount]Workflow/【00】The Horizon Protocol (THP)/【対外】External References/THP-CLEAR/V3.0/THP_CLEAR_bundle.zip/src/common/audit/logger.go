package audit

import (
	"encoding/json"
	"errors"
	"os"
	"sync"
)

type JSONL struct {
	mu   sync.Mutex
	file *os.File
	enc  *json.Encoder
}

func NewJSONL(path string) (*JSONL, error) {
	if path == "" {
		return nil, errors.New("audit: path is required")
	}
	file, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o600)
	if err != nil {
		return nil, err
	}
	if err := os.Chmod(path, 0o600); err != nil {
		file.Close()
		return nil, err
	}
	return &JSONL{file: file, enc: json.NewEncoder(file)}, nil
}

func (l *JSONL) Write(entry interface{}) error {
	if l == nil {
		return errors.New("audit: logger is nil")
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	if err := l.enc.Encode(entry); err != nil {
		return err
	}
	return nil
}

func (l *JSONL) Close() error {
	if l == nil {
		return nil
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.file.Close()
}
