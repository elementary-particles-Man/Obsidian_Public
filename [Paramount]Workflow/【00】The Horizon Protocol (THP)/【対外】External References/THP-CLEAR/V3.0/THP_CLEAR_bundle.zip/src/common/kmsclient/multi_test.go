package kmsclient

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"
	"time"

	"thp-clear/src/common/kmsproto"
)

func TestMultiClientChallengeFailoverAndSessionAffinity(t *testing.T) {
	var challengeHits int32
	var submitHits int32

	failServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		atomic.AddInt32(&challengeHits, 1)
		w.WriteHeader(http.StatusInternalServerError)
	}))
	defer failServer.Close()

	successServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/keys/request":
			var req kmsproto.KeyRequest
			if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
				t.Fatalf("decode request: %v", err)
			}
			atomic.AddInt32(&challengeHits, 1)
			resp := kmsproto.ChallengeSet{Type: "Challenges", ReqID: req.ReqID, NodeID: req.NodeID}
			w.Header().Set("Content-Type", "application/json")
			if err := json.NewEncoder(w).Encode(resp); err != nil {
				t.Fatalf("encode challenge: %v", err)
			}
		case "/keys/respond":
			atomic.AddInt32(&submitHits, 1)
			res := kmsproto.KeyResult{Status: "OK"}
			w.Header().Set("Content-Type", "application/json")
			if err := json.NewEncoder(w).Encode(res); err != nil {
				t.Fatalf("encode result: %v", err)
			}
		default:
			w.WriteHeader(http.StatusNotFound)
		}
	}))
	defer successServer.Close()

	client := NewMulti([]string{failServer.URL, successServer.URL}, 1, WithRequestTimeout(500*time.Millisecond))
	if mc, ok := client.(*multiClient); ok {
		atomic.StoreUint32(&mc.rr, uint32(len(mc.urls)-1))
	}

	req := kmsproto.KeyRequest{ReqID: "req-1", NodeID: "node-1", KeyType: "transport"}
	challenge, meta, err := client.RequestChallenges(context.Background(), req)
	if err != nil {
		t.Fatalf("RequestChallenges error: %v", err)
	}
	if meta.Primary != successServer.URL {
		t.Fatalf("expected primary %s, got %s", successServer.URL, meta.Primary)
	}
	if meta.ChallengeFailovers != 1 {
		t.Fatalf("expected 1 challenge failover, got %d", meta.ChallengeFailovers)
	}
	if challenge == nil || challenge.ReqID != req.ReqID {
		t.Fatalf("unexpected challenge payload: %+v", challenge)
	}

	resp := kmsproto.ChallengeResponse{ReqID: req.ReqID, NodeID: req.NodeID}
	result, submitMeta, err := client.SubmitResponses(context.Background(), resp)
	if err != nil {
		t.Fatalf("SubmitResponses error: %v", err)
	}
	if result == nil || result.Status != "OK" {
		t.Fatalf("unexpected key result: %+v", result)
	}
	if submitMeta.Primary != successServer.URL {
		t.Fatalf("submit used wrong endpoint: %s", submitMeta.Primary)
	}
	if submitMeta.ChallengeFailovers != meta.ChallengeFailovers {
		t.Fatalf("challenge failover count mismatch: have %d want %d", submitMeta.ChallengeFailovers, meta.ChallengeFailovers)
	}
	if atomic.LoadInt32(&submitHits) != 1 {
		t.Fatalf("expected submit to hit success server once, got %d", atomic.LoadInt32(&submitHits))
	}
}

func TestMultiClientSessionTTLExpiry(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/keys/request":
			var req kmsproto.KeyRequest
			if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
				t.Fatalf("decode request: %v", err)
			}
			resp := kmsproto.ChallengeSet{Type: "Challenges", ReqID: req.ReqID, NodeID: req.NodeID}
			w.Header().Set("Content-Type", "application/json")
			if err := json.NewEncoder(w).Encode(resp); err != nil {
				t.Fatalf("encode challenge: %v", err)
			}
		case "/keys/respond":
			res := kmsproto.KeyResult{Status: "OK"}
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(res)
		default:
			w.WriteHeader(http.StatusNotFound)
		}
	}))
	defer server.Close()

	client := NewMulti([]string{server.URL}, 1, WithSessionTTL(5*time.Millisecond))
	req := kmsproto.KeyRequest{ReqID: "req-ttl", NodeID: "node"}
	if _, _, err := client.RequestChallenges(context.Background(), req); err != nil {
		t.Fatalf("RequestChallenges error: %v", err)
	}
	time.Sleep(20 * time.Millisecond)
	_, meta, err := client.SubmitResponses(context.Background(), kmsproto.ChallengeResponse{ReqID: req.ReqID})
	if err == nil {
		t.Fatalf("expected session expiry error")
	}
	if meta.Attempts != 1 {
		t.Fatalf("expected attempts 1 on expiry, got %d", meta.Attempts)
	}
}
