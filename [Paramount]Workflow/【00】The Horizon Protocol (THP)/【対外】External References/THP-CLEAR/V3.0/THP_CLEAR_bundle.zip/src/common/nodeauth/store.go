package nodeauth

import (
	"crypto/hmac"
	"crypto/rand"
	"errors"
	"io"

	"thp-clear/src/common/kmscrypto"
	"thp-clear/src/common/kmsproto"
)

// CommitEntry represents locally stored commitment information.
type CommitEntry struct {
	ID     string
	Digest []byte
}

// Store keeps node specific commitments for answering challenges.
type Store struct {
	NodeID  string
	commits map[string][]byte
	rand    io.Reader
}

// NewStore builds a store from the provided commit entries.
func NewStore(nodeID string, entries []CommitEntry) *Store {
	st := &Store{
		NodeID:  nodeID,
		commits: make(map[string][]byte),
		rand:    rand.Reader,
	}
	for _, entry := range entries {
		st.AddCommit(entry)
	}
	return st
}

// SetRandom allows overriding the randomness source (useful for tests).
func (s *Store) SetRandom(r io.Reader) {
	if r != nil {
		s.rand = r
	}
}

// AddCommit registers a new commit entry in the store.
func (s *Store) AddCommit(entry CommitEntry) {
	cp := append([]byte(nil), entry.Digest...)
	s.commits[entry.ID] = cp
}

// Session captures state for a single challenge/response exchange.
type Session struct {
	store      *Store
	reqID      string
	kmsNonce   []byte
	usedCommit map[string]struct{}
}

// BuildResponses processes the challenge set and produces responses alongside a session handle.
func (s *Store) BuildResponses(challenge *kmsproto.ChallengeSet) (*kmsproto.ChallengeResponse, *Session, error) {
	if challenge == nil {
		return nil, nil, errors.New("challenge is nil")
	}
	session := &Session{
		store:      s,
		reqID:      challenge.ReqID,
		kmsNonce:   append([]byte(nil), challenge.KMSNonce...),
		usedCommit: make(map[string]struct{}),
	}

	resp := &kmsproto.ChallengeResponse{
		Type:   "Responses",
		ReqID:  challenge.ReqID,
		NodeID: s.NodeID,
	}

	for _, round := range challenge.Rounds {
		digest, ok := s.commits[round.CommitID]
		if !ok {
			resp.Responses = append(resp.Responses, kmsproto.RoundResponse{
				ID:      round.ID,
				Decline: true,
			})
			continue
		}

		rndNode := make([]byte, 16)
		if _, err := io.ReadFull(s.rand, rndNode); err != nil {
			return nil, nil, err
		}

		response := kmscrypto.ComputeRoundMAC(round.Kind, digest, challenge.KMSNonce, round.Param, round.RndKMS, rndNode)
		resp.Responses = append(resp.Responses, kmsproto.RoundResponse{
			ID:       round.ID,
			Response: response,
			RndNode:  rndNode,
		})
		session.usedCommit[round.CommitID] = struct{}{}
	}

	return resp, session, nil
}

// VerifyTicket checks the returned KeyTicket against the stored commitments.
func (s *Session) VerifyTicket(ticket *kmsproto.KeyTicket, payload *kmsproto.KeyMaterialPayload) error {
	if s == nil {
		return errors.New("session is nil")
	}
	if ticket == nil {
		return errors.New("ticket is nil")
	}
	if payload == nil {
		return errors.New("payload is nil")
	}
	if ticket.ReqID != s.reqID {
		return errors.New("ticket req_id mismatch")
	}
	if len(ticket.CommitIDs) != len(ticket.ExpectedMACs) {
		return errors.New("ticket mac length mismatch")
	}

	for i, commitID := range ticket.CommitIDs {
		digest, ok := s.store.commits[commitID]
		if !ok {
			return errors.New("missing commit for ticket verification")
		}
		expected := kmscrypto.ComputeTicketMAC(digest, payload, s.kmsNonce, s.reqID)
		if !hmac.Equal(expected, ticket.ExpectedMACs[i]) {
			return errors.New("ticket mac mismatch")
		}
	}
	return nil
}
