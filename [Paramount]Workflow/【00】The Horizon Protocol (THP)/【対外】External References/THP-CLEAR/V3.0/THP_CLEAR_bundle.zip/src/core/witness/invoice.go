package witness

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"time"
)

// Invoice represents a tax invoice emitted during the CLEAR-TAX workflow.
type Invoice struct {
	ID          string    `json:"invoice_id"`
	VendorID    string    `json:"vendor_id"`
	VendorName  string    `json:"vendor_name"`
	Amount      float64   `json:"amount"`
	Tax         float64   `json:"tax"`
	Total       float64   `json:"total"`
	GeneratedAt time.Time `json:"generated_at"`
	Signature   string    `json:"signature"`
}

// NewInvoice constructs a new invoice with a deterministic ID.
func NewInvoice(vendorID, vendorName string, amount, tax, total float64) Invoice {
	ts := time.Now().UTC()
	return Invoice{
		ID:          fmt.Sprintf("INV_%s_%s", ts.Format("20060102T150405Z"), vendorID),
		VendorID:    vendorID,
		VendorName:  vendorName,
		Amount:      amount,
		Tax:         tax,
		Total:       total,
		GeneratedAt: ts,
	}
}

// Save persists the invoice as JSON and appends an entry to the witness log.
func Save(inv Invoice) error {
	invoiceDir := filepath.Join("witness", "invoice")
	logDir := filepath.Join("witness", "logs")

	if err := os.MkdirAll(invoiceDir, 0o755); err != nil {
		return fmt.Errorf("create invoice dir: %w", err)
	}
	if err := os.MkdirAll(logDir, 0o755); err != nil {
		return fmt.Errorf("create witness log dir: %w", err)
	}

	inv.Signature = signInvoice(inv)

	payload, err := json.MarshalIndent(inv, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal invoice: %w", err)
	}

	invoicePath := filepath.Join(invoiceDir, inv.ID+".json")
	if err := os.WriteFile(invoicePath, payload, 0o644); err != nil {
		return fmt.Errorf("write invoice: %w", err)
	}

	logLine := fmt.Sprintf("%s %s %.2f %.2f %.2f %s\n", inv.ID, inv.VendorID, inv.Amount, inv.Tax, inv.Total, inv.Signature)
	logPath := filepath.Join(logDir, fmt.Sprintf("witness_%s.log", inv.GeneratedAt.Format("20060102")))
	f, err := os.OpenFile(logPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
	if err != nil {
		return fmt.Errorf("open witness log: %w", err)
	}
	defer f.Close()

	if _, err := f.WriteString(logLine); err != nil {
		return fmt.Errorf("append witness log: %w", err)
	}

	return nil
}

func signInvoice(inv Invoice) string {
	data := fmt.Sprintf("%s|%s|%s|%.2f|%.2f|%.2f|%s",
		inv.ID, inv.VendorID, inv.VendorName, inv.Amount, inv.Tax, inv.Total, inv.GeneratedAt.Format(time.RFC3339Nano))
	sum := sha256.Sum256([]byte(data))
	return hex.EncodeToString(sum[:])
}
