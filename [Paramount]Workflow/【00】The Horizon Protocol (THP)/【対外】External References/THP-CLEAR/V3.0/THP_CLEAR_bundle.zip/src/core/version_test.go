package core

import "testing"

func TestRustVersion(t *testing.T) {
	v := RustVersion()
	if v == "" {
		t.Fatalf("RustVersion returned empty string")
	}
	t.Logf("Rust core version: %s", v)
}

func TestEMADandWitness(t *testing.T) {
	score := ComputeEMAD([]float64{1.0, 1.0, 1.0})
	if score < 0.99 {
		t.Fatalf("Unexpected EMAD score: %f", score)
	}
	sig := GenerateWitnessSignature("sample")
	if len(sig) < 10 {
		t.Fatalf("Witness signature too short: %s", sig)
	}
	t.Logf("Witness signature: %s", sig)
}
