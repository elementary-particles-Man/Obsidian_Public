package taxcalc

import "math"

// Compute returns the tax amount and grand total for a given tax rate (percentage or ratio).
// The rate can be specified either as a whole number percentage (e.g. 10 for 10%) or as a
// fractional value (e.g. 0.10). Amounts are rounded to the nearest cent.
func Compute(rate, amount float64) (tax float64, total float64) {
	if amount < 0 {
		return 0, 0
	}
	r := rate
	if r > 1 {
		r = r / 100.0
	}

	tax = roundToCents(amount * r)
	total = roundToCents(amount + tax)
	return tax, total
}

func roundToCents(value float64) float64 {
	return math.Round(value*100) / 100
}
