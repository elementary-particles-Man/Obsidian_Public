package core

// #cgo LDFLAGS: -L../../rust/core/target/debug -lcore_runtime
// #include <stdint.h>
// #include <stdlib.h>
// const char* rust_get_version();
import "C"

func RustVersion() string {
	return C.GoString(C.rust_get_version())
}
