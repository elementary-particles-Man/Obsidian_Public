package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"time"

	"thp-clear/src/core/taxcalc"
	"thp-clear/src/core/witness"
)

type vendor struct {
	ID          string  `json:"id"`
	VendorID    string  `json:"vendor_id"`
	DisplayName string  `json:"display_name"`
	Name        string  `json:"name"`
	Category    string  `json:"category"`
	TaxRate     float64 `json:"tax_rate"`
}

type transaction struct {
	CaseID    string          `json:"case_id"`
	VendorID  string          `json:"vendor_id"`
	AmountRaw json.RawMessage `json:"amount"`
	Type      string          `json:"type"`
}

type combinedPayload struct {
	Vendors      []vendor      `json:"vendors"`
	Transactions []transaction `json:"transactions"`
}

func main() {
	inputPath := flag.String("input", "./tests/data/dummy_tax.json", "path to transactions JSON")
	vendorsPath := flag.String("vendors", "", "optional vendors JSON path")
	expectedPath := flag.String("expected", "", "optional expected outputs path")
	outPath := flag.String("out", "./tests/output/systemtest_witness.log", "aggregated log output")
	flag.Parse()

	vendors, transactions, err := loadData(*inputPath, *vendorsPath)
	if err != nil {
		panic(err)
	}

	vendorMap := indexVendors(vendors)

	if err := os.MkdirAll(filepath.Dir(*outPath), 0o755); err != nil {
		panic(err)
	}
	outFile, err := os.OpenFile(*outPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
	if err != nil {
		panic(err)
	}
	defer outFile.Close()

	for _, tx := range transactions {
		v, ok := vendorMap[tx.VendorID]
		if !ok {
			logLine(outFile, "ERR_COIN_NOT_FOUND", tx.CaseID, tx.VendorID, 0, 0, 0)
			continue
		}

		amount, err := parseAmount(tx.AmountRaw)
		if err != nil {
			logLine(outFile, "ERR_INVALID_FORMAT", tx.CaseID, tx.VendorID, 0, 0, 0)
			continue
		}
		if amount < 0 {
			logLine(outFile, "ERR_INVALID_AMOUNT", tx.CaseID, tx.VendorID, amount, 0, 0)
			continue
		}

		tax, total := taxcalc.Compute(v.TaxRate, amount)
		vendorID := v.ID
		if vendorID == "" {
			vendorID = v.VendorID
		}
		invoice := witness.NewInvoice(vendorID, v.Name, amount, tax, total)
		if err := witness.Save(invoice); err != nil {
			logLine(outFile, "ERR_WITNESS_SAVE", tx.CaseID, tx.VendorID, amount, tax, total)
			continue
		}

		line := fmt.Sprintf("Processed %s (%s): amount %.2f, tax %.2f, total %.2f", invoice.VendorName, v.Category, amount, tax, total)
		fmt.Fprintln(os.Stdout, line)
		fmt.Fprintln(outFile, line)
	}

	if *expectedPath != "" {
		fmt.Fprintf(outFile, "Expected outputs reference: %s\n", *expectedPath)
	}
}

func loadData(inputPath, vendorsPath string) ([]vendor, []transaction, error) {
	data, err := os.ReadFile(inputPath)
	if err != nil {
		return nil, nil, err
	}

	var payload combinedPayload
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	if err := dec.Decode(&payload); err != nil {
		return nil, nil, err
	}

	vendors := payload.Vendors
	if len(vendors) == 0 && vendorsPath != "" {
		v, err := loadVendorsFile(vendorsPath)
		if err != nil {
			return nil, nil, err
		}
		vendors = v
	}

	return vendors, payload.Transactions, nil
}

func loadVendorsFile(path string) ([]vendor, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	var wrapper combinedPayload
	if err := json.Unmarshal(data, &wrapper); err == nil && len(wrapper.Vendors) > 0 {
		return wrapper.Vendors, nil
	}

	var list []vendor
	if err := json.Unmarshal(data, &list); err != nil {
		return nil, err
	}
	return list, nil
}

func indexVendors(vs []vendor) map[string]vendor {
	index := make(map[string]vendor, len(vs))
	for _, v := range vs {
		if v.Name == "" && v.DisplayName != "" {
			v.Name = v.DisplayName
		}
		id := v.ID
		if id == "" {
			id = v.VendorID
		}
		if id == "" {
			continue
		}
		index[id] = v
	}
	return index
}

func parseAmount(raw json.RawMessage) (float64, error) {
	if raw == nil {
		return 0, errors.New("missing amount")
	}

	var f float64
	if err := json.Unmarshal(raw, &f); err == nil {
		return f, nil
	}

	var s string
	if err := json.Unmarshal(raw, &s); err == nil {
		return strconv.ParseFloat(s, 64)
	}

	return 0, errors.New("unsupported amount format")
}

func logLine(w io.Writer, code string, caseID string, vendorID string, amount, tax, total float64) {
	timestamp := time.Now().UTC().Format(time.RFC3339)
	fmt.Fprintf(w, "%s %s case=%s vendor=%s amount=%.2f tax=%.2f total=%.2f\n", timestamp, code, caseID, vendorID, amount, tax, total)
}
