package core

/*
#cgo LDFLAGS: -L../../rust/core/target/debug -lcore_runtime
#include <stdint.h>
#include <stdlib.h>
const char* rust_generate_witness_signature(const char* data);
double rust_compute_emad_score(const double* ptr, uintptr_t len);
void rust_string_free(char* ptr);
*/
import "C"
import "unsafe"

// GenerateWitnessSignature wraps the Rust witness signature generator.
func GenerateWitnessSignature(data string) string {
	cdata := C.CString(data)
	defer C.free(unsafe.Pointer(cdata))

	ptr := C.rust_generate_witness_signature(cdata)
	if ptr == nil {
		return ""
	}
	defer C.rust_string_free(ptr)
	return C.GoString(ptr)
}

// ComputeEMAD calls into Rust to compute the EMAD score.
func ComputeEMAD(inputs []float64) float64 {
	if len(inputs) == 0 {
		return 0
	}
	return float64(C.rust_compute_emad_score(
		(*C.double)(unsafe.Pointer(&inputs[0])),
		C.uintptr_t(len(inputs)),
	))
}
