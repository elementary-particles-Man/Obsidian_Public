package kms

import (
	"sync"
	"time"

	"golang.org/x/time/rate"
)

type RateLimiter struct {
	mu         sync.Mutex
	limit      rate.Limit
	burst      int
	perNode    map[string]*rate.Limiter
	failWindow time.Duration
	blockAfter int
	failures   map[string][]time.Time
}

func NewRateLimiter(perMin, burst int, failWindow time.Duration, blockAfter int) *RateLimiter {
	if perMin <= 0 {
		perMin = 6
	}
	if burst <= 0 {
		burst = perMin
	}
	if blockAfter <= 0 {
		blockAfter = 2
	}
	limit := rate.Limit(float64(perMin) / 60.0)
	return &RateLimiter{
		limit:      limit,
		burst:      burst,
		perNode:    make(map[string]*rate.Limiter),
		failWindow: failWindow,
		blockAfter: blockAfter,
		failures:   make(map[string][]time.Time),
	}
}

func (l *RateLimiter) Allow(node string) bool {
	l.mu.Lock()
	defer l.mu.Unlock()
	limiter := l.perNode[node]
	if limiter == nil {
		limiter = rate.NewLimiter(l.limit, l.burst)
		l.perNode[node] = limiter
	}
	return limiter.Allow()
}

// RecordFailure logs a failed attempt and reports whether the node should be blocked.
func (l *RateLimiter) RecordFailure(node string) bool {
	if l.blockAfter <= 0 {
		return false
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	now := time.Now()
	window := l.failWindow
	if window <= 0 {
		window = 10 * time.Minute
	}
	entries := append(l.failures[node], now)
	cutoff := now.Add(-window)
	cleaned := entries[:0]
	for _, ts := range entries {
		if ts.After(cutoff) {
			cleaned = append(cleaned, ts)
		}
	}
	l.failures[node] = cleaned
	return len(cleaned) >= l.blockAfter
}
