package kms

import (
	"crypto/rand"
	"errors"
	"io"
	"sync"
)

const keyBytes = 32

// KeyMaterial combines both AES-GCM and ISE secrets for a single epoch.
type KeyMaterial struct {
	Version uint64
	AES     [keyBytes]byte
	ISE     [keyBytes]byte
}

type keyHistory struct {
	current KeyMaterial
	old1    KeyMaterial
	old2    KeyMaterial
	counter uint64
}

// ClientV2 exposes triple-key retrieval for replication flows.
type ClientV2 struct {
	mu      sync.Mutex
	scopes  map[string]*keyHistory
	randSrc io.Reader
}

// NewClientV2 creates a client backed by crypto/rand by default.
func NewClientV2() *ClientV2 {
	return &ClientV2{
		scopes:  make(map[string]*keyHistory),
		randSrc: rand.Reader,
	}
}

// WithRand overrides the random source (useful for deterministic tests).
func (c *ClientV2) WithRand(r io.Reader) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if r != nil {
		c.randSrc = r
	}
}

// GetKeys returns the current + two historical keysets for the requested scope.
// The txid parameter is accepted for auditing and future per-transaction policies.
func (c *ClientV2) GetKeys(scope string, _ uint64) ([3]KeyMaterial, error) {
	c.mu.Lock()
	defer c.mu.Unlock()

	if scope == "" {
		return [3]KeyMaterial{}, errors.New("kms: scope is required")
	}

	hist, ok := c.scopes[scope]
	if !ok {
		mat, err := c.newMaterialLocked(scope, 1)
		if err != nil {
			return [3]KeyMaterial{}, err
		}
		hist = &keyHistory{
			current: mat,
			counter: 1,
		}
		c.scopes[scope] = hist
	}

	return [3]KeyMaterial{hist.current, hist.old1, hist.old2}, nil
}

// Rotate issues a new current key, shifting history (Current -> Old1 -> Old2).
func (c *ClientV2) Rotate(scope string) (KeyMaterial, error) {
	c.mu.Lock()
	defer c.mu.Unlock()

	if scope == "" {
		return KeyMaterial{}, errors.New("kms: scope is required")
	}

	hist, ok := c.scopes[scope]
	if !ok {
		mat, err := c.newMaterialLocked(scope, 1)
		if err != nil {
			return KeyMaterial{}, err
		}
		hist = &keyHistory{
			current: mat,
			counter: 1,
		}
		c.scopes[scope] = hist
		return mat, nil
	}

	hist.counter++
	next, err := c.newMaterialLocked(scope, hist.counter)
	if err != nil {
		return KeyMaterial{}, err
	}

	zeroKeyMaterial(&hist.old2)
	hist.old2 = hist.old1
	hist.old1 = hist.current
	hist.current = next

	return hist.current, nil
}

func (c *ClientV2) newMaterialLocked(scope string, version uint64) (KeyMaterial, error) {
	if c.randSrc == nil {
		c.randSrc = rand.Reader
	}
	mat := KeyMaterial{Version: version}
	if _, err := io.ReadFull(c.randSrc, mat.AES[:]); err != nil {
		return KeyMaterial{}, err
	}
	if _, err := io.ReadFull(c.randSrc, mat.ISE[:]); err != nil {
		return KeyMaterial{}, err
	}
	return mat, nil
}

func zeroKeyMaterial(mat *KeyMaterial) {
	if mat == nil {
		return
	}
	mat.Version = 0
	for i := range mat.AES {
		mat.AES[i] = 0
	}
	for i := range mat.ISE {
		mat.ISE[i] = 0
	}
}
