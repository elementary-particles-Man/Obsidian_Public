package kms

import (
	"context"
	"crypto/rand"
	"strconv"
	"sync"
	"time"

	"thp-clear/src/common/kmsproto"
)

const transportKeyLen = 8 + 32

// EpochProvider returns the current epoch number.
type EpochProvider interface {
	CurrentEpoch() uint64
}

// EpochKeyIssuer issues key material keyed by epoch and stores the last two generations.
type EpochKeyIssuer struct {
	mu       sync.RWMutex
	epochFn  EpochProvider
	cache    map[string]*kmsproto.KeyMaterialPayload
	retain   int
	keyBytes map[string]int
}

// NewEpochKeyIssuer constructs an issuer with the given provider and retention.
func NewEpochKeyIssuer(ep EpochProvider, retain int) *EpochKeyIssuer {
	if retain < 2 {
		retain = 2
	}
	return &EpochKeyIssuer{
		epochFn:  ep,
		cache:    make(map[string]*kmsproto.KeyMaterialPayload),
		retain:   retain,
		keyBytes: map[string]int{"transport": transportKeyLen},
	}
}

// IssueReal returns stable key material for the current epoch.
func (e *EpochKeyIssuer) IssueReal(_ context.Context, nodeID, keyType string) (*kmsproto.KeyMaterialPayload, error) {
	e.mu.Lock()
	defer e.mu.Unlock()

	epoch := e.epochFn.CurrentEpoch()
	key := e.composeKey(nodeID, keyType, epoch)
	if payload, ok := e.cache[key]; ok {
		return clonePayload(payload), nil
	}

	length := e.keyBytes[keyType]
	if length == 0 {
		length = 32
	}
	material := make([]byte, length)
	if _, err := rand.Read(material); err != nil {
		return nil, err
	}

	payload := &kmsproto.KeyMaterialPayload{
		Type:     keyType,
		Key:      material,
		Epoch:    epoch,
		KeyID:    keyType + ":" + time.Now().UTC().Format("20060102T150405"),
		Deadline: time.Now().Add(10 * time.Minute).Unix(),
	}
	e.cache[key] = payload
	e.pruneLocked(epoch)
	return clonePayload(payload), nil
}

// IssueDecoy returns random material flagged as decoy.
func (e *EpochKeyIssuer) IssueDecoy(_ context.Context, _ string, keyType string) (*kmsproto.KeyMaterialPayload, error) {
	length := e.keyBytes[keyType]
	if length == 0 {
		length = 32
	}
	material := make([]byte, length)
	if _, err := rand.Read(material); err != nil {
		return nil, err
	}
	return &kmsproto.KeyMaterialPayload{
		Type:  keyType,
		Key:   material,
		Epoch: e.epochFn.CurrentEpoch(),
		KeyID: keyType + ":decoy",
		Notes: "decoy",
	}, nil
}

func (e *EpochKeyIssuer) composeKey(nodeID, keyType string, epoch uint64) string {
	return nodeID + "|" + keyType + "|" + strconv.FormatUint(epoch, 10)
}

func (e *EpochKeyIssuer) pruneLocked(current uint64) {
	for k, v := range e.cache {
		if current > v.Epoch && current-v.Epoch >= uint64(e.retain) {
			delete(e.cache, k)
		}
	}
}

func clonePayload(src *kmsproto.KeyMaterialPayload) *kmsproto.KeyMaterialPayload {
	cp := *src
	cp.Key = append([]byte(nil), src.Key...)
	return &cp
}
