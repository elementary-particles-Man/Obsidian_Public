package kms

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"fmt"
	"testing"
	"time"

	"thp-clear/src/common/kmscrypto"
	"thp-clear/src/common/kmsproto"
)

func TestServiceVerifySuccess(t *testing.T) {
	signers := makeTestSigners(t, 3)
	issuer := &stubIssuer{}
	svc, err := NewService(Config{
		Rounds:          5,
		RealRatio:       1.0,
		Signers:         signers,
		KeyIssuer:       issuer,
		Random:          &deterministicReader{},
		Threshold:       2,
		FailureWindow:   time.Minute,
		BlockAfterFails: 2,
	})
	if err != nil {
		t.Fatalf("NewService: %v", err)
	}

	nodeID := "WN-17"
	commitData := make(map[string][]byte)
	for i := 0; i < 3; i++ {
		commitID := fcommitID(i)
		digest := make([]byte, 32)
		if _, err := rand.Read(digest); err != nil {
			t.Fatalf("rand: %v", err)
		}
		commitData[commitID] = digest
		if err := svc.RegisterCommit(nodeID, commitID, digest); err != nil {
			t.Fatalf("RegisterCommit: %v", err)
		}
	}

	req := kmsproto.KeyRequest{
		Type:      "KeyRequest",
		NodeID:    nodeID,
		ReqID:     "req-1",
		KeyType:   "ISE",
		Timestamp: time.Now().Unix(),
	}
	challenges, err := svc.GenerateChallenges(context.Background(), req)
	if err != nil {
		t.Fatalf("GenerateChallenges: %v", err)
	}

	resp := kmsproto.ChallengeResponse{
		Type:   "Responses",
		ReqID:  req.ReqID,
		NodeID: nodeID,
	}

	for _, round := range challenges.Rounds {
		commit, ok := commitData[round.CommitID]
		if !ok {
			resp.Responses = append(resp.Responses, kmsproto.RoundResponse{
				ID:      round.ID,
				Decline: true,
			})
			continue
		}
		rndNode := make([]byte, 8)
		if _, err := rand.Read(rndNode); err != nil {
			t.Fatalf("rand: %v", err)
		}
		expected := kmscrypto.ComputeRoundMAC(round.Kind, commit, challenges.KMSNonce, round.Param, round.RndKMS, rndNode)
		resp.Responses = append(resp.Responses, kmsproto.RoundResponse{
			ID:       round.ID,
			Response: expected,
			RndNode:  rndNode,
		})
	}

	result, alert, err := svc.VerifyAndIssue(context.Background(), resp)
	if err != nil {
		t.Fatalf("VerifyAndIssue: %v", err)
	}
	if alert != nil {
		t.Fatalf("expected no alert on success, got %+v", alert)
	}
	if result.Status != "OK" {
		t.Fatalf("expected status OK, got %s", result.Status)
	}
	if result.Payload == nil || len(result.Payload.Key) == 0 {
		t.Fatalf("missing payload key")
	}
	if result.Ticket == nil {
		t.Fatalf("missing ticket")
	}
	if len(result.Ticket.CommitIDs) == 0 {
		t.Fatalf("ticket should list used commits")
	}
	if len(result.Ticket.ExpectedMACs) != len(result.Ticket.CommitIDs) {
		t.Fatalf("ticket macs mismatch")
	}
	for _, mac := range result.Ticket.ExpectedMACs {
		if len(mac) == 0 {
			t.Fatalf("expected mac to be non-empty")
		}
	}
}

func TestServiceVerifyFailure(t *testing.T) {
	signers := makeTestSigners(t, 3)
	issuer := &stubIssuer{}
	svc, err := NewService(Config{
		Rounds:          4,
		RealRatio:       1.0,
		Signers:         signers,
		KeyIssuer:       issuer,
		Random:          &deterministicReader{},
		Threshold:       2,
		FailureWindow:   time.Minute,
		BlockAfterFails: 2,
	})
	if err != nil {
		t.Fatalf("NewService: %v", err)
	}

	nodeID := "MQ-01"
	digest := make([]byte, 32)
	if _, err := rand.Read(digest); err != nil {
		t.Fatalf("rand: %v", err)
	}
	if err := svc.RegisterCommit(nodeID, "c-aaa", digest); err != nil {
		t.Fatalf("RegisterCommit: %v", err)
	}

	req := kmsproto.KeyRequest{
		Type:      "KeyRequest",
		NodeID:    nodeID,
		ReqID:     "req-fail",
		KeyType:   "AES",
		Timestamp: time.Now().Unix(),
	}
	challenges, err := svc.GenerateChallenges(context.Background(), req)
	if err != nil {
		t.Fatalf("GenerateChallenges: %v", err)
	}

	resp := kmsproto.ChallengeResponse{
		Type:   "Responses",
		ReqID:  req.ReqID,
		NodeID: nodeID,
	}
	for _, round := range challenges.Rounds {
		if round.CommitID != "c-aaa" {
			resp.Responses = append(resp.Responses, kmsproto.RoundResponse{
				ID:      round.ID,
				Decline: true,
			})
			continue
		}
		// Purposely wrong response
		resp.Responses = append(resp.Responses, kmsproto.RoundResponse{
			ID:       round.ID,
			Response: []byte("wrong"),
			RndNode:  []byte("rnd"),
		})
	}

	result, alert, err := svc.VerifyAndIssue(context.Background(), resp)
	if err != nil {
		t.Fatalf("VerifyAndIssue: %v", err)
	}
	if result.Status != "DECOY" {
		t.Fatalf("expected DECOY status, got %s", result.Status)
	}
	if alert == nil {
		t.Fatalf("expected alert on failure")
	}
	if alert.Level != "warn" {
		t.Fatalf("expected warn level, got %s", alert.Level)
	}
}

type stubIssuer struct{}

func (s *stubIssuer) IssueReal(ctx context.Context, nodeID, keyType string) (*kmsproto.KeyMaterialPayload, error) {
	return &kmsproto.KeyMaterialPayload{
		Type:  keyType,
		Key:   []byte("real-key-material"),
		Epoch: 12345,
		KeyID: "K:" + keyType + ":12345",
	}, nil
}

func (s *stubIssuer) IssueDecoy(ctx context.Context, nodeID, keyType string) (*kmsproto.KeyMaterialPayload, error) {
	return &kmsproto.KeyMaterialPayload{
		Type:  keyType,
		Key:   []byte("decoy-key"),
		Epoch: 12345,
		KeyID: "K:" + keyType + ":decoy",
		Notes: "decoy",
	}, nil
}

type testSigner struct {
	id  string
	pub ed25519.PublicKey
	sk  ed25519.PrivateKey
}

func (t *testSigner) KeyID() string                   { return t.id }
func (t *testSigner) PublicKey() ed25519.PublicKey    { return t.pub }
func (t *testSigner) Sign(msg []byte) ([]byte, error) { return ed25519.Sign(t.sk, msg), nil }
func makeTestSigners(t *testing.T, n int) []Signer {
	t.Helper()
	var signers []Signer
	for i := 0; i < n; i++ {
		pub, priv, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			t.Fatalf("GenerateKey: %v", err)
		}
		signers = append(signers, &testSigner{
			id:  fcommitID(i),
			pub: pub,
			sk:  priv,
		})
	}
	return signers
}

type deterministicReader struct {
	counter byte
}

func (d *deterministicReader) Read(p []byte) (int, error) {
	for i := range p {
		p[i] = d.counter
		d.counter++
	}
	return len(p), nil
}

func fcommitID(i int) string {
	return fmt.Sprintf("c-%03d", i)
}
