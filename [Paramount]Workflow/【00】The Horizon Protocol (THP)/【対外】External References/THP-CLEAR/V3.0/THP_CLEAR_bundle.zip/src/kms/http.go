package kms

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"time"

	"thp-clear/src/common/audit"
	"thp-clear/src/common/kmsproto"
)

// SpyBroadcaster delivers alerts to downstream nodes.
type SpyBroadcaster interface {
	Broadcast(ctx context.Context, alert *kmsproto.SpyAlert) error
}

// Handler wires HTTPS endpoints for the KMS service.
type Handler struct {
	svc         *Service
	broadcaster SpyBroadcaster
	audit       *audit.JSONL
	now         func() time.Time
	retryAfter  int
}

// NewHandler builds a HTTP handler backed by the given service.
func NewHandler(svc *Service, broadcaster SpyBroadcaster, auditLogger *audit.JSONL) http.Handler {
	h := &Handler{svc: svc, broadcaster: broadcaster, audit: auditLogger, now: time.Now, retryAfter: 60}
	mux := http.NewServeMux()
	mux.HandleFunc("/commits/register", h.handleRegisterCommit)
	mux.HandleFunc("/keys/request", h.handleKeyRequest)
	mux.HandleFunc("/keys/respond", h.handleKeyRespond)
	mux.HandleFunc("/spy/broadcast", h.handleSpyBroadcast)
	return mux
}

func (h *Handler) handleRegisterCommit(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var payload struct {
		NodeID   string `json:"node_id"`
		CommitID string `json:"commit_id"`
		Digest   []byte `json:"digest"`
	}
	if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
		http.Error(w, "invalid json", http.StatusBadRequest)
		return
	}
	if payload.NodeID == "" || payload.CommitID == "" || len(payload.Digest) == 0 {
		http.Error(w, "missing fields", http.StatusBadRequest)
		return
	}
	if err := h.svc.RegisterCommit(payload.NodeID, payload.CommitID, payload.Digest); err != nil {
		if errors.Is(err, errCommitExists) {
			http.Error(w, "conflict", http.StatusConflict)
			return
		}
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	h.log("commit_register", map[string]interface{}{
		"node":      payload.NodeID,
		"commit_id": payload.CommitID,
	})
	w.WriteHeader(http.StatusCreated)
}

func (h *Handler) handleKeyRequest(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req kmsproto.KeyRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid json", http.StatusBadRequest)
		return
	}
	challenge, err := h.svc.GenerateChallenges(r.Context(), req)
	if err != nil {
		var rlErr *rateLimitError
		if errors.As(err, &rlErr) {
			h.log("key_request", map[string]interface{}{
				"node":   req.NodeID,
				"req_id": req.ReqID,
				"status": "rate_limited",
			})
			w.Header().Set("Retry-After", strconv.Itoa(h.retryAfter))
			w.WriteHeader(http.StatusTooManyRequests)
			if rlErr != nil && h.broadcaster != nil {
				if alert := rlErr.Alert(); alert != nil {
					_ = h.broadcaster.Broadcast(r.Context(), alert)
					h.log("spy_alert_emit", map[string]interface{}{
						"node":   alert.NodeID,
						"req_id": alert.ReqID,
						"level":  alert.Level,
						"kids":   bundleKids(alert.SigBundle),
					})
				}
			}
			return
		}
		h.log("key_request", map[string]interface{}{
			"node":   req.NodeID,
			"req_id": req.ReqID,
			"status": "error",
			"error":  err.Error(),
		})
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	h.log("key_request", map[string]interface{}{
		"node":   req.NodeID,
		"req_id": req.ReqID,
		"status": "ok",
		"rounds": len(challenge.Rounds),
	})
	writeJSON(w, challenge)
}

func (h *Handler) handleKeyRespond(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var resp kmsproto.ChallengeResponse
	if err := json.NewDecoder(r.Body).Decode(&resp); err != nil {
		http.Error(w, "invalid json", http.StatusBadRequest)
		return
	}
	result, alert, err := h.svc.VerifyAndIssue(r.Context(), resp)
	if err != nil {
		h.log("key_respond", map[string]interface{}{
			"node":   resp.NodeID,
			"req_id": resp.ReqID,
			"status": "error",
			"error":  err.Error(),
		})
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	if alert != nil && h.broadcaster != nil {
		_ = h.broadcaster.Broadcast(r.Context(), alert)
		h.log("spy_alert_emit", map[string]interface{}{
			"node":   alert.NodeID,
			"req_id": alert.ReqID,
			"level":  alert.Level,
			"kids":   bundleKids(alert.SigBundle),
		})
	}
	fields := map[string]interface{}{
		"node":   resp.NodeID,
		"req_id": resp.ReqID,
		"status": result.Status,
		"kids":   bundleKids(result.SigBundle),
	}
	if result.Ticket != nil {
		fields["commit_ids"] = result.Ticket.CommitIDs
	}
	h.log("key_respond", fields)
	writeJSON(w, result)
}

func (h *Handler) handleSpyBroadcast(w http.ResponseWriter, r *http.Request) {
	if h.broadcaster == nil {
		http.Error(w, "broadcast disabled", http.StatusServiceUnavailable)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var alert kmsproto.SpyAlert
	if err := json.NewDecoder(r.Body).Decode(&alert); err != nil {
		http.Error(w, "invalid json", http.StatusBadRequest)
		return
	}
	if err := h.broadcaster.Broadcast(r.Context(), &alert); err != nil {
		http.Error(w, err.Error(), http.StatusBadGateway)
		return
	}
	h.log("spy_alert_relay", map[string]interface{}{
		"node":   alert.NodeID,
		"req_id": alert.ReqID,
		"level":  alert.Level,
		"kids":   bundleKids(alert.SigBundle),
	})
	w.WriteHeader(http.StatusAccepted)
}

func writeJSON(w http.ResponseWriter, payload interface{}) {
	w.Header().Set("Content-Type", "application/json")
	enc := json.NewEncoder(w)
	_ = enc.Encode(payload)
}

func (h *Handler) log(event string, fields map[string]interface{}) {
	if h.audit == nil {
		return
	}
	if fields == nil {
		fields = make(map[string]interface{})
	}
	fields["event"] = event
	fields["ts"] = h.now().UTC()
	_ = h.audit.Write(fields)
}

func bundleKids(bundle kmsproto.SigBundle) []string {
	if len(bundle) == 0 {
		return nil
	}
	kids := make([]string, 0, len(bundle))
	for _, sig := range bundle {
		kids = append(kids, sig.KeyID)
	}
	return kids
}

// NoopBroadcaster discards alerts.
type NoopBroadcaster struct{}

// Broadcast implements SpyBroadcaster.
func (NoopBroadcaster) Broadcast(context.Context, *kmsproto.SpyAlert) error { return nil }
