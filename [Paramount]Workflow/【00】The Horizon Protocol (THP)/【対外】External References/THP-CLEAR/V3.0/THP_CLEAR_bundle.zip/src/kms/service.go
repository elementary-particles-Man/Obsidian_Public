package kms

import (
	"context"
	"crypto/ed25519"
	"crypto/hmac"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"math/big"
	"sync"
	"time"

	"thp-clear/src/common/kmscrypto"
	"thp-clear/src/common/kmsproto"
)

var (
	errCommitExists   = errors.New("commit already registered")
	errUnknownCommit  = errors.New("unknown commit id")
	errSessionMissing = errors.New("challenge session not found")
	errRateLimited    = errors.New("kms: rate limited")
)

type rateLimitError struct {
	alert *kmsproto.SpyAlert
}

func (e *rateLimitError) Error() string {
	return errRateLimited.Error()
}

func (e *rateLimitError) Alert() *kmsproto.SpyAlert {
	if e == nil {
		return nil
	}
	return e.alert
}

// Signer represents a KMS quorum member capable of producing Ed25519 signatures.
type Signer interface {
	KeyID() string
	Sign(message []byte) ([]byte, error)
	PublicKey() ed25519.PublicKey
}

// KeyIssuer provides real and decoy key material.
type KeyIssuer interface {
	IssueReal(ctx context.Context, nodeID, keyType string) (*kmsproto.KeyMaterialPayload, error)
	IssueDecoy(ctx context.Context, nodeID, keyType string) (*kmsproto.KeyMaterialPayload, error)
}

// Config controls the behaviour of the KMS service.
type Config struct {
	Rounds           int
	RealRatio        float64
	Timeout          time.Duration
	FailureWindow    time.Duration
	BlockAfterFails  int
	Threshold        int
	Signers          []Signer
	KeyIssuer        KeyIssuer
	Random           io.Reader
	SpyWarnBackoff   time.Duration
	SpyBlockDuration time.Duration
	Metrics          MetricsRecorder
	RateLimit        RateLimitConfig
}

type RateLimitConfig struct {
	PerNodePerMin   int
	Burst           int
	BlockAfterFails int
	FailWindowMin   int
}

// Service orchestrates the challenge-response flow and key distribution.
type Service struct {
	cfg     Config
	metrics MetricsRecorder
	limiter *RateLimiter

	mu        sync.Mutex
	commits   map[string]CommitRecord
	byNode    map[string][]string
	pending   map[string]*session
	failLog   map[string][]time.Time
	blockedTo map[string]time.Time
}

// CommitRecord stores a node bound commitment.
type CommitRecord struct {
	NodeID string
	Digest []byte
}

type session struct {
	ReqID    string
	NodeID   string
	KeyType  string
	KMSNonce []byte
	Issued   time.Time
	Rounds   []internalRound
}

type internalRound struct {
	Challenge kmsproto.ChallengeRound
	Commit    *CommitRecord
}

// NewService builds a new KMS service instance.
func NewService(cfg Config) (*Service, error) {
	if cfg.Rounds <= 0 {
		cfg.Rounds = 7
	}
	if cfg.RealRatio <= 0 || cfg.RealRatio > 1 {
		cfg.RealRatio = 0.8
	}
	if cfg.Timeout == 0 {
		cfg.Timeout = 3 * time.Second
	}
	if cfg.FailureWindow == 0 {
		cfg.FailureWindow = 10 * time.Minute
	}
	if cfg.BlockAfterFails == 0 {
		cfg.BlockAfterFails = 2
	}
	if cfg.Threshold <= 0 {
		cfg.Threshold = 2
	}
	if cfg.KeyIssuer == nil {
		return nil, errors.New("kms: key issuer is required")
	}
	if len(cfg.Signers) < cfg.Threshold {
		return nil, errors.New("kms: insufficient signers for threshold")
	}
	if cfg.Random == nil {
		cfg.Random = rand.Reader
	}
	if cfg.SpyWarnBackoff == 0 {
		cfg.SpyWarnBackoff = 60 * time.Second
	}
	if cfg.SpyBlockDuration == 0 {
		cfg.SpyBlockDuration = 60 * time.Second
	}
	if cfg.Metrics == nil {
		cfg.Metrics = nopMetrics{}
	}

	var limiter *RateLimiter
	if cfg.RateLimit.PerNodePerMin > 0 {
		failWindow := cfg.FailureWindow
		if cfg.RateLimit.FailWindowMin > 0 {
			failWindow = time.Duration(cfg.RateLimit.FailWindowMin) * time.Minute
		}
		if failWindow == 0 {
			failWindow = 10 * time.Minute
		}
		limiter = NewRateLimiter(cfg.RateLimit.PerNodePerMin, cfg.RateLimit.Burst, failWindow, cfg.RateLimit.BlockAfterFails)
	}

	return &Service{
		cfg:       cfg,
		metrics:   cfg.Metrics,
		limiter:   limiter,
		commits:   make(map[string]CommitRecord),
		byNode:    make(map[string][]string),
		pending:   make(map[string]*session),
		failLog:   make(map[string][]time.Time),
		blockedTo: make(map[string]time.Time),
	}, nil
}

// RegisterCommit stores a commit hash for later challenge verification.
func (s *Service) RegisterCommit(nodeID, commitID string, commit []byte) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.commits[commitID]; ok {
		return errCommitExists
	}
	cp := make([]byte, len(commit))
	copy(cp, commit)
	s.commits[commitID] = CommitRecord{NodeID: nodeID, Digest: cp}
	s.byNode[nodeID] = append(s.byNode[nodeID], commitID)
	return nil
}

// GenerateChallenges prepares a challenge set for the node request.
func (s *Service) GenerateChallenges(ctx context.Context, req kmsproto.KeyRequest) (*kmsproto.ChallengeSet, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if s.limiter != nil && !s.limiter.Allow(req.NodeID) {
		alert := s.handleRateLimit(req.NodeID, req.ReqID)
		s.metrics.IncRateLimited(req.NodeID)
		return nil, &rateLimitError{alert: alert}
	}

	s.metrics.IncKeyRequest(req.NodeID)

	if until, blocked := s.blockedTo[req.NodeID]; blocked && time.Now().Before(until) {
		return nil, fmt.Errorf("kms: node %s is temporarily blocked", req.NodeID)
	}

	commitIDs := s.byNode[req.NodeID]
	if len(commitIDs) == 0 {
		return nil, fmt.Errorf("kms: no commits registered for node %s", req.NodeID)
	}
	rounds := s.cfg.Rounds
	kmsNonce := make([]byte, 16)
	if _, err := io.ReadFull(s.cfg.Random, kmsNonce); err != nil {
		return nil, err
	}

	internalRounds, err := s.buildRounds(commitIDs, kmsNonce, rounds)
	if err != nil {
		return nil, err
	}

	for _, r := range internalRounds {
		if err := s.seedRound(r, kmsNonce); err != nil {
			return nil, err
		}
	}

	challenge := kmsproto.ChallengeSet{
		Type:     "Challenges",
		ReqID:    req.ReqID,
		NodeID:   req.NodeID,
		KMSNonce: kmsNonce,
	}
	for _, r := range internalRounds {
		challenge.Rounds = append(challenge.Rounds, r.Challenge)
	}

	digest, err := json.Marshal(challenge)
	if err != nil {
		return nil, err
	}
	challenge.SigBundle, err = s.signBytes(digest)
	if err != nil {
		return nil, err
	}

	s.pending[req.ReqID] = &session{
		ReqID:    req.ReqID,
		NodeID:   req.NodeID,
		KeyType:  req.KeyType,
		KMSNonce: kmsNonce,
		Issued:   time.Now(),
		Rounds:   internalRounds,
	}
	return &challenge, nil
}

// VerifyAndIssue processes node responses and returns key material + optional alert.
func (s *Service) VerifyAndIssue(ctx context.Context, resp kmsproto.ChallengeResponse) (*kmsproto.KeyResult, *kmsproto.SpyAlert, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	sess, ok := s.pending[resp.ReqID]
	if !ok {
		return nil, nil, errSessionMissing
	}
	delete(s.pending, resp.ReqID)
	if sess.NodeID != resp.NodeID {
		return nil, nil, errors.New("kms: node mismatch for response")
	}

	responseMap := make(map[int]kmsproto.RoundResponse)
	for _, r := range resp.Responses {
		responseMap[r.ID] = r
	}

	var failed []int
	var usedCommits []string

	for _, round := range sess.Rounds {
		rResp, has := responseMap[round.Challenge.ID]
		if !has {
			failed = append(failed, round.Challenge.ID)
			continue
		}
		if round.Commit == nil {
			// decoy - expect decline
			if !rResp.Decline {
				failed = append(failed, round.Challenge.ID)
			}
			continue
		}
		usedCommits = append(usedCommits, round.Challenge.CommitID)
		if rResp.Decline {
			failed = append(failed, round.Challenge.ID)
			continue
		}
		expected := kmscrypto.ComputeRoundMAC(round.Challenge.Kind, round.Commit.Digest, sess.KMSNonce, round.Challenge.Param, round.Challenge.RndKMS, rResp.RndNode)
		if !hmac.Equal(expected, rResp.Response) {
			failed = append(failed, round.Challenge.ID)
		}
	}

	statusOK := len(failed) == 0
	if statusOK {
		s.recordSuccessLocked(resp.NodeID)
	} else {
		s.recordFailureLocked(resp.NodeID)
		s.metrics.IncChallengeFail(resp.NodeID)
	}

	var (
		payload *kmsproto.KeyMaterialPayload
		err     error
	)
	if statusOK {
		payload, err = s.cfg.KeyIssuer.IssueReal(ctx, resp.NodeID, sess.KeyType)
	} else {
		payload, err = s.cfg.KeyIssuer.IssueDecoy(ctx, resp.NodeID, sess.KeyType)
		s.metrics.IncDecoyIssued(resp.NodeID)
	}
	if err != nil {
		return nil, nil, err
	}

	ticket := s.buildTicket(sess, usedCommits, payload, statusOK)

	result := kmsproto.KeyResult{
		Type:   "KeyResult",
		ReqID:  resp.ReqID,
		Status: map[bool]string{true: "OK", false: "DECOY"}[statusOK],
		Payload: &kmsproto.KeyMaterialPayload{
			Type:     payload.Type,
			Key:      append([]byte(nil), payload.Key...),
			Epoch:    payload.Epoch,
			KeyID:    payload.KeyID,
			Notes:    payload.Notes,
			Deadline: payload.Deadline,
		},
		Ticket: ticket,
	}
	resultDigest, err := json.Marshal(result)
	if err != nil {
		return nil, nil, err
	}
	result.SigBundle, err = s.signBytes(resultDigest)
	if err != nil {
		return nil, nil, err
	}

	var alert *kmsproto.SpyAlert
	if !statusOK {
		alert = s.buildAlert(resp.NodeID, resp.ReqID, failed, s.shouldBlock(resp.NodeID))
		if alert != nil {
			s.metrics.IncSpyAlert(alert.Level)
		}
	}
	return &result, alert, nil
}

func (s *Service) buildTicket(sess *session, usedCommits []string, payload *kmsproto.KeyMaterialPayload, valid bool) *kmsproto.KeyTicket {
	macs := make([][]byte, 0, len(usedCommits))
	if valid {
		for _, commitID := range usedCommits {
			rec, ok := s.commits[commitID]
			if !ok {
				continue
			}
			mac := kmscrypto.ComputeTicketMAC(rec.Digest, payload, sess.KMSNonce, sess.ReqID)
			macs = append(macs, mac)
		}
	} else {
		for range usedCommits {
			macs = append(macs, nil)
		}
	}
	ticket := &kmsproto.KeyTicket{
		ReqID:        sess.ReqID,
		CommitIDs:    usedCommits,
		ExpectedMACs: macs,
		IssuedAtUnix: time.Now().Unix(),
	}
	if bytes, err := json.Marshal(ticket); err == nil {
		if sig, err := s.signBytes(bytes); err == nil {
			ticket.TicketSig = sig
		}
	}
	return ticket
}

func (s *Service) buildAlert(nodeID, reqID string, failed []int, block bool) *kmsproto.SpyAlert {
	alert := &kmsproto.SpyAlert{
		Type:         "SPY_ALERT",
		Level:        map[bool]string{true: "block", false: "warn"}[block],
		NodeID:       nodeID,
		ReqID:        reqID,
		FailedRounds: append([]int(nil), failed...),
		Timestamp:    time.Now().UTC(),
	}
	if bytes, err := json.Marshal(alert); err == nil {
		if sig, err := s.signBytes(bytes); err == nil {
			alert.SigBundle = sig
		}
	}
	if block {
		s.blockedTo[nodeID] = time.Now().Add(s.cfg.SpyBlockDuration)
	}
	return alert
}

func (s *Service) recordSuccessLocked(nodeID string) {
	delete(s.failLog, nodeID)
	delete(s.blockedTo, nodeID)
}

func (s *Service) handleRateLimit(nodeID, reqID string) *kmsproto.SpyAlert {
	if s.limiter == nil {
		return nil
	}
	if !s.limiter.RecordFailure(nodeID) {
		return nil
	}
	alert := s.buildAlert(nodeID, reqID, nil, true)
	if alert != nil {
		s.metrics.IncSpyAlert(alert.Level)
	}
	return alert
}

func (s *Service) recordFailureLocked(nodeID string) {
	now := time.Now()
	window := s.cfg.FailureWindow
	failures := append(s.failLog[nodeID], now)
	var clipped []time.Time
	for _, ts := range failures {
		if now.Sub(ts) <= window {
			clipped = append(clipped, ts)
		}
	}
	s.failLog[nodeID] = clipped
}

func (s *Service) shouldBlock(nodeID string) bool {
	failures := s.failLog[nodeID]
	return len(failures) >= s.cfg.BlockAfterFails
}

func (s *Service) buildRounds(commitIDs []string, kmsNonce []byte, rounds int) ([]internalRound, error) {
	realCount := int(math.Round(float64(rounds) * s.cfg.RealRatio))
	if realCount > rounds {
		realCount = rounds
	}
	if realCount < 1 {
		realCount = 1
	}

	selectedCommits := randomSample(commitIDs, realCount)
	internal := make([]internalRound, 0, rounds)
	nextID := 1
	for _, id := range selectedCommits {
		rec := s.commits[id]
		internal = append(internal, internalRound{
			Commit: &rec,
			Challenge: kmsproto.ChallengeRound{
				ID:       nextID,
				Kind:     randomKind(s.cfg.Random),
				CommitID: id,
			},
		})
		nextID++
	}

	decoys := rounds - len(internal)
	for i := 0; i < decoys; i++ {
		internal = append(internal, internalRound{
			Commit: nil,
			Challenge: kmsproto.ChallengeRound{
				ID:       nextID,
				Kind:     randomKind(s.cfg.Random),
				CommitID: randomDecoyID(s.cfg.Random),
				IsDecoy:  true,
			},
		})
		nextID++
	}

	// shuffle
	for i := range internal {
		jBig, err := rand.Int(s.cfg.Random, big.NewInt(int64(i+1)))
		if err != nil {
			return nil, err
		}
		j := int(jBig.Int64())
		internal[i], internal[j] = internal[j], internal[i]
	}

	return internal, nil
}

func (s *Service) seedRound(r internalRound, kmsNonce []byte) error {
	param := make([]byte, 32)
	rndKMS := make([]byte, 16)
	if _, err := io.ReadFull(s.cfg.Random, param); err != nil {
		return err
	}
	if _, err := io.ReadFull(s.cfg.Random, rndKMS); err != nil {
		return err
	}
	r.Challenge.Param = param
	r.Challenge.RndKMS = rndKMS
	if r.Commit != nil {
		// generate hint as digest for quick verification logging
		mac := kmscrypto.ComputeHint(r.Challenge.Kind, r.Commit.Digest, kmsNonce, param, rndKMS)
		r.Challenge.Hint = mac
	}
	return nil
}

func (s *Service) signBytes(msg []byte) (kmsproto.SigBundle, error) {
	var bundle kmsproto.SigBundle
	for _, signer := range s.cfg.Signers {
		sig, err := signer.Sign(msg)
		if err != nil {
			return nil, err
		}
		bundle = append(bundle, kmsproto.Signature{
			KeyID: signer.KeyID(),
			Sig:   sig,
		})
	}
	return bundle, nil
}

func randomKind(r io.Reader) kmsproto.ChallengeKind {
	kinds := []kmsproto.ChallengeKind{
		kmsproto.ChallengeKindHMAC,
		kmsproto.ChallengeKindKDF,
		kmsproto.ChallengeKindXOR,
		kmsproto.ChallengeKindPerm,
	}
	nBig, err := rand.Int(r, big.NewInt(int64(len(kinds))))
	if err != nil {
		return kmsproto.ChallengeKindHMAC
	}
	return kinds[int(nBig.Int64())]
}

func randomDecoyID(r io.Reader) string {
	buf := make([]byte, 6)
	io.ReadFull(r, buf)
	return fmt.Sprintf("decoy-%x", buf)
}

func randomSample(commitIDs []string, count int) []string {
	if count >= len(commitIDs) {
		cp := append([]string(nil), commitIDs...)
		return cp
	}
	perm := append([]string(nil), commitIDs...)
	for i := range perm {
		j := i + randInt(len(perm)-i)
		perm[i], perm[j] = perm[j], perm[i]
	}
	return append([]string(nil), perm[:count]...)
}

func randInt(n int) int {
	if n <= 0 {
		return 0
	}
	val, err := rand.Int(rand.Reader, big.NewInt(int64(n)))
	if err != nil {
		return 0
	}
	return int(val.Int64())
}
