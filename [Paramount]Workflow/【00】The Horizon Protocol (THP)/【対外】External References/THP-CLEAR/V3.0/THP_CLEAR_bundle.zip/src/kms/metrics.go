package kms

import (
	"net/http"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

type MetricsRecorder interface {
	IncKeyRequest(nodeID string)
	IncChallengeFail(nodeID string)
	IncDecoyIssued(nodeID string)
	IncSpyAlert(level string)
	IncRateLimited(nodeID string)
}

type promMetrics struct {
	registry       *prometheus.Registry
	keyRequests    *prometheus.CounterVec
	challengeFails *prometheus.CounterVec
	decoyIssued    *prometheus.CounterVec
	spyAlerts      *prometheus.CounterVec
	rateLimited    *prometheus.CounterVec
}

func NewPromMetrics() *promMetrics {
	reg := prometheus.NewRegistry()
	m := &promMetrics{
		registry: reg,
		keyRequests: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "kms_keyreq_total",
				Help: "Number of key requests processed",
			},
			[]string{"node"},
		),
		challengeFails: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "kms_challenge_fail_total",
				Help: "Number of challenge verifications that failed",
			},
			[]string{"node"},
		),
		decoyIssued: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "kms_decoy_issued_total",
				Help: "Number of decoy keys issued",
			},
			[]string{"node"},
		),
		spyAlerts: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "kms_spy_alert_total",
				Help: "Number of SPY alerts broadcast",
			},
			[]string{"level"},
		),
		rateLimited: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "kms_rate_limited_total",
				Help: "Number of requests rejected due to rate limiting",
			},
			[]string{"node"},
		),
	}
	reg.MustRegister(m.keyRequests, m.challengeFails, m.decoyIssued, m.spyAlerts, m.rateLimited)
	return m
}

func (m *promMetrics) Handler() http.Handler {
	return promhttp.HandlerFor(m.registry, promhttp.HandlerOpts{})
}

func (m *promMetrics) IncKeyRequest(nodeID string) {
	m.keyRequests.WithLabelValues(nodeID).Inc()
}

func (m *promMetrics) IncChallengeFail(nodeID string) {
	m.challengeFails.WithLabelValues(nodeID).Inc()
}

func (m *promMetrics) IncDecoyIssued(nodeID string) {
	m.decoyIssued.WithLabelValues(nodeID).Inc()
}

func (m *promMetrics) IncSpyAlert(level string) {
	m.spyAlerts.WithLabelValues(level).Inc()
}

func (m *promMetrics) IncRateLimited(nodeID string) {
	m.rateLimited.WithLabelValues(nodeID).Inc()
}

type nopMetrics struct{}

func (nopMetrics) IncKeyRequest(string)    {}
func (nopMetrics) IncChallengeFail(string) {}
func (nopMetrics) IncDecoyIssued(string)   {}
func (nopMetrics) IncSpyAlert(string)      {}
func (nopMetrics) IncRateLimited(string)   {}

func (m *promMetrics) AsRecorder() MetricsRecorder { return m }
