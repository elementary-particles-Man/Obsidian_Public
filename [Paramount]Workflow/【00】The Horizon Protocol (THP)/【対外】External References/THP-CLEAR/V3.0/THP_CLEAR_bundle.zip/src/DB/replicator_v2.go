package DB

import (
	"bytes"
	"compress/gzip"
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"

	"thp-clear/src/common/crypto"
	"thp-clear/src/kms"
	"thp-clear/src/tpm"
)

var (
	// ErrResend indicates the receiver could not decrypt with any available keyset.
	ErrResend = errors.New("replicator: resend required")
)

// Replicator coordinates triple-key resealing between DB nodes.
type Replicator struct {
	kms  *kms.ClientV2
	tpm  *tpm.HandlerV2
	rand io.Reader

	onPlaintextFinalized func([]byte)
}

// Chunk encapsulates a batch of re-sealed witness payloads.
type Chunk struct {
	Scope    string        `json:"scope"`
	Sequence uint64        `json:"sequence"`
	Metadata ChunkMetadata `json:"metadata"`
	Records  []ChunkRecord `json:"records"`
}

// ChunkMetadata summarises integrity data for the payload.
type ChunkMetadata struct {
	KeyVersion uint64 `json:"key_version"`
	Count      int    `json:"count"`
	MerkleRoot []byte `json:"merkle_root"`
}

// ChunkRecord stores an AES-GCM sealed payload prepared for replication.
type ChunkRecord struct {
	KeyVersion       uint64 `json:"key_version"`
	SeqID            uint32 `json:"seq_id"`
	OrderForward     bool   `json:"order_forward"`
	OrderUsedForward bool   `json:"order_used_forward"`
	Nonce            []byte `json:"nonce"`
	Ciphertext       []byte `json:"ciphertext"`
	PlainHash        []byte `json:"plain_hash"`
}

// ReceiveResult bundles the envelopes reconstructed on the receiver.
type ReceiveResult struct {
	Envelopes []crypto.Envelope
	Merkle    []byte
}

// NewReplicator wires a replication helper using the provided services.
func NewReplicator(client *kms.ClientV2, handler *tpm.HandlerV2) *Replicator {
	return &Replicator{
		kms:  client,
		tpm:  handler,
		rand: rand.Reader,
	}
}

// SetPlaintextHook registers an optional callback invoked after zeroisation (tests).
func (r *Replicator) SetPlaintextHook(fn func([]byte)) {
	r.onPlaintextFinalized = fn
}

// SetRand overrides the random source (deterministic testing support).
func (r *Replicator) SetRand(src io.Reader) {
	if src != nil {
		r.rand = src
	}
}

// GenerateChunk decrypts envelopes, compresses with gzip and reseals using the current key.
func (r *Replicator) GenerateChunk(ctx context.Context, scope string, sequence uint64, envelopes []crypto.Envelope) (*Chunk, error) {
	if len(envelopes) == 0 {
		return nil, errors.New("replicator: no envelopes provided")
	}
	keys, err := r.kms.GetKeys(scope, sequence)
	if err != nil {
		return nil, err
	}
	current := keys[0]
	if current.Version == 0 {
		return nil, errors.New("replicator: current key not initialised")
	}

	chunk := &Chunk{
		Scope:    scope,
		Sequence: sequence,
		Records:  make([]ChunkRecord, 0, len(envelopes)),
	}

	recordHashes := make([][]byte, 0, len(envelopes))
	for _, env := range envelopes {
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		default:
		}
		plain, meta, err := r.decryptEnvelope(env, keys)
		if err != nil {
			return nil, err
		}
		rec, err := r.resealPlaintext(meta, plain, current)
		if err != nil {
			return nil, err
		}
		chunk.Records = append(chunk.Records, rec)
		recordHashes = append(recordHashes, rec.PlainHash)
		chunk.Metadata = ChunkMetadata{
			KeyVersion: current.Version,
			Count:      len(chunk.Records),
			MerkleRoot: computeMerkleRoot(recordHashes),
		}
		r.zeroize(plain)
	}

	return chunk, nil
}

// SendChunk serialises the chunk for transport.
func (r *Replicator) SendChunk(_ context.Context, chunk *Chunk) ([]byte, error) {
	if chunk == nil {
		return nil, errors.New("replicator: chunk is nil")
	}
	return json.Marshal(chunk)
}

// ReceiveChunk decrypts remote payloads, reseals with the current key and returns envelopes.
func (r *Replicator) ReceiveChunk(ctx context.Context, scope string, payload []byte) (*ReceiveResult, error) {
	if len(payload) == 0 {
		return nil, errors.New("replicator: empty payload")
	}
	var chunk Chunk
	if err := json.Unmarshal(payload, &chunk); err != nil {
		return nil, fmt.Errorf("replicator: unmarshal chunk: %w", err)
	}
	if chunk.Scope != scope {
		return nil, fmt.Errorf("replicator: scope mismatch (%s != %s)", chunk.Scope, scope)
	}

	keys, err := r.kms.GetKeys(scope, chunk.Sequence)
	if err != nil {
		return nil, err
	}
	current := keys[0]
	envelopes := make([]crypto.Envelope, 0, len(chunk.Records))
	recordHashes := make([][]byte, 0, len(chunk.Records))

	for _, rec := range chunk.Records {
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		default:
		}
		plain, err := r.decryptRecord(rec, keys)
		if err != nil {
			return nil, err
		}
		env, err := r.buildEnvelope(plain, rec, current)
		if err != nil {
			return nil, err
		}
		envelopes = append(envelopes, env)
		recordHashes = append(recordHashes, rec.PlainHash)
		r.zeroize(plain)
	}

	root := computeMerkleRoot(recordHashes)
	if !bytes.Equal(root, chunk.Metadata.MerkleRoot) {
		return nil, errors.New("replicator: merkle mismatch")
	}

	return &ReceiveResult{
		Envelopes: envelopes,
		Merkle:    root,
	}, nil
}

type envelopeMeta struct {
	SeqID            uint32
	OrderForward     bool
	OrderUsedForward bool
	PlainHash        []byte
	SourceKey        kms.KeyMaterial
}

func (r *Replicator) decryptEnvelope(env crypto.Envelope, keys [3]kms.KeyMaterial) ([]byte, envelopeMeta, error) {
	var lastErr error
	for _, key := range keys {
		if key.Version == 0 {
			continue
		}
		plain, err := r.openEnvelopeWithKey(env, key)
		if err == nil {
			return plain, envelopeMeta{
				SeqID:            env.SeqID,
				OrderForward:     env.OrderForward,
				OrderUsedForward: env.OrderUsedForward,
				PlainHash:        hashSHA256(plain),
				SourceKey:        key,
			}, nil
		}
		lastErr = err
	}
	if lastErr == nil {
		return nil, envelopeMeta{}, ErrResend
	}
	return nil, envelopeMeta{}, errors.Join(ErrResend, lastErr)
}

func (r *Replicator) decryptRecord(rec ChunkRecord, keys [3]kms.KeyMaterial) ([]byte, error) {
	var lastErr error
	for _, key := range keys {
		if key.Version == 0 {
			continue
		}
		plain, err := r.openRecordWithKey(rec, key)
		if err == nil {
			if !bytes.Equal(hashSHA256(plain), rec.PlainHash) {
				r.zeroize(plain)
				return nil, errors.New("replicator: plain hash mismatch")
			}
			return plain, nil
		}
		lastErr = err
	}
	if lastErr == nil {
		return nil, ErrResend
	}
	return nil, errors.Join(ErrResend, lastErr)
}

func (r *Replicator) resealPlaintext(meta envelopeMeta, plain []byte, key kms.KeyMaterial) (ChunkRecord, error) {
	isePayload, err := r.tpm.ISEEncrypt(plain, key.ISE[:])
	if err != nil {
		return ChunkRecord{}, err
	}
	defer r.zeroize(isePayload)

	compressed, err := compress(isePayload)
	if err != nil {
		return ChunkRecord{}, err
	}
	defer r.zeroize(compressed)

	nonce, ciphertext, err := r.sealAESGCM(key.AES[:], compressed)
	if err != nil {
		return ChunkRecord{}, err
	}

	rec := ChunkRecord{
		KeyVersion:       key.Version,
		SeqID:            meta.SeqID,
		OrderForward:     meta.OrderForward,
		OrderUsedForward: meta.OrderUsedForward,
		Nonce:            nonce,
		Ciphertext:       ciphertext,
		PlainHash:        meta.PlainHash,
	}
	return rec, nil
}

func (r *Replicator) buildEnvelope(plain []byte, rec ChunkRecord, key kms.KeyMaterial) (crypto.Envelope, error) {
	plainDigest := hashSHA256(plain)

	isePayload, err := r.tpm.ISEEncrypt(plain, key.ISE[:])
	if err != nil {
		return crypto.Envelope{}, err
	}
	defer r.zeroize(isePayload)

	compressed, err := compress(isePayload)
	if err != nil {
		return crypto.Envelope{}, err
	}
	defer r.zeroize(compressed)

	nonce, ciphertext, err := r.sealAESGCM(key.AES[:], compressed)
	if err != nil {
		return crypto.Envelope{}, err
	}

	cipherHash := hashSHA256(packCipher(nonce, ciphertext))

	return crypto.Envelope{
		KeyVersion:           key.Version,
		SeqID:                rec.SeqID,
		OrderForward:         rec.OrderForward,
		OrderUsedForward:     rec.OrderUsedForward,
		Nonce:                nonce,
		Ciphertext:           ciphertext,
		PlainHash:            plainDigest,
		CipherHash:           cipherHash,
		CommitSignature:      computeSignature(key.ISE[:], key.Version, plainDigest, rec.SeqID, !rec.OrderForward, "commit"),
		OperationalSignature: computeSignature(key.ISE[:], key.Version, cipherHash, rec.SeqID, rec.OrderUsedForward, "oper"),
	}, nil
}

func (r *Replicator) openEnvelopeWithKey(env crypto.Envelope, key kms.KeyMaterial) ([]byte, error) {
	payload, err := r.openAESGCM(key.AES[:], env.Nonce, env.Ciphertext)
	if err != nil {
		return nil, err
	}
	defer r.zeroize(payload)

	decoded, err := decompress(payload)
	if err != nil {
		return nil, err
	}
	defer r.zeroize(decoded)

	plain, err := r.tpm.Decrypt(decoded, key.ISE[:])
	if err != nil {
		return nil, err
	}
	return plain, nil
}

func (r *Replicator) openRecordWithKey(rec ChunkRecord, key kms.KeyMaterial) ([]byte, error) {
	if rec.KeyVersion != 0 && key.Version != rec.KeyVersion {
		return nil, fmt.Errorf("replicator: unexpected key version %d != %d", key.Version, rec.KeyVersion)
	}

	payload, err := r.openAESGCM(key.AES[:], rec.Nonce, rec.Ciphertext)
	if err != nil {
		return nil, err
	}
	defer r.zeroize(payload)

	decoded, err := decompress(payload)
	if err != nil {
		return nil, err
	}
	defer r.zeroize(decoded)

	plain, err := r.tpm.Decrypt(decoded, key.ISE[:])
	if err != nil {
		return nil, err
	}
	return plain, nil
}

func (r *Replicator) sealAESGCM(key []byte, data []byte) ([]byte, []byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, nil, err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(r.rand, nonce); err != nil {
		return nil, nil, err
	}
	ciphertext := gcm.Seal(nil, nonce, data, nil)
	return nonce, ciphertext, nil
}

func (r *Replicator) openAESGCM(key []byte, nonce []byte, ciphertext []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	plain, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return nil, err
	}
	return plain, nil
}

func compress(data []byte) ([]byte, error) {
	var buf bytes.Buffer
	zw := gzip.NewWriter(&buf)
	if _, err := zw.Write(data); err != nil {
		zw.Close()
		return nil, err
	}
	if err := zw.Close(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func decompress(data []byte) ([]byte, error) {
	zr, err := gzip.NewReader(bytes.NewReader(data))
	if err != nil {
		return nil, err
	}
	defer zr.Close()
	var out bytes.Buffer
	if _, err := io.Copy(&out, zr); err != nil {
		return nil, err
	}
	return out.Bytes(), nil
}

func (r *Replicator) zeroize(buf []byte) {
	if buf == nil {
		return
	}
	for i := range buf {
		buf[i] = 0
	}
	if r.onPlaintextFinalized != nil {
		r.onPlaintextFinalized(buf)
	}
}

func computeMerkleRoot(leaves [][]byte) []byte {
	if len(leaves) == 0 {
		return nil
	}
	nodes := make([][]byte, len(leaves))
	for i, leaf := range leaves {
		nodes[i] = append([]byte(nil), leaf...)
	}
	for len(nodes) > 1 {
		var next [][]byte
		for i := 0; i < len(nodes); i += 2 {
			if i+1 == len(nodes) {
				next = append(next, nodes[i])
				continue
			}
			combined := append(append([]byte(nil), nodes[i]...), nodes[i+1]...)
			next = append(next, hashSHA256(combined))
		}
		nodes = next
	}
	return nodes[0]
}

func computeSignature(key []byte, version uint64, dataHash []byte, seqID uint32, orderForward bool, label string) []byte {
	mac := hmac.New(sha256.New, key)
	mac.Write(dataHash)

	var seqBuf [4]byte
	binary.LittleEndian.PutUint32(seqBuf[:], seqID)
	mac.Write(seqBuf[:])

	var verBuf [8]byte
	binary.LittleEndian.PutUint64(verBuf[:], version)
	mac.Write(verBuf[:])

	if orderForward {
		mac.Write([]byte{0x01})
	} else {
		mac.Write([]byte{0x00})
	}

	mac.Write([]byte(label))
	return mac.Sum(nil)
}

func packCipher(nonce, ciphertext []byte) []byte {
	out := make([]byte, 0, len(nonce)+len(ciphertext))
	out = append(out, nonce...)
	out = append(out, ciphertext...)
	return out
}

func hashSHA256(data []byte) []byte {
	sum := sha256.Sum256(data)
	return sum[:]
}
