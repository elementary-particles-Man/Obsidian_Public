package DB

import "time"

// Invoice represents a transactional invoice persisted by the DB service.
type Invoice struct {
	ID          string    `json:"invoice_id" db:"invoice_id"`
	VendorID    string    `json:"vendor_id" db:"vendor_id"`
	VendorName  string    `json:"vendor_name" db:"vendor_name"`
	Amount      float64   `json:"amount" db:"amount"`
	Tax         float64   `json:"tax" db:"tax"`
	Total       float64   `json:"total" db:"total"`
	GeneratedAt time.Time `json:"generated_at" db:"generated_at"`
	Signature   string    `json:"signature" db:"signature"`
}

// WitnessLog captures a tamper-evident record emitted alongside invoice storage.
type WitnessLog struct {
	EntryID    string    `json:"entry_id" db:"entry_id"`
	InvoiceID  string    `json:"invoice_id" db:"invoice_id"`
	VendorID   string    `json:"vendor_id" db:"vendor_id"`
	Amount     float64   `json:"amount" db:"amount"`
	Tax        float64   `json:"tax" db:"tax"`
	Total      float64   `json:"total" db:"total"`
	RecordedAt time.Time `json:"recorded_at" db:"recorded_at"`
	Signature  string    `json:"signature" db:"signature"`
}

// TaxLedger represents the aggregated tax position derived from invoices.
type TaxLedger struct {
	LedgerID    string    `json:"ledger_id" db:"ledger_id"`
	InvoiceID   string    `json:"invoice_id" db:"invoice_id"`
	VendorID    string    `json:"vendor_id" db:"vendor_id"`
	Period      string    `json:"period" db:"period"`
	Amount      float64   `json:"amount" db:"amount"`
	Tax         float64   `json:"tax" db:"tax"`
	Total       float64   `json:"total" db:"total"`
	SubmittedAt time.Time `json:"submitted_at" db:"submitted_at"`
	Status      string    `json:"status" db:"status"`
	Notes       string    `json:"notes,omitempty" db:"notes"`
}
