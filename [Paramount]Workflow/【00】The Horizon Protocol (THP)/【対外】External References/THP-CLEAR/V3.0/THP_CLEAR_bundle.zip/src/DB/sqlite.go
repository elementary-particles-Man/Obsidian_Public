// Package DB offers the persistence adapter skeleton for the split deployment.
// It demonstrates how Witness records coming from worker nodes are verified and inserted
// into SQLite, mirroring the behaviour of `internal/adapters/sqlite` in the monolith.
package DB
