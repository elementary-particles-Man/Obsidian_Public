package DB

import (
	"context"
	"testing"

	"thp-clear/src/model"
)

func TestWitnessStoreInsertDuplicate(t *testing.T) {
	store, err := NewWitnessStore("")
	if err != nil {
		t.Fatalf("store: %v", err)
	}
	t.Cleanup(func() { _ = store.Close() })

	rec := &model.WitnessRecord128{
		TxID:         1,
		TimestampISE: 2,
		FromID:       3,
		ToID:         4,
		AssetCode:    5,
		CurrencyNum:  392,
		Flags:        model.WitnessFlags{OK: true},
		AmountMinor:  1000,
		FeeMinor:     50,
		SeqNo:        10,
	}

	inserted, err := store.Insert(context.Background(), rec)
	if err != nil {
		t.Fatalf("insert: %v", err)
	}
	if !inserted {
		t.Fatalf("expected first insert to succeed")
	}

	inserted, err = store.Insert(context.Background(), rec)
	if err != nil {
		t.Fatalf("insert duplicate: %v", err)
	}
	if inserted {
		t.Fatalf("duplicate insert should be ignored")
	}

	pk := rec.PrimaryKey()
	stored, err := store.GetByPrimaryKey(context.Background(), pk)
	if err != nil {
		t.Fatalf("get: %v", err)
	}
	if stored == nil {
		t.Fatalf("expected stored record")
	}
	if stored.TxID != rec.TxID || stored.TimestampISE != rec.TimestampISE {
		t.Fatalf("retrieved record mismatch")
	}

	count, err := store.Count(context.Background())
	if err != nil {
		t.Fatalf("count: %v", err)
	}
	if count != 1 {
		t.Fatalf("expected count=1, got %d", count)
	}
}
