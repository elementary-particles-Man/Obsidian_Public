package DB

import (
	"crypto/ed25519"
	"fmt"
	"log"

	intcrypto "thp-clear/internal/crypto"
)

// VerifyWitnessWithKeyHub は KeyHub から公開鍵を取得して Witness 署名を検証する。
func VerifyWitnessWithKeyHub(endpoint string, payload, sig []byte) (bool, int64, error) {
	pub, epoch, err := intcrypto.KeyHubGetPubKey(endpoint)
	if err != nil {
		return false, 0, fmt.Errorf("keyhub pubkey fetch failed: %w", err)
	}
	ok := ed25519.Verify(pub, payload, sig)
	log.Printf("[KeyHubVerify] epoch=%d verified=%v", epoch, ok)
	return ok, epoch, nil
}
