package DB

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	_ "modernc.org/sqlite"

	"thp-clear/src/model"
)

const witnessSchema = `
CREATE TABLE IF NOT EXISTS witness_records (
    h          BLOB PRIMARY KEY,
    record     BLOB NOT NULL,
    from_id    INTEGER NOT NULL,
    to_id      INTEGER NOT NULL,
    asset_code INTEGER NOT NULL,
    seq_no     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS witness_secondary
ON witness_records(from_id, to_id, asset_code, seq_no);
`

// WitnessStore persists witness records into SQLite with UNIQUE(H).
type WitnessStore struct {
	db *sql.DB
}

// NewWitnessStore opens (and initialises) the SQLite database at path.
func NewWitnessStore(path string) (*WitnessStore, error) {
	if path == "" {
		path = ":memory:"
	}
	db, err := sql.Open("sqlite", path)
	if err != nil {
		return nil, fmt.Errorf("witness store: open: %w", err)
	}
	if _, err := db.Exec(witnessSchema); err != nil {
		db.Close()
		return nil, fmt.Errorf("witness store: schema: %w", err)
	}
	return &WitnessStore{db: db}, nil
}

// Close releases the underlying database handle.
func (s *WitnessStore) Close() error {
	if s == nil || s.db == nil {
		return nil
	}
	return s.db.Close()
}

// Insert stores the witness record. Returns true if inserted, false if duplicate.
func (s *WitnessStore) Insert(ctx context.Context, rec *model.WitnessRecord128) (bool, error) {
	if s == nil || s.db == nil {
		return false, errors.New("witness store: not initialised")
	}
	raw, err := rec.MarshalBinary()
	if err != nil {
		return false, err
	}
	pk := rec.PrimaryKey()

	res, err := s.db.ExecContext(ctx, `
        INSERT INTO witness_records (h, record, from_id, to_id, asset_code, seq_no)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(h) DO NOTHING
    `, pk[:], raw, rec.FromID, rec.ToID, rec.AssetCode, rec.SeqNo)
	if err != nil {
		return false, fmt.Errorf("witness store: insert: %w", err)
	}
	count, err := res.RowsAffected()
	if err != nil {
		return false, fmt.Errorf("witness store: rows affected: %w", err)
	}
	return count == 1, nil
}

// GetByPrimaryKey retrieves the stored record by its primary hash.
func (s *WitnessStore) GetByPrimaryKey(ctx context.Context, hash [32]byte) (*model.WitnessRecord128, error) {
	if s == nil || s.db == nil {
		return nil, errors.New("witness store: not initialised")
	}
	row := s.db.QueryRowContext(ctx, `SELECT record FROM witness_records WHERE h = ?`, hash[:])
	var raw []byte
	if err := row.Scan(&raw); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, fmt.Errorf("witness store: scan: %w", err)
	}
	var rec model.WitnessRecord128
	if err := rec.UnmarshalBinary(raw); err != nil {
		return nil, err
	}
	return &rec, nil
}

// Count returns the total witness records stored.
func (s *WitnessStore) Count(ctx context.Context) (int64, error) {
	if s == nil || s.db == nil {
		return 0, errors.New("witness store: not initialised")
	}
	row := s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM witness_records`)
	var count int64
	if err := row.Scan(&count); err != nil {
		return 0, fmt.Errorf("witness store: count: %w", err)
	}
	return count, nil
}
