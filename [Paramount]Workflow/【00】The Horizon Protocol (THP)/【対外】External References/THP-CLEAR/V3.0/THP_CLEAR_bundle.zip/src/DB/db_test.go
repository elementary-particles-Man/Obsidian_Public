package DB

import (
	"bytes"
	"testing"

	"thp-clear/src/common/crypto"
)

func TestInsertEnvelopePersists(t *testing.T) {
	db, err := connect(":memory:")
	if err != nil {
		t.Fatalf("connect: %v", err)
	}
	t.Cleanup(func() { _ = db.Close() })

	env := sampleEnvelope()
	if err := InsertEnvelope(db, env); err != nil {
		t.Fatalf("insert envelope: %v", err)
	}

	count, err := QueryCount(db, "SELECT COUNT(*) FROM witness_envelopes")
	if err != nil {
		t.Fatalf("query count: %v", err)
	}
	if count != 1 {
		t.Fatalf("expected 1 row, got %d", count)
	}

	var (
		keyVersion int64
		seqID      int64
		forward    int64
		used       int64
		nonce      []byte
		cipher     []byte
		plainHash  []byte
		cipherHash []byte
		commitSig  []byte
		operSig    []byte
	)
	row := db.QueryRow(`
		SELECT key_version, seq_id, order_forward, order_used_forward,
		       nonce, ciphertext, plain_hash, cipher_hash,
		       commit_signature, operational_signature
		  FROM witness_envelopes
		 LIMIT 1`)
	if err := row.Scan(&keyVersion, &seqID, &forward, &used, &nonce, &cipher, &plainHash, &cipherHash, &commitSig, &operSig); err != nil {
		t.Fatalf("scan row: %v", err)
	}

	if uint64(keyVersion) != env.KeyVersion {
		t.Fatalf("key version mismatch: got %d", keyVersion)
	}
	if uint32(seqID) != env.SeqID {
		t.Fatalf("seq id mismatch: got %d", seqID)
	}
	if forward != int64(boolToInt(env.OrderForward)) {
		t.Fatalf("order forward mismatch: got %d", forward)
	}
	if used != int64(boolToInt(env.OrderUsedForward)) {
		t.Fatalf("order used mismatch: got %d", used)
	}
	if !bytes.Equal(nonce, env.Nonce) {
		t.Fatalf("nonce mismatch")
	}
	if !bytes.Equal(cipher, env.Ciphertext) {
		t.Fatalf("ciphertext mismatch")
	}
	if !bytes.Equal(plainHash, env.PlainHash) {
		t.Fatalf("plain hash mismatch")
	}
	if !bytes.Equal(cipherHash, env.CipherHash) {
		t.Fatalf("cipher hash mismatch")
	}
	if !bytes.Equal(commitSig, env.CommitSignature) {
		t.Fatalf("commit signature mismatch")
	}
	if !bytes.Equal(operSig, env.OperationalSignature) {
		t.Fatalf("oper signature mismatch")
	}
}

func TestInsertEnvelopeValidation(t *testing.T) {
	db, err := connect(":memory:")
	if err != nil {
		t.Fatalf("connect: %v", err)
	}
	t.Cleanup(func() { _ = db.Close() })

	env := sampleEnvelope()
	env.Nonce = []byte{1, 2}
	if err := InsertEnvelope(db, env); err == nil {
		t.Fatal("expected validation error for short nonce")
	}
}

func sampleEnvelope() crypto.Envelope {
	return crypto.Envelope{
		KeyVersion:           42,
		SeqID:                20251031,
		OrderForward:         true,
		OrderUsedForward:     false,
		Nonce:                bytes.Repeat([]byte{0x01}, 12),
		Ciphertext:           []byte{0xAA, 0xBB, 0xCC},
		PlainHash:            bytes.Repeat([]byte{0x02}, 32),
		CipherHash:           bytes.Repeat([]byte{0x03}, 32),
		CommitSignature:      bytes.Repeat([]byte{0x04}, 32),
		OperationalSignature: bytes.Repeat([]byte{0x05}, 32),
	}
}
