package DB

import (
	"bytes"
	"context"
	"errors"

	"thp-clear/src/MQ/encryptor"
	"thp-clear/src/common/crypto"
	"thp-clear/src/kms"
	"thp-clear/src/tpm"
)

var (
	ErrEpochMismatch       = errors.New("db: key epoch mismatch")
	ErrReplicationDisabled = errors.New("db: replication handler not initialised")
)

type Ingestor struct {
	ring       *encryptor.KeyRing
	pipeline   *encryptor.Pipeline
	replicator *Replicator
}

func NewIngestor(ring *encryptor.KeyRing) (*Ingestor, error) {
	if ring == nil {
		return nil, errors.New("db: key ring is required")
	}
	pipeline, err := encryptor.NewPipeline(encryptor.Config{Keys: ring})
	if err != nil {
		return nil, err
	}
	return &Ingestor{ring: ring, pipeline: pipeline}, nil
}

// NewIngestorWithReplicator wires the replication pipeline in addition to the legacy seal path.
func NewIngestorWithReplicator(ring *encryptor.KeyRing, kmsClient *kms.ClientV2, tpmHandler *tpm.HandlerV2) (*Ingestor, error) {
	base, err := NewIngestor(ring)
	if err != nil {
		return nil, err
	}
	if kmsClient == nil || tpmHandler == nil {
		return nil, errors.New("db: kms client and tpm handler are required for replication")
	}
	base.replicator = NewReplicator(kmsClient, tpmHandler)
	return base, nil
}

// AttachReplicator retrofits an existing ingestor with a replication handler.
func (i *Ingestor) AttachReplicator(repl *Replicator) {
	if i != nil {
		i.replicator = repl
	}
}

func (i *Ingestor) DecodeEnvelope(env *encryptor.Envelope) ([]byte, bool, error) {
	if i == nil {
		return nil, false, errors.New("db: ingestor not initialised")
	}
	plain, err := i.pipeline.Open(env)
	if err != nil {
		if errors.Is(err, encryptor.ErrKeyVersionUnavailable) {
			return nil, false, ErrEpochMismatch
		}
		return nil, false, err
	}
	usedPrev := false
	if prev, ok := i.ring.Previous(); ok && env != nil && env.KeyVersion == prev.Version {
		usedPrev = true
	}
	return plain, usedPrev, nil
}

// ProcessReplicationChunk consumes replicated payloads from a peer, reseals them via TPM/KMS, and persists them through the supplied store callback.
func (i *Ingestor) ProcessReplicationChunk(ctx context.Context, scope string, payload []byte, store func(crypto.Envelope) error) (*ReceiveResult, error) {
	if i == nil {
		return nil, errors.New("db: ingestor not initialised")
	}
	if i.replicator == nil {
		return nil, ErrReplicationDisabled
	}
	if store == nil {
		return nil, errors.New("db: store callback is required")
	}
	result, err := i.replicator.ReceiveChunk(ctx, scope, payload)
	if err != nil {
		return nil, err
	}
	if len(result.Envelopes) > 0 {
		expected := merkleFromEnvelopes(result.Envelopes)
		if !bytes.Equal(expected, result.Merkle) {
			return nil, errors.New("db: merkle verification failed")
		}
	}
	for _, env := range result.Envelopes {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		if err := store(env); err != nil {
			return nil, err
		}
	}
	return result, nil
}

func merkleFromEnvelopes(envs []crypto.Envelope) []byte {
	if len(envs) == 0 {
		return nil
	}
	hashes := make([][]byte, 0, len(envs))
	for _, env := range envs {
		if len(env.PlainHash) == 0 {
			continue
		}
		hash := append([]byte(nil), env.PlainHash...)
		hashes = append(hashes, hash)
	}
	return computeMerkleRoot(hashes)
}
