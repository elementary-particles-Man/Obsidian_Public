package DB

import (
	"database/sql"
	"errors"
	"fmt"
	"log"

	_ "modernc.org/sqlite"
	"thp-clear/src/common/crypto"
)

func Connect() *sql.DB {
	db, err := connect("test.db")
	if err != nil {
		log.Fatal(err)
	}
	return db
}

func InsertEnvelope(db *sql.DB, env crypto.Envelope) error {
	if db == nil {
		return errors.New("db: nil handle")
	}
	if err := validateEnvelope(env); err != nil {
		return err
	}
	_, err := db.Exec(
		`INSERT INTO witness_envelopes(
			key_version,
			seq_id,
			order_forward,
			order_used_forward,
			nonce,
			ciphertext,
			plain_hash,
			cipher_hash,
			commit_signature,
			operational_signature
		) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		env.KeyVersion,
		env.SeqID,
		boolToInt(env.OrderForward),
		boolToInt(env.OrderUsedForward),
		env.Nonce,
		env.Ciphertext,
		env.PlainHash,
		env.CipherHash,
		env.CommitSignature,
		env.OperationalSignature,
	)
	if err != nil {
		return fmt.Errorf("db: insert envelope: %w", err)
	}
	return nil
}

func QueryCount(db *sql.DB, query string, args ...any) (int, error) {
	if db == nil {
		return 0, errors.New("db: nil handle")
	}
	row := db.QueryRow(query, args...)
	var count int
	if err := row.Scan(&count); err != nil {
		return 0, fmt.Errorf("db: query count: %w", err)
	}
	return count, nil
}

func connect(dsn string) (*sql.DB, error) {
	if dsn == "" {
		dsn = ":memory:"
	}
	db, err := sql.Open("sqlite", dsn)
	if err != nil {
		return nil, fmt.Errorf("db: open: %w", err)
	}
	db.SetMaxOpenConns(1)
	if err := initSchema(db); err != nil {
		db.Close()
		return nil, err
	}
	return db, nil
}

func initSchema(db *sql.DB) error {
	const schema = `
CREATE TABLE IF NOT EXISTS witness_envelopes (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	key_version INTEGER NOT NULL,
	seq_id INTEGER NOT NULL,
	order_forward INTEGER NOT NULL,
	order_used_forward INTEGER NOT NULL,
	nonce BLOB NOT NULL,
	ciphertext BLOB NOT NULL,
	plain_hash BLOB NOT NULL,
	cipher_hash BLOB NOT NULL,
	commit_signature BLOB NOT NULL,
	operational_signature BLOB NOT NULL,
	UNIQUE(cipher_hash)
);
CREATE INDEX IF NOT EXISTS idx_witness_envelopes_seq
	ON witness_envelopes(key_version, seq_id);`
	if _, err := db.Exec(schema); err != nil {
		return fmt.Errorf("db: init schema: %w", err)
	}
	return nil
}

func validateEnvelope(env crypto.Envelope) error {
	if len(env.Nonce) != 12 {
		return fmt.Errorf("db: invalid nonce length %d", len(env.Nonce))
	}
	if len(env.Ciphertext) == 0 {
		return errors.New("db: ciphertext is empty")
	}
	if len(env.PlainHash) != 32 {
		return fmt.Errorf("db: invalid plain hash length %d", len(env.PlainHash))
	}
	if len(env.CipherHash) != 32 {
		return fmt.Errorf("db: invalid cipher hash length %d", len(env.CipherHash))
	}
	if len(env.CommitSignature) == 0 {
		return errors.New("db: commit signature missing")
	}
	if len(env.OperationalSignature) == 0 {
		return errors.New("db: operational signature missing")
	}
	return nil
}

func boolToInt(v bool) int {
	if v {
		return 1
	}
	return 0
}
