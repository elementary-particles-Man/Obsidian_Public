CREATE TABLE IF NOT EXISTS witness_envelopes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  key_version INTEGER NOT NULL,
  seq_id INTEGER NOT NULL,
  order_forward INTEGER NOT NULL,
  order_used_forward INTEGER NOT NULL,
  nonce BLOB NOT NULL,
  ciphertext BLOB NOT NULL,
  plain_hash BLOB NOT NULL,
  cipher_hash BLOB NOT NULL,
  commit_signature BLOB NOT NULL,
  operational_signature BLOB NOT NULL,
  UNIQUE(cipher_hash)
);
CREATE INDEX IF NOT EXISTS idx_witness_envelopes_seq
ON witness_envelopes(key_version, seq_id);
