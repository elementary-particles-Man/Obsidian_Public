package encryptor

import (
	"encoding/binary"
	"errors"
	"math/bits"
)

const (
	iseKeySize   = 8
	iseRounds    = 8
	iseMinShift  = 1
	iseShiftMask = 0x07
)

// ISEPlan maps the 64bit ISE鍵 to a deterministic round schedule and order bit.
// Apply(true) reproduces the「初回暗号化（順逆ビット反転）」を行い、
// Apply(false) は順逆ビット通りの手順を実行する（実質的な逆順＝検証用）。
type ISEPlan struct {
	rounds       []iseRound
	seqID        uint32
	orderForward bool
}

type iseRound struct {
	xorByte byte
	shift   uint8
	reverse bool
}

// NewISEPlan constructs a plan from a raw 8-byte key.
func NewISEPlan(key []byte) (*ISEPlan, error) {
	if len(key) != iseKeySize {
		return nil, errors.New("ise: key must be 8 bytes")
	}

	rounds, seqID, orderForward := derivePlan(key)
	return &ISEPlan{
		rounds:       rounds,
		seqID:        seqID,
		orderForward: orderForward,
	}, nil
}

// NewISEPlanFromUint64 constructs a plan from a 64-bit integer key.
func NewISEPlanFromUint64(key uint64) *ISEPlan {
	k := make([]byte, iseKeySize)
	binary.LittleEndian.PutUint64(k, key)
	p, _ := NewISEPlan(k)
	return p
}

// SeqID returns the deterministic sequence identifier derived from the key.
func (p *ISEPlan) SeqID() uint32 {
	return p.seqID
}

// OrderForward reports the canonical順逆ビット（true=正順, false=逆順）.
func (p *ISEPlan) OrderForward() bool {
	return p.orderForward
}

// Apply clones input and executes the configured rounds.
// invertOrder=true → 初回暗号化（順逆ビット反転）
// invertOrder=false → 順逆ビット通り（再適用で原像が得られる）
func (p *ISEPlan) Apply(input []byte, invertOrder bool) []byte {
	if p == nil {
		return nil
	}

	out := append([]byte(nil), input...)
	useForward := p.orderForward
	if invertOrder {
		useForward = !useForward
	}

	if useForward {
		for i := 0; i < len(p.rounds); i++ {
			p.rounds[i].applyForward(out)
		}
		return out
	}

	for i := len(p.rounds) - 1; i >= 0; i-- {
		p.rounds[i].applyReverse(out)
	}
	return out
}

func (r iseRound) applyReverse(buf []byte) {
	if r.reverse {
		for i := range buf {
			buf[i] ^= r.xorByte
			buf[i] = bits.RotateLeft8(buf[i], -int(r.shift))
		}
		return
	}
	for i := range buf {
		buf[i] ^= r.xorByte
		buf[i] = bits.RotateLeft8(buf[i], int(r.shift))
	}
}

func (r iseRound) applyForward(buf []byte) {
	if r.reverse {
		for i := range buf {
			buf[i] = bits.RotateLeft8(buf[i], int(r.shift))
			buf[i] ^= r.xorByte
		}
		return
	}
	for i := range buf {
		buf[i] = bits.RotateLeft8(buf[i], -int(r.shift))
		buf[i] ^= r.xorByte
	}
}

func derivePlan(key []byte) ([]iseRound, uint32, bool) {
	state := binary.LittleEndian.Uint64(key)
	if state == 0 {
		state = 0x9E3779B97F4A7C15 // golden ratio constant to avoid zero cycles
	}

	orderForward := (state & 1) == 1
	seqID := uint32((state >> 1) & 0xffffffff)

	order := make([]int, iseRounds)
	for i := range order {
		order[i] = i
	}

	// Fisher-Yates shuffle driven by the key-derived PRNG.
	for i := iseRounds - 1; i > 0; i-- {
		j := int(nextState(&state) % uint64(i+1))
		order[i], order[j] = order[j], order[i]
	}

	rounds := make([]iseRound, iseRounds)
	for idx, pos := range order {
		val := nextState(&state)
		xorByte := byte(val) ^ key[pos]
		shift := uint8((val>>8)&iseShiftMask) + iseMinShift
		reverse := ((val >> 11) & 1) == 1

		rounds[idx] = iseRound{
			xorByte: xorByte,
			shift:   shift,
			reverse: reverse,
		}
	}

	return rounds, seqID, orderForward
}

func nextState(state *uint64) uint64 {
	x := *state
	x ^= x << 7
	x ^= x >> 9
	x ^= x << 8
	*state = x
	return x
}
