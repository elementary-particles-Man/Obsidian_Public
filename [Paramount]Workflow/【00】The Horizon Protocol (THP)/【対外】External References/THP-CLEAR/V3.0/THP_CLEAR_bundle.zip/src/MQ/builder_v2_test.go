package MQ

import (
	"bytes"
	"context"
	"encoding/binary"
	"testing"
	"time"

	"thp-clear/src/crypto"
	"thp-clear/src/model"
)

func TestPacketBuilder(t *testing.T) {
	var mat KeyMaterial
	fillSequential(mat.AESKey[:])
	fillSequential(mat.MgmtKey[:])
	fillSequential(mat.PayKey[:])
	copy(mat.TPMHandle[:], makeSequential(0x80)[:16])

	builder, err := NewPacketBuilder(&StaticMaterialProvider{Material: mat})
	if err != nil {
		t.Fatalf("new builder: %v", err)
	}

	req := BuildRequest{
		FromID:      0x0102030405060708,
		ToID:        0x1112131415161718,
		AssetCode:   0x100,
		CurrencyNum: 392,
		AmountMinor: 1_000_000_000_000_000_000,
		FeeMinor:    12345,
		Timestamp:   time.UnixMilli(1700000000000),
		Flags: model.PacketFlags{
			DualSign:    true,
			StrictOrder: true,
		},
	}
	copy(req.SigMgmt[:], makeSequential(0x10)[:64])
	copy(req.SigPay[:], makeSequential(0x20)[:64])

	packetCipher, body, err := builder.Build(context.Background(), req)
	if err != nil {
		t.Fatalf("build: %v", err)
	}
	if packetCipher == nil || body == nil {
		t.Fatalf("expected non-nil results")
	}
	if !packetCipher.ValidateCRC() {
		t.Fatalf("crc validation failed")
	}

	wire, err := packetCipher.MarshalBinary()
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	if len(wire) != model.PacketTotalSize {
		t.Fatalf("wire size mismatch: %d", len(wire))
	}

	aesgcm, err := crypto.NewAES256GCM(mat.AESKey[:])
	if err != nil {
		t.Fatalf("aes: %v", err)
	}
	aad := buildAAD(body.Header.TxID, body.Header.TimestampISE)
	plain, err := aesgcm.Decrypt(packetCipher.IV, packetCipher.Ciphertext[:], aad[:], packetCipher.Tag)
	if err != nil {
		t.Fatalf("decrypt: %v", err)
	}
	if len(plain) != model.PacketInnerBodySize {
		t.Fatalf("plain size mismatch: %d", len(plain))
	}

	var decoded model.PacketBody
	if err := decoded.UnmarshalBinary(plain); err != nil {
		t.Fatalf("unmarshal body: %v", err)
	}

	if decoded.Header.FromID != req.FromID || decoded.Header.ToID != req.ToID {
		t.Fatalf("id mismatch")
	}
	if decoded.Header.AssetCode != req.AssetCode {
		t.Fatalf("asset code mismatch")
	}
	if decoded.Header.Flags2 != 0 {
		t.Fatalf("expected stable coin flags2 to be zero")
	}
	if !bytes.Equal(decoded.SignatureBlock.SigMgmt[:], req.SigMgmt[:]) {
		t.Fatalf("sig mgmt mismatch")
	}
	if binary.BigEndian.Uint64(decoded.Control.H[:8]) == 0 {
		t.Fatalf("idempotency hash should not be zero")
	}
}

func fillSequential(buf []byte) {
	for i := range buf {
		buf[i] = byte(i)
	}
}

func makeSequential(start byte) []byte {
	out := make([]byte, 512)
	for i := range out {
		out[i] = start + byte(i)
	}
	return out
}

func TestPacketBuilderSetsExchangeFlagForVoidCoin(t *testing.T) {
	var mat KeyMaterial
	fillSequential(mat.AESKey[:])
	fillSequential(mat.MgmtKey[:])
	fillSequential(mat.PayKey[:])

	builder, err := NewPacketBuilder(&StaticMaterialProvider{Material: mat})
	if err != nil {
		t.Fatalf("new builder: %v", err)
	}

	req := BuildRequest{
		FromID:      0x0101010101010101,
		ToID:        0x0202020202020202,
		AssetCode:   0x80000005,
		CurrencyNum: 65535,
		AmountMinor: 100,
		FeeMinor:    0,
	}

	packetCipher, body, err := builder.Build(context.Background(), req)
	if err != nil {
		t.Fatalf("build: %v", err)
	}

	if body.Header.Flags2&model.PacketFlags2Exchange == 0 {
		t.Fatalf("expected exchange flag to be set for voidcoin")
	}

	// decrypt for confirmation
	aesgcm, err := crypto.NewAES256GCM(mat.AESKey[:])
	if err != nil {
		t.Fatalf("aes: %v", err)
	}
	aad := buildAAD(body.Header.TxID, body.Header.TimestampISE)
	plain, err := aesgcm.Decrypt(packetCipher.IV, packetCipher.Ciphertext[:], aad[:], packetCipher.Tag)
	if err != nil {
		t.Fatalf("decrypt: %v", err)
	}
	var decoded model.PacketBody
	if err := decoded.UnmarshalBinary(plain); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if decoded.Header.Flags2&model.PacketFlags2Exchange == 0 {
		t.Fatalf("exchange flag lost after decrypt")
	}
}
