package encryptor

import (
	"crypto/rand"
	"errors"
	"sync"
)

type KeyMaterial struct {
	Version uint64
	ISEKey  [iseKeySize]byte
	AESKey  [aesKeySize]byte
}

type KeySource interface {
	Current() (KeyMaterial, error)
	Previous() (KeyMaterial, bool)
	ByVersion(version uint64) (KeyMaterial, bool)
	Rotate() (KeyMaterial, error)
	Apply(KeyMaterial)
}

type KeyRing struct {
	mu          sync.RWMutex
	current     KeyMaterial
	previous    KeyMaterial
	hasCurrent  bool
	hasPrevious bool
	initialised bool
}

func NewKeyRing() (*KeyRing, error) {
	mat, err := generateKeyMaterial(1)
	if err != nil {
		return nil, err
	}

	return &KeyRing{
		current:     mat,
		hasCurrent:  true,
		initialised: true,
	}, nil
}

func (k *KeyRing) Current() (KeyMaterial, error) {
	k.mu.RLock()
	defer k.mu.RUnlock()

	if !k.hasCurrent {
		return KeyMaterial{}, errors.New("keyring: current key not initialised")
	}
	return k.current, nil
}

func (k *KeyRing) Previous() (KeyMaterial, bool) {
	k.mu.RLock()
	defer k.mu.RUnlock()

	if !k.hasPrevious {
		return KeyMaterial{}, false
	}
	return k.previous, true
}

func (k *KeyRing) ByVersion(version uint64) (KeyMaterial, bool) {
	k.mu.RLock()
	defer k.mu.RUnlock()

	if k.hasCurrent && k.current.Version == version {
		return k.current, true
	}
	if k.hasPrevious && k.previous.Version == version {
		return k.previous, true
	}
	return KeyMaterial{}, false
}

func (k *KeyRing) Rotate() (KeyMaterial, error) {
	k.mu.Lock()
	defer k.mu.Unlock()

	if !k.initialised {
		mat, err := generateKeyMaterial(1)
		if err != nil {
			return KeyMaterial{}, err
		}
		k.current = mat
		k.hasCurrent = true
		k.initialised = true
		return mat, nil
	}

	nextVersion := k.current.Version + 1
	mat, err := generateKeyMaterial(nextVersion)
	if err != nil {
		return KeyMaterial{}, err
	}

	if k.hasCurrent {
		k.previous = k.current
		k.hasPrevious = true
	}

	k.current = mat
	k.hasCurrent = true
	return mat, nil
}

// Apply stores externally provided material and shifts the previous entry when needed.
func (k *KeyRing) Apply(mat KeyMaterial) {
	k.mu.Lock()
	defer k.mu.Unlock()

	if !k.hasCurrent {
		k.current = mat
		k.hasCurrent = true
		return
	}
	if mat.Version > k.current.Version {
		if k.hasCurrent {
			k.previous = k.current
			k.hasPrevious = true
		}
		k.current = mat
		return
	}
	if mat.Version == k.current.Version {
		k.current = mat
		return
	}
	if (!k.hasPrevious) || mat.Version >= k.previous.Version {
		k.previous = mat
		k.hasPrevious = true
	}
}

func generateKeyMaterial(version uint64) (KeyMaterial, error) {
	var mat KeyMaterial
	mat.Version = version

	if _, err := rand.Read(mat.ISEKey[:]); err != nil {
		return KeyMaterial{}, err
	}
	if _, err := rand.Read(mat.AESKey[:]); err != nil {
		return KeyMaterial{}, err
	}

	return mat, nil
}
