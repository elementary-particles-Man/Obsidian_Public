package encryptor

import (
	"bytes"
	"crypto/sha256"
	"testing"
)

func TestPipelineSealAndOpenInitial(t *testing.T) {
	key := makeKeyMaterial(1, 0x10, 0x40)
	source := &stubKeySource{current: key}

	p, err := NewPipeline(Config{Keys: source})
	if err != nil {
		t.Fatalf("failed to create pipeline: %v", err)
	}

	plain := []byte("ise-stage-check")
	env, err := p.Seal(plain, true)
	if err != nil {
		t.Fatalf("seal failed: %v", err)
	}

	if env.KeyVersion != key.Version {
		t.Fatalf("unexpected key version: got %d want %d", env.KeyVersion, key.Version)
	}

	if len(env.Nonce) != aesNonceSize {
		t.Fatalf("unexpected nonce length: got %d", len(env.Nonce))
	}
	if len(env.Ciphertext) == 0 {
		t.Fatal("ciphertext must not be empty")
	}

	if env.OrderUsedForward == env.OrderForward {
		t.Fatal("initial seal must invert order bit")
	}

	wantPlainHash := sha256.Sum256(plain)
	if env.PlainHash != wantPlainHash {
		t.Fatal("plain hash mismatch")
	}

	wantCipherHash := sha256.Sum256(packCipher(env.Nonce, env.Ciphertext))
	if env.CipherHash != wantCipherHash {
		t.Fatal("cipher hash mismatch")
	}

	expectedCommit := computeSignature(key.ISEKey[:], key.Version, env.PlainHash[:], env.SeqID, !env.OrderForward, "commit")
	if !bytes.Equal(env.CommitSignature, expectedCommit) {
		t.Fatal("commit signature mismatch")
	}

	expectedOper := computeSignature(key.ISEKey[:], key.Version, env.CipherHash[:], env.SeqID, env.OrderUsedForward, "oper")
	if !bytes.Equal(env.OperationalSignature, expectedOper) {
		t.Fatal("oper signature mismatch")
	}

	recovered, err := p.Open(env)
	if err != nil {
		t.Fatalf("open failed: %v", err)
	}
	if !bytes.Equal(recovered, plain) {
		t.Fatalf("recovered payload mismatch: got %x want %x", recovered, plain)
	}
}

func TestPipelineOpenFallbackToPrevious(t *testing.T) {
	key1 := makeKeyMaterial(1, 0x01, 0x21)
	key2 := makeKeyMaterial(2, 0x11, 0x31)

	source := &stubKeySource{current: key1}
	p, err := NewPipeline(Config{Keys: source})
	if err != nil {
		t.Fatalf("failed to create pipeline: %v", err)
	}

	plain := []byte("fall-back-test")
	envOld, err := p.Seal(plain, true)
	if err != nil {
		t.Fatalf("seal with initial key failed: %v", err)
	}

	source.setNext(key2)
	if _, err := source.Rotate(); err != nil {
		t.Fatalf("rotate failed: %v", err)
	}

	recovered, err := p.Open(envOld)
	if err != nil {
		t.Fatalf("open using previous key failed: %v", err)
	}
	if !bytes.Equal(recovered, plain) {
		t.Fatalf("recovered payload mismatch: got %x want %x", recovered, plain)
	}

	envNew, err := p.Seal(plain, false)
	if err != nil {
		t.Fatalf("seal with new key failed: %v", err)
	}

	stale := &stubKeySource{current: key1}
	oldPipeline, err := NewPipeline(Config{Keys: stale})
	if err != nil {
		t.Fatalf("failed to create stale pipeline: %v", err)
	}

	if _, err := oldPipeline.Open(envNew); err == nil {
		t.Fatal("expected open to fail with missing key version")
	}

	stale.setNext(key2)
	if _, err := stale.Rotate(); err != nil {
		t.Fatalf("stale rotation failed: %v", err)
	}

	if _, err := oldPipeline.Open(envNew); err != nil {
		t.Fatalf("open after key update failed: %v", err)
	}
}

func makeKeyMaterial(version uint64, iseSeed, aesSeed byte) KeyMaterial {
	var mat KeyMaterial
	mat.Version = version
	for i := range mat.ISEKey {
		mat.ISEKey[i] = iseSeed + byte(i)
	}
	for i := range mat.AESKey {
		mat.AESKey[i] = aesSeed + byte(i)
	}
	return mat
}

type stubKeySource struct {
	current  KeyMaterial
	previous *KeyMaterial
	next     KeyMaterial
	hasNext  bool
}

func (s *stubKeySource) Current() (KeyMaterial, error) {
	return s.current, nil
}

func (s *stubKeySource) Previous() (KeyMaterial, bool) {
	if s.previous == nil {
		return KeyMaterial{}, false
	}
	return *s.previous, true
}

func (s *stubKeySource) ByVersion(version uint64) (KeyMaterial, bool) {
	if s.current.Version == version {
		return s.current, true
	}
	if s.previous != nil && s.previous.Version == version {
		return *s.previous, true
	}
	return KeyMaterial{}, false
}

func (s *stubKeySource) Rotate() (KeyMaterial, error) {
	if !s.hasNext {
		return s.current, nil
	}
	prev := s.current
	s.previous = &prev
	s.current = s.next
	s.hasNext = false
	return s.current, nil
}

func (s *stubKeySource) Apply(mat KeyMaterial) {
	prev := s.current
	s.previous = &prev
	s.current = mat
}

func (s *stubKeySource) setNext(mat KeyMaterial) {
	s.next = mat
	s.hasNext = true
}
