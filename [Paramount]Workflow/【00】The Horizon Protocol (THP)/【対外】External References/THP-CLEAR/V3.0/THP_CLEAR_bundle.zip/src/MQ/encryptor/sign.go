package encryptor

// 暗号後データ + ISE鍵 から一意シグネチャ生成（SHA-256/HMAC等）
