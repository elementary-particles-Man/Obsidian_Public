package encryptor

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"errors"
	"io"
)

const (
	aesKeySize   = 32
	aesNonceSize = 12
)

func sealAES256GCM(key, plaintext []byte) (nonce, ciphertext []byte, err error) {
	if len(key) != aesKeySize {
		return nil, nil, errors.New("aes: key must be 32 bytes for AES-256")
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, nil, err
	}

	nonce = make([]byte, aesNonceSize)
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, nil, err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, nil, err
	}

	ciphertext = gcm.Seal(nil, nonce, plaintext, nil)
	return nonce, ciphertext, nil
}

func openAES256GCM(key, nonce, ciphertext []byte) ([]byte, error) {
	if len(key) != aesKeySize {
		return nil, errors.New("aes: key must be 32 bytes for AES-256")
	}
	if len(nonce) != aesNonceSize {
		return nil, errors.New("aes: nonce must be 12 bytes for GCM")
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}

	return gcm.Open(nil, nonce, ciphertext, nil)
}
