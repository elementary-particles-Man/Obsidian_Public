package MQ

import (
	"container/heap"
	"sync"
	"time"
)

// QueueType identifies the logical queue a packet belongs to.
type QueueType string

const (
	QueueCLEAR  QueueType = "CLEAR"
	QueueTAXGOV QueueType = "TAX_GOV"
)

// TxPacket represents a transaction packet pending dispatch.
type TxPacket struct {
	ID          string
	Payload     []byte
	Queue       QueueType
	EnqueuedAt  time.Time
	LastAttempt time.Time
	Attempts    int
	ReadyAt     time.Time
}

// Clock abstracts time sources for deterministic testing.
type Clock func() time.Time

var defaultClock Clock = time.Now

type ringBuffer struct {
	items []*TxPacket
	head  int
	tail  int
	size  int
}

func newRing(capacity int) ringBuffer {
	if capacity <= 0 {
		capacity = 1024
	}
	return ringBuffer{items: make([]*TxPacket, capacity)}
}

func (r *ringBuffer) capacity() int {
	return len(r.items)
}

func (r *ringBuffer) push(pkt *TxPacket) bool {
	if r.size == len(r.items) {
		return false
	}
	r.items[r.tail] = pkt
	r.tail = (r.tail + 1) % len(r.items)
	r.size++
	return true
}

func (r *ringBuffer) pop() (*TxPacket, bool) {
	if r.size == 0 {
		return nil, false
	}
	pkt := r.items[r.head]
	r.items[r.head] = nil
	r.head = (r.head + 1) % len(r.items)
	r.size--
	return pkt, true
}

func (r *ringBuffer) peek() (*TxPacket, bool) {
	if r.size == 0 {
		return nil, false
	}
	return r.items[r.head], true
}

func (r *ringBuffer) len() int {
	return r.size
}

// CLEARQueue implements a non-blocking ring buffer for CLEAR packets.
type CLEARQueue struct {
	mu    sync.Mutex
	buf   ringBuffer
	clock Clock
}

// NewCLEARQueue creates a CLEAR queue with the provided capacity.
func NewCLEARQueue(capacity int, clk Clock) *CLEARQueue {
	if clk == nil {
		clk = defaultClock
	}
	return &CLEARQueue{
		buf:   newRing(capacity),
		clock: clk,
	}
}

// Push inserts a packet at the tail. Returns false when the queue is full.
func (q *CLEARQueue) Push(pkt *TxPacket) bool {
	if pkt == nil {
		return false
	}
	q.mu.Lock()
	defer q.mu.Unlock()
	if pkt.EnqueuedAt.IsZero() {
		now := q.clock()
		pkt.EnqueuedAt = now
		pkt.ReadyAt = now
	}
	pkt.Queue = QueueCLEAR
	return q.buf.push(pkt)
}

// Pop removes and returns the next packet.
func (q *CLEARQueue) Pop() (*TxPacket, bool) {
	q.mu.Lock()
	defer q.mu.Unlock()
	return q.buf.pop()
}

// Peek returns, without removing, the next packet.
func (q *CLEARQueue) Peek() (*TxPacket, bool) {
	q.mu.Lock()
	defer q.mu.Unlock()
	return q.buf.peek()
}

// Len returns the number of packets currently queued.
func (q *CLEARQueue) Len() int {
	q.mu.Lock()
	defer q.mu.Unlock()
	return q.buf.len()
}

// Capacity returns the maximum number of packets the queue can hold.
func (q *CLEARQueue) Capacity() int {
	q.mu.Lock()
	defer q.mu.Unlock()
	return q.buf.capacity()
}

type delayedPacket struct {
	pkt   *TxPacket
	due   time.Time
	index int
}

type delayedHeap []*delayedPacket

func (h delayedHeap) Len() int { return len(h) }
func (h delayedHeap) Less(i, j int) bool {
	if h[i].due.Equal(h[j].due) {
		return h[i].pkt.EnqueuedAt.Before(h[j].pkt.EnqueuedAt)
	}
	return h[i].due.Before(h[j].due)
}
func (h delayedHeap) Swap(i, j int) {
	h[i], h[j] = h[j], h[i]
	h[i].index = i
	h[j].index = j
}
func (h *delayedHeap) Push(x interface{}) {
	node := x.(*delayedPacket)
	node.index = len(*h)
	*h = append(*h, node)
}
func (h *delayedHeap) Pop() interface{} {
	old := *h
	n := len(old)
	node := old[n-1]
	node.index = -1
	*h = old[:n-1]
	return node
}

// TAXGOVQueue extends CLEARQueue semantics with delayed re-insertion support.
type TAXGOVQueue struct {
	mu         sync.Mutex
	buf        ringBuffer
	backlog    delayedHeap
	persisted  map[string]*delayedPacket
	clock      Clock
	maxBacklog int
}

// NewTAXGOVQueue constructs a TAX-GOV queue.
func NewTAXGOVQueue(capacity int, clk Clock) *TAXGOVQueue {
	if clk == nil {
		clk = defaultClock
	}
	q := &TAXGOVQueue{
		buf:       newRing(capacity),
		persisted: make(map[string]*delayedPacket),
		clock:     clk,
	}
	heap.Init(&q.backlog)
	return q
}

// Push enqueues a packet for immediate dispatch.
func (q *TAXGOVQueue) Push(pkt *TxPacket) bool {
	if pkt == nil {
		return false
	}
	q.mu.Lock()
	defer q.mu.Unlock()
	q.promoteLocked(q.clock())
	if pkt.EnqueuedAt.IsZero() {
		now := q.clock()
		pkt.EnqueuedAt = now
	}
	pkt.Queue = QueueTAXGOV
	pkt.ReadyAt = q.clock()
	return q.buf.push(pkt)
}

// DelayInsert schedules a packet for future delivery.
func (q *TAXGOVQueue) DelayInsert(pkt *TxPacket, readyAt time.Time) {
	if pkt == nil {
		return
	}
	q.mu.Lock()
	defer q.mu.Unlock()
	if readyAt.Before(q.clock()) {
		readyAt = q.clock()
	}
	node := &delayedPacket{
		pkt: pkt,
		due: readyAt,
	}
	pkt.Queue = QueueTAXGOV
	pkt.ReadyAt = readyAt
	pkt.LastAttempt = q.clock()
	q.persisted[pkt.ID] = node
	heap.Push(&q.backlog, node)
}

// Pop removes the next ready packet, promoting delayed entries as needed.
func (q *TAXGOVQueue) Pop() (*TxPacket, bool) {
	q.mu.Lock()
	defer q.mu.Unlock()
	q.promoteLocked(q.clock())
	return q.buf.pop()
}

// Peek returns the next ready TAX-GOV packet without removing it.
func (q *TAXGOVQueue) Peek() (*TxPacket, bool) {
	q.mu.Lock()
	defer q.mu.Unlock()
	q.promoteLocked(q.clock())
	return q.buf.peek()
}

// Len returns the number of ready packets.
func (q *TAXGOVQueue) Len() int {
	q.mu.Lock()
	defer q.mu.Unlock()
	q.promoteLocked(q.clock())
	return q.buf.len()
}

// BacklogLen returns the number of delayed packets pending promotion.
func (q *TAXGOVQueue) BacklogLen() int {
	q.mu.Lock()
	defer q.mu.Unlock()
	return len(q.backlog)
}

// Capacity returns queue capacity.
func (q *TAXGOVQueue) Capacity() int {
	q.mu.Lock()
	defer q.mu.Unlock()
	return q.buf.capacity()
}

// SnapshotBacklog returns a copy of the persisted backlog for diagnostics.
func (q *TAXGOVQueue) SnapshotBacklog() []*TxPacket {
	q.mu.Lock()
	defer q.mu.Unlock()
	out := make([]*TxPacket, 0, len(q.backlog))
	for _, node := range q.backlog {
		out = append(out, node.pkt)
	}
	return out
}

func (q *TAXGOVQueue) promoteLocked(now time.Time) {
	for q.backlog.Len() > 0 {
		node := q.backlog[0]
		if node.due.After(now) {
			break
		}
		heap.Pop(&q.backlog)
		delete(q.persisted, node.pkt.ID)
		node.pkt.Queue = QueueTAXGOV
		if node.pkt.ReadyAt.Before(now) {
			node.pkt.ReadyAt = now
		}
		_ = q.buf.push(node.pkt)
	}
}
