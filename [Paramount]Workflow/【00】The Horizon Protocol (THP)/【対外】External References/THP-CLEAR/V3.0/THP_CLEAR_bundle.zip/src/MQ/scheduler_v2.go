package MQ

import (
	"sync"
	"time"
)

// SchedulerMode defines the dispatcher policy window.
type SchedulerMode string

const (
	ModeNormal    SchedulerMode = "normal"
	ModeEmergency SchedulerMode = "emergency"
	ModeOffpeak   SchedulerMode = "offpeak"
)

type modeRatio struct {
	Clear float64
	Tax   float64
}

// QueuePolicy captures runtime tuning knobs for queue selection/backpressure.
type QueuePolicy struct {
	ClearThreshold       float64
	TaxGovThreshold      float64
	ClearPriorityWeight  float64
	BackpressureDelayMin time.Duration
	BackpressureDelayMax time.Duration
}

// Scheduler coordinates two priority queues (CLEAR / TAX-GOV) with adaptive ratios.
type Scheduler struct {
	clearQueue *CLEARQueue
	taxQueue   *TAXGOVQueue
	policy     QueuePolicy

	mu            sync.Mutex
	mode          SchedulerMode
	ratios        map[SchedulerMode]modeRatio
	clearDeficit  float64
	taxDeficit    float64
	clearDispatch uint64
	taxDispatch   uint64
	clock         Clock
}

// NewScheduler wires the scheduler around CLEAR and TAX-GOV queues.
func NewScheduler(clear *CLEARQueue, tax *TAXGOVQueue, policy QueuePolicy) *Scheduler {
	if clear == nil || tax == nil {
		panic("scheduler: queues must not be nil")
	}
	if policy.ClearThreshold <= 0 {
		policy.ClearThreshold = 0.7
	}
	if policy.TaxGovThreshold <= 0 {
		policy.TaxGovThreshold = 0.3
	}
	if policy.ClearPriorityWeight <= 0 {
		policy.ClearPriorityWeight = 0.75
	}
	if policy.BackpressureDelayMin <= 0 {
		policy.BackpressureDelayMin = 100 * time.Millisecond
	}
	if policy.BackpressureDelayMax < policy.BackpressureDelayMin {
		policy.BackpressureDelayMax = 3 * time.Second
	}

	s := &Scheduler{
		clearQueue: clear,
		taxQueue:   tax,
		policy:     policy,
		mode:       ModeNormal,
		ratios: map[SchedulerMode]modeRatio{
			ModeNormal:    {Clear: 0.7, Tax: 0.3},
			ModeEmergency: {Clear: 0.9, Tax: 0.1},
			ModeOffpeak:   {Clear: 0.6, Tax: 0.4},
		},
		clock: defaultClock,
	}
	if tax.clock != nil {
		s.clock = tax.clock
	} else if clear.clock != nil {
		s.clock = clear.clock
	}
	return s
}

// SetMode switches the active scheduling window.
func (s *Scheduler) SetMode(mode SchedulerMode) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.ratios[mode]; ok {
		s.mode = mode
	}
}

// Mode returns the current scheduling mode.
func (s *Scheduler) Mode() SchedulerMode {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.mode
}

// NextTx selects the next packet per configured policy.
func (s *Scheduler) NextTx() (*TxPacket, QueueType, bool) {
	s.mu.Lock()
	weights := s.currentWeightsLocked()
	s.clearDeficit += weights.Clear
	s.taxDeficit += weights.Tax

	clearLen := s.clearQueue.Len()
	taxLen := s.taxQueue.Len()

	if clearLen == 0 && taxLen == 0 {
		s.mu.Unlock()
		return nil, "", false
	}

	var chosen QueueType
	switch {
	case clearLen == 0:
		chosen = QueueTAXGOV
	case taxLen == 0:
		chosen = QueueCLEAR
	default:
		totalLen := float64(clearLen + taxLen)
		clearUtil := float64(clearLen) / totalLen
		taxUtil := float64(taxLen) / totalLen

		if clearUtil >= s.policy.ClearThreshold && clearUtil >= taxUtil {
			chosen = QueueCLEAR
		} else if taxUtil >= s.policy.TaxGovThreshold && taxUtil >= clearUtil {
			chosen = QueueTAXGOV
		} else {
			weightedClear := s.clearDeficit * s.policy.ClearPriorityWeight
			if weightedClear >= s.taxDeficit {
				chosen = QueueCLEAR
			} else {
				chosen = QueueTAXGOV
			}
		}
	}
	s.mu.Unlock()

	var pkt *TxPacket
	var ok bool
	switch chosen {
	case QueueCLEAR:
		pkt, ok = s.clearQueue.Pop()
	default:
		pkt, ok = s.taxQueue.Pop()
	}
	if !ok {
		if chosen == QueueCLEAR {
			pkt, ok = s.taxQueue.Pop()
			if ok {
				chosen = QueueTAXGOV
			}
		} else {
			pkt, ok = s.clearQueue.Pop()
			if ok {
				chosen = QueueCLEAR
			}
		}
		if !ok {
			return nil, "", false
		}
	}

	if pkt != nil {
		pkt.LastAttempt = s.clock()
	}

	s.mu.Lock()
	switch chosen {
	case QueueCLEAR:
		s.clearDeficit -= 1
		s.clearDispatch++
	default:
		s.taxDeficit -= 1
		s.taxDispatch++
	}
	s.mu.Unlock()

	return pkt, chosen, true
}

// ApplyBackpressure exponentially delays TAX-GOV packets to honour CLEAR priority.
func (s *Scheduler) ApplyBackpressure(pkt *TxPacket) time.Duration {
	if pkt == nil {
		return 0
	}

	s.mu.Lock()
	pkt.Attempts++
	attempt := pkt.Attempts
	minDelay := s.policy.BackpressureDelayMin
	maxDelay := s.policy.BackpressureDelayMax
	clock := s.clock
	s.mu.Unlock()

	scale := 1 << (attempt - 1)
	delay := minDelay * time.Duration(scale)
	if delay > maxDelay {
		delay = maxDelay
	}
	readyAt := clock().Add(delay)
	s.taxQueue.DelayInsert(pkt, readyAt)
	return delay
}

// DispatchRatio returns the cumulative CLEAR/TAX dispatch ratio.
func (s *Scheduler) DispatchRatio() (float64, float64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	total := float64(s.clearDispatch + s.taxDispatch)
	if total == 0 {
		return 0, 0
	}
	return float64(s.clearDispatch) / total, float64(s.taxDispatch) / total
}

// Stats exposes cumulative dispatch counts.
func (s *Scheduler) Stats() (clear uint64, tax uint64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.clearDispatch, s.taxDispatch
}

func (s *Scheduler) currentWeightsLocked() modeRatio {
	if ratio, ok := s.ratios[s.mode]; ok {
		return ratio
	}
	return s.ratios[ModeNormal]
}
