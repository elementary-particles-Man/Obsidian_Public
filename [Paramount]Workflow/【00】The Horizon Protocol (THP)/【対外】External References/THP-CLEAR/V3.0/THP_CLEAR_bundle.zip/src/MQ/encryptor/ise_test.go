package encryptor

import (
	"encoding/hex"
	"testing"
)

func TestISEApplyRoundTrip(t *testing.T) {
	key := []byte{0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80}
	p, err := NewISEPlan(key)
	if err != nil {
		t.Fatalf("failed to construct plan: %v", err)
	}

	plain := []byte("witness-ledger")
	ciphertext := p.Apply(plain, true) // 初回暗号化（順逆反転）
	if len(ciphertext) != len(plain) {
		t.Fatalf("ciphertext length mismatch: got %d, want %d", len(ciphertext), len(plain))
	}

	recovered := p.Apply(ciphertext, false) // 順逆ビット通り＝検証
	if string(recovered) != string(plain) {
		t.Fatalf("recovered mismatch: got %q, want %q", recovered, plain)
	}

	if string(plain) != "witness-ledger" {
		t.Fatalf("plain slice was modified: %q", plain)
	}
}

func TestISEDeterministicPlan(t *testing.T) {
	key := []byte{0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF}
	p, err := NewISEPlan(key)
	if err != nil {
		t.Fatalf("failed to construct plan: %v", err)
	}

	plain := []byte("CLEAR-LIFELINE")
	ciphertext := p.Apply(plain, true)

	const expectedHex = "8c6d4cccae416dcd2c4c6dcd2d4c"
	if got := hex.EncodeToString(ciphertext); got != expectedHex {
		t.Fatalf("unexpected ciphertext: got %s, want %s", got, expectedHex)
	}
}

func TestISEDifferentKeysDiffer(t *testing.T) {
	key1 := []byte{0x56, 0x47, 0x38, 0x29, 0x1A, 0x0B, 0xFC, 0xED}
	key2 := []byte{0x56, 0x47, 0x38, 0x29, 0x1A, 0x0B, 0xFC, 0xEE}

	p1, err := NewISEPlan(key1)
	if err != nil {
		t.Fatalf("failed to construct plan 1: %v", err)
	}
	p2, err := NewISEPlan(key2)
	if err != nil {
		t.Fatalf("failed to construct plan 2: %v", err)
	}

	input := []byte("mq-sequence-check")

	out1 := p1.Apply(input, true)
	out2 := p2.Apply(input, true)

	if hex.EncodeToString(out1) == hex.EncodeToString(out2) {
		t.Fatalf("ciphertexts should differ for different keys")
	}
}
