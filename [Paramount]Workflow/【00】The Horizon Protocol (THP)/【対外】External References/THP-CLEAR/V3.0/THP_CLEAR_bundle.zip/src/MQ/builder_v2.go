package MQ

import (
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"time"

	"thp-clear/src/crypto"
	"thp-clear/src/model"
)

// MaterialProvider surfaces the key sources (KMS/TPM abstraction).
type MaterialProvider interface {
	FetchMaterial(ctx context.Context) (*KeyMaterial, error)
}

// KeyMaterial combines AES session key, ISE keys, and TPM handle metadata.
type KeyMaterial struct {
	AESKey    [crypto.AES256KeySize]byte
	MgmtKey   [crypto.ISEKeySize]byte
	PayKey    [crypto.ISEKeySize]byte
	TPMHandle [16]byte
}

// StaticMaterialProvider is a helper for tests or deterministic configs.
type StaticMaterialProvider struct {
	Material KeyMaterial
}

// FetchMaterial returns the static material.
func (s *StaticMaterialProvider) FetchMaterial(context.Context) (*KeyMaterial, error) {
	return &s.Material, nil
}

// BuildRequest captures the upstream payload used to construct packets.
type BuildRequest struct {
	FromID      uint64
	ToID        uint64
	AssetCode   uint32
	CurrencyNum uint16
	AmountMinor int64
	FeeMinor    int32
	Timestamp   time.Time
	TxID        uint64
	Flags       model.PacketFlags

	SigMgmt [64]byte
	SigPay  [64]byte

	// Optional override for KeyMaterial; if nil the provider is used.
	MaterialOverride *KeyMaterial
}

// PacketBuilder assembles THP v2.2 packets by fusing keys and payloads.
type PacketBuilder struct {
	materials MaterialProvider
}

// NewPacketBuilder constructs the builder.
func NewPacketBuilder(provider MaterialProvider) (*PacketBuilder, error) {
	if provider == nil {
		return nil, errors.New("mq builder: material provider required")
	}
	return &PacketBuilder{
		materials: provider,
	}, nil
}

// Build creates an encrypted packet and returns both wire bytes and plaintext body.
func (b *PacketBuilder) Build(ctx context.Context, req BuildRequest) (*model.PacketCipher, *model.PacketBody, error) {
	if b == nil {
		return nil, nil, errors.New("mq builder: nil builder")
	}
	mat, err := b.resolveMaterial(ctx, req.MaterialOverride)
	if err != nil {
		return nil, nil, err
	}

	// Fill header defaults.
	header := model.PacketHeader{
		TxID:         req.TxID,
		TimestampISE: model.Millis(req.Timestamp),
		FromID:       req.FromID,
		ToID:         req.ToID,
		AssetCode:    req.AssetCode,
		CurrencyNum:  req.CurrencyNum,
		AmountMinor:  req.AmountMinor,
		FeeMinor:     req.FeeMinor,
		Flags:        req.Flags,
	}
	if header.TimestampISE == 0 {
		header.TimestampISE = model.Millis(time.Now().UTC())
	}
	if header.TxID == 0 {
		header.TxID = randomUint64()
	}
	if header.AssetCode&0x80000000 != 0 {
		header.Flags2 = model.PacketFlags2Exchange
	}

	body := &model.PacketBody{
		Header: header,
		KeyBlock: model.PacketKeyBlock{
			MgmtKeyISE: mat.MgmtKey,
			PayKeyISE:  mat.PayKey,
		},
		SignatureBlock: model.PacketSignatureBlock{
			SigMgmt: req.SigMgmt,
			SigPay:  req.SigPay,
		},
		Control: model.PacketControlBlock{
			TPMHandle: mat.TPMHandle,
		},
	}
	body.Control.H = body.IdempotencyHash()

	plain, err := body.MarshalBinary()
	if err != nil {
		return nil, nil, err
	}

	aesgcm, err := crypto.NewAES256GCM(mat.AESKey[:])
	if err != nil {
		return nil, nil, err
	}
	aad := buildAAD(body.Header.TxID, body.Header.TimestampISE)
	iv, ciphertext, tag, err := aesgcm.Encrypt(plain, aad[:])
	if err != nil {
		return nil, nil, fmt.Errorf("mq builder: encrypt: %w", err)
	}
	var cipher model.PacketCipher
	cipher.IV = iv
	cipher.Tag = tag
	copy(cipher.Ciphertext[:], ciphertext)
	cipher.UpdateCRC()
	return &cipher, body, nil
}

func (b *PacketBuilder) resolveMaterial(ctx context.Context, override *KeyMaterial) (*KeyMaterial, error) {
	if override != nil {
		return override, nil
	}
	mat, err := b.materials.FetchMaterial(ctx)
	if err != nil {
		return nil, fmt.Errorf("mq builder: material fetch: %w", err)
	}
	if mat == nil {
		return nil, errors.New("mq builder: provider returned nil material")
	}
	return mat, nil
}

func randomUint64() uint64 {
	var buf [8]byte
	if _, err := rand.Read(buf[:]); err != nil {
		panic(fmt.Errorf("mq builder: rand: %w", err))
	}
	return binary.BigEndian.Uint64(buf[:])
}

func buildAAD(txID, timestamp uint64) [17]byte {
	var aad [17]byte
	binary.BigEndian.PutUint64(aad[0:8], txID)
	binary.BigEndian.PutUint64(aad[8:16], timestamp)
	aad[16] = model.PacketVersion
	return aad
}
