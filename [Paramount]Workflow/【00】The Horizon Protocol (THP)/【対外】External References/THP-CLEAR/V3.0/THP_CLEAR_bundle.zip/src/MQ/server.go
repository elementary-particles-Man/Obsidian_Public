// Package MQ contains the prototype message queue daemon used by the legacy CLEAR stack.
// It shows how envelopes are accepted from the API tier, encrypted with ISE, and dispatched
// to worker nodes while keeping key rotation state locally. The production implementation
// lives in `internal/messaging`, but this package remains as documentation and integration
// test scaffold for the microservice split.
package MQ
