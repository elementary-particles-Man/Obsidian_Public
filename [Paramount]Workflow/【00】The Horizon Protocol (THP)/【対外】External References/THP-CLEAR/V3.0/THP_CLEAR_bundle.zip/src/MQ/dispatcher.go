package MQ

import (
	"context"
	"sync"
	"time"
)

// PacketHandler defines the consumer contract for dispatched packets.
type PacketHandler interface {
	Handle(context.Context, *TxPacket) error
}

// PacketHandlerFunc adapts a function into a PacketHandler.
type PacketHandlerFunc func(context.Context, *TxPacket) error

// Handle invokes f(ctx, pkt).
func (f PacketHandlerFunc) Handle(ctx context.Context, pkt *TxPacket) error {
	return f(ctx, pkt)
}

// EventEmitter delivers dispatcher lifecycle events.
type EventEmitter func(event string, fields map[string]interface{})

// Dispatcher coordinates queue polling, scheduling, metrics, and event emission.
type Dispatcher struct {
	scheduler               *Scheduler
	handler                 PacketHandler
	metrics                 *DispatcherMetrics
	eventFn                 EventEmitter
	maxBackpressureAttempts int
	idleSleep               time.Duration
	clock                   Clock
	sleepFn                 func(time.Duration)
}

// DispatcherOption configures optional Dispatcher behaviour.
type DispatcherOption func(*Dispatcher)

// WithEventEmitter wires the dispatcher event hook.
func WithEventEmitter(fn EventEmitter) DispatcherOption {
	return func(d *Dispatcher) { d.eventFn = fn }
}

// WithIdleSleep overrides the idle loop sleep duration.
func WithIdleSleep(dur time.Duration) DispatcherOption {
	return func(d *Dispatcher) { d.idleSleep = dur }
}

// WithMaxBackpressureAttempts adjusts the number of times a TAX packet can be delayed.
func WithMaxBackpressureAttempts(n int) DispatcherOption {
	return func(d *Dispatcher) {
		if n > 0 {
			d.maxBackpressureAttempts = n
		}
	}
}

// WithClock overrides the dispatcher clock (testing).
func WithClock(clk Clock) DispatcherOption {
	return func(d *Dispatcher) {
		if clk != nil {
			d.clock = clk
		}
	}
}

// WithSleepFunc injects a custom sleep function (testing).
func WithSleepFunc(fn func(time.Duration)) DispatcherOption {
	return func(d *Dispatcher) {
		if fn != nil {
			d.sleepFn = fn
		}
	}
}

// NewDispatcher constructs a dispatcher with the supplied scheduler and handler.
func NewDispatcher(s *Scheduler, handler PacketHandler, opts ...DispatcherOption) *Dispatcher {
	if s == nil {
		panic("dispatcher: scheduler must not be nil")
	}
	d := &Dispatcher{
		scheduler:               s,
		handler:                 handler,
		metrics:                 &DispatcherMetrics{},
		maxBackpressureAttempts: 5,
		idleSleep:               5 * time.Millisecond,
		clock:                   s.clock,
		sleepFn:                 time.Sleep,
	}
	for _, opt := range opts {
		opt(d)
	}
	if d.clock == nil {
		d.clock = defaultClock
	}
	return d
}

// Metrics exposes dispatcher metrics (thread-safe).
func (d *Dispatcher) Metrics() *DispatcherMetrics {
	return d.metrics
}

// Run executes the dispatch loop until the context is cancelled.
func (d *Dispatcher) Run(ctx context.Context) {
	for {
		if ctx.Err() != nil {
			return
		}

		pkt, queue, ok := d.scheduler.NextTx()
		clearLen := d.scheduler.clearQueue.Len()
		taxLen := d.scheduler.taxQueue.Len()
		d.metrics.UpdateQueueLens(clearLen, taxLen)

		if !ok {
			d.sleepFn(d.idleSleep)
			continue
		}

		if queue == QueueTAXGOV {
			clearRatio, _ := d.scheduler.DispatchRatio()
			if clearRatio > 0.9 && pkt.Attempts < d.maxBackpressureAttempts && clearLen > taxLen {
				delay := d.scheduler.ApplyBackpressure(pkt)
				d.metrics.IncBackpressure()
				if d.eventFn != nil {
					d.eventFn("TAX_BACKPRESSURE", map[string]interface{}{
						"packet_id": pkt.ID,
						"attempt":   pkt.Attempts,
						"delay_ms":  delay.Milliseconds(),
					})
				}
				// Refresh queue lens after requeue
				clearLen = d.scheduler.clearQueue.Len()
				taxLen = d.scheduler.taxQueue.Len()
				d.metrics.UpdateQueueLens(clearLen, taxLen)
				continue
			}
		}

		dispatchStart := d.clock()
		if d.handler != nil && pkt != nil {
			_ = d.handler.Handle(ctx, pkt)
		}
		if pkt != nil {
			if pkt.Attempts > 0 {
				pkt.Attempts = 0
			}
			latency := dispatchStart.Sub(pkt.EnqueuedAt)
			if latency < 0 {
				latency = 0
			}
			d.metrics.ObserveLatency(latency)
		}
	}
}

// DispatcherMetrics aggregates basic queue and latency statistics.
type DispatcherMetrics struct {
	mu                sync.Mutex
	clearQueueLen     int
	taxQueueLen       int
	backpressureCount int
	totalLatency      time.Duration
	dispatched        int64
}

// UpdateQueueLens records the current queue lengths.
func (m *DispatcherMetrics) UpdateQueueLens(clearLen, taxLen int) {
	m.mu.Lock()
	m.clearQueueLen = clearLen
	m.taxQueueLen = taxLen
	m.mu.Unlock()
}

// ObserveLatency accumulates latency for dispatched packets.
func (m *DispatcherMetrics) ObserveLatency(latency time.Duration) {
	m.mu.Lock()
	m.totalLatency += latency
	m.dispatched++
	m.mu.Unlock()
}

// IncBackpressure increments the backpressure counter.
func (m *DispatcherMetrics) IncBackpressure() {
	m.mu.Lock()
	m.backpressureCount++
	m.mu.Unlock()
}

// Snapshot returns a point-in-time copy of dispatcher metrics.
func (m *DispatcherMetrics) Snapshot() DispatcherMetricsSnapshot {
	m.mu.Lock()
	defer m.mu.Unlock()
	var avg time.Duration
	if m.dispatched > 0 {
		avg = time.Duration(int64(m.totalLatency) / m.dispatched)
	}
	return DispatcherMetricsSnapshot{
		ClearQueueLen:     m.clearQueueLen,
		TaxGovQueueLen:    m.taxQueueLen,
		AvgLatency:        avg,
		BackpressureCount: m.backpressureCount,
		TotalDispatched:   m.dispatched,
	}
}

// DispatcherMetricsSnapshot describes dispatcher state for observation.
type DispatcherMetricsSnapshot struct {
	ClearQueueLen     int
	TaxGovQueueLen    int
	AvgLatency        time.Duration
	BackpressureCount int
	TotalDispatched   int64
}
