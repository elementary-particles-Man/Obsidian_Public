package WN

import (
	"crypto/sha256"

	intcrypto "thp-clear/internal/crypto"
)

// SignRemote はKeyHubに署名を委譲するヘルパー。
// 成功時は署名と公開鍵（いずれもバイト列）を返します。
func SignRemote(endpoint string, data []byte) ([]byte, []byte, error) {
	hash := sha256.Sum256(data)
	sig, pub, _, err := intcrypto.KeyHubSign(endpoint, hash[:])
	if err != nil {
		return nil, nil, err
	}
	return sig, pub, nil
}
