package WN

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"errors"
	"fmt"

	"thp-clear/src/crypto"
	"thp-clear/src/model"
)

var (
	errVoidCurrencyMismatch   = errors.New("wn: voidcoin currency mismatch")
	errVoidFeeInvalid         = errors.New("wn: voidcoin fee must be zero")
	errVoidExchangeRequired   = errors.New("wn: EXCHANGE_ONLY_REQUIRED")
	errVoidExchangeToExchange = errors.New("wn: VOID_TO_VOID_FORBIDDEN")
	errHeaderMalformed        = errors.New("wn: packet header malformed")
	errVersionMismatch        = errors.New("wn: unsupported packet version")
)

// VoidRules describes the runtime policy for VoidCoin handling.
type VoidRules struct {
	CurrencyNum      uint16
	FeeMinor         int32
	ExchangeNodeIDs  map[uint64]struct{}
	ForbidVoidToVoid bool
}

// ProcessRequest groups dependencies required to process a packet.
type ProcessRequest struct {
	PacketBytes   []byte
	AESKey        [crypto.AES256KeySize]byte
	MgmtPublicKey []byte
	PayPublicKey  []byte
	SeqNo         uint64
	VoidRules     VoidRules
}

// ProcessResult returns the decrypted body and witness metadata.
type ProcessResult struct {
	Body    *model.PacketBody
	Witness *model.WitnessRecord128
}

// Processor handles decrypt/verify logic for worker nodes.
type Processor struct{}

// NewProcessor constructs the processor.
func NewProcessor() *Processor {
	return &Processor{}
}

// Process executes AES-GCM open, signature verification, and witness generation.
func (p *Processor) Process(ctx context.Context, req ProcessRequest) (*ProcessResult, error) {
	if p == nil {
		return nil, errors.New("wn: nil processor")
	}
	_ = ctx
	if len(req.PacketBytes) != model.PacketTotalSize {
		return nil, fmt.Errorf("wn: invalid packet size %d", len(req.PacketBytes))
	}

	packet, err := model.UnmarshalPacketCipher(req.PacketBytes)
	if err != nil {
		return nil, err
	}
	if !packet.ValidateCRC() {
		return nil, errors.New("wn: header crc mismatch")
	}

	block, err := aes.NewCipher(req.AESKey[:])
	if err != nil {
		return nil, err
	}

	preview := decryptCTR(block, packet.IV, packet.Ciphertext[:])
	txID, timestamp, version, err := extractAADFields(preview)
	if err != nil {
		return nil, err
	}
	if version != model.PacketVersion {
		return nil, errVersionMismatch
	}

	aad := buildAAD(txID, timestamp, version)
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}

	combined := append(packet.Ciphertext[:], packet.Tag[:]...)
	plain, err := gcm.Open(nil, packet.IV[:], combined, aad[:])
	if err != nil {
		return nil, fmt.Errorf("wn: decrypt: %w", err)
	}

	var body model.PacketBody
	if err := body.UnmarshalBinary(plain); err != nil {
		return nil, fmt.Errorf("wn: unmarshal body: %w", err)
	}

	expected := body.IdempotencyHash()
	if body.Control.H != expected {
		return nil, errors.New("wn: idempotency hash mismatch")
	}

	if len(req.MgmtPublicKey) > 0 {
		if err := crypto.VerifyEd25519(req.MgmtPublicKey, plain, body.SignatureBlock.SigMgmt[:]); err != nil {
			return nil, fmt.Errorf("wn: mgmt signature invalid: %w", err)
		}
	}
	if len(req.PayPublicKey) > 0 {
		if err := crypto.VerifyEd25519(req.PayPublicKey, plain, body.SignatureBlock.SigPay[:]); err != nil {
			return nil, fmt.Errorf("wn: pay signature invalid: %w", err)
		}
	}

	if err := validateVoidCoinRules(&body.Header, req.VoidRules); err != nil {
		return nil, err
	}

	witness := model.WitnessFromPacket(&body, req.SeqNo, model.WitnessFlags{OK: true})
	return &ProcessResult{
		Body:    &body,
		Witness: witness,
	}, nil
}

func decryptCTR(block cipher.Block, iv [12]byte, ciphertext []byte) []byte {
	counter := make([]byte, 16)
	copy(counter[:12], iv[:])
	binary.BigEndian.PutUint32(counter[12:], 2)
	stream := cipher.NewCTR(block, counter)
	plain := make([]byte, len(ciphertext))
	stream.XORKeyStream(plain, ciphertext)
	return plain
}

func extractAADFields(buf []byte) (txID uint64, timestamp uint64, version uint8, err error) {
	if len(buf) < 48 {
		return 0, 0, 0, errHeaderMalformed
	}
	if string(buf[0:4]) != "TCF2" {
		return 0, 0, 0, errHeaderMalformed
	}
	version = buf[4]
	txID = binary.BigEndian.Uint64(buf[8:16])
	timestamp = binary.BigEndian.Uint64(buf[16:24])
	return txID, timestamp, version, nil
}

func buildAAD(txID, timestamp uint64, version uint8) [17]byte {
	var aad [17]byte
	binary.BigEndian.PutUint64(aad[0:8], txID)
	binary.BigEndian.PutUint64(aad[8:16], timestamp)
	aad[16] = version
	return aad
}

func validateVoidCoinRules(header *model.PacketHeader, rules VoidRules) error {
	if header == nil {
		return errors.New("wn: header missing")
	}
	if !isVoidAsset(header.AssetCode) {
		return nil
	}
	if rules.CurrencyNum != 0 && header.CurrencyNum != rules.CurrencyNum {
		return errVoidCurrencyMismatch
	}
	if header.FeeMinor != rules.FeeMinor {
		return errVoidFeeInvalid
	}
	if !header.ExchangeFlag() {
		return errVoidExchangeRequired
	}

	fromExchange := rules.isExchangeNode(header.FromID)
	toExchange := rules.isExchangeNode(header.ToID)
	if !fromExchange && !toExchange {
		return errVoidExchangeRequired
	}
	if rules.ForbidVoidToVoid && fromExchange && toExchange {
		return errVoidExchangeToExchange
	}
	return nil
}

func (v VoidRules) isExchangeNode(id uint64) bool {
	if len(v.ExchangeNodeIDs) == 0 {
		return false
	}
	_, ok := v.ExchangeNodeIDs[id]
	return ok
}

func isVoidAsset(assetCode uint32) bool {
	return assetCode&0x80000000 != 0
}
