package e20

type Transfer struct {
	ChainID   int64
	Contract  string
	BlockNum  uint64
	TxHash    string
	From      string
	To        string
	AmountWei string
	LogIndex  uint
}

type TokenMeta struct {
	Contract string
	Symbol   string
	Decimals uint8
}
