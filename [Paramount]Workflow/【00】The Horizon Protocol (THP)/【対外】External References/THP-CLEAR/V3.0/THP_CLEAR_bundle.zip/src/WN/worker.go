// Package WN provides the worker-node reference implementation for external ledger ingestion.
// The worker consumes encrypted envelopes from the MQ prototype, verifies asset finality via
// the `e20.Adapter`, generates Witness payloads, and submits them to the DB service stub.
// Although production ingestion runs inside `internal/settlement`, this package documents the
// responsibilities when the worker is promoted to an independent microservice.
package WN
