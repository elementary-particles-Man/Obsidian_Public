package e20

type Adapter interface {
	Confirmed(txHash string, depth uint64) (bool, uint64, error)
	GetTransferByTx(txHash string) (*Transfer, error)
	GetTokenMeta(contract string) (*TokenMeta, error)
}
