package WN

import (
	"bytes"
	"context"
	"crypto/aes"
	"errors"
	"testing"
	"time"

	"thp-clear/src/MQ"
	"thp-clear/src/crypto"
	"thp-clear/src/model"
)

func TestProcessorStable(t *testing.T) {
	var mat MQ.KeyMaterial
	fillBytes(mat.AESKey[:], 0x01)
	fillBytes(mat.MgmtKey[:], 0x11)
	fillBytes(mat.PayKey[:], 0x21)

	builder, err := MQ.NewPacketBuilder(&MQ.StaticMaterialProvider{Material: mat})
	if err != nil {
		t.Fatalf("builder: %v", err)
	}

	req := MQ.BuildRequest{
		FromID:      1,
		ToID:        2,
		AssetCode:   3,
		CurrencyNum: 392,
		AmountMinor: 1000,
		FeeMinor:    10,
	}

	packetCipher, body, err := builder.Build(context.Background(), req)
	if err != nil {
		t.Fatalf("build: %v", err)
	}

	wire, err := packetCipher.MarshalBinary()
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}

	processor := NewProcessor()
	block, err := aes.NewCipher(mat.AESKey[:])
	if err != nil {
		t.Fatalf("cipher: %v", err)
	}
	preview := decryptCTR(block, packetCipher.IV, packetCipher.Ciphertext[:])
	if string(preview[:4]) != "TCF2" {
		bodyBytes, _ := body.MarshalBinary()
		if !bytes.Equal(preview, bodyBytes) {
			t.Fatalf("preview mismatch, first bytes %x", preview[:4])
		}
	}
	res, err := processor.Process(context.Background(), ProcessRequest{
		PacketBytes: wire,
		AESKey:      mat.AESKey,
		SeqNo:       1,
		VoidRules: VoidRules{
			FeeMinor: 0,
		},
	})
	if err != nil {
		t.Fatalf("process: %v", err)
	}

	if res.Body.Header.FromID != body.Header.FromID {
		t.Fatalf("from id mismatch")
	}
	if res.Witness == nil || res.Witness.TxID != body.Header.TxID {
		t.Fatalf("witness mismatch")
	}
}

func TestVoidCoinRules(t *testing.T) {
	var mat MQ.KeyMaterial
	fillBytes(mat.AESKey[:], 0x02)
	fillBytes(mat.MgmtKey[:], 0x12)
	fillBytes(mat.PayKey[:], 0x22)

	exchangeID := uint64(0x0001000000000001)
	otherExchangeID := uint64(0x0001000000000002)
	userID := uint64(0x0002000000000001)
	outsiderID := uint64(0x0003000000000001)

	voidRules := VoidRules{
		CurrencyNum:      65535,
		FeeMinor:         0,
		ExchangeNodeIDs:  map[uint64]struct{}{exchangeID: {}, otherExchangeID: {}},
		ForbidVoidToVoid: true,
	}

	tests := []struct {
		name         string
		fromID       uint64
		toID         uint64
		exchangeFlag bool
		rules        VoidRules
		expectErr    error
	}{
		{
			name:         "missing exchange flag",
			fromID:       exchangeID,
			toID:         userID,
			exchangeFlag: false,
			rules:        voidRules,
			expectErr:    errVoidExchangeRequired,
		},
		{
			name:         "no exchange participants",
			fromID:       outsiderID,
			toID:         userID,
			exchangeFlag: true,
			rules:        voidRules,
			expectErr:    errVoidExchangeRequired,
		},
		{
			name:         "exchange to user ok",
			fromID:       exchangeID,
			toID:         userID,
			exchangeFlag: true,
			rules:        voidRules,
			expectErr:    nil,
		},
		{
			name:         "exchange to exchange forbidden",
			fromID:       exchangeID,
			toID:         otherExchangeID,
			exchangeFlag: true,
			rules:        voidRules,
			expectErr:    errVoidExchangeToExchange,
		},
	}

	for _, tc := range tests {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			wire, body := buildVoidPacket(t, mat, tc.fromID, tc.toID, tc.exchangeFlag)
			processor := NewProcessor()
			_, err := processor.Process(context.Background(), ProcessRequest{
				PacketBytes: wire,
				AESKey:      mat.AESKey,
				SeqNo:       99,
				VoidRules:   tc.rules,
			})

			if tc.expectErr == nil {
				if err != nil {
					t.Fatalf("unexpected error: %v", err)
				}
				if body.Header.ExchangeFlag() == false {
					t.Fatalf("exchange flag expected set")
				}
				return
			}
			if !errors.Is(err, tc.expectErr) {
				t.Fatalf("expected %v, got %v", tc.expectErr, err)
			}
		})
	}
}

func fillBytes(buf []byte, start byte) {
	for i := range buf {
		buf[i] = start + byte(i)
	}
}

func buildVoidPacket(t *testing.T, mat MQ.KeyMaterial, fromID, toID uint64, exchangeFlag bool) ([]byte, *model.PacketBody) {
	t.Helper()

	now := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)
	body := &model.PacketBody{
		Header: model.PacketHeader{
			TxID:         0x0102030405060708,
			TimestampISE: model.Millis(now),
			FromID:       fromID,
			ToID:         toID,
			AssetCode:    0x80000001,
			CurrencyNum:  65535,
			AmountMinor:  12345,
			FeeMinor:     0,
		},
	}
	if exchangeFlag {
		body.Header.Flags2 = model.PacketFlags2Exchange
	}

	copy(body.KeyBlock.MgmtKeyISE[:], mat.MgmtKey[:])
	copy(body.KeyBlock.PayKeyISE[:], mat.PayKey[:])
	body.Control.H = body.IdempotencyHash()

	plain, err := body.MarshalBinary()
	if err != nil {
		t.Fatalf("marshal body: %v", err)
	}

	aesgcm, err := crypto.NewAES256GCM(mat.AESKey[:])
	if err != nil {
		t.Fatalf("aes: %v", err)
	}
	aad := buildAAD(body.Header.TxID, body.Header.TimestampISE, model.PacketVersion)
	iv, ciphertext, tag, err := aesgcm.Encrypt(plain, aad[:])
	if err != nil {
		t.Fatalf("encrypt: %v", err)
	}

	var packet model.PacketCipher
	packet.IV = iv
	packet.Tag = tag
	copy(packet.Ciphertext[:], ciphertext)
	packet.UpdateCRC()

	wire, err := packet.MarshalBinary()
	if err != nil {
		t.Fatalf("marshal packet: %v", err)
	}
	return wire, body
}
