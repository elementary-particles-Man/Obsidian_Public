package model

import (
	"bytes"
	"testing"
)

func TestWitnessMarshalUnmarshal(t *testing.T) {
	rec := WitnessRecord128{
		TxID:         0x0102030405060708,
		TimestampISE: 0x1112131415161718,
		FromID:       0x2122232425262728,
		ToID:         0x3132333435363738,
		AssetCode:    0x7fff0123,
		CurrencyNum:  392,
		Flags: WitnessFlags{
			OK:        true,
			Mismatch:  false,
			Duplicate: true,
		},
		AmountMinor: 987654321012345678,
		FeeMinor:    4321,
		MgmtKeyISE:  bytesTo32(makeSequential(0x01)),
		PayKeyISE:   bytesTo32(makeSequential(0x21)),
		SeqNo:       99,
	}

	raw, err := rec.MarshalBinary()
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	if len(raw) != WitnessRecordSize {
		t.Fatalf("size mismatch: %d", len(raw))
	}

	var decoded WitnessRecord128
	if err := decoded.UnmarshalBinary(raw); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}

	if decoded.TxID != rec.TxID || decoded.TimestampISE != rec.TimestampISE {
		t.Fatalf("header mismatch")
	}
	if decoded.AssetCode != rec.AssetCode || decoded.CurrencyNum != rec.CurrencyNum {
		t.Fatalf("asset mismatch")
	}
	if decoded.AmountMinor != rec.AmountMinor || decoded.FeeMinor != rec.FeeMinor {
		t.Fatalf("amount mismatch")
	}
	if !bytes.Equal(decoded.MgmtKeyISE[:], rec.MgmtKeyISE[:]) {
		t.Fatalf("mgmt key mismatch")
	}
	if !bytes.Equal(decoded.PayKeyISE[:], rec.PayKeyISE[:]) {
		t.Fatalf("pay key mismatch")
	}
	if decoded.SeqNo != rec.SeqNo {
		t.Fatalf("seq mismatch")
	}
	if !decoded.Flags.OK || !decoded.Flags.Duplicate || decoded.Flags.Mismatch {
		t.Fatalf("flags mismatch: %#v", decoded.Flags)
	}
}

func TestWitnessFromPacket(t *testing.T) {
	body := PacketBody{
		Header: PacketHeader{
			TxID:         11,
			TimestampISE: 22,
			FromID:       33,
			ToID:         44,
			AssetCode:    55,
			CurrencyNum:  66,
			AmountMinor:  77,
			FeeMinor:     88,
		},
	}
	copy(body.KeyBlock.MgmtKeyISE[:], makeSequential(0x01)[:32])
	copy(body.KeyBlock.PayKeyISE[:], makeSequential(0x21)[:32])

	rec := WitnessFromPacket(&body, 123, WitnessFlags{OK: true})
	if rec == nil {
		t.Fatalf("expected record")
	}
	if rec.TxID != 11 || rec.TimestampISE != 22 {
		t.Fatalf("unexpected fields")
	}
	if rec.SeqNo != 123 {
		t.Fatalf("seq mismatch")
	}
	if !rec.Flags.OK {
		t.Fatalf("flags mismatch")
	}
	if rec.Flags.Mismatch || rec.Flags.Duplicate {
		t.Fatalf("unexpected flags")
	}
}
