package model

import (
	"encoding/binary"
	"errors"
	"fmt"
	"hash/crc32"
	"time"

	"golang.org/x/crypto/sha3"
)

const (
	// Packet constants derived from Implementation Directives v2.2.
	PacketVersion         uint8 = 2
	PacketDecimals        uint8 = 18
	PacketOuterHeaderSize       = 32
	PacketInnerBodySize         = 320
	PacketTotalSize             = PacketOuterHeaderSize + PacketInnerBodySize
	packetMagicString           = "TCF2"

	// PacketFlags2Exchange marks participation of an exchange node for VoidCoin transfers.
	PacketFlags2Exchange = 0x01
)

var (
	packetMagic = [4]byte{'T', 'C', 'F', '2'}

	crcTable = crc32.MakeTable(crc32.Castagnoli)
)

// PacketFlags is the 1-byte bitfield stored in Header.Flags.
// Bit 0: DUAL_SIGN, Bit 1: STRICT_ORDER.
type PacketFlags struct {
	DualSign    bool
	StrictOrder bool
}

// Byte renders the bitfield representation.
func (f PacketFlags) Byte() byte {
	var b byte
	if f.DualSign {
		b |= 0x01
	}
	if f.StrictOrder {
		b |= 0x02
	}
	return b
}

// FlagsFromByte parses the bitfield and returns the typed representation.
func FlagsFromByte(b byte) PacketFlags {
	return PacketFlags{
		DualSign:    b&0x01 == 0x01,
		StrictOrder: b&0x02 == 0x02,
	}
}

// PacketHeader mirrors the 64-byte header section of the inner body.
type PacketHeader struct {
	TxID         uint64
	TimestampISE uint64 // milliseconds since epoch UTC
	FromID       uint64
	ToID         uint64
	AssetCode    uint32
	CurrencyNum  uint16
	Flags        PacketFlags
	Flags2       uint8 // bit0=ExchangeFlag (Stable<->Void via exchange node), other bits reserved=0
	AmountMinor  int64
	FeeMinor     int32
}

// SetFlags updates the flags bitfield based on convenience booleans.
func (h *PacketHeader) SetFlags(flags PacketFlags) {
	h.Flags = flags
}

// ExchangeFlag reports whether the Flags2.ExchangeFlag bit is set.
func (h PacketHeader) ExchangeFlag() bool {
	return h.Flags2&PacketFlags2Exchange != 0
}

// PacketKeyBlock stores the pair of ISE keys exposed from TPM (Mgmt/Pay).
type PacketKeyBlock struct {
	MgmtKeyISE [32]byte
	PayKeyISE  [32]byte
}

// PacketSignatureBlock stores ed25519 signatures for management/payment paths.
type PacketSignatureBlock struct {
	SigMgmt [64]byte
	SigPay  [64]byte
}

// PacketControlBlock stores the idempotency hash and TPM handle metadata.
type PacketControlBlock struct {
	H         [32]byte
	TPMHandle [16]byte
	RsvPad    [16]byte
}

// PacketBody aggregates the inner body sections (total 320 bytes).
type PacketBody struct {
	Header         PacketHeader
	KeyBlock       PacketKeyBlock
	SignatureBlock PacketSignatureBlock
	Control        PacketControlBlock
}

// MarshalBinary encodes the packet body into its canonical 320 byte representation.
func (b *PacketBody) MarshalBinary() ([]byte, error) {
	if b == nil {
		return nil, errors.New("packet body is nil")
	}

	buf := make([]byte, PacketInnerBodySize)
	offset := 0

	copy(buf[offset:], packetMagic[:])
	offset += 4

	buf[offset] = PacketVersion
	offset++

	buf[offset] = b.Header.Flags.Byte()
	offset++

	// Reserved (u16)
	binary.BigEndian.PutUint16(buf[offset:], 0)
	offset += 2

	binary.BigEndian.PutUint64(buf[offset:], b.Header.TxID)
	offset += 8

	binary.BigEndian.PutUint64(buf[offset:], b.Header.TimestampISE)
	offset += 8

	binary.BigEndian.PutUint64(buf[offset:], b.Header.FromID)
	offset += 8

	binary.BigEndian.PutUint64(buf[offset:], b.Header.ToID)
	offset += 8

	binary.BigEndian.PutUint32(buf[offset:], b.Header.AssetCode)
	offset += 4

	binary.BigEndian.PutUint16(buf[offset:], b.Header.CurrencyNum)
	offset += 2

	buf[offset] = PacketDecimals
	offset++

	buf[offset] = b.Header.Flags2
	offset++

	binary.BigEndian.PutUint64(buf[offset:], uint64(b.Header.AmountMinor))
	offset += 8

	binary.BigEndian.PutUint32(buf[offset:], uint32(b.Header.FeeMinor))
	offset += 4

	binary.BigEndian.PutUint32(buf[offset:], 0) // Rsv3
	offset += 4

	copy(buf[offset:], b.KeyBlock.MgmtKeyISE[:])
	offset += 32
	copy(buf[offset:], b.KeyBlock.PayKeyISE[:])
	offset += 32

	copy(buf[offset:], b.SignatureBlock.SigMgmt[:])
	offset += 64
	copy(buf[offset:], b.SignatureBlock.SigPay[:])
	offset += 64

	copy(buf[offset:], b.Control.H[:])
	offset += 32
	copy(buf[offset:], b.Control.TPMHandle[:])
	offset += 16
	copy(buf[offset:], b.Control.RsvPad[:])
	offset += 16

	if offset != PacketInnerBodySize {
		return nil, fmt.Errorf("packet body marshal size mismatch: got %d want %d", offset, PacketInnerBodySize)
	}

	return buf, nil
}

// UnmarshalBinary parses the canonical inner body representation.
func (b *PacketBody) UnmarshalBinary(data []byte) error {
	if len(data) != PacketInnerBodySize {
		return fmt.Errorf("packet body size mismatch: got %d want %d", len(data), PacketInnerBodySize)
	}
	if b == nil {
		return errors.New("packet body is nil")
	}

	offset := 0
	if string(data[offset:offset+4]) != packetMagicString {
		return errors.New("packet body: magic mismatch")
	}
	offset += 4

	version := data[offset]
	if version != PacketVersion {
		return fmt.Errorf("packet body: version mismatch %d", version)
	}
	offset++

	flags := data[offset]
	b.Header.Flags = FlagsFromByte(flags)
	offset++

	offset += 2 // reserved

	b.Header.TxID = binary.BigEndian.Uint64(data[offset:])
	offset += 8
	b.Header.TimestampISE = binary.BigEndian.Uint64(data[offset:])
	offset += 8
	b.Header.FromID = binary.BigEndian.Uint64(data[offset:])
	offset += 8
	b.Header.ToID = binary.BigEndian.Uint64(data[offset:])
	offset += 8
	b.Header.AssetCode = binary.BigEndian.Uint32(data[offset:])
	offset += 4
	b.Header.CurrencyNum = binary.BigEndian.Uint16(data[offset:])
	offset += 2

	decimals := data[offset]
	if decimals != PacketDecimals {
		return fmt.Errorf("packet body: decimals mismatch %d", decimals)
	}
	offset++

	flags2 := data[offset]
	if flags2&^PacketFlags2Exchange != 0 {
		return errors.New("packet body: flags2 reserved bits set")
	}
	b.Header.Flags2 = flags2
	offset++

	b.Header.AmountMinor = int64(binary.BigEndian.Uint64(data[offset:]))
	offset += 8

	b.Header.FeeMinor = int32(binary.BigEndian.Uint32(data[offset:]))
	offset += 4

	offset += 4 // Rsv3

	copy(b.KeyBlock.MgmtKeyISE[:], data[offset:offset+32])
	offset += 32
	copy(b.KeyBlock.PayKeyISE[:], data[offset:offset+32])
	offset += 32

	copy(b.SignatureBlock.SigMgmt[:], data[offset:offset+64])
	offset += 64
	copy(b.SignatureBlock.SigPay[:], data[offset:offset+64])
	offset += 64

	copy(b.Control.H[:], data[offset:offset+32])
	offset += 32
	copy(b.Control.TPMHandle[:], data[offset:offset+16])
	offset += 16
	copy(b.Control.RsvPad[:], data[offset:offset+16])
	return nil
}

// IdempotencyHash computes SHA3-256(TxID || Timestamp_ISE).
func (b *PacketBody) IdempotencyHash() [32]byte {
	var buf [16]byte
	binary.BigEndian.PutUint64(buf[0:8], b.Header.TxID)
	binary.BigEndian.PutUint64(buf[8:16], b.Header.TimestampISE)
	return sha3.Sum256(buf[:])
}

// PacketCipher carries the encrypted representation (320 bytes cipher text).
type PacketCipher struct {
	IV         [12]byte
	Tag        [16]byte
	HdrCRC     uint32
	Ciphertext [PacketInnerBodySize]byte
}

// MarshalBinary renders the 352B packet.
func (p *PacketCipher) MarshalBinary() ([]byte, error) {
	if p == nil {
		return nil, errors.New("packet cipher is nil")
	}

	buf := make([]byte, PacketTotalSize)
	offset := 0
	copy(buf[offset:], p.IV[:])
	offset += len(p.IV)
	copy(buf[offset:], p.Tag[:])
	offset += len(p.Tag)
	binary.BigEndian.PutUint32(buf[offset:], p.HdrCRC)
	offset += 4
	copy(buf[offset:], p.Ciphertext[:])
	return buf, nil
}

// ComputeCRC recalculates the CRC32 (Castagnoli) over the ciphertext.
func (p *PacketCipher) ComputeCRC() uint32 {
	return crc32.Checksum(p.Ciphertext[:], crcTable)
}

// UpdateCRC updates HdrCRC to match the current ciphertext.
func (p *PacketCipher) UpdateCRC() {
	p.HdrCRC = p.ComputeCRC()
}

// ValidateCRC checks whether stored CRC matches computed CRC.
func (p *PacketCipher) ValidateCRC() bool {
	return p.HdrCRC == p.ComputeCRC()
}

// UnmarshalPacketCipher parses a raw 352B packet into the cipher representation.
func UnmarshalPacketCipher(data []byte) (*PacketCipher, error) {
	if len(data) != PacketTotalSize {
		return nil, fmt.Errorf("packet size mismatch: got %d want %d", len(data), PacketTotalSize)
	}
	p := &PacketCipher{}
	offset := 0
	copy(p.IV[:], data[offset:offset+len(p.IV)])
	offset += len(p.IV)
	copy(p.Tag[:], data[offset:offset+len(p.Tag)])
	offset += len(p.Tag)
	p.HdrCRC = binary.BigEndian.Uint32(data[offset:])
	offset += 4
	copy(p.Ciphertext[:], data[offset:])
	return p, nil
}

// Millis returns the current timestamp in milliseconds UTC.
func Millis(t time.Time) uint64 {
	return uint64(t.UnixNano() / int64(time.Millisecond))
}
