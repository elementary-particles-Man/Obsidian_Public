package model

import (
	"bytes"
	"encoding/binary"
	"testing"
	"time"
)

func TestPacketBodyMarshalUnmarshal(t *testing.T) {
	body := PacketBody{
		Header: PacketHeader{
			TxID:         0x0102030405060708,
			TimestampISE: Millis(time.Date(2024, 12, 1, 12, 34, 56, 0, time.UTC)),
			FromID:       0x1111222233334444,
			ToID:         0x5555666677778888,
			AssetCode:    0x80000001,
			CurrencyNum:  392,
			AmountMinor:  1234567890123456789,
			FeeMinor:     12345,
			Flags2:       PacketFlags2Exchange,
		},
		KeyBlock: PacketKeyBlock{},
		SignatureBlock: PacketSignatureBlock{
			SigMgmt: bytesTo64(makeSequential(0x01)),
			SigPay:  bytesTo64(makeSequential(0x41)),
		},
		Control: PacketControlBlock{
			H:         bytesTo32(makeSequential(0x81)),
			TPMHandle: bytesTo16(makeSequential(0xA1)),
		},
	}
	body.Header.SetFlags(PacketFlags{DualSign: true, StrictOrder: true})
	copy(body.KeyBlock.MgmtKeyISE[:], makeSequential(0x11)[:32])
	copy(body.KeyBlock.PayKeyISE[:], makeSequential(0x31)[:32])

	raw, err := body.MarshalBinary()
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	if len(raw) != PacketInnerBodySize {
		t.Fatalf("body size mismatch: %d", len(raw))
	}

	var decoded PacketBody
	if err := decoded.UnmarshalBinary(raw); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}

	if decoded.Header.TxID != body.Header.TxID ||
		decoded.Header.TimestampISE != body.Header.TimestampISE ||
		decoded.Header.FromID != body.Header.FromID ||
		decoded.Header.ToID != body.Header.ToID ||
		decoded.Header.AssetCode != body.Header.AssetCode ||
		decoded.Header.CurrencyNum != body.Header.CurrencyNum ||
		decoded.Header.AmountMinor != body.Header.AmountMinor ||
		decoded.Header.FeeMinor != body.Header.FeeMinor {
		t.Fatalf("header mismatch: %#v", decoded.Header)
	}

	if !decoded.Header.Flags.DualSign || !decoded.Header.Flags.StrictOrder {
		t.Fatalf("flags mismatch: %#v", decoded.Header.Flags)
	}
	if decoded.Header.Flags2 != PacketFlags2Exchange {
		t.Fatalf("flags2 mismatch: %x", decoded.Header.Flags2)
	}

	if !bytes.Equal(decoded.KeyBlock.MgmtKeyISE[:], body.KeyBlock.MgmtKeyISE[:]) {
		t.Fatalf("mgmt key mismatch")
	}
	if !bytes.Equal(decoded.KeyBlock.PayKeyISE[:], body.KeyBlock.PayKeyISE[:]) {
		t.Fatalf("pay key mismatch")
	}
	if !bytes.Equal(decoded.SignatureBlock.SigMgmt[:], body.SignatureBlock.SigMgmt[:]) {
		t.Fatalf("sig mgmt mismatch")
	}
	if !bytes.Equal(decoded.SignatureBlock.SigPay[:], body.SignatureBlock.SigPay[:]) {
		t.Fatalf("sig pay mismatch")
	}
	if !bytes.Equal(decoded.Control.H[:], body.Control.H[:]) {
		t.Fatalf("control H mismatch")
	}
	if !bytes.Equal(decoded.Control.TPMHandle[:], body.Control.TPMHandle[:]) {
		t.Fatalf("control handle mismatch")
	}
}

func TestPacketCipherMarshal(t *testing.T) {
	var packet PacketCipher
	copy(packet.IV[:], makeSequential(0)[:len(packet.IV)])
	copy(packet.Tag[:], makeSequential(16)[:len(packet.Tag)])
	copy(packet.Ciphertext[:], makeSequential(64)[:len(packet.Ciphertext)])

	packet.UpdateCRC()
	if packet.HdrCRC == 0 {
		t.Fatalf("crc should not be zero")
	}
	if !packet.ValidateCRC() {
		t.Fatalf("crc validation failed")
	}

	wire, err := packet.MarshalBinary()
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	if len(wire) != PacketTotalSize {
		t.Fatalf("total size mismatch: %d", len(wire))
	}

	out, err := UnmarshalPacketCipher(wire)
	if err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if !bytes.Equal(out.Ciphertext[:], packet.Ciphertext[:]) {
		t.Fatalf("ciphertext mismatch after roundtrip")
	}
	if binary.BigEndian.Uint32(wire[28:32]) != packet.HdrCRC {
		t.Fatalf("hdr crc not encoded correctly")
	}
}

func TestIdempotencyHash(t *testing.T) {
	body := PacketBody{
		Header: PacketHeader{
			TxID:         0x0102030405060708,
			TimestampISE: 0x1112131415161718,
		},
	}
	hash := body.IdempotencyHash()
	if len(hash) != 32 {
		t.Fatalf("hash len: %d", len(hash))
	}

	expected := body.IdempotencyHash()
	if hash != expected {
		t.Fatalf("hash mismatch")
	}
}

func makeSequential(start byte) []byte {
	buf := make([]byte, 512)
	for i := range buf {
		buf[i] = start + byte(i)
	}
	return buf
}

func bytesTo64(src []byte) [64]byte {
	var out [64]byte
	copy(out[:], src[:64])
	return out
}

func bytesTo32(src []byte) [32]byte {
	var out [32]byte
	copy(out[:], src[:32])
	return out
}

func bytesTo16(src []byte) [16]byte {
	var out [16]byte
	copy(out[:], src[:16])
	return out
}
