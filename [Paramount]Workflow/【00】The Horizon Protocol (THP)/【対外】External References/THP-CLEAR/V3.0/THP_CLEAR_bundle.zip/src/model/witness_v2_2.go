package model

import (
	"encoding/binary"
	"errors"
	"fmt"

	"golang.org/x/crypto/sha3"
)

const (
	WitnessRecordSize = 128
)

// WitnessFlags matches the 16-bit bitfield in witness records.
type WitnessFlags struct {
	OK        bool
	Mismatch  bool
	Duplicate bool
}

// ToUint16 renders the bitfield representation.
func (f WitnessFlags) ToUint16() uint16 {
	var out uint16
	if f.OK {
		out |= 1 << 0
	}
	if f.Mismatch {
		out |= 1 << 1
	}
	if f.Duplicate {
		out |= 1 << 2
	}
	return out
}

// WitnessFlagsFromUint16 parses the raw bitfield.
func WitnessFlagsFromUint16(v uint16) WitnessFlags {
	return WitnessFlags{
		OK:        v&(1<<0) != 0,
		Mismatch:  v&(1<<1) != 0,
		Duplicate: v&(1<<2) != 0,
	}
}

// WitnessRecord128 represents the fixed 128-byte witness log schema.
type WitnessRecord128 struct {
	TxID         uint64
	TimestampISE uint64
	FromID       uint64
	ToID         uint64
	AssetCode    uint32
	CurrencyNum  uint16
	Flags        WitnessFlags
	AmountMinor  int64
	FeeMinor     int32
	MgmtKeyISE   [32]byte
	PayKeyISE    [32]byte
	SeqNo        uint64
}

// MarshalBinary renders the canonical 128B representation.
func (w *WitnessRecord128) MarshalBinary() ([]byte, error) {
	if w == nil {
		return nil, errors.New("witness record is nil")
	}

	buf := make([]byte, WitnessRecordSize)
	offset := 0

	binary.BigEndian.PutUint64(buf[offset:], w.TxID)
	offset += 8
	binary.BigEndian.PutUint64(buf[offset:], w.TimestampISE)
	offset += 8
	binary.BigEndian.PutUint64(buf[offset:], w.FromID)
	offset += 8
	binary.BigEndian.PutUint64(buf[offset:], w.ToID)
	offset += 8
	binary.BigEndian.PutUint32(buf[offset:], w.AssetCode)
	offset += 4
	binary.BigEndian.PutUint16(buf[offset:], w.CurrencyNum)
	offset += 2
	binary.BigEndian.PutUint16(buf[offset:], w.Flags.ToUint16())
	offset += 2
	binary.BigEndian.PutUint64(buf[offset:], uint64(w.AmountMinor))
	offset += 8
	binary.BigEndian.PutUint32(buf[offset:], uint32(w.FeeMinor))
	offset += 4
	offset += 4 // reserved zero
	copy(buf[offset:], w.MgmtKeyISE[:])
	offset += 32
	copy(buf[offset:], w.PayKeyISE[:])
	offset += 32
	binary.BigEndian.PutUint64(buf[offset:], w.SeqNo)
	offset += 8

	if offset != WitnessRecordSize {
		return nil, fmt.Errorf("witness marshal size mismatch: %d", offset)
	}
	return buf, nil
}

// UnmarshalBinary decodes the canonical representation.
func (w *WitnessRecord128) UnmarshalBinary(data []byte) error {
	if len(data) != WitnessRecordSize {
		return fmt.Errorf("witness record size mismatch: %d", len(data))
	}
	if w == nil {
		return errors.New("witness record is nil")
	}

	offset := 0
	w.TxID = binary.BigEndian.Uint64(data[offset:])
	offset += 8
	w.TimestampISE = binary.BigEndian.Uint64(data[offset:])
	offset += 8
	w.FromID = binary.BigEndian.Uint64(data[offset:])
	offset += 8
	w.ToID = binary.BigEndian.Uint64(data[offset:])
	offset += 8
	w.AssetCode = binary.BigEndian.Uint32(data[offset:])
	offset += 4
	w.CurrencyNum = binary.BigEndian.Uint16(data[offset:])
	offset += 2
	w.Flags = WitnessFlagsFromUint16(binary.BigEndian.Uint16(data[offset:]))
	offset += 2
	w.AmountMinor = int64(binary.BigEndian.Uint64(data[offset:]))
	offset += 8
	w.FeeMinor = int32(binary.BigEndian.Uint32(data[offset:]))
	offset += 4
	offset += 4 // reserved
	copy(w.MgmtKeyISE[:], data[offset:offset+32])
	offset += 32
	copy(w.PayKeyISE[:], data[offset:offset+32])
	offset += 32
	w.SeqNo = binary.BigEndian.Uint64(data[offset:])
	return nil
}

// PrimaryKey returns the SHA3-256(TxID || Timestamp_ISE) identifier.
func (w *WitnessRecord128) PrimaryKey() [32]byte {
	var buf [16]byte
	binary.BigEndian.PutUint64(buf[0:8], w.TxID)
	binary.BigEndian.PutUint64(buf[8:16], w.TimestampISE)
	return sha3.Sum256(buf[:])
}

// WitnessFromPacket builds a witness record from a decrypted packet body.
func WitnessFromPacket(body *PacketBody, seqNo uint64, flags WitnessFlags) *WitnessRecord128 {
	if body == nil {
		return nil
	}
	return &WitnessRecord128{
		TxID:         body.Header.TxID,
		TimestampISE: body.Header.TimestampISE,
		FromID:       body.Header.FromID,
		ToID:         body.Header.ToID,
		AssetCode:    body.Header.AssetCode,
		CurrencyNum:  body.Header.CurrencyNum,
		Flags:        flags,
		AmountMinor:  body.Header.AmountMinor,
		FeeMinor:     body.Header.FeeMinor,
		MgmtKeyISE:   body.KeyBlock.MgmtKeyISE,
		PayKeyISE:    body.KeyBlock.PayKeyISE,
		SeqNo:        seqNo,
	}
}
