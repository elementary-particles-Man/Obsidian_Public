#!/usr/bin/env bash
# THP-CLEAR snapshot orchestrator (v2.2)
#
# - Creates a timestamped export of witness/key databases every 10 minutes
# - Invokes RS(10,2) parity generation for durability
# - Designed to be called by cron/systemd timer under thpclear user

set -euo pipefail

SNAPSHOT_ROOT=${THPCLEAR_SNAPSHOT_DIR:-/var/thpclear/export}
WITNESS_DB=${THPCLEAR_WITNESS_DB:-/var/thpclear/witness/witness.memdb}
KEY_DB=${THPCLEAR_KEY_DB:-/var/thpclear/keydb/keydb.sqlite}
LOG_SRC=${THPCLEAR_LOG_DIR:-/var/thpclear/log}
RETENTION_MINUTES=${THPCLEAR_SNAPSHOT_RETENTION_MINUTES:-4320} # 3 days
RS_SCRIPT=${THPCLEAR_RS_SCRIPT:-$(dirname "$0")/rs_repair.py}

timestamp=$(date '+%Y%m%d_%H%M%S')
target_dir="${SNAPSHOT_ROOT}/${timestamp}"

mkdir -p "${target_dir}" "${SNAPSHOT_ROOT}"

echo "[snapshot] exporting witness db -> ${target_dir}" >&2
if command -v sqlite3 >/dev/null 2>&1; then
  sqlite3 "${WITNESS_DB}" ".backup '${target_dir}/witness.sqlite'"
else
  cp -f "${WITNESS_DB}" "${target_dir}/witness.sqlite"
fi

if [[ -f "${KEY_DB}" ]]; then
  cp -f "${KEY_DB}" "${target_dir}/keydb.sqlite"
fi

if [[ -d "${LOG_SRC}" ]]; then
  tar -czf "${target_dir}/logs.tar.gz" -C "${LOG_SRC}" .
fi

if [[ -x "${RS_SCRIPT}" ]]; then
  echo "[snapshot] generating RS parity shards" >&2
  python3 "${RS_SCRIPT}" encode "${target_dir}" --k 10 --m 2 --chunk-bytes 134217728
else
  echo "[snapshot] WARN: rs_repair.py not executable; skipping parity generation" >&2
fi

echo "[snapshot] pruning exports older than ${RETENTION_MINUTES} minutes" >&2
find "${SNAPSHOT_ROOT}" -mindepth 1 -maxdepth 1 -type d -mmin +"${RETENTION_MINUTES}" -print0 | xargs -0r rm -rf

echo "[snapshot] complete" >&2
