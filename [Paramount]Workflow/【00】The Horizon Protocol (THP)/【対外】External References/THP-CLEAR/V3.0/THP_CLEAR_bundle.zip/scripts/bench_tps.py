#!/usr/bin/env python3
"""Simple TPS benchmark harness for THP-CLEAR endpoints.

The script fires concurrent HTTP POST requests using aiohttp and
produces a rough throughput/latency summary. Adjust TARGET_URL and
payload template to match the MQ ingress endpoint.
"""

import argparse
import asyncio
import json
import statistics
import time

try:
    import aiohttp
except ImportError:  # pragma: no cover
    raise SystemExit("aiohttp is required. Install with `pip install aiohttp`. ")


DEFAULT_PAYLOAD = {
    "from_id": 1,
    "to_id": 2,
    "asset_code": 0x00000001,
    "amount_minor": 10 ** 15,
    "fee_minor": 10,
}


async def worker(session: aiohttp.ClientSession, url: str, payload: dict, results: list[float]) -> None:
    start = time.perf_counter()
    async with session.post(url, json=payload) as resp:
        await resp.text()
    end = time.perf_counter()
    results.append(end - start)


async def run_benchmark(url: str, concurrency: int, requests: int) -> None:
    results: list[float] = []
    connector = aiohttp.TCPConnector(limit=concurrency)
    async with aiohttp.ClientSession(connector=connector) as session:
        sem = asyncio.Semaphore(concurrency)

        async def limited_worker():
            async with sem:
                await worker(session, url, DEFAULT_PAYLOAD, results)

        tasks = [asyncio.create_task(limited_worker()) for _ in range(requests)]
        start = time.perf_counter()
        await asyncio.gather(*tasks)
        duration = time.perf_counter() - start

    throughput = requests / duration if duration > 0 else 0
    p95 = statistics.quantiles(results, n=20)[18] if len(results) >= 20 else max(results, default=0)
    print(json.dumps({
        "requests": requests,
        "duration_sec": duration,
        "throughput_rps": throughput,
        "latency_p95_sec": p95,
    }, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="MQ ingress TPS benchmark")
    parser.add_argument("positional_url", nargs="?", help="target HTTP endpoint")
    parser.add_argument("--url", dest="flag_url", help="target HTTP endpoint (alternative to positional)")
    parser.add_argument("--concurrency", type=int, default=64, help="simultaneous workers")
    parser.add_argument("--requests", type=int, default=1000, help="total requests")
    args = parser.parse_args()

    target_url = args.flag_url or args.positional_url
    if not target_url:
        parser.error("URL must be provided either as positional argument or via --url")

    asyncio.run(run_benchmark(target_url, args.concurrency, args.requests))


if __name__ == "__main__":  # pragma: no cover
    main()
