#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOG_FILE="${PROJECT_ROOT}/test.log"
DLL_TARGET="${CLEAR_ENCRYPTOR_DLL:-/opt/clear_encryptor.dll}"
SO_TARGET="/usr/local/lib/libclear_encryptor.so"
RUST_CORE_DIR="${PROJECT_ROOT}/rust/core"

echo '--- [THP-CLEAR CI start] ---'
echo "Using project root: ${PROJECT_ROOT}"
echo "Target DLL path: ${DLL_TARGET}"
echo "Target SO path: ${SO_TARGET}"

GO_VERSION_OUTPUT="$(go version)"
echo "Go toolchain: ${GO_VERSION_OUTPUT}"

GO_VERSION_VALUE="$(awk '{print $3}' <<< "${GO_VERSION_OUTPUT}")"
CURRENT_GO_VERSION="${GO_VERSION_VALUE#go}"
REQUIRED_GO_VERSION="1.24"
if [[ "$(printf '%s\n' "${CURRENT_GO_VERSION}" "${REQUIRED_GO_VERSION}" | sort -V | tail -n1)" != "${CURRENT_GO_VERSION}" ]]; then
  echo "Go ${CURRENT_GO_VERSION} detected, but ${REQUIRED_GO_VERSION} or newer is required." >&2
  exit 1
fi

echo '--- Step 1: Clean previous build artifacts ---'
(cd "${RUST_CORE_DIR}" && cargo clean)
go clean -cache -testcache -modcache

echo '--- Step 2: Build Rust FFI (clear_encryptor) ---'
(cd "${RUST_CORE_DIR}" && cargo build --release)

echo '--- Step 3: Sync FFI artifacts ---'
mkdir -p "$(dirname "${DLL_TARGET}")"
SO_DIR="$(dirname "${SO_TARGET}")"
if [ -f "${RUST_CORE_DIR}/target/release/clear_encryptor.dll" ]; then
  cp "${RUST_CORE_DIR}/target/release/clear_encryptor.dll" "${DLL_TARGET}"
fi
if [ -f "${RUST_CORE_DIR}/target/release/libclear_encryptor.so" ]; then
  mkdir -p "${SO_DIR}"
  cp "${RUST_CORE_DIR}/target/release/libclear_encryptor.so" "${SO_TARGET}"
elif [ ! -f "${RUST_CORE_DIR}/target/release/clear_encryptor.dll" ]; then
  echo "clear_encryptor artifact not found in ${RUST_CORE_DIR}/target/release" >&2
  exit 1
fi

if [[ "$(uname -s)" == "Linux" ]] && [ ! -f "${SO_TARGET}" ]; then
  echo "FFI artifact missing at ${SO_TARGET}" >&2
  exit 1
fi

echo '--- Step 4: Rebuild Go modules ---'
(cd "${PROJECT_ROOT}" && go mod tidy)
(cd "${PROJECT_ROOT}" && go build ./...)

echo '--- Step 5: Run Go test suite ---'
pushd "${PROJECT_ROOT}" >/dev/null
go test ./... | tee "${LOG_FILE}"
popd >/dev/null

echo '--- [THP-CLEAR CI complete] ---'
