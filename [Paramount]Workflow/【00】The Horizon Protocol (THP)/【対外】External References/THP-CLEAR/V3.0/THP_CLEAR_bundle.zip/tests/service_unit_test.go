package tests

import (
	"context"
	"testing"
	"time"

	"thp-clear/internal/adapters/memory"
	"thp-clear/internal/domain"
	pkgcrypto "thp-clear/pkg/crypto"
)

// In tests we don't need file writer -> we will create stub writer.

type stubWitnessWriter struct {
	entries []*domain.WitnessEntry
}

func (s *stubWitnessWriter) Append(entry *domain.WitnessEntry) error {
	s.entries = append(s.entries, entry)
	return nil
}

func TestServiceIssueSettle(t *testing.T) {
	store := memory.New()
	ctx := context.Background()
	signer, err := pkgcrypto.Generate()
	if err != nil {
		t.Fatalf("generate signer: %v", err)
	}

	writer := &stubWitnessWriter{}
	service := domain.NewService(store, signer, writer)
	fixed := time.Date(2025, 1, 1, 0, 0, 0, 0, time.UTC)
	service.WithNow(func() time.Time { return fixed })

	acc, err := service.UpsertAccount(ctx, domain.AccountInput{
		ID:          "acct-1",
		DisplayName: "Test Account",
		Currency:    "JPY",
		Balance:     1_000_000,
		Status:      domain.AccountActive,
	})
	if err != nil {
		t.Fatalf("upsert account: %v", err)
	}
	if acc.Balance != 1_000_000 {
		t.Fatalf("unexpected balance: %d", acc.Balance)
	}

	cmd, err := service.IssueCommand(ctx, domain.IssueCommandInput{
		AccountID: "acct-1",
		Amount:    1000,
		Currency:  "JPY",
		Purpose:   domain.PurposeFood,
	})
	if err != nil {
		t.Fatalf("issue command: %v", err)
	}

	settledCmd, entry, err := service.SettleCommand(ctx, domain.SettleCommandInput{
		CommandID: cmd.ID,
		Quantity:  10,
		Unit:      "t",
	})
	if err != nil {
		t.Fatalf("settle command: %v", err)
	}
	if settledCmd.Status != domain.CommandSettled {
		t.Fatalf("expected settled status, got %s", settledCmd.Status)
	}
	if entry.Hash == "" {
		t.Fatalf("hash should not be empty")
	}
	if len(writer.entries) != 1 {
		t.Fatalf("expected 1 witness entry, got %d", len(writer.entries))
	}
}

func TestBlacklistFlow(t *testing.T) {
	store := memory.New()
	ctx := context.Background()
	signer, err := pkgcrypto.Generate()
	if err != nil {
		t.Fatalf("generate signer: %v", err)
	}
	writer := &stubWitnessWriter{}
	service := domain.NewService(store, signer, writer)
	fixed := time.Date(2025, 1, 2, 0, 0, 0, 0, time.UTC)
	service.WithNow(func() time.Time { return fixed })

	if _, err := service.UpsertAccount(ctx, domain.AccountInput{
		ID:          "acct-2",
		DisplayName: "Blocked",
		Currency:    "JPY",
		Balance:     5000,
	}); err != nil {
		t.Fatalf("upsert account: %v", err)
	}
	t.Log("account ready")

	if err := service.AddBlacklistEntry(ctx, domain.BlacklistInput{
		AccountID: "acct-2",
		Reason:    "fraud",
	}); err != nil {
		t.Fatalf("add blacklist: %v", err)
	}
	t.Log("blacklisted")

	if _, err := service.IssueCommand(ctx, domain.IssueCommandInput{
		AccountID: "acct-2",
		Amount:    100,
		Currency:  "JPY",
		Purpose:   domain.PurposeEnergy,
	}); err == nil {
		t.Fatalf("expected error for blacklisted account")
	}
	t.Log("blocked as expected")

	if err := service.ClearBlacklist(ctx, "acct-2"); err != nil {
		t.Fatalf("clear blacklist: %v", err)
	}
	t.Log("cleared")

	if _, err := service.IssueCommand(ctx, domain.IssueCommandInput{
		AccountID: "acct-2",
		Amount:    100,
		Currency:  "JPY",
		Purpose:   domain.PurposeEnergy,
	}); err != nil {
		t.Fatalf("issue command after clear: %v", err)
	}
	t.Log("command succeeded")
}
