package tests

import (
	"bytes"
	"context"
	"encoding/binary"
	"testing"
	"time"

	"thp-clear/src/MQ"
	"thp-clear/src/WN"
	"thp-clear/src/model"
)

func TestPacketV22Roundtrip(t *testing.T) {
	body := model.PacketBody{
		Header: model.PacketHeader{
			TxID:         0x0102030405060708,
			TimestampISE: model.Millis(time.Date(2025, 1, 1, 12, 0, 0, 0, time.UTC)),
			FromID:       0x1111222233334444,
			ToID:         0x5555666677778888,
			AssetCode:    0x80000010,
			CurrencyNum:  65535,
			Flags:        model.PacketFlags{DualSign: true},
			Flags2:       model.PacketFlags2Exchange,
			AmountMinor:  987654321012345678,
			FeeMinor:     0,
		},
	}
	copy(body.KeyBlock.MgmtKeyISE[:], repeatBytes(0x11, 32))
	copy(body.KeyBlock.PayKeyISE[:], repeatBytes(0x21, 32))
	copy(body.SignatureBlock.SigMgmt[:], repeatBytes(0x31, 64))
	copy(body.SignatureBlock.SigPay[:], repeatBytes(0x41, 64))
	copy(body.Control.TPMHandle[:], repeatBytes(0x51, 16))
	body.Control.H = body.IdempotencyHash()

	raw, err := body.MarshalBinary()
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	if len(raw) != model.PacketInnerBodySize {
		t.Fatalf("unexpected size: %d", len(raw))
	}

	expected := make([]byte, model.PacketInnerBodySize)
	offset := 0
	copy(expected[offset:], []byte("TCF2"))
	offset += 4
	expected[offset] = model.PacketVersion
	offset++
	expected[offset] = body.Header.Flags.Byte()
	offset++
	binary.BigEndian.PutUint16(expected[offset:], 0)
	offset += 2
	binary.BigEndian.PutUint64(expected[offset:], body.Header.TxID)
	offset += 8
	binary.BigEndian.PutUint64(expected[offset:], body.Header.TimestampISE)
	offset += 8
	binary.BigEndian.PutUint64(expected[offset:], body.Header.FromID)
	offset += 8
	binary.BigEndian.PutUint64(expected[offset:], body.Header.ToID)
	offset += 8
	binary.BigEndian.PutUint32(expected[offset:], body.Header.AssetCode)
	offset += 4
	binary.BigEndian.PutUint16(expected[offset:], body.Header.CurrencyNum)
	offset += 2
	expected[offset] = model.PacketDecimals
	offset++
	expected[offset] = body.Header.Flags2
	offset++
	binary.BigEndian.PutUint64(expected[offset:], uint64(body.Header.AmountMinor))
	offset += 8
	binary.BigEndian.PutUint32(expected[offset:], uint32(body.Header.FeeMinor))
	offset += 4
	binary.BigEndian.PutUint32(expected[offset:], 0)
	offset += 4
	copy(expected[offset:], body.KeyBlock.MgmtKeyISE[:])
	offset += 32
	copy(expected[offset:], body.KeyBlock.PayKeyISE[:])
	offset += 32
	copy(expected[offset:], body.SignatureBlock.SigMgmt[:])
	offset += 64
	copy(expected[offset:], body.SignatureBlock.SigPay[:])
	offset += 64
	copy(expected[offset:], body.Control.H[:])
	offset += 32
	copy(expected[offset:], body.Control.TPMHandle[:])
	offset += 16
	copy(expected[offset:], body.Control.RsvPad[:])

	if !bytes.Equal(raw, expected) {
		t.Fatalf("marshalled bytes mismatch")
	}

	var decoded model.PacketBody
	if err := decoded.UnmarshalBinary(raw); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if decoded.Header.Flags2 != body.Header.Flags2 {
		t.Fatalf("flags2 mismatch: %x vs %x", decoded.Header.Flags2, body.Header.Flags2)
	}
	if decoded.Header.ExchangeFlag() == false {
		t.Fatalf("exchange flag should be true")
	}
	if decoded.Control.H != body.Control.H {
		t.Fatalf("idempotency hash mismatch")
	}
}

func repeatBytes(start byte, n int) []byte {
	out := make([]byte, n)
	for i := 0; i < n; i++ {
		out[i] = start + byte(i%7)
	}
	return out
}

func TestWNProcessorDerivesAAD(t *testing.T) {
	var mat MQ.KeyMaterial
	for i := range mat.AESKey {
		mat.AESKey[i] = byte(i)
	}
	builder, err := MQ.NewPacketBuilder(&MQ.StaticMaterialProvider{Material: mat})
	if err != nil {
		t.Fatalf("builder: %v", err)
	}

	req := MQ.BuildRequest{
		FromID:      0x0101010101010101,
		ToID:        0x0202020202020202,
		AssetCode:   0x00000003,
		CurrencyNum: 392,
		AmountMinor: 5000,
		FeeMinor:    100,
		Timestamp:   time.Date(2025, 2, 1, 0, 0, 0, 0, time.UTC),
	}

	packetCipher, body, err := builder.Build(context.Background(), req)
	if err != nil {
		t.Fatalf("build: %v", err)
	}

	wire, err := packetCipher.MarshalBinary()
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}

	processor := WN.NewProcessor()
	res, err := processor.Process(context.Background(), WN.ProcessRequest{
		PacketBytes: wire,
		AESKey:      mat.AESKey,
		SeqNo:       99,
	})
	if err != nil {
		t.Fatalf("process: %v", err)
	}
	if res.Body.Header.TxID != body.Header.TxID || res.Body.Header.TimestampISE != body.Header.TimestampISE {
		t.Fatalf("aad fields mismatch after process")
	}
	if res.Witness.SeqNo != 99 {
		t.Fatalf("witness seq mismatch")
	}
}
