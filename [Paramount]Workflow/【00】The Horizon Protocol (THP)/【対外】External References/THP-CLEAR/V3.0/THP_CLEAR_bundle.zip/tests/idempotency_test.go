package tests

import (
	"context"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	DB "thp-clear/src/DB"
	"thp-clear/src/model"
)

func TestWitnessIdempotencyInsertOrIgnore(t *testing.T) {
	dir := t.TempDir()
	store, err := DB.NewWitnessStore(filepath.Join(dir, "witness.sqlite"))
	if err != nil {
		t.Fatalf("store: %v", err)
	}
	t.Cleanup(func() { _ = store.Close() })

	rec := &model.WitnessRecord128{
		TxID:         100,
		TimestampISE: 200,
		FromID:       300,
		ToID:         400,
		AssetCode:    0x80000001,
		CurrencyNum:  65535,
		Flags:        model.WitnessFlags{OK: true},
		AmountMinor:  1234,
		FeeMinor:     0,
		SeqNo:        1,
	}

	inserted, err := store.Insert(context.Background(), rec)
	if err != nil {
		t.Fatalf("insert: %v", err)
	}
	if !inserted {
		t.Fatalf("expected first insert to succeed")
	}

	inserted, err = store.Insert(context.Background(), rec)
	if err != nil {
		t.Fatalf("duplicate insert: %v", err)
	}
	if inserted {
		t.Fatalf("duplicate should be ignored")
	}

	count, err := store.Count(context.Background())
	if err != nil {
		t.Fatalf("count: %v", err)
	}
	if count != 1 {
		t.Fatalf("expected count=1, got %d", count)
	}
}

func TestWitnessIdempotencyConcurrent(t *testing.T) {
	dir := t.TempDir()
	store, err := DB.NewWitnessStore(filepath.Join(dir, "witness.sqlite"))
	if err != nil {
		t.Fatalf("store: %v", err)
	}
	t.Cleanup(func() { _ = store.Close() })

	base := model.WitnessRecord128{
		TxID:         500,
		TimestampISE: 600,
		FromID:       700,
		ToID:         800,
		AssetCode:    0x00000002,
		CurrencyNum:  392,
		Flags:        model.WitnessFlags{OK: true},
		AmountMinor:  98765,
		FeeMinor:     12,
		SeqNo:        42,
	}

	if inserted, err := store.Insert(context.Background(), &base); err != nil || !inserted {
		t.Fatalf("initial insert: inserted=%v err=%v", inserted, err)
	}

	const workers = 16
	var wg sync.WaitGroup
	wg.Add(workers)

	for i := 0; i < workers; i++ {
		go func() {
			defer wg.Done()
			retryCtx := context.Background()
			for attempt := 0; attempt < 5; attempt++ {
				rec := base
				if _, err := store.Insert(retryCtx, &rec); err != nil {
					if strings.Contains(err.Error(), "SQLITE_BUSY") {
						time.Sleep(time.Millisecond * 10)
						continue
					}
					t.Errorf("insert: %v", err)
				}
				break
			}
		}()
	}
	wg.Wait()

	count, err := store.Count(context.Background())
	if err != nil {
		t.Fatalf("count: %v", err)
	}
	if count != 1 {
		t.Fatalf("expected count=1 after concurrent inserts, got %d", count)
	}
}
