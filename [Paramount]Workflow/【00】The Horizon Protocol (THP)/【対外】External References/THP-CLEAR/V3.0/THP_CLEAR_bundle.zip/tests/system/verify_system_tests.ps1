param(
    [string]$LogDir = 'witness/logs',
    [string]$InvoiceDir = 'witness/invoice',
    [string]$OutputDir = 'tests/output'
)

$ErrorActionPreference = 'Stop'

Write-Host '=== THP-CLEAR System Test Verification ==='

$root = Resolve-Path '.'
$logDirPath = Join-Path $root $LogDir
$invoiceDirPath = Join-Path $root $InvoiceDir
$outputDirPath = Join-Path $root $OutputDir
New-Item -ItemType Directory -Force -Path $outputDirPath | Out-Null

if (-not (Test-Path $logDirPath)) {
    throw "Witness log directory not found: $logDirPath"
}
if (-not (Test-Path $invoiceDirPath)) {
    throw "Invoice directory not found: $invoiceDirPath"
}

Write-Host '[1/3] Summarizing witness logs'
Get-ChildItem $logDirPath -Filter '*.log' | ForEach-Object {
    $file = $_.FullName
    $hash = Get-FileHash $file -Algorithm SHA256
    "$($hash.Hash) $($hash.Path)"
} | Out-File (Join-Path $outputDirPath 'witness_hashes.txt')

Write-Host '[2/3] Summarizing invoices'
Get-ChildItem $invoiceDirPath -Filter '*.json' | Out-File (Join-Path $outputDirPath 'invoice_index.txt')

Write-Host '[3/3] Extracting error codes from logs'
Get-ChildItem $logDirPath -Filter '*.log' | ForEach-Object {
    Select-String -Path $_.FullName -Pattern 'ERR_' -SimpleMatch | ForEach-Object { $_.Line }
} | Out-File (Join-Path $outputDirPath 'error_summary.log')

Write-Host 'Verification artifacts written to' $outputDirPath
