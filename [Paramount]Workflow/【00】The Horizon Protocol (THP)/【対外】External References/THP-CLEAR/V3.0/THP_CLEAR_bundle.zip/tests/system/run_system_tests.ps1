param(
    [switch]$SkipGoBuild,
    [switch]$SkipRust,
    [string]$OutputDir = "tests/output"
)

$ErrorActionPreference = 'Stop'

Write-Host '=== THP-CLEAR System Test Runner ==='

$root = Resolve-Path '.'
$witnessLogDir = Join-Path $root 'witness/logs'
$invoiceDir = Join-Path $root 'witness/invoice'
$dataDir = Join-Path $root 'tests/data'
$outputDirPath = Join-Path $root $OutputDir

New-Item -ItemType Directory -Force -Path $witnessLogDir | Out-Null
New-Item -ItemType Directory -Force -Path $invoiceDir | Out-Null
New-Item -ItemType Directory -Force -Path $outputDirPath | Out-Null

$env:CGO_ENABLED = '1'
$env:PATH = "${env:USERPROFILE}\\.cargo\\bin;${root}\\rust\\core\\target\\debug;C:\\ProgramData\\mingw64\\mingw64\\bin;$env:PATH"

if (-not $SkipRust) {
    Write-Host '[1/4] cargo build/test --workspace'
    Push-Location (Join-Path $root 'rust/core')
    cargo build --workspace
    cargo test --workspace
    Pop-Location
}

if (-not $SkipGoBuild) {
    Write-Host '[2/4] go build ./src/...'
    Push-Location (Join-Path $root 'src')
    go build ./...
    Pop-Location
}

Write-Host '[3/4] Running transaction simulator'
Push-Location $root
$taxsimPath = Join-Path $root 'src/core/taxsim/main.go'
if (Test-Path $taxsimPath) {
    go run ./src/core/taxsim/main.go `
        --vendors (Join-Path $dataDir 'vendors_full.json') `
        --input (Join-Path $dataDir 'transactions_full.json') `
        --expected (Join-Path $dataDir 'expected_outputs.json') `
        --out (Join-Path $outputDirPath 'systemtest_witness.log')
} else {
    Write-Warning 'taxsim tool not present; skipping go run ./src/core/taxsim/main.go'
}
Pop-Location

Write-Host '[4/4] Running go test ./...'
Push-Location $root
$goTestOutput = go test -tags testshim -v ./...
$goTestOutput | Tee-Object -FilePath (Join-Path $outputDirPath 'go_test_output.log') | Write-Host
Pop-Location

if (Test-Path $witnessLogDir) {
    Get-ChildItem $witnessLogDir | Out-File (Join-Path $outputDirPath 'witness_log_index.txt')
}

Write-Host '=== System Test Runner Completed ==='
