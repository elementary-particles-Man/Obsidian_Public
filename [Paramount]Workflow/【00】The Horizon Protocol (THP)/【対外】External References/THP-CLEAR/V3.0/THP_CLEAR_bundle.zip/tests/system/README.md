# THP-CLEAR / CLEAR-TAX System Test Suite

This suite covers 12 scenarios, spanning normal, abnormal, tax-specific, lifecycle, and boundary cases.

Data sources:
- 	ests/data/vendors_full.json
- 	ests/data/transactions_full.json
- 	ests/data/expected_outputs.json

Execution flow is scripted in scripts/run_system_test_realcode.ps1 once data is prepared.
