package tests

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"errors"
	"net/http/httptest"
	"sync"
	"testing"
	"time"

	"thp-clear/src/DB"
	"thp-clear/src/MQ/encryptor"
	"thp-clear/src/common/kmsclient"
	"thp-clear/src/common/kmsproto"
	"thp-clear/src/common/nodeauth"
	"thp-clear/src/kms"
)

func TestEpochRotateE2E(t *testing.T) {
	t.Helper()

	const nodeID = "WN-test-01"
	const commitID = "commit-001"

	clock := &stubEpochClock{current: 400}
	issuer := kms.NewEpochKeyIssuer(clock, 2)
	signers, pubKeys := makeSigners(t, 3)

	service, err := kms.NewService(kms.Config{
		Rounds:           4,
		RealRatio:        1.0,
		Signers:          signers,
		KeyIssuer:        issuer,
		Random:           &deterministicReader{},
		Threshold:        2,
		FailureWindow:    time.Minute,
		BlockAfterFails:  2,
		SpyWarnBackoff:   5 * time.Second,
		SpyBlockDuration: 30 * time.Second,
	})
	if err != nil {
		t.Fatalf("kms.NewService: %v", err)
	}

	commitDigest := bytes.Repeat([]byte{0x42}, 32)
	if err := service.RegisterCommit(nodeID, commitID, commitDigest); err != nil {
		t.Fatalf("RegisterCommit: %v", err)
	}

	store := nodeauth.NewStore(nodeID, []nodeauth.CommitEntry{
		{ID: commitID, Digest: commitDigest},
	})
	store.SetRandom(&deterministicReader{})

	ring, err := encryptor.NewKeyRing()
	if err != nil {
		t.Fatalf("encryptor.NewKeyRing: %v", err)
	}

	prevMaterial := makeMaterial(clock.CurrentEpoch()-1, 0x11, 0x21)
	ring.Apply(prevMaterial)

	spyEvents := newSpyRecorder()
	handler := kms.NewHandler(service, spyEvents, nil)

	server := httptest.NewServer(handler)
	defer server.Close()

	client := kmsclient.New(server.URL, server.Client())

	manager, err := nodeauth.NewManager(store, ring, client, nodeauth.ManagerConfig{
		NodeID:        nodeID,
		KeyType:       "transport",
		MaxRetry:      1,
		WarnBackoff:   2 * time.Second,
		BlockDuration: 5 * time.Second,
		PublicKeys:    pubKeys,
		Threshold:     2,
	})
	if err != nil {
		t.Fatalf("nodeauth.NewManager: %v", err)
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := manager.EnsureEpoch(ctx, clock.CurrentEpoch()); err != nil {
		t.Fatalf("EnsureEpoch: %v", err)
	}

	current, err := ring.Current()
	if err != nil {
		t.Fatalf("ring.Current: %v", err)
	}
	if current.Version != clock.CurrentEpoch() {
		t.Fatalf("expected current version %d, got %d", clock.CurrentEpoch(), current.Version)
	}
	prev, ok := ring.Previous()
	if !ok {
		t.Fatalf("expected previous key to be set")
	}
	if prev.Version != prevMaterial.Version {
		t.Fatalf("expected previous version %d, got %d", prevMaterial.Version, prev.Version)
	}

	ingestor, err := DB.NewIngestor(ring)
	if err != nil {
		t.Fatalf("DB.NewIngestor: %v", err)
	}

	envPrev := sealWithMaterial(t, prev, []byte("payload-prev"))
	plainPrev, usedPrev, err := ingestor.DecodeEnvelope(envPrev)
	if err != nil {
		t.Fatalf("DecodeEnvelope(prev): %v", err)
	}
	if !usedPrev {
		t.Fatalf("expected previous key usage for E-1 payload")
	}
	if string(plainPrev) != "payload-prev" {
		t.Fatalf("unexpected plaintext for prev: %s", plainPrev)
	}

	envCurr := sealWithMaterial(t, current, []byte("payload-current"))
	plainCurr, usedPrevCurrent, err := ingestor.DecodeEnvelope(envCurr)
	if err != nil {
		t.Fatalf("DecodeEnvelope(current): %v", err)
	}
	if usedPrevCurrent {
		t.Fatalf("expected current key usage for E payload")
	}
	if string(plainCurr) != "payload-current" {
		t.Fatalf("unexpected plaintext for current: %s", plainCurr)
	}

	oldMaterial := makeMaterial(prev.Version-1, 0x01, 0x02)
	envOld := sealWithMaterial(t, oldMaterial, []byte("payload-old"))
	if _, _, err := ingestor.DecodeEnvelope(envOld); !errors.Is(err, DB.ErrEpochMismatch) {
		t.Fatalf("expected ErrEpochMismatch for E-2 payload, got %v", err)
	}

	currentBefore := current

	store.AddCommit(nodeauth.CommitEntry{
		ID:     commitID,
		Digest: bytes.Repeat([]byte{0x99}, 32),
	})
	clock.Advance(1)

	ctxWarn, cancelWarn := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancelWarn()

	if err := manager.EnsureEpoch(ctxWarn, clock.CurrentEpoch()); err == nil {
		t.Fatalf("expected EnsureEpoch failure for decoy result")
	}

	alert := spyEvents.Wait(t)
	if alert.Level != "warn" {
		t.Fatalf("expected warn alert, got %s", alert.Level)
	}
	if alert.NodeID != nodeID {
		t.Fatalf("unexpected alert node: %s", alert.NodeID)
	}

	currentAfter, err := ring.Current()
	if err != nil {
		t.Fatalf("ring.Current (after): %v", err)
	}
	if currentAfter.Version != currentBefore.Version {
		t.Fatalf("expected key version to remain at %d, got %d", currentBefore.Version, currentAfter.Version)
	}
}

type stubEpochClock struct {
	mu      sync.Mutex
	current uint64
}

func (s *stubEpochClock) CurrentEpoch() uint64 {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.current
}

func (s *stubEpochClock) Advance(n uint64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.current += n
}

type deterministicReader struct {
	counter byte
}

func (d *deterministicReader) Read(p []byte) (int, error) {
	for i := range p {
		p[i] = d.counter
		d.counter++
	}
	return len(p), nil
}

func makeMaterial(version uint64, iseSeed, aesSeed byte) encryptor.KeyMaterial {
	var mat encryptor.KeyMaterial
	mat.Version = version
	for i := range mat.ISEKey {
		mat.ISEKey[i] = iseSeed + byte(i)
	}
	for i := range mat.AESKey {
		mat.AESKey[i] = aesSeed + byte(i)
	}
	return mat
}

func sealWithMaterial(t *testing.T, mat encryptor.KeyMaterial, payload []byte) *encryptor.Envelope {
	t.Helper()
	src := &staticKeySource{current: mat}
	pipeline, err := encryptor.NewPipeline(encryptor.Config{Keys: src})
	if err != nil {
		t.Fatalf("encryptor.NewPipeline: %v", err)
	}
	env, err := pipeline.Seal(payload, true)
	if err != nil {
		t.Fatalf("pipeline.Seal: %v", err)
	}
	return env
}

type staticKeySource struct {
	current encryptor.KeyMaterial
}

func (s *staticKeySource) Current() (encryptor.KeyMaterial, error) { return s.current, nil }
func (s *staticKeySource) Previous() (encryptor.KeyMaterial, bool) {
	return encryptor.KeyMaterial{}, false
}
func (s *staticKeySource) ByVersion(version uint64) (encryptor.KeyMaterial, bool) {
	if version == s.current.Version {
		return s.current, true
	}
	return encryptor.KeyMaterial{}, false
}
func (s *staticKeySource) Rotate() (encryptor.KeyMaterial, error) { return s.current, nil }
func (s *staticKeySource) Apply(mat encryptor.KeyMaterial)        { s.current = mat }

type spyRecorder struct {
	ch chan *kmsproto.SpyAlert
}

func newSpyRecorder() *spyRecorder {
	return &spyRecorder{ch: make(chan *kmsproto.SpyAlert, 1)}
}

func (s *spyRecorder) Broadcast(_ context.Context, alert *kmsproto.SpyAlert) error {
	if alert == nil {
		return nil
	}
	select {
	case s.ch <- alert:
	default:
	}
	return nil
}

func (s *spyRecorder) Wait(t *testing.T) *kmsproto.SpyAlert {
	t.Helper()
	select {
	case alert := <-s.ch:
		return alert
	case <-time.After(2 * time.Second):
		t.Fatal("spy alert not received")
		return nil
	}
}

type signerStub struct {
	id  string
	pub ed25519.PublicKey
	sk  ed25519.PrivateKey
}

func (s *signerStub) KeyID() string                   { return s.id }
func (s *signerStub) Sign(msg []byte) ([]byte, error) { return ed25519.Sign(s.sk, msg), nil }
func (s *signerStub) PublicKey() ed25519.PublicKey    { return s.pub }

func makeSigners(t *testing.T, n int) ([]kms.Signer, map[string]ed25519.PublicKey) {
	t.Helper()
	signers := make([]kms.Signer, 0, n)
	pubKeys := make(map[string]ed25519.PublicKey, n)
	entropy := &deterministicReader{}
	for i := 0; i < n; i++ {
		pub, priv, err := ed25519.GenerateKey(entropy)
		if err != nil {
			t.Fatalf("ed25519.GenerateKey: %v", err)
		}
		id := "kms-" + string(rune('A'+i))
		stub := &signerStub{id: id, pub: pub, sk: priv}
		signers = append(signers, stub)
		pubKeys[id] = pub
	}
	return signers, pubKeys
}
