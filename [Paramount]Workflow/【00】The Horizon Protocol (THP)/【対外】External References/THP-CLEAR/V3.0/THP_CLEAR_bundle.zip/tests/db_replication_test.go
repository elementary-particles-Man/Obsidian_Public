package tests

import (
	"bytes"
	"compress/gzip"
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"io"
	"sync"
	"testing"

	DBpkg "thp-clear/src/DB"
	"thp-clear/src/common/crypto"
	"thp-clear/src/kms"
	"thp-clear/src/tpm"
)

func TestDBReplication_CurrentKeySuccess(t *testing.T) {
	ctx := context.Background()
	scope := "witness"
	seq := uint64(1)

	kmsClient := kms.NewClientV2()
	dRand := newReplicationRand()
	kmsClient.WithRand(dRand)

	senderTPM := tpm.NewHandlerV2()
	receiverTPM := tpm.NewHandlerV2()

	sender := DBpkg.NewReplicator(kmsClient, senderTPM)
	sender.SetRand(newReplicationRand())
	receiver := DBpkg.NewReplicator(kmsClient, receiverTPM)
	receiver.SetRand(newReplicationRand())

	keys, err := kmsClient.GetKeys(scope, seq)
	if err != nil {
		t.Fatalf("GetKeys: %v", err)
	}

	plain := []byte("replication payload v1")
	env := sealWithKey(t, keys[0], 101, true, false, plain, tpm.NewHandlerV2(), newReplicationRand())

	chunk, err := sender.GenerateChunk(ctx, scope, seq, []crypto.Envelope{env})
	if err != nil {
		t.Fatalf("GenerateChunk: %v", err)
	}

	payload, err := sender.SendChunk(ctx, chunk)
	if err != nil {
		t.Fatalf("SendChunk: %v", err)
	}

	result, err := receiver.ReceiveChunk(ctx, scope, payload)
	if err != nil {
		t.Fatalf("ReceiveChunk: %v", err)
	}
	if len(result.Envelopes) != 1 {
		t.Fatalf("expected 1 envelope, got %d", len(result.Envelopes))
	}
	if !bytes.Equal(result.Merkle, chunk.Metadata.MerkleRoot) {
		t.Fatalf("merkle mismatch")
	}
	if result.Envelopes[0].KeyVersion != keys[0].Version {
		t.Fatalf("unexpected key version %d", result.Envelopes[0].KeyVersion)
	}
}

func TestDBReplication_KeyFallback(t *testing.T) {
	ctx := context.Background()
	scope := "witness"
	seq := uint64(42)

	kmsClient := kms.NewClientV2()
	kmsClient.WithRand(newReplicationRand())
	sender := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	sender.SetRand(newReplicationRand())
	receiverTPM := tpm.NewHandlerV2()
	receiver := DBpkg.NewReplicator(kmsClient, receiverTPM)
	receiver.SetRand(newReplicationRand())

	keys, _ := kmsClient.GetKeys(scope, seq)
	plain := []byte("payload-old1")
	old1Env := sealWithKey(t, keys[0], 55, true, true, plain, tpm.NewHandlerV2(), newReplicationRand())

	if _, err := kmsClient.Rotate(scope); err != nil {
		t.Fatalf("Rotate current->old1: %v", err)
	}

	chunk, err := sender.GenerateChunk(ctx, scope, seq, []crypto.Envelope{old1Env})
	if err != nil {
		t.Fatalf("GenerateChunk old1: %v", err)
	}
	payload, err := sender.SendChunk(ctx, chunk)
	if err != nil {
		t.Fatalf("SendChunk old1: %v", err)
	}
	if _, err := receiver.ReceiveChunk(ctx, scope, payload); err != nil {
		t.Fatalf("ReceiveChunk old1: %v", err)
	}

	// Rotate again pushing v1 to Old2.
	if _, err := kmsClient.Rotate(scope); err != nil {
		t.Fatalf("Rotate old1->old2: %v", err)
	}

	keysAfter, _ := kmsClient.GetKeys(scope, seq)
	old2Env := sealWithKey(t, keysAfter[2], 77, false, false, []byte("payload-old2"), tpm.NewHandlerV2(), newReplicationRand())
	chunk2, err := sender.GenerateChunk(ctx, scope, seq, []crypto.Envelope{old2Env})
	if err != nil {
		t.Fatalf("GenerateChunk old2: %v", err)
	}
	payload2, err := sender.SendChunk(ctx, chunk2)
	if err != nil {
		t.Fatalf("SendChunk old2: %v", err)
	}
	if _, err := receiver.ReceiveChunk(ctx, scope, payload2); err != nil {
		t.Fatalf("ReceiveChunk old2: %v", err)
	}
}

func TestDBReplication_TPMAndZeroization(t *testing.T) {
	ctx := context.Background()
	scope := "witness"
	seq := uint64(99)

	kmsClient := kms.NewClientV2()
	kmsClient.WithRand(newReplicationRand())

	senderTPM := tpm.NewHandlerV2()
	receiverTPM := tpm.NewHandlerV2()

	sender := DBpkg.NewReplicator(kmsClient, senderTPM)
	senderRand := newReplicationRand()
	sender.SetRand(senderRand)

	var zeroized [][]byte
	var mu sync.Mutex
	sender.SetPlaintextHook(func(buf []byte) {
		mu.Lock()
		defer mu.Unlock()
		zeroized = append(zeroized, append([]byte(nil), buf...))
	})

	receiver := DBpkg.NewReplicator(kmsClient, receiverTPM)
	receiver.SetRand(newReplicationRand())

	keys, _ := kmsClient.GetKeys(scope, seq)
	env := sealWithKey(t, keys[0], 3, true, true, []byte("zeroization-check"), tpm.NewHandlerV2(), newReplicationRand())

	chunk, err := sender.GenerateChunk(ctx, scope, seq, []crypto.Envelope{env})
	if err != nil {
		t.Fatalf("GenerateChunk: %v", err)
	}
	payload, err := sender.SendChunk(ctx, chunk)
	if err != nil {
		t.Fatalf("SendChunk: %v", err)
	}
	if _, err := receiver.ReceiveChunk(ctx, scope, payload); err != nil {
		t.Fatalf("ReceiveChunk: %v", err)
	}

	if !receiverTPM.LastZeroized() {
		t.Fatalf("expected TPM handler to observe zeroized plaintext")
	}

	mu.Lock()
	found := false
	for _, buf := range zeroized {
		if len(buf) == len("zeroization-check") && allZero(buf) {
			found = true
			break
		}
	}
	mu.Unlock()
	if !found {
		t.Fatalf("plaintext buffer not zeroized after reseal")
	}
}

func TestDBReplication_SQLiteAndMerkle(t *testing.T) {
	ctx := context.Background()
	scope := "witness"
	seq := uint64(7)

	kmsClient := kms.NewClientV2()
	kmsClient.WithRand(newReplicationRand())

	sender := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	sender.SetRand(newReplicationRand())
	receiver := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	receiver.SetRand(newReplicationRand())

	keys, _ := kmsClient.GetKeys(scope, seq)
	env := sealWithKey(t, keys[0], 88, true, false, []byte("sqlite-merkle"), tpm.NewHandlerV2(), newReplicationRand())

	chunk, err := sender.GenerateChunk(ctx, scope, seq, []crypto.Envelope{env})
	if err != nil {
		t.Fatalf("GenerateChunk: %v", err)
	}
	payload, err := sender.SendChunk(ctx, chunk)
	if err != nil {
		t.Fatalf("SendChunk: %v", err)
	}
	res, err := receiver.ReceiveChunk(ctx, scope, payload)
	if err != nil {
		t.Fatalf("ReceiveChunk: %v", err)
	}

	db := DBpkg.Connect()
	defer db.Close()

	if err := DBpkg.InsertEnvelope(db, res.Envelopes[0]); err != nil {
		t.Fatalf("first insert failed: %v", err)
	}
	if err := DBpkg.InsertEnvelope(db, res.Envelopes[0]); err == nil {
		t.Fatalf("expected duplicate insert error")
	}

	expectedRoot := recomputeMerkle([]crypto.Envelope{res.Envelopes[0]})
	if !bytes.Equal(expectedRoot, res.Merkle) {
		t.Fatalf("merkle root mismatch")
	}
}

func TestDBReplication_ErrResend(t *testing.T) {
	ctx := context.Background()
	scope := "witness"
	seq := uint64(5)

	kmsClient := kms.NewClientV2()
	kmsClient.WithRand(newReplicationRand())

	sender := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	sender.SetRand(newReplicationRand())
	receiver := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	receiver.SetRand(newReplicationRand())

	keys, _ := kmsClient.GetKeys(scope, seq)
	env := sealWithKey(t, keys[0], 11, false, false, []byte("resend-path"), tpm.NewHandlerV2(), newReplicationRand())

	chunk, err := sender.GenerateChunk(ctx, scope, seq, []crypto.Envelope{env})
	if err != nil {
		t.Fatalf("GenerateChunk: %v", err)
	}

	// Rotate keys beyond history to invalidate chunk.
	if _, err := kmsClient.Rotate(scope); err != nil {
		t.Fatalf("rotate: %v", err)
	}
	if _, err := kmsClient.Rotate(scope); err != nil {
		t.Fatalf("rotate 2: %v", err)
	}
	if _, err := kmsClient.Rotate(scope); err != nil {
		t.Fatalf("rotate 3: %v", err)
	}

	payload, err := sender.SendChunk(ctx, chunk)
	if err != nil {
		t.Fatalf("SendChunk: %v", err)
	}
	_, err = receiver.ReceiveChunk(ctx, scope, payload)
	if !errors.Is(err, DBpkg.ErrResend) {
		t.Fatalf("expected ErrResend, got %v", err)
	}
}

// Helpers

func sealWithKey(t *testing.T, key kms.KeyMaterial, seqID uint32, orderForward, orderUsed bool, plain []byte, tpmHandler *tpm.HandlerV2, randSrc io.Reader) crypto.Envelope {
	t.Helper()
	payload, err := tpmHandler.ISEEncrypt(append([]byte(nil), plain...), key.ISE[:])
	if err != nil {
		t.Fatalf("ISEEncrypt: %v", err)
	}
	defer zero(payload)

	compressed := mustCompress(t, payload)
	defer zero(compressed)

	block, err := aes.NewCipher(key.AES[:])
	if err != nil {
		t.Fatalf("aes cipher: %v", err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		t.Fatalf("gcm: %v", err)
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(randSrc, nonce); err != nil {
		t.Fatalf("rand: %v", err)
	}
	ct := gcm.Seal(nil, nonce, compressed, nil)

	plainHash := sha256.Sum256(plain)
	cipherHash := sha256.Sum256(pack(nonce, ct))

	return crypto.Envelope{
		KeyVersion:           key.Version,
		SeqID:                seqID,
		OrderForward:         orderForward,
		OrderUsedForward:     orderUsed,
		Nonce:                nonce,
		Ciphertext:           ct,
		PlainHash:            plainHash[:],
		CipherHash:           cipherHash[:],
		CommitSignature:      testSignature(key.ISE[:], key.Version, plainHash[:], seqID, !orderForward, "commit"),
		OperationalSignature: testSignature(key.ISE[:], key.Version, cipherHash[:], seqID, orderUsed, "oper"),
	}
}

func mustCompress(t *testing.T, data []byte) []byte {
	t.Helper()
	var buf bytes.Buffer
	zw := gzip.NewWriter(&buf)
	if _, err := zw.Write(data); err != nil {
		t.Fatalf("gzip write: %v", err)
	}
	if err := zw.Close(); err != nil {
		t.Fatalf("gzip close: %v", err)
	}
	return buf.Bytes()
}

func recomputeMerkle(envelopes []crypto.Envelope) []byte {
	if len(envelopes) == 0 {
		return nil
	}
	nodes := make([][]byte, len(envelopes))
	for i, env := range envelopes {
		nodes[i] = append([]byte(nil), env.PlainHash...)
	}
	for len(nodes) > 1 {
		next := make([][]byte, 0, (len(nodes)+1)/2)
		for i := 0; i < len(nodes); i += 2 {
			if i+1 == len(nodes) {
				next = append(next, nodes[i])
				continue
			}
			merged := append(append([]byte(nil), nodes[i]...), nodes[i+1]...)
			h := sha256.Sum256(merged)
			next = append(next, h[:])
		}
		nodes = next
	}
	return nodes[0]
}

func testSignature(key []byte, version uint64, hash []byte, seqID uint32, orderForward bool, label string) []byte {
	mac := hmac.New(sha256.New, key)
	mac.Write(hash)
	var seqBuf [4]byte
	binary.LittleEndian.PutUint32(seqBuf[:], seqID)
	mac.Write(seqBuf[:])
	var verBuf [8]byte
	binary.LittleEndian.PutUint64(verBuf[:], version)
	mac.Write(verBuf[:])
	if orderForward {
		mac.Write([]byte{0x01})
	} else {
		mac.Write([]byte{0x00})
	}
	mac.Write([]byte(label))
	return mac.Sum(nil)
}

type replicationRand struct {
	mu sync.Mutex
	n  byte
}

func newReplicationRand() *replicationRand {
	return &replicationRand{}
}

func (r *replicationRand) Read(p []byte) (int, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for i := range p {
		p[i] = r.n
		r.n++
	}
	return len(p), nil
}

func zero(buf []byte) {
	for i := range buf {
		buf[i] = 0
	}
}

func pack(nonce, ciphertext []byte) []byte {
	out := make([]byte, 0, len(nonce)+len(ciphertext))
	out = append(out, nonce...)
	out = append(out, ciphertext...)
	return out
}

func allZero(buf []byte) bool {
	for _, b := range buf {
		if b != 0 {
			return false
		}
	}
	return true
}
