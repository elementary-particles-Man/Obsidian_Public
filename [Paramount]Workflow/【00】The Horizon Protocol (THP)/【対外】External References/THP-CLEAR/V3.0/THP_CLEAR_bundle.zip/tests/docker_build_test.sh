#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOG_PREFIX="[docker-build-test]"

echo "${LOG_PREFIX} ensuring docker compose build succeeds..."
docker compose build thpclear-ci

echo "${LOG_PREFIX} verifying DLL availability and running go test inside container..."
docker compose run --rm thpclear-ci bash -c '
  set -euo pipefail
  if [ ! -r /opt/clear_encryptor.dll ]; then
    echo "clear_encryptor DLL missing at /opt/clear_encryptor.dll" >&2
    exit 1
  fi
  mkdir -p /var/tpm || true
  if [ ! -w /var/tpm ]; then
    echo "/var/tpm is not writable" >&2
    exit 1
  fi
  go test ./... > /app/test.log
'

echo "${LOG_PREFIX} go test passed and results captured in test.log"
