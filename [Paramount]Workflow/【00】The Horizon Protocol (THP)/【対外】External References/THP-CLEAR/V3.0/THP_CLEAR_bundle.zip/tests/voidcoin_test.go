package tests

import (
	"context"
	"encoding/binary"
	"strings"
	"testing"
	"time"

	"thp-clear/src/WN"
	"thp-clear/src/crypto"
	"thp-clear/src/model"
)

func TestVoidCoinEnforcement(t *testing.T) {
	var aesKey [crypto.AES256KeySize]byte
	for i := range aesKey {
		aesKey[i] = byte(i)
	}

	exchangeID := uint64(0x0001000000000001)
	alternateExchange := uint64(0x0001000000000002)
	outsiderID := uint64(0x0002000000000001)

	rules := WN.VoidRules{
		CurrencyNum:      65535,
		FeeMinor:         0,
		ExchangeNodeIDs:  map[uint64]struct{}{exchangeID: {}, alternateExchange: {}},
		ForbidVoidToVoid: true,
	}

	cases := []struct {
		name         string
		fromID       uint64
		toID         uint64
		exchangeFlag bool
		wantContains string
	}{
		{
			name:         "flag missing",
			fromID:       exchangeID,
			toID:         outsiderID,
			exchangeFlag: false,
			wantContains: "EXCHANGE_ONLY_REQUIRED",
		},
		{
			name:         "no exchange participant",
			fromID:       outsiderID,
			toID:         outsiderID + 1,
			exchangeFlag: true,
			wantContains: "EXCHANGE_ONLY_REQUIRED",
		},
		{
			name:         "exchange ok",
			fromID:       exchangeID,
			toID:         outsiderID,
			exchangeFlag: true,
			wantContains: "",
		},
		{
			name:         "exchange to exchange",
			fromID:       exchangeID,
			toID:         alternateExchange,
			exchangeFlag: true,
			wantContains: "VOID_TO_VOID_FORBIDDEN",
		},
	}

	// Map expected errors to concrete ones after building once to access package-level vars.
	processor := WN.NewProcessor()

	for i, tc := range cases {
		wire, _ := buildVoidPacketForTest(t, aesKey, tc.fromID, tc.toID, tc.exchangeFlag)
		res, err := processor.Process(context.Background(), WN.ProcessRequest{
			PacketBytes: wire,
			AESKey:      aesKey,
			SeqNo:       uint64(i + 1),
			VoidRules:   rules,
		})

		if tc.wantContains == "" {
			if err != nil {
				t.Fatalf("%s: unexpected error %v", tc.name, err)
			}
			if res == nil || res.Body == nil {
				t.Fatalf("%s: expected result", tc.name)
			}
			if !res.Body.Header.ExchangeFlag() {
				t.Fatalf("%s: exchange flag should remain set", tc.name)
			}
			if res.Witness.SeqNo != uint64(i+1) {
				t.Fatalf("%s: seq mismatch", tc.name)
			}
			continue
		}

		if err == nil {
			t.Fatalf("%s: expected error containing %q", tc.name, tc.wantContains)
		}
		if !strings.Contains(err.Error(), tc.wantContains) {
			t.Fatalf("%s: expected error containing %q, got %v", tc.name, tc.wantContains, err)
		}
	}
}

func buildVoidPacketForTest(t *testing.T, aesKey [crypto.AES256KeySize]byte, fromID, toID uint64, exchangeFlag bool) ([]byte, *model.PacketBody) {
	t.Helper()

	body := &model.PacketBody{
		Header: model.PacketHeader{
			TxID:         0x0a0b0c0d0e0f0001,
			TimestampISE: model.Millis(time.Date(2025, 1, 2, 0, 0, 0, 0, time.UTC)),
			FromID:       fromID,
			ToID:         toID,
			AssetCode:    0x80000001,
			CurrencyNum:  65535,
			AmountMinor:  4321,
			FeeMinor:     0,
		},
	}
	if exchangeFlag {
		body.Header.Flags2 = model.PacketFlags2Exchange
	}
	body.Control.H = body.IdempotencyHash()

	plain, err := body.MarshalBinary()
	if err != nil {
		t.Fatalf("marshal body: %v", err)
	}

	aesgcm, err := crypto.NewAES256GCM(aesKey[:])
	if err != nil {
		t.Fatalf("aes init: %v", err)
	}
	aad := makeAAD(body.Header.TxID, body.Header.TimestampISE, model.PacketVersion)
	iv, ciphertext, tag, err := aesgcm.Encrypt(plain, aad)
	if err != nil {
		t.Fatalf("encrypt: %v", err)
	}

	var packet model.PacketCipher
	packet.IV = iv
	packet.Tag = tag
	copy(packet.Ciphertext[:], ciphertext)
	packet.UpdateCRC()

	wire, err := packet.MarshalBinary()
	if err != nil {
		t.Fatalf("marshal packet: %v", err)
	}
	return wire, body
}

func makeAAD(txID, timestamp uint64, version uint8) []byte {
	var aad [17]byte
	binary.BigEndian.PutUint64(aad[0:8], txID)
	binary.BigEndian.PutUint64(aad[8:16], timestamp)
	aad[16] = version
	return aad[:]
}
