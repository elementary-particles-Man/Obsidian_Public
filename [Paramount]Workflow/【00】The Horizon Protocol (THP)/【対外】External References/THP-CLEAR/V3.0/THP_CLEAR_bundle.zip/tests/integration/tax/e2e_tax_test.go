package tax

import (
	"bytes"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"thp-clear/pkg/clear"
	"thp-clear/pkg/crypto"
	"thp-clear/pkg/witness"
)

func TestEndToEndTAX(t *testing.T) {
	atomic.StoreInt64(&CommitCount, 0)
	go startMockClear()
	time.Sleep(500 * time.Millisecond)

	// 1) Encrypt sample payload
	key := selectAESKey(t)
	nonce := make([]byte, 12)
	aad := []byte("tax")
	plain := []byte("integration-demo-payload")
	env, _ := crypto.EncryptAESGCM(key, nonce, aad, plain)
	data, _ := json.Marshal(env.ToBase64())

	// 2) POST to mock DBE-TAX ingest endpoint (expected 200)
	resp, err := http.Post("http://localhost:9443/tax/ingest", "application/json", bytes.NewReader(data))
	if err != nil {
		t.Fatal(err)
	}
	body, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Fatalf("bad status %d body=%s", resp.StatusCode, string(body))
	}

	// 3) Generate Witness pointer and post to mock CLEAR
	tp := witness.NewTaxPointer([]byte("clear-secret"), "commit-demo", "kid-demo", "plain-hash", "cipher-hash", "dbe-node")
	wr := clear.WitnessRecord{Type: "tax_batch_commit", CommitID: "commit-demo", Kid: "kid-demo", Sha256Plain: "plain-hash", Sha256Cipher: "cipher-hash", DBENode: "dbe-node", Epoch: int64(tp.Epoch)}
	clear.PostWitness("http://localhost:9555/witness/commit", wr)

	// 4) Wait and verify
	time.Sleep(500 * time.Millisecond)
	if CommitCount < 1 {
		t.Fatal("witness commit not received")
	}
	log.Printf("[E2E] PASS: %d witness commits", CommitCount)

	manifestPath := filepath.Join("..", "..", "..", "var", "dbe-tax", "batch_commit.json")
	manifestPath, _ = filepath.Abs(manifestPath)
	var (
		manifestData []byte
		readErr      error
	)
	for i := 0; i < 10; i++ {
		manifestData, readErr = os.ReadFile(manifestPath)
		if readErr == nil {
			break
		}
		time.Sleep(100 * time.Millisecond)
	}
	if readErr != nil {
		t.Fatalf("manifest read failure: %v", readErr)
	}
	var manifest struct {
		Kid           string `json:"kid"`
		PayloadBase64 string `json:"payload_base64"`
		PayloadSize   int    `json:"payload_size"`
	}
	if err := json.Unmarshal(manifestData, &manifest); err != nil {
		t.Fatalf("manifest decode error: %v", err)
	}
	if manifest.Kid == "" {
		t.Fatalf("manifest missing kid")
	}
	payload, err := base64.StdEncoding.DecodeString(manifest.PayloadBase64)
	if err != nil {
		t.Fatalf("manifest payload decode error: %v", err)
	}
	if string(payload) != "integration-demo-payload" {
		t.Fatalf("manifest payload mismatch: %q", string(payload))
	}
	if manifest.PayloadSize != len(payload) {
		t.Fatalf("manifest payload size mismatch: %d vs %d", manifest.PayloadSize, len(payload))
	}
}

func selectAESKey(t *testing.T) []byte {
	t.Helper()
	candidates := []string{
		os.Getenv("WN_TAX_AES_KEY"),
		os.Getenv("DBE_TAX_AES_KEY"),
	}
	for _, candidate := range candidates {
		candidate = strings.TrimSpace(candidate)
		if candidate == "" {
			continue
		}
		raw, err := decodeKeyString(candidate)
		if err != nil {
			t.Fatalf("invalid AES key env: %v", err)
		}
		return raw
	}
	return make([]byte, 32)
}

func decodeKeyString(val string) ([]byte, error) {
	if raw, err := hex.DecodeString(val); err == nil && len(raw) == 32 {
		return raw, nil
	}
	if raw, err := base64.StdEncoding.DecodeString(val); err == nil && len(raw) == 32 {
		return raw, nil
	}
	if len(val) == 32 {
		return []byte(val), nil
	}
	return nil, fmt.Errorf("unsupported key format or length %d", len(val))
}
