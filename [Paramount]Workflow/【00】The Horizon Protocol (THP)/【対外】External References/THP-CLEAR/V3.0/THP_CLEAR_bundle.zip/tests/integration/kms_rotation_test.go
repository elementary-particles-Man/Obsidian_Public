package integration

import (
	"fmt"
	"testing"

	DBpkg "thp-clear/src/DB"
	"thp-clear/src/kms"
	"thp-clear/src/tpm"
)

func TestKMSRotationFallback(t *testing.T) {
	const scope = "integration-rotation"
	kmsClient := kms.NewClientV2()
	kmsClient.WithRand(newReplicationRand())

	sender := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	sender.SetRand(newReplicationRand())
	receiver := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	receiver.SetRand(newReplicationRand())

	// Establish initial state.
	keys, err := kmsClient.GetKeys(scope, 1)
	if err != nil {
		t.Fatalf("GetKeys: %v", err)
	}
	initial := buildEnvelope(t, keys[0], 1, true, true, []byte("initial"))
	replicateOnce(t, sender, receiver, scope, 1, initial)

	// Rotate twice to populate Old1/Old2.
	keyV2, err := kmsClient.Rotate(scope)
	if err != nil {
		t.Fatalf("Rotate v2: %v", err)
	}
	keyV3, err := kmsClient.Rotate(scope)
	if err != nil {
		t.Fatalf("Rotate v3: %v", err)
	}

	// Keep copies for zeroization check.
	keyCopies := []kms.KeyMaterial{keys[0], keyV2, keyV3}

	for i := 0; i < 100; i++ {
		seq := uint64(i + 10)
		keyset, err := kmsClient.GetKeys(scope, seq)
		if err != nil {
			t.Fatalf("GetKeys(%d): %v", seq, err)
		}

		var source kms.KeyMaterial
		switch i % 3 {
		case 0:
			source = keyset[0]
		case 1:
			source = keyset[1]
		default:
			source = keyset[2]
		}

		payload := []byte(fmt.Sprintf("rot-tx-%03d", i))
		env := buildEnvelope(t, source, uint32(seq), true, true, payload)
		result, _ := replicateOnce(t, sender, receiver, scope, seq, env)

		if len(result.Envelopes) != 1 {
			t.Fatalf("expected 1 envelope, got %d", len(result.Envelopes))
		}

		resealed := result.Envelopes[0]
		if _, err := decryptEnvelope(resealed, keyset[0], tpm.NewHandlerV2()); err != nil {
			t.Fatalf("decrypt with current key failed: %v", err)
		}
		if _, err := decryptEnvelope(resealed, keyset[1], tpm.NewHandlerV2()); err == nil && keyset[1].Version != keyset[0].Version {
			t.Fatalf("old1 key should not decrypt resealed payload")
		}
		if _, err := decryptEnvelope(resealed, keyset[2], tpm.NewHandlerV2()); err == nil && keyset[2].Version != keyset[0].Version {
			t.Fatalf("old2 key should not decrypt resealed payload")
		}
	}

	for idx := range keyCopies {
		zeroKeyMaterialLocal(&keyCopies[idx])
		if keyCopies[idx].Version != 0 {
			t.Fatalf("expected key copy %d version zeroized", idx)
		}
		if !allZero(keyCopies[idx].AES[:]) || !allZero(keyCopies[idx].ISE[:]) {
			t.Fatalf("expected key copy %d zeroized buffers", idx)
		}
	}
}
