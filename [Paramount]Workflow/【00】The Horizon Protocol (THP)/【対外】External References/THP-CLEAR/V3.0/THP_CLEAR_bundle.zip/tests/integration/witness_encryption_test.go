package integration

import (
	"bytes"
	"fmt"
	"testing"

	DBpkg "thp-clear/src/DB"
	"thp-clear/src/kms"
	"thp-clear/src/tpm"
)

func TestWitnessEncryptionVerification(t *testing.T) {
	const scope = "integration-witness"
	kmsClient := kms.NewClientV2()
	kmsClient.WithRand(newReplicationRand())

	sender := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	sender.SetRand(newReplicationRand())
	receiver := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	receiver.SetRand(newReplicationRand())

	for i := 0; i < 5; i++ {
		seq := uint64(i + 1)
		payload := []byte(fmt.Sprintf("witness-payload-%d", i))
		keys, err := kmsClient.GetKeys(scope, seq)
		if err != nil {
			t.Fatalf("GetKeys: %v", err)
		}
		origEnv := buildEnvelope(t, keys[0], uint32(seq), true, true, payload)
		origCipher := append([]byte(nil), origEnv.Ciphertext...)

		result, chunk := replicateOnce(t, sender, receiver, scope, seq, origEnv)
		if len(result.Envelopes) != 1 {
			t.Fatalf("expected single envelope, got %d", len(result.Envelopes))
		}

		replayed := result.Envelopes[0]
		handler := tpm.NewHandlerV2()
		plain, err := decryptEnvelope(replayed, keys[0], handler)
		if err != nil {
			t.Fatalf("decryptEnvelope: %v", err)
		}
		if !bytes.Equal(plain, payload) {
			t.Fatalf("plaintext mismatch: %q vs %q", plain, payload)
		}

		badKey := randomKeyMaterial(keys[0].Version + 100)
		if _, err := decryptEnvelope(replayed, badKey, tpm.NewHandlerV2()); err == nil {
			t.Fatalf("expected decryption failure with mismatched key")
		}

		if bytes.Equal(origCipher, replayed.Ciphertext) {
			t.Fatalf("resealed ciphertext should differ from original")
		}

		root := merkleFromEnvelopes(result.Envelopes)
		if !bytesEqual(root, chunk.Metadata.MerkleRoot) {
			t.Fatalf("merkle root mismatch")
		}
	}
}
