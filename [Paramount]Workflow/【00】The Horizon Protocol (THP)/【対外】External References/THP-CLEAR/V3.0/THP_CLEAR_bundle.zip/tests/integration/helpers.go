package integration

import (
	"bytes"
	"compress/gzip"
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"io"
	"sync"
	"testing"

	DBpkg "thp-clear/src/DB"
	"thp-clear/src/common/crypto"
	"thp-clear/src/kms"
	"thp-clear/src/tpm"
)

type replicationRand struct {
	mu sync.Mutex
	n  byte
}

func newReplicationRand() *replicationRand {
	return &replicationRand{}
}

func (r *replicationRand) Read(p []byte) (int, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for i := range p {
		p[i] = r.n
		r.n++
	}
	return len(p), nil
}

func buildEnvelope(t *testing.T, key kms.KeyMaterial, seqID uint32, orderForward, orderUsed bool, plain []byte) crypto.Envelope {
	t.Helper()
	handler := tpm.NewHandlerV2()
	payload, err := handler.ISEEncrypt(append([]byte(nil), plain...), key.ISE[:])
	if err != nil {
		t.Fatalf("ISEEncrypt: %v", err)
	}
	defer zero(payload)

	compressed, err := compress(payload)
	if err != nil {
		t.Fatalf("compress: %v", err)
	}
	defer zero(compressed)

	block, err := aes.NewCipher(key.AES[:])
	if err != nil {
		t.Fatalf("aes cipher: %v", err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		t.Fatalf("gcm: %v", err)
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(newReplicationRand(), nonce); err != nil {
		t.Fatalf("rand: %v", err)
	}
	ciphertext := gcm.Seal(nil, nonce, compressed, nil)

	plainHash := sha256.Sum256(plain)
	cipherHash := sha256.Sum256(pack(nonce, ciphertext))

	return crypto.Envelope{
		KeyVersion:           key.Version,
		SeqID:                seqID,
		OrderForward:         orderForward,
		OrderUsedForward:     orderUsed,
		Nonce:                nonce,
		Ciphertext:           ciphertext,
		PlainHash:            plainHash[:],
		CipherHash:           cipherHash[:],
		CommitSignature:      computeSignature(key.ISE[:], key.Version, plainHash[:], seqID, !orderForward, "commit"),
		OperationalSignature: computeSignature(key.ISE[:], key.Version, cipherHash[:], seqID, orderUsed, "oper"),
	}
}

func compress(data []byte) ([]byte, error) {
	var buf bytes.Buffer
	zw := gzip.NewWriter(&buf)
	if _, err := zw.Write(data); err != nil {
		zw.Close()
		return nil, err
	}
	if err := zw.Close(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func merkleFromEnvelopes(envs []crypto.Envelope) []byte {
	if len(envs) == 0 {
		return nil
	}
	nodes := make([][]byte, len(envs))
	for i, env := range envs {
		nodes[i] = append([]byte(nil), env.PlainHash...)
	}
	for len(nodes) > 1 {
		next := make([][]byte, 0, (len(nodes)+1)/2)
		for i := 0; i < len(nodes); i += 2 {
			if i+1 == len(nodes) {
				next = append(next, nodes[i])
				continue
			}
			merged := append(append([]byte(nil), nodes[i]...), nodes[i+1]...)
			hash := sha256.Sum256(merged)
			next = append(next, hash[:])
		}
		nodes = next
	}
	return nodes[0]
}

func computeSignature(key []byte, version uint64, dataHash []byte, seqID uint32, orderForward bool, label string) []byte {
	mac := hmac.New(sha256.New, key)
	mac.Write(dataHash)

	var seqBuf [4]byte
	binary.LittleEndian.PutUint32(seqBuf[:], seqID)
	mac.Write(seqBuf[:])

	var verBuf [8]byte
	binary.LittleEndian.PutUint64(verBuf[:], version)
	mac.Write(verBuf[:])

	if orderForward {
		mac.Write([]byte{0x01})
	} else {
		mac.Write([]byte{0x00})
	}

	mac.Write([]byte(label))
	return mac.Sum(nil)
}

func pack(nonce, ciphertext []byte) []byte {
	out := make([]byte, 0, len(nonce)+len(ciphertext))
	out = append(out, nonce...)
	out = append(out, ciphertext...)
	return out
}

func zero(buf []byte) {
	for i := range buf {
		buf[i] = 0
	}
}

func allZero(buf []byte) bool {
	for _, b := range buf {
		if b != 0 {
			return false
		}
	}
	return true
}

func zeroKeyMaterialLocal(mat *kms.KeyMaterial) {
	if mat == nil {
		return
	}
	zero(mat.AES[:])
	zero(mat.ISE[:])
	mat.Version = 0
}

func decryptEnvelope(env crypto.Envelope, key kms.KeyMaterial, handler *tpm.HandlerV2) ([]byte, error) {
	if len(key.AES) != 32 {
		return nil, errors.New("invalid key material")
	}
	block, err := aes.NewCipher(key.AES[:])
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	payload, err := gcm.Open(nil, env.Nonce, env.Ciphertext, nil)
	if err != nil {
		return nil, err
	}
	defer zero(payload)
	zr, err := gzip.NewReader(bytes.NewReader(payload))
	if err != nil {
		return nil, err
	}
	defer zr.Close()

	var plainBuf bytes.Buffer
	if _, err := io.Copy(&plainBuf, zr); err != nil {
		return nil, err
	}
	plain, err := handler.Decrypt(plainBuf.Bytes(), key.ISE[:])
	if err != nil {
		return nil, err
	}
	return plain, nil
}

func replicateOnce(t *testing.T, sender *DBpkg.Replicator, receiver *DBpkg.Replicator, scope string, seq uint64, env crypto.Envelope) (*DBpkg.ReceiveResult, *DBpkg.Chunk) {
	t.Helper()
	ctx := context.Background()
	chunk, err := sender.GenerateChunk(ctx, scope, seq, []crypto.Envelope{env})
	if err != nil {
		t.Fatalf("GenerateChunk: %v", err)
	}
	payload, err := sender.SendChunk(ctx, chunk)
	if err != nil {
		t.Fatalf("SendChunk: %v", err)
	}
	result, err := receiver.ReceiveChunk(ctx, scope, payload)
	if err != nil {
		t.Fatalf("ReceiveChunk: %v", err)
	}
	return result, chunk
}

func randomKeyMaterial(version uint64) kms.KeyMaterial {
	mat := kms.KeyMaterial{Version: version}
	_, _ = rand.Read(mat.AES[:])
	_, _ = rand.Read(mat.ISE[:])
	return mat
}
