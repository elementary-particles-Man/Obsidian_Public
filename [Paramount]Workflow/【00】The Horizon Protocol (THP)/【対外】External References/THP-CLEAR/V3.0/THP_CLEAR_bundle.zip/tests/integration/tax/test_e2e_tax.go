//go:build legacy_tax_tests
// +build legacy_tax_tests

package tax

import (
	"bytes"
	"encoding/json"
	"io"
	"log"
	"net/http"
	"testing"
	"thp-clear/pkg/clear"
	"thp-clear/pkg/crypto"
	"thp-clear/pkg/witness"
	"time"
)

func TestEndToEndTAX(t *testing.T) {
	go startMockClear()
	time.Sleep(500 * time.Millisecond)

	// 1) Encrypt sample payload
	key := make([]byte, 32)
	nonce := make([]byte, 12)
	aad := []byte("tax")
	plain := []byte("integration-demo-payload")
	env, _ := crypto.EncryptAESGCM(key, nonce, aad, plain)
	data, _ := json.Marshal(env.ToBase64())

	// 2) POST to mock DBE-TAX ingest endpoint (expected 200)
	resp, err := http.Post("http://localhost:9443/tax/ingest", "application/json", bytes.NewReader(data))
	if err != nil {
		t.Fatal(err)
	}
	body, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Fatalf("bad status %d body=%s", resp.StatusCode, string(body))
	}

	// 3) Generate Witness pointer and post to mock CLEAR
	tp := witness.NewTaxPointer([]byte("clear-secret"), "commit-demo", "kid-demo", "plain-hash", "cipher-hash", "dbe-node")
	wr := clear.WitnessRecord{Type: "tax_batch_commit", CommitID: "commit-demo", Kid: "kid-demo", Sha256Plain: "plain-hash", Sha256Cipher: "cipher-hash", DBENode: "dbe-node", Epoch: int64(tp.Epoch)}
	clear.PostWitness("http://localhost:9555/witness/commit", wr)

	// 4) Wait and verify
	time.Sleep(500 * time.Millisecond)
	if CommitCount < 1 {
		t.Fatal("witness commit not received")
	}
	log.Printf("[E2E] PASS: %d witness commits", CommitCount)
}
