package tax

import (
	"testing"
	"thp-clear/pkg/crypto"
)

func TestAESGCM(t *testing.T) {
	key := make([]byte, 32)
	nonce := make([]byte, 12)
	aad := []byte("test")
	plain := []byte("hello world")
	env, err := crypto.EncryptAESGCM(key, nonce, aad, plain)
	if err != nil {
		t.Fatal(err)
	}
	dec, err := crypto.DecryptAESGCM(key, env)
	if err != nil {
		t.Fatal(err)
	}
	if string(dec) != string(plain) {
		t.Fatal("mismatch")
	}
}
