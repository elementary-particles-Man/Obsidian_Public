package tax

import (
	"encoding/json"
	"log"
	"net/http"
	"sync/atomic"
)

var CommitCount int64

func startMockClear() {
	http.HandleFunc("/witness/commit", func(w http.ResponseWriter, r *http.Request) {
		atomic.AddInt64(&CommitCount, 1)
		var body map[string]interface{}
		json.NewDecoder(r.Body).Decode(&body)
		log.Printf("[MOCK-CLEAR] commit received: %v", body["commit_id"])
		w.WriteHeader(200)
	})
	go http.ListenAndServe(":9555", nil)
	log.Println("[MOCK-CLEAR] listening :9555")
}
