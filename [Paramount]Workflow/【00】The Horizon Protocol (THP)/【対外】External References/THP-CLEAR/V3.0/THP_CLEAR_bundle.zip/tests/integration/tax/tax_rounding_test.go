package tax

import (
	"errors"
	"math"
	"testing"

	"thp-clear/internal/jptax"
)

func TestTaxRounding(t *testing.T) {
	cases := []struct {
		name      string
		base      float64
		rate      float64
		wantBase  int64
		wantTax   int64
		wantTotal int64
	}{
		{"WholeAmount", 1000, 0.1, 1000, 100, 1100},
		{"RoundingUpBase", 1000.6, 0.1, 1001, 100, 1101},
		{"RoundingDownBase", 999.4, 0.1, 999, 99, 1098},
		{"HighRate", 1000, 0.08, 1000, 80, 1080},
	}

	for _, tc := range cases {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			t.Helper()
			result, err := jptax.ComputeTax(jptax.ComputationInput{BaseAmount: tc.base, TaxRate: tc.rate})
			if err != nil {
				t.Fatalf("ComputeTax returned error: %v", err)
			}
			if result.RoundedBase != tc.wantBase {
				t.Fatalf("RoundedBase = %d, want %d", result.RoundedBase, tc.wantBase)
			}
			if result.TaxAmount != tc.wantTax {
				t.Fatalf("TaxAmount = %d, want %d", result.TaxAmount, tc.wantTax)
			}
			if result.TotalAmount != tc.wantTotal {
				t.Fatalf("TotalAmount = %d, want %d", result.TotalAmount, tc.wantTotal)
			}
		})
	}
}

func TestTaxRounding_InvalidInput(t *testing.T) {
	_, err := jptax.ComputeTax(jptax.ComputationInput{BaseAmount: math.NaN(), TaxRate: 0.1})
	if err == nil {
		t.Fatal("expected error for NaN base")
	}
	if !errors.Is(err, jptax.ErrInvalidBaseAmount) {
		t.Fatalf("unexpected error %v", err)
	}

	_, err = jptax.ComputeTax(jptax.ComputationInput{BaseAmount: 100, TaxRate: -0.1})
	if err == nil {
		t.Fatal("expected error for negative rate")
	}
	if !errors.Is(err, jptax.ErrInvalidTaxRate) {
		t.Fatalf("unexpected error %v", err)
	}
}
