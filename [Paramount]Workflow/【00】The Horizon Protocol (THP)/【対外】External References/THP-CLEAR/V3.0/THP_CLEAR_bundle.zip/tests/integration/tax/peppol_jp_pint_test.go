package tax

import (
	"bytes"
	"encoding/xml"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"thp-clear/internal/peppoljp"
)

func TestPeppolJP_PINT(t *testing.T) {
	t.Run("BuildInvoice", func(t *testing.T) {
		inv := peppoljp.InvoiceData{
			ID:               "INV-UT-001",
			DocumentCurrency: "JPY",
			IssueDate:        time.Date(2024, 11, 6, 0, 0, 0, 0, time.UTC),
			AccountingSupplier: peppoljp.Party{
				PartyName: "ACME Corp",
				ID:        "JP-SUP-001",
			},
			AccountingCustomer: peppoljp.Party{
				PartyName: "Tokyo Trading",
				ID:        "JP-CUS-001",
			},
			Tax: peppoljp.TaxTotal{TaxAmount: peppoljp.AmountFromInt(100, "JPY")},
			Total: peppoljp.MonetaryTotal{
				PayableAmount: peppoljp.AmountFromInt(1100, "JPY"),
			},
		}

		payload, err := peppoljp.BuildInvoice(inv)
		if err != nil {
			t.Fatalf("BuildInvoice error: %v", err)
		}
		if !bytes.Contains(payload, []byte(`xmlns="`+peppoljp.NamespaceJP+`"`)) {
			t.Fatalf("payload missing JP namespace: %s", string(payload))
		}

		var parsed struct {
			XMLName              xml.Name `xml:"Invoice"`
			Xmlns                string   `xml:"xmlns,attr"`
			DocumentCurrencyCode string   `xml:"DocumentCurrencyCode"`
			ID                   string   `xml:"ID"`
		}
		if err := xml.Unmarshal(payload, &parsed); err != nil {
			t.Fatalf("unmarshal invoice: %v", err)
		}
		if parsed.Xmlns != peppoljp.NamespaceJP {
			t.Fatalf("namespace = %s, want %s", parsed.Xmlns, peppoljp.NamespaceJP)
		}
		if parsed.DocumentCurrencyCode != "JPY" {
			t.Fatalf("DocumentCurrencyCode = %s, want JPY", parsed.DocumentCurrencyCode)
		}
		if parsed.ID != inv.ID {
			t.Fatalf("cbc:ID = %s, want %s", parsed.ID, inv.ID)
		}
	})

	t.Run("SendToPeppol", func(t *testing.T) {
		payload := []byte("<Invoice />")
		var received bytes.Buffer
		srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			defer r.Body.Close()
			if ct := r.Header.Get("Content-Type"); ct != "application/xml; charset=utf-8" {
				t.Fatalf("Content-Type = %s", ct)
			}
			body, _ := io.ReadAll(r.Body)
			received.Write(body)
			w.WriteHeader(http.StatusOK)
		}))
		defer srv.Close()

		client := srv.Client()
		client.Timeout = 2 * time.Second

		if err := peppoljp.SendWithClient(client, srv.URL, payload); err != nil {
			t.Fatalf("SendWithClient error: %v", err)
		}
		if received.Len() == 0 {
			t.Fatal("expected payload to be received")
		}
	})
}
