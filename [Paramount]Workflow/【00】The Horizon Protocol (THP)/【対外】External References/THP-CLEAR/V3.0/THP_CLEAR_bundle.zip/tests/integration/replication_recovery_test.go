package integration

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"testing"

	DBpkg "thp-clear/src/DB"
	"thp-clear/src/common/crypto"
	"thp-clear/src/kms"
	"thp-clear/src/tpm"
)

func TestReplicationRecoveryFlow(t *testing.T) {
	const scope = "integration-recovery"
	kmsClient := kms.NewClientV2()
	kmsClient.WithRand(newReplicationRand())

	sender := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	sender.SetRand(newReplicationRand())

	seq := uint64(1)
	payload := []byte(fmt.Sprintf("recovery-%d", seq))
	keys, err := kmsClient.GetKeys(scope, seq)
	if err != nil {
		t.Fatalf("GetKeys: %v", err)
	}
	env := buildEnvelope(t, keys[0], uint32(seq), true, true, payload)

	chunk, err := sender.GenerateChunk(context.Background(), scope, seq, []crypto.Envelope{env})
	if err != nil {
		t.Fatalf("GenerateChunk: %v", err)
	}
	raw, err := sender.SendChunk(context.Background(), chunk)
	if err != nil {
		t.Fatalf("SendChunk: %v", err)
	}

	// Simulate DB2 restart before receiving chunk.
	receiver := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	receiver.SetRand(newReplicationRand())

	result, err := receiver.ReceiveChunk(context.Background(), scope, raw)
	if err != nil {
		t.Fatalf("ReceiveChunk after recovery: %v", err)
	}
	if len(result.Envelopes) != 1 {
		t.Fatalf("expected one envelope after recovery, got %d", len(result.Envelopes))
	}
	root := merkleFromEnvelopes(result.Envelopes)
	if !bytesEqual(root, chunk.Metadata.MerkleRoot) {
		t.Fatalf("merkle mismatch after recovery")
	}

	plain, err := decryptEnvelope(result.Envelopes[0], keys[0], tpm.NewHandlerV2())
	if err != nil {
		t.Fatalf("decryptEnvelope: %v", err)
	}
	if !bytes.Equal(plain, payload) {
		t.Fatalf("payload mismatch after reseal: %q vs %q", plain, payload)
	}

	// Corrupt payload to trigger ErrResend.
	corrupt := append([]byte(nil), raw...)
	corrupt[len(corrupt)/2] ^= 0xFF
	_, err = receiver.ReceiveChunk(context.Background(), scope, corrupt)
	if !errors.Is(err, DBpkg.ErrResend) {
		t.Fatalf("expected ErrResend, got %v", err)
	}
}
