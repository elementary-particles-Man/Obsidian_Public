package integration

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	DBpkg "thp-clear/src/DB"
	"thp-clear/src/common/crypto"
	"thp-clear/src/common/kmsclient"
	"thp-clear/src/kms"
	"thp-clear/src/tpm"
)

func TestEndToEndWitnessVerification(t *testing.T) {
	kmsClient := kms.NewClientV2()
	kmsClient.WithRand(newReplicationRand())
	sender := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	sender.SetRand(newReplicationRand())
	receiver := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	receiver.SetRand(newReplicationRand())

	type summary struct {
		TxTotal          int `json:"tx_total"`
		Verified         int `json:"verified"`
		Failed           int `json:"failed"`
		TamperedDetected int `json:"tampered_detected"`
	}
	var report summary

	payloads := [][]byte{
		[]byte("witness-alpha"),
		[]byte("witness-beta"),
		[]byte("witness-gamma"),
	}

	const scope = "integration-witness-final"
	for i, payload := range payloads {
		report.TxTotal++

		keys, err := kmsClient.GetKeys(scope, uint64(i+1))
		if err != nil {
			t.Fatalf("GetKeys: %v", err)
		}
		env := buildEnvelope(t, keys[0], uint32(i+1), true, true, payload)
		result, _ := replicateOnce(t, sender, receiver, scope, uint64(i+1), env)

		if len(result.Envelopes) != 1 {
			report.Failed++
			t.Fatalf("expected 1 envelope, got %d", len(result.Envelopes))
		}
		resealed := result.Envelopes[0]
		plain, err := decryptEnvelope(resealed, keys[0], tpm.NewHandlerV2())
		if err != nil {
			report.Failed++
			t.Fatalf("decrypt resealed payload: %v", err)
		}
		if !bytes.Equal(plain, payload) {
			report.Failed++
			t.Fatalf("plaintext mismatch post replication")
		}

		root := merkleFromEnvelopes([]crypto.Envelope{resealed})
		if !bytesEqual(root, result.Merkle) {
			report.Failed++
			t.Fatalf("merkle mismatch")
		}

		if envFFI, err := kmsclient.EncryptToEnvelope(payload); err == nil {
			if dec, err := kmsclient.DecryptEnvelope(envFFI); err == nil && bytes.Equal(dec, payload) {
				report.Verified++
				envFFI.CommitSignature[0] ^= 0xAA
				if _, err := kmsclient.DecryptEnvelope(envFFI); err != nil {
					report.TamperedDetected++
				}
			} else {
				report.Failed++
			}
		} else {
			report.Verified++
		}
	}

	outDir := filepath.Join("tests", "output")
	if err := os.MkdirAll(outDir, 0o755); err != nil {
		t.Fatalf("create output dir: %v", err)
	}
	summaryPath := filepath.Join(outDir, "witness_summary.json")
	data, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		t.Fatalf("marshal summary: %v", err)
	}
	if err := os.WriteFile(summaryPath, data, 0o644); err != nil {
		t.Fatalf("write summary: %v", err)
	}
}
