package integration

import (
	"fmt"
	"math"
	"sort"
	"testing"
	"time"

	DBpkg "thp-clear/src/DB"
	MQ "thp-clear/src/MQ"
	"thp-clear/src/common/crypto"
	"thp-clear/src/kms"
	"thp-clear/src/tpm"
)

func TestClearTaxMixIntegration(t *testing.T) {
	const (
		totalTx     = 1000
		scope       = "integration-clear-tax"
		clearWeight = 7
		window      = 10
	)

	clearQ := MQ.NewCLEARQueue(4096, time.Now)
	taxQ := MQ.NewTAXGOVQueue(4096, time.Now)
	policy := MQ.QueuePolicy{
		ClearThreshold:       0.7,
		TaxGovThreshold:      0.3,
		ClearPriorityWeight:  0.75,
		BackpressureDelayMin: 50 * time.Millisecond,
		BackpressureDelayMax: 2 * time.Second,
	}
	scheduler := MQ.NewScheduler(clearQ, taxQ, policy)

	kmsClient := kms.NewClientV2()
	kmsClient.WithRand(newReplicationRand())

	sender := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	sender.SetRand(newReplicationRand())
	receiver := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	receiver.SetRand(newReplicationRand())

	clearLatencies := make([]time.Duration, 0, totalTx)
	taxLatencies := make([]time.Duration, 0, totalTx)
	witnessLog := make([]crypto.Envelope, 0, totalTx)

	for i := 0; i < totalTx; i++ {
		pkt := &MQ.TxPacket{
			ID:         fmt.Sprintf("tx-%04d", i),
			Payload:    []byte(fmt.Sprintf("payload-%04d", i)),
			EnqueuedAt: time.Now(),
		}
		if i%window < clearWeight {
			if !clearQ.Push(pkt) {
				t.Fatalf("failed to push CLEAR packet %d", i)
			}
		} else {
			if !taxQ.Push(pkt) {
				t.Fatalf("failed to push TAX packet %d", i)
			}
		}
	}

	processed := 0
	for processed < totalTx {
		pkt, queueType, ok := scheduler.NextTx()
		if !ok {
			t.Fatalf("scheduler empty after %d processed", processed)
		}
		seq := uint64(processed + 1)
		keys, err := kmsClient.GetKeys(scope, seq)
		if err != nil {
			t.Fatalf("GetKeys: %v", err)
		}

		plain := append([]byte(nil), pkt.Payload...)
		env := buildEnvelope(t, keys[0], uint32(seq), queueType == MQ.QueueCLEAR, queueType == MQ.QueueCLEAR, plain)
		result, chunk := replicateOnce(t, sender, receiver, scope, seq, env)

		if chunk.Metadata.Count != len(chunk.Records) {
			t.Fatalf("chunk metadata count mismatch: want %d got %d", len(chunk.Records), chunk.Metadata.Count)
		}
		root := merkleFromEnvelopes(result.Envelopes)
		if got := chunk.Metadata.MerkleRoot; !bytesEqual(root, got) {
			t.Fatalf("merkle mismatch: computed %x chunk %x", root, got)
		}

		witnessLog = append(witnessLog, result.Envelopes...)

		lat := time.Duration((processed%10)+1) * time.Millisecond
		if queueType == MQ.QueueCLEAR {
			clearLatencies = append(clearLatencies, lat)
		} else {
			taxLatencies = append(taxLatencies, lat)
		}

		processed++
	}

	clearRatio, _ := scheduler.DispatchRatio()
	if clearRatio < 0.7 {
		t.Fatalf("expected CLEAR ratio >=0.7, got %.3f", clearRatio)
	}
	if len(witnessLog) != totalTx {
		t.Fatalf("expected %d witness entries, got %d", totalTx, len(witnessLog))
	}

	checkLatencyMetrics(t, clearLatencies, "CLEAR")
	checkLatencyMetrics(t, taxLatencies, "TAX-GOV")
}

func checkLatencyMetrics(t *testing.T, samples []time.Duration, label string) {
	t.Helper()
	if len(samples) == 0 {
		return
	}
	var total time.Duration
	for _, v := range samples {
		total += v
	}
	avg := total / time.Duration(len(samples))

	cpy := append([]time.Duration(nil), samples...)
	sort.Slice(cpy, func(i, j int) bool { return cpy[i] < cpy[j] })
	index := int(math.Ceil(0.95*float64(len(cpy)))) - 1
	if index < 0 {
		index = 0
	}
	p95 := cpy[index]

	if avg <= 0 || p95 <= 0 {
		t.Fatalf("%s latency metrics invalid: avg=%s p95=%s", label, avg, p95)
	}
}

func bytesEqual(a, b []byte) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}
