#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
LOG_FILE="/app/test_integration.log"

pushd "${ROOT_DIR}" >/dev/null

echo "[integration] bringing up thpclear-ci container..."
docker compose up -d thpclear-ci

echo "[integration] running go test for integration suite..."
docker compose run --rm thpclear-ci go test -v ./tests/integration/... | tee test_integration.log

echo "[integration] collecting integration log..."
docker compose run --rm thpclear-ci bash -c "cat ${LOG_FILE}" || true

echo "[integration] shutting down container..."
docker compose down

popd >/dev/null
