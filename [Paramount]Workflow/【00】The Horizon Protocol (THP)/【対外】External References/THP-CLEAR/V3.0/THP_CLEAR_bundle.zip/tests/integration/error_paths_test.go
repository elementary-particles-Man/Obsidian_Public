package integration

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"testing"
	"time"

	DBpkg "thp-clear/src/DB"
	MQ "thp-clear/src/MQ"
	"thp-clear/src/common/crypto"
	"thp-clear/src/kms"
	"thp-clear/src/tpm"
)

func TestIntegrationErrorPaths(t *testing.T) {
	t.Run("MalformedPayloads", func(t *testing.T) {
		testMalformedReplicationPayloads(t)
	})
	t.Run("SchedulerBackpressureUnderLatency", func(t *testing.T) {
		testSchedulerBackpressure(t)
	})
}

func testMalformedReplicationPayloads(t *testing.T) {
	const scope = "integration-errors"
	kmsClient := kms.NewClientV2()
	kmsClient.WithRand(newReplicationRand())

	sender := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	sender.SetRand(newReplicationRand())
	receiver := DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	receiver.SetRand(newReplicationRand())

	keys, _ := kmsClient.GetKeys(scope, 1)
	env := buildEnvelope(t, keys[0], 1, true, true, []byte("error-payload"))
	chunk, _ := sender.GenerateChunk(context.Background(), scope, 1, []crypto.Envelope{env})
	raw, _ := sender.SendChunk(context.Background(), chunk)

	var mutated DBpkg.Chunk
	if err := json.Unmarshal(raw, &mutated); err != nil {
		t.Fatalf("unmarshal chunk: %v", err)
	}

	// Invalid IV.
	mutatedIV := mutated
	mutatedIV.Records[0].Nonce[0] ^= 0xFF
	payloadIV, _ := json.Marshal(mutatedIV)
	if _, err := receiver.ReceiveChunk(context.Background(), scope, payloadIV); err == nil {
		t.Fatalf("expected error for invalid IV")
	}

	// Tampered ciphertext.
	mutatedCT := mutated
	mutatedCT.Records[0].Ciphertext[0] ^= 0xAA
	payloadCT, _ := json.Marshal(mutatedCT)
	if _, err := receiver.ReceiveChunk(context.Background(), scope, payloadCT); !errors.Is(err, DBpkg.ErrResend) {
		t.Fatalf("expected ErrResend for tampered ciphertext, got %v", err)
	}

	// Corrupted payload length (simulate gzip failure).
	mutatedZip := mutated
	if len(mutatedZip.Records[0].Ciphertext) > 4 {
		mutatedZip.Records[0].Ciphertext = mutatedZip.Records[0].Ciphertext[:len(mutatedZip.Records[0].Ciphertext)-4]
	}
	payloadZip, _ := json.Marshal(mutatedZip)
	if _, err := receiver.ReceiveChunk(context.Background(), scope, payloadZip); !errors.Is(err, DBpkg.ErrResend) {
		t.Fatalf("expected ErrResend for gzip corruption, got %v", err)
	}

	// Re-initialise TPM handler and confirm recovery succeeds with original payload.
	receiver = DBpkg.NewReplicator(kmsClient, tpm.NewHandlerV2())
	receiver.SetRand(newReplicationRand())
	if _, err := receiver.ReceiveChunk(context.Background(), scope, raw); err != nil {
		t.Fatalf("expected recovery to succeed, got %v", err)
	}
}

func testSchedulerBackpressure(t *testing.T) {
	policy := MQ.QueuePolicy{
		ClearThreshold:       0.7,
		TaxGovThreshold:      0.3,
		ClearPriorityWeight:  0.75,
		BackpressureDelayMin: 10 * time.Millisecond,
		BackpressureDelayMax: 100 * time.Millisecond,
	}

	clearQ := MQ.NewCLEARQueue(128, time.Now)
	taxQ := MQ.NewTAXGOVQueue(128, time.Now)
	scheduler := MQ.NewScheduler(clearQ, taxQ, policy)

	for i := 0; i < 50; i++ {
		clearQ.Push(&MQ.TxPacket{ID: fmt.Sprintf("clear-latency-%d", i)})
	}
	for i := 0; i < 30; i++ {
		taxQ.Push(&MQ.TxPacket{ID: fmt.Sprintf("tax-latency-%d", i)})
	}

	backpressure := make(chan struct{}, 1)
	dispatcher := MQ.NewDispatcher(
		scheduler,
		MQ.PacketHandlerFunc(func(ctx context.Context, pkt *MQ.TxPacket) error {
			time.Sleep(2 * time.Millisecond)
			return nil
		}),
		MQ.WithEventEmitter(func(event string, fields map[string]interface{}) {
			if event == "TAX_BACKPRESSURE" {
				select {
				case backpressure <- struct{}{}:
				default:
				}
			}
		}),
		MQ.WithIdleSleep(1*time.Millisecond),
		MQ.WithMaxBackpressureAttempts(3),
	)

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()

	done := make(chan struct{})
	go func() {
		dispatcher.Run(ctx)
		close(done)
	}()

	select {
	case <-backpressure:
	case <-time.After(500 * time.Millisecond):
		t.Fatalf("expected TAX_BACKPRESSURE event under latency fault")
	}
	cancel()
	<-done

	clearRatio, _ := scheduler.DispatchRatio()
	if clearRatio < 0.7 {
		t.Fatalf("expected CLEAR dominance after backpressure, got %.3f", clearRatio)
	}
}
