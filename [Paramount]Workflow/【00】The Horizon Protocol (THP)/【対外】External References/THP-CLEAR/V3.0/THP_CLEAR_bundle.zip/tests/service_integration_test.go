//go:build integration

package tests

import (
	"context"
	"testing"
	"time"

	"thp-clear/internal/adapters/sqlite"
	"thp-clear/internal/domain"
	pkgcrypto "thp-clear/pkg/crypto"
)

type noopWriter struct{}

func (n *noopWriter) Append(entry *domain.WitnessEntry) error {
	return nil
}

func TestIntegrationSQLiteIssueSettle(t *testing.T) {
	store, err := sqlite.New("file:integration.db?mode=memory&cache=shared")
	if err != nil {
		t.Fatalf("failed to open sqlite: %v", err)
	}
	defer store.Close()

	ctx := context.Background()
	if err := store.InitSchema(ctx); err != nil {
		t.Fatalf("init schema: %v", err)
	}
	if err := store.EnableTestOptimizations(ctx); err != nil {
		t.Fatalf("enable pragmas: %v", err)
	}

	signer, err := pkgcrypto.Generate()
	if err != nil {
		t.Fatalf("generate signer: %v", err)
	}
	writer := &noopWriter{}

	service := domain.NewService(store, signer, writer)
	service.WithNow(func() time.Time {
		return time.Date(2025, 1, 1, 12, 0, 0, 0, time.UTC)
	})

	if _, err := service.UpsertAccount(ctx, domain.AccountInput{
		ID:          "acct-int",
		DisplayName: "Integration Account",
		Currency:    "JPY",
		Balance:     50_000,
		Status:      domain.AccountActive,
	}); err != nil {
		t.Fatalf("upsert account: %v", err)
	}

	cmd, err := service.IssueCommand(ctx, domain.IssueCommandInput{
		AccountID: "acct-int",
		Amount:    1200,
		Currency:  "JPY",
		Purpose:   domain.PurposeFood,
	})
	if err != nil {
		t.Fatalf("issue command: %v", err)
	}

	if _, _, err := service.SettleCommand(ctx, domain.SettleCommandInput{
		CommandID: cmd.ID,
		Quantity:  4.2,
		Unit:      "t",
	}); err != nil {
		t.Fatalf("settle command: %v", err)
	}
}
