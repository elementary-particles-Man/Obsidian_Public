package tests

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/prometheus/client_golang/prometheus/testutil"
	dto "github.com/prometheus/client_model/go"
	"gopkg.in/yaml.v3"

	"thp-clear/internal/adapters/memory"
	"thp-clear/internal/domain"
	"thp-clear/internal/monitoring"
	pkgcrypto "thp-clear/pkg/crypto"
)

type bufferWitnessWriter struct {
	entries []*domain.WitnessEntry
}

func (b *bufferWitnessWriter) Append(entry *domain.WitnessEntry) error {
	payload := make([]byte, len(entry.Payload))
	copy(payload, entry.Payload)
	clone := *entry
	clone.Payload = payload
	b.entries = append(b.entries, &clone)
	return nil
}

type mockE20 struct {
	finalized bool
	score     float64
	unit      string
	quantity  float64
	txHash    string
}

func newMockE20() mockE20 {
	return mockE20{
		finalized: true,
		score:     0.912,
		unit:      "kg",
		quantity:  42.0,
		txHash:    "0xfeedface",
	}
}

func (m mockE20) Score() float64  { return m.score }
func (m mockE20) Finalized() bool { return m.finalized }

func TestE20IntegrationFlow(t *testing.T) {
	t.Parallel()

	cfgPath := filepath.Join("..", "configs", "mock_e20.yaml")
	cfgBytes, err := os.ReadFile(cfgPath)
	if err != nil {
		t.Fatalf("read mock config: %v", err)
	}
	var mockCfg struct {
		Endpoint string `yaml:"endpoint"`
	}
	if err := yaml.Unmarshal(cfgBytes, &mockCfg); err != nil {
		t.Fatalf("unmarshal mock config: %v", err)
	}
	if mockCfg.Endpoint == "" {
		t.Fatalf("mock config endpoint is empty")
	}

	store := memory.New()
	writer := &bufferWitnessWriter{}
	signer, err := pkgcrypto.Generate()
	if err != nil {
		t.Fatalf("generate signer: %v", err)
	}

	service := domain.NewService(store, signer, writer)
	exporter := monitoring.NewExporter()
	service.WithMetrics(exporter)
	appendBefore := testutil.ToFloat64(exporter.WitnessAppendCounter())
	verifyBefore := testutil.ToFloat64(exporter.WitnessVerifySuccessCounter())
	failureBefore := testutil.ToFloat64(exporter.WitnessVerifyFailureCounter())
	fixed := time.Date(2025, 10, 13, 0, 0, 0, 0, time.UTC)
	service.WithNow(func() time.Time { return fixed })

	ctx := context.Background()
	_, err = service.UpsertAccount(ctx, domain.AccountInput{
		ID:          "acct-e20",
		DisplayName: "E20 Beneficiary",
		Currency:    "JPY",
		Balance:     5_000_000,
	})
	if err != nil {
		t.Fatalf("upsert account: %v", err)
	}

	commandID := uuid.NewString()
	cmd, err := service.IssueCommand(ctx, domain.IssueCommandInput{
		AccountID: "acct-e20",
		Amount:    1200,
		Currency:  "JPY",
		Purpose:   domain.PurposeMedicine,
		Metadata: map[string]any{
			"e20_reference": commandID,
		},
		Reference: "E20-AID-2025",
	})
	if err != nil {
		t.Fatalf("issue command: %v", err)
	}

	mock := newMockE20()
	if !mock.Finalized() {
		t.Fatalf("mock e20 finality failed")
	}
	exporter.SetEMADViolationScore(mock.Score())

	settled, entry, err := service.SettleCommand(ctx, domain.SettleCommandInput{
		CommandID: cmd.ID,
		Quantity:  mock.quantity,
		Unit:      mock.unit,
		Extra: map[string]any{
			"e20_tx":     mock.txHash,
			"emad_score": mock.Score(),
		},
	})
	if err != nil {
		t.Fatalf("settle command: %v", err)
	}
	if settled.Status != domain.CommandSettled {
		t.Fatalf("unexpected command status %s", settled.Status)
	}
	if entry == nil {
		t.Fatalf("settle command returned nil witness entry")
	}

	if len(writer.entries) != 1 {
		t.Fatalf("expected witness entry to be appended")
	}

	payload := writer.entries[0].Payload
	var witnessBody map[string]any
	if err := json.Unmarshal(payload, &witnessBody); err != nil {
		t.Fatalf("unmarshal witness payload: %v", err)
	}
	for _, key := range []string{"command_id", "account_id", "amount", "currency", "recorded_at"} {
		if _, ok := witnessBody[key]; !ok {
			t.Fatalf("witness payload missing key %s", key)
		}
	}

	if after := testutil.ToFloat64(exporter.WitnessAppendCounter()); after-appendBefore != 1 {
		t.Fatalf("witness append metric delta = %v, want 1", after-appendBefore)
	}
	if after := testutil.ToFloat64(exporter.WitnessVerifySuccessCounter()); after-verifyBefore != 1 {
		t.Fatalf("witness verify success metric delta = %v, want 1", after-verifyBefore)
	}
	if after := testutil.ToFloat64(exporter.WitnessVerifyFailureCounter()); after-failureBefore != 0 {
		t.Fatalf("witness verify failure delta = %v, want 0", after-failureBefore)
	}
	metric := &dto.Metric{}
	if err := exporter.WitnessLatencyHistogram().Write(metric); err != nil {
		t.Fatalf("read latency histogram: %v", err)
	}
	if metric.GetHistogram().GetSampleCount() == 0 {
		t.Fatalf("expected latency histogram sample count > 0")
	}
	if got := testutil.ToFloat64(exporter.EMADScoreGauge()); got != mock.Score() {
		t.Fatalf("emad violation score = %v, want %v", got, mock.Score())
	}
}
