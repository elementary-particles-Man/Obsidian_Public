package tests

import (
	"context"
	"fmt"
	"math"
	"sync"
	"testing"
	"time"

	MQ "thp-clear/src/MQ"
)

func TestSchedulerNormalMaintainsClearDominance(t *testing.T) {
	clk := newControlledClock()
	clearQ := MQ.NewCLEARQueue(4096, clk.Now)
	taxQ := MQ.NewTAXGOVQueue(4096, clk.Now)
	scheduler := MQ.NewScheduler(clearQ, taxQ, MQ.QueuePolicy{})

	for i := 0; i < 1000; i++ {
		if !clearQ.Push(&MQ.TxPacket{ID: fmt.Sprintf("c-%d", i)}) {
			t.Fatalf("failed to enqueue clear packet %d", i)
		}
		if !taxQ.Push(&MQ.TxPacket{ID: fmt.Sprintf("t-%d", i)}) {
			t.Fatalf("failed to enqueue tax packet %d", i)
		}
	}

	for i := 0; i < 1000; i++ {
		if _, _, ok := scheduler.NextTx(); !ok {
			t.Fatalf("expected packet on iteration %d", i)
		}
	}

	clearRatio, _ := scheduler.DispatchRatio()
	if clearRatio < 0.7 {
		t.Fatalf("expected CLEAR ratio >=0.7, got %.3f", clearRatio)
	}
}

func TestDispatcherAppliesTaxBackpressure(t *testing.T) {
	clk := newControlledClock()
	policy := MQ.QueuePolicy{
		ClearThreshold:       0.7,
		TaxGovThreshold:      0.3,
		ClearPriorityWeight:  0.75,
		BackpressureDelayMin: 50 * time.Millisecond,
		BackpressureDelayMax: 400 * time.Millisecond,
	}
	clearQ := MQ.NewCLEARQueue(64, clk.Now)
	taxQ := MQ.NewTAXGOVQueue(64, clk.Now)
	scheduler := MQ.NewScheduler(clearQ, taxQ, policy)

	for i := 0; i < 25; i++ {
		clearQ.Push(&MQ.TxPacket{ID: fmt.Sprintf("warm-clear-%d", i)})
	}
	for i := 0; i < 25; i++ {
		if _, queue, ok := scheduler.NextTx(); !ok || queue != MQ.QueueCLEAR {
			t.Fatalf("warming dispatch expected CLEAR queue")
		}
	}

	for i := 0; i < 20; i++ {
		clearQ.Push(&MQ.TxPacket{ID: fmt.Sprintf("clear-%d", i)})
	}
	for i := 0; i < 4; i++ {
		taxQ.Push(&MQ.TxPacket{ID: fmt.Sprintf("tax-%d", i)})
	}

	events := make(chan map[string]interface{}, 2)
	dispatcher := MQ.NewDispatcher(
		scheduler,
		MQ.PacketHandlerFunc(func(ctx context.Context, pkt *MQ.TxPacket) error {
			clk.Advance(1 * time.Millisecond)
			return nil
		}),
		MQ.WithEventEmitter(func(event string, fields map[string]interface{}) {
			if event == "TAX_BACKPRESSURE" {
				select {
				case events <- fields:
				default:
				}
			}
		}),
		MQ.WithClock(clk.Now),
		MQ.WithSleepFunc(func(d time.Duration) {
			if d <= 0 {
				d = time.Millisecond
			}
			clk.Advance(d)
		}),
		MQ.WithMaxBackpressureAttempts(2),
	)

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() {
		dispatcher.Run(ctx)
		close(done)
	}()

	select {
	case <-events:
		cancel()
	case <-time.After(300 * time.Millisecond):
		cancel()
		t.Fatalf("expected TAX_BACKPRESSURE event")
	}
	<-done

	if taxQ.BacklogLen() == 0 {
		t.Fatalf("expected TAX backlog after backpressure")
	}
	snapshot := dispatcher.Metrics().Snapshot()
	if snapshot.BackpressureCount == 0 {
		t.Fatalf("expected backpressure metric to increment")
	}
}

func TestSchedulerEmergencyModePrefersClear(t *testing.T) {
	clk := newControlledClock()
	clearQ := MQ.NewCLEARQueue(2048, clk.Now)
	taxQ := MQ.NewTAXGOVQueue(2048, clk.Now)
	scheduler := MQ.NewScheduler(clearQ, taxQ, MQ.QueuePolicy{})
	scheduler.SetMode(MQ.ModeEmergency)

	for i := 0; i < 1000; i++ {
		clearQ.Push(&MQ.TxPacket{ID: fmt.Sprintf("clear-em-%d", i)})
		taxQ.Push(&MQ.TxPacket{ID: fmt.Sprintf("tax-em-%d", i)})
	}

	taxDispatches := 0
	for i := 0; i < 1000; i++ {
		if _, queue, ok := scheduler.NextTx(); ok {
			if queue == MQ.QueueTAXGOV {
				taxDispatches++
			}
		} else {
			t.Fatalf("expected packet during emergency run")
		}
	}

	clearRatio, _ := scheduler.DispatchRatio()
	if clearRatio < 0.9 {
		t.Fatalf("expected CLEAR ratio >=0.9 in emergency mode, got %.3f", clearRatio)
	}
	if taxDispatches > 120 {
		t.Fatalf("expected TAX dispatches to remain limited, saw %d", taxDispatches)
	}
}

func TestSchedulerOffpeakBalanced(t *testing.T) {
	clk := newControlledClock()
	clearQ := MQ.NewCLEARQueue(4096, clk.Now)
	taxQ := MQ.NewTAXGOVQueue(4096, clk.Now)
	scheduler := MQ.NewScheduler(clearQ, taxQ, MQ.QueuePolicy{})
	scheduler.SetMode(MQ.ModeOffpeak)

	for i := 0; i < 1200; i++ {
		clearQ.Push(&MQ.TxPacket{ID: fmt.Sprintf("clear-off-%d", i)})
		taxQ.Push(&MQ.TxPacket{ID: fmt.Sprintf("tax-off-%d", i)})
	}

	for i := 0; i < 1200; i++ {
		if _, _, ok := scheduler.NextTx(); !ok {
			t.Fatalf("unexpected scheduler exhaustion in offpeak mode")
		}
	}

	clearRatio, taxRatio := scheduler.DispatchRatio()
	if math.Abs(clearRatio-0.6) > 0.05 {
		t.Fatalf("expected CLEAR ratio ~0.6, got %.3f", clearRatio)
	}
	if math.Abs(taxRatio-0.4) > 0.05 {
		t.Fatalf("expected TAX ratio ~0.4, got %.3f", taxRatio)
	}
}

func TestSchedulerFairnessVariance(t *testing.T) {
	clk := newControlledClock()
	clearQ := MQ.NewCLEARQueue(32, clk.Now)
	taxQ := MQ.NewTAXGOVQueue(32, clk.Now)
	scheduler := MQ.NewScheduler(clearQ, taxQ, MQ.QueuePolicy{})

	// seed queues with one packet each
	clearPkt := &MQ.TxPacket{ID: "fair-clear"}
	taxPkt := &MQ.TxPacket{ID: "fair-tax"}
	clearQ.Push(clearPkt)
	taxQ.Push(taxPkt)

	clearCount := 0
	taxCount := 0
	iterations := 10000
	for i := 0; i < iterations; i++ {
		pkt, queue, ok := scheduler.NextTx()
		if !ok {
			t.Fatalf("scheduler produced no packet at iteration %d", i)
		}
		switch queue {
		case MQ.QueueCLEAR:
			clearCount++
			clearQ.Push(pkt)
		case MQ.QueueTAXGOV:
			taxCount++
			taxQ.Push(pkt)
		default:
			t.Fatalf("unexpected queue type %q", queue)
		}
	}

	total := clearCount + taxCount
	ratio := float64(clearCount) / float64(total)
	if math.Abs(ratio-0.7) > 0.05 {
		t.Fatalf("expected CLEAR ratio near 0.7, got %.3f", ratio)
	}
}

type controlledClock struct {
	mu  sync.Mutex
	now time.Time
}

func newControlledClock() *controlledClock {
	return &controlledClock{now: time.Unix(0, 0)}
}

func (c *controlledClock) Now() time.Time {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.now
}

func (c *controlledClock) Advance(d time.Duration) {
	c.mu.Lock()
	c.now = c.now.Add(d)
	c.mu.Unlock()
}
