package e2e

import (
	"encoding/json"
	"os"
	"testing"

	"thp-clear/src/DB"
	"thp-clear/src/common/kmsclient"
)

func TestWitnessIngestE2E(t *testing.T) {
	sample := map[string]string{"tx": "alpha", "ts": "2025-10-31T00:00Z"}
	data, err := json.Marshal(sample)
	if err != nil {
		t.Fatalf("Failed to marshal sample data: %v", err)
	}

	env, err := kmsclient.EncryptToEnvelope(data)
	if err != nil {
		t.Fatalf("failed to encrypt envelope: %v", err)
	}
	db := DB.Connect()
	defer db.Close()
	defer os.Remove("test.db")

	if err := DB.InsertEnvelope(db, env); err != nil {
		t.Fatalf("Failed to insert envelope: %v", err)
	}

	rows, err := DB.QueryCount(db, "SELECT COUNT(*) FROM witness_envelopes")
	if err != nil {
		t.Fatalf("Failed to query count: %v", err)
	}
	if rows == 0 {
		t.Fatal("no envelope inserted")
	}
}
