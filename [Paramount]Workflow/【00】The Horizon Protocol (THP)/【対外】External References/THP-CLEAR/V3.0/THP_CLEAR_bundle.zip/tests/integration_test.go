package tests

// 擬似Tx/擬似VendorSigでMQ→WN→DBの最小パスの成功/失敗を確認
