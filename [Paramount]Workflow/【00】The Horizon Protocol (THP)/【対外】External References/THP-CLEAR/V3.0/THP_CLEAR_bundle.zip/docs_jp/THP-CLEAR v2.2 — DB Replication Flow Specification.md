
# **THP-CLEAR v2.2 — DB Replication Flow Specification**

### （KMS三履歴鍵＋TPM再封緘方式）

---

## 🧩 概要

本仕様は、DBノード間でWitnessブロックを冗長複製する際の暗号化・復号・再封緘処理を定義する。  
目的は、**欠損ゼロ／改ざんゼロ／ローテーション非同期吸収**を同時に成立させることである。

---

## ⚙️ 処理フロー概要

```mermaid
sequenceDiagram
  participant WN as WNノード
  participant DB1 as DBノードA（送信側）
  participant KMS as KMS
  participant DB2 as DBノードB（受信側）
  participant TPM1 as TPM(A)
  participant TPM2 as TPM(B)

  WN->>DB1: AES( ISE(plain, ISE_WN), AES_WN ) 送信
  DB1->>KMS: GetKeys("WN→DB")
  DB1->>TPM1: Re-ISE(temp_plain)
  DB1->>DB1: 永続化(SQLite)
  DB1->>TPM1: Decrypt(final_ise_block)
  TPM1-->>DB1: temp_plain
  DB1->>KMS: GetKeys("DB→DB")
  DB1->>DB2: AES( GZIP( ISE(temp_plain, ISE_KMS) ), AES_KMS )
  DB2->>KMS: GetKeys("DB→DB", 3履歴)
  DB2->>DB2: AES復号順次試行(Current→Old1→Old2)
  DB2->>DB2: GZIP展開→ISE一時復号
  DB2->>TPM2: Re-ISE(temp_plain)
  TPM2-->>DB2: final_ise_block_local
  DB2->>DB2: 永続化・Merkle更新・RS冗長化
```

---

## 🧠 詳細シーケンス

### 1️⃣ 送信側DBノード（DB1）

1. **永続化済Witness取得**
    
    - 対象：`final_ise_block (TPM再封緘済)`
        
2. **TPM一時平文化**
    
    - `temp_plain = TPM.Decrypt(final_ise_block)`
        
    - メモリ上のみ存在、即時再封緘前提。
        
3. **KMS鍵取得**
    
    - `keys = KMS.GetKeys("DB→DB", TxID)`
        
    - 現行AES/ISE鍵ペア。
        
4. **再封緘と送信**
    
    ```
    ise_temp = ISE(temp_plain, keys.ISE)
    payload = AES256-GCM( gzip(ise_temp), keys.AES )
    Send(peerDB, payload)
    ```
    
5. **メモリ消去**
    
    - `temp_plain` / `keys` をゼロ化。
        

---

### 2️⃣ 受信側DBノード（DB2）

1. **三履歴鍵の取得**
    
    ```
    keysets = KMS.GetKeys("DB→DB", TxID) 
              => [Current, Old1, Old2]
    ```
    
2. **AES復号試行**
    
    - 順次復号。すべて失敗なら再送要求。
        
3. **復号成功後**
    
    ```
    temp_ise = GZIP.Decompress(decrypted)
    temp_plain = ISE_Decrypt(temp_ise, keyset.ISE)
    ```
    
4. **TPM再封緘（Re-ISE）**
    
    ```
    final_ise_block_local = TPM.ISE_Encrypt(temp_plain)
    ```
    
    - 旧署名廃棄。TPM固有鍵による再封緘。
        
5. **永続化／整合化**
    
    - SQLite挿入 → Merkleブランチ更新 → RS冗長ブロック生成。
        
    - Root一致確認後「不変化確定」。
        

---

## 🔐 セキュリティ要件

|項目|内容|
|---|---|
|**KMS鍵管理**|三履歴（Current / Old1 / Old2）保持。TxID単位で自動ローテーション。|
|**TPM平文化**|一時セッション限定、メモリ上のみ。ログ・キャッシュ残留禁止。|
|**データ再封緘**|受信側TPMで新規ISE封緘、WN鍵由来データと論理的独立性確保。|
|**冗長同期**|AES鍵不一致を吸収しつつRS冗長化を行う。|
|**監査整合**|各DBのMerkle Root一致をもって改ざんなしを証明。|

---

## 🧭 運用上の指針

1. **再送要求トリガー**
    
    - AES復号失敗が3履歴すべてで発生した場合のみ送信側へ `Resend(TxID)`。
        
2. **KMS更新ポリシー**
    
    - 鍵寿命：1トランザクション。
        
    - 履歴保持：現行＋旧2。新鍵発行時に最古を破棄。
        
3. **TPM更新ポリシー**
    
    - ノード再起動時にシード再生成。再封緘対象データはすべて自ノード署名で置換。
        
4. **スナップショット周期**
    
    - 10 GB または 1 時間ごと。生成後に再封緘・RS冗長化・Peer同期。
        

---

## ✅ 結論

> DBノード間のWitness冗長化は、  
> **TPM平文化 → KMS鍵で再封緘（ISE-ZIP-AES） → 受信側でKMS復号 → TPM再封緘 → 永続化**  
> という循環的シーケンスにより、  
> 鍵非同期・データ欠損・改ざんの全てを防ぐ。
> 
> この仕組みにより、THP-CLEARのDB層は「自己修復可能な改ざん不能分散ジャーナル」として機能する。
