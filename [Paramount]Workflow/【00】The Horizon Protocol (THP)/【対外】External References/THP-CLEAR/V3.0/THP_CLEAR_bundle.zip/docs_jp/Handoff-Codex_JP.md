# 作業サマリ (2025-10-11)

## ビルド再現性
- `make all` を再実行し、`dist/SHA256SUMS` を更新。
- `sha256sum -c dist/SHA256SUMS` が全バイナリで OK。
- 旧バイナリは `mv bin bin_old_<timestamp>` で退避後、現在は `bin/` に最新のみ。

## TLS / mTLS 準備
- `certs/` に以下を生成：
  - ルート CA (`ca.pem`, `ca.key`)
  - KMS 証明書 (`kms.pem`, `kms.key`, `kms.csr`, `kms.cnf`)
  - ノード証明書 (`node.pem`, `node.key`, `node.csr`, `node.cnf`)
  - KMS signer 公開鍵 `certs/kms-1.pub`。
- KMS signer 秘密鍵 `data/kms/signers/kms-1.key` を生成済み。

## 監査ログディレクトリ
- デフォルト設定は `/var/log/clear/*.jsonl` だが、ローカル権限不足で作成不可。ステージングではログパスを変更するか、事前に `/var/log/clear` を整備する。

## メトリクス / SPY ドリル
- `curl http://kms-metrics:9100/metrics` / `http://node-metrics:9101/metrics` はホスト未解決で失敗。ステージングで `/etc/hosts` 追加、もしくは `127.0.0.1` 指定で確認する。
- 429→SPY(block) ドリルは KMS/ノード起動と commit ファイル整備後に実施予定。

## git 状態メモ
- 不要ファイル `THP-CLEAR.txt`, `Task.md`, `fromGemini.md` を削除 (git status で `D`)。
- `certs/` は未追跡。必要に応じ `.gitignore` へ追加または動作確認後に削除。

