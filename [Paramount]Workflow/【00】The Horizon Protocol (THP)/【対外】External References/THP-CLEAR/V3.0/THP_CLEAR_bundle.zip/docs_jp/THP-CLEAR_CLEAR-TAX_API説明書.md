# THP-CLEAR / CLEAR-TAX API説明書

最終更新: 2025-11-06  
対象バージョン: feature/clear-tax-e2e ブランチの実装

本書は THP-CLEAR コアおよび CLEAR-TAX（DBE-TAX, WN-TAX）で現在実装されている HTTP API を網羅的にまとめたものです。  
各サービスのデフォルト Listen アドレスや環境変数は `.env`/`configs` から変更可能です。

---

## 1. THP-CLEAR Core API

- **ベースURL**: `http://<thp-clear-host>:<port>`（既定 `:8080`。`configs/*.yaml` の `app.listen_address` で設定）
- **Content-Type**: すべて `application/json; charset=utf-8`
- **認証**: 現バージョンでは未実装（将来の署名/トークン連携を想定）

| 区分 | メソッド & パス | 説明 |
|------|-----------------|------|
|ヘルス|`GET /healthz`|単純な死活監視。`{"status":"ok"}` を返す。|
|コマンド発行|`POST /command`|送金/決済等のコマンドを新規作成。|
|コマンド参照|`GET /command/{id}`|指定 ID のコマンド詳細を取得。|
|コマンド精算|`POST /settle`|既存コマンドを消込し、証跡（witness）を生成。|
|証跡参照|`GET /witness?limit=50`|最新 witness エントリを降順で取得（既定 50 件）。|
|管理:口座|`POST /admin/accounts`|口座レコードを作成/更新。既存 ID 指定で上書き。|
|管理:BL 登録|`POST /admin/blacklist`|口座をブラックリストに登録。`expires_at` で期限指定可。|
|管理:BL 解除|`DELETE /admin/blacklist/{account_id}`|ブラックリスト登録を解除。|
|メトリクス|`GET /metrics`|Prometheus 形式のメトリクス。|

### 1.1 `POST /command`

```json
{
  "account_id": "ACC-9001",
  "amount": 120000,
  "currency": "JPY",
  "purpose": "tax_settlement",
  "metadata": {
    "invoice_id": "INV-771",
    "channel": "peppol"
  },
  "reference": "DR-20251106"
}
```

- `amount`: 64bit 整数（最小単位は通貨の最小額）
- `purpose`: `domain.Purpose` 列挙に定義されている値のいずれか。無効な値は `422` を返す。

**レスポンス 201**

```json
{
  "id": "cmd_01HD...",
  "account_id": "ACC-9001",
  "amount": 120000,
  "currency": "JPY",
  "purpose": "tax_settlement",
  "status": "issued",
  "requested_at": "2025-11-06T10:44:30Z",
  "metadata": {
    "invoice_id": "INV-771",
    "channel": "peppol"
  }
}
```

### 1.2 `POST /settle`

```json
{
  "command_id": "cmd_01HD...",
  "quantity": 1,
  "unit": "batch",
  "metadata": {
    "witness_kid": "kid-2025-1106",
    "dbe_manifest": "/var/dbe-tax/batch_commit.json"
  }
}
```

- 成功時は `200` で以下のようにコマンドと witness の両方を返す。

```json
{
  "command": {
    "id": "cmd_01HD...",
    "status": "settled",
    "quantity": 1,
    "unit": "batch",
    "settled_at": "2025-11-06T10:45:02Z",
    "witness_hash": "b6f2..."
  },
  "witness": {
    "id": "wit_01HD...",
    "command_id": "cmd_01HD...",
    "hash": "b6f2...",
    "previous_hash": "2ad4...",
    "recorded_at": "2025-11-06T10:45:02Z",
    "signature": "MEUCIF...",
    "payload": {
      "manifest_path": "/var/dbe-tax/batch_commit.json",
      "kid": "kid-2025-1106"
    }
  }
}
```

### 1.3 エラーハンドリング

| 状況 | HTTP | `error` メッセージ |
|------|------|--------------------|
|JSON 解析失敗|400|`"invalid json"`|
|口座なし|404|`"account not found"`|
|凍結|423|`"account frozen"`|
|残高不足|422|`"insufficient funds"`|
|ブラックリスト|403|`"account blacklisted"`|
|目的不正|422|`"invalid purpose"`|
|コマンド未存在|404|`"command not found"`|
|コマンド済|409|`"command already settled"`|
|その他|500|`"internal server error"`|

---

## 2. CLEAR-TAX DBE-TAX API

- **ベースURL**: `http://<dbe-tax-host>:9101`
- **環境変数**: `DBE_TAX_LISTEN_ADDR`、`DBE_TAX_FLUSH_DIR` 等
- **Content-Type**: JSON（Peppol系は XML）

| 区分 | メソッド & パス | 説明 |
|------|-----------------|------|
|バッチ受信|`POST /tax/ingest`|AES-GCM で暗号化された税バッチを受信し、フラッシュディレクトリに `batch_commit.json` を保存。|
|計算API|`POST /tax/query`|金額と税率を受け取り、DR-20251106 準拠の端数処理結果を返す。`GET` は互換目的で空配列を返却。|
|Peppolクレジットノート|`/peppol/credit-note`|モック用。HTTP メソッドを問わず 200 と `{"credit_note":"ok"}` を返す。|
|メトリクス|`GET /metrics`|Prometheus 形式（`metrics.TaxBatchBytes` など）。|

### 2.1 `POST /tax/ingest`

```json
{
  "nonce": "base64-encoded 12 bytes",
  "aad": "base64-encoded associated data",
  "ciphertext": "base64(ciphertext||tag)",
  "kid": "optional-key-id"
}
```

- `ciphertext` の末尾 16 バイトが GCM Tag として扱われる。
- `kid` 未指定の場合は `batch-<unix-nano>` が自動採番。

**レスポンス 200**

```json
{
  "status": "committed",
  "kid": "batch-1730899470123456000",
  "manifest_path": "/var/dbe-tax/batch_commit.json"
}
```

エラー時は 400（JSON 不正）、409（重複バッチ）、500（復号/書き込み失敗）を返す。

### 2.2 `POST /tax/query`

```json
{
  "base_amount": 125000.75,
  "tax_rate": 0.1
}
```

**レスポンス 200**

```json
{
  "base_rounding_mode": "round",
  "tax_rounding_mode": "floor",
  "total_rounding_mode": "round",
  "rounded_base_amount": 125001,
  "computed_tax_amount": 12500,
  "computed_total_amount": 137501,
  "tax_rate": 0.1
}
```

- 不正入力は 400 (`"invalid base amount"` / `"invalid tax rate"`)、その他は 500。

---

## 3. CLEAR-TAX WN-TAX API

WN-TAX は DBE とのバッチ疎通と Peppol 送信のクライアント。外部公開するのは健全性確認エンドポイントのみ。

- **ベースURL**: `http://<wn-tax-host>:9103`（`WN_TAX_HTTP_ADDR`）
- **関連環境変数**: `WN_TAX_DBE_ENDPOINT`, `WN_TAX_PEPPOL_ENDPOINT`, `WN_TAX_SEND_INTERVAL`, `WN_TAX_MODE`

| メソッド & パス | 説明 |
|-----------------|------|
|`GET /health`|直近 AS4 送信結果を返す。成功時 200/`"ok"`、失敗時 503 と最後のエラー文字列。|
|`GET /metrics`|Prometheus 形式。`as4_send_total`, `as4_send_failures_total`, `last send timestamp` などを出力。|

### 内部的に行われる処理

1. `postPeppolInvoiceWithSig` が JP PINT 準拠の XML を生成（`urn:jp:pint:billing:1.0` NameSpace、`ProfileID=JP-PINT`）。
2. `SendToPeppol(peppolEndpoint, payload)` で AS4 ゲートウェイへ HTTP POST。
3. 成功後 `postTaxBatch()` が DBE へ AES-GCM ハンドオフ。

これら内部呼び出しは外部公開 API ではないが、Peppol 連携試験時の仕様確認として掲載している。

---

## 4. 付録

### 4.1 端数処理（DR-20251106）

`internal/jptax` で共通実装。`tax_round` モードは以下:

| モード | 説明 |
|--------|------|
|`round`|四捨五入（`math.Round`）|
|`floor`|切り捨て|
|`ceil`|切り上げ|

DBE・WN 双方で `base` → round、`tax` → floor、`total` → round を必ず適用。

### 4.2 Peppol JP PINT 要求

- NameSpace: `urn:jp:pint:billing:1.0`
- `cbc:ProfileID`: 既定 `JP-PINT`
- `cbc:DocumentCurrencyCode`: 省略不可。未指定時は `JPY`
- HTTP 送信ヘッダー: `Content-Type: application/xml; charset=utf-8`
- 正常応答: ステータス 200。非 200 の場合は再送対象。

---

本書に未掲載のエンドポイントを追加した場合は、該当セクションを更新してください。Pull Request のレビュー項目に「API説明書更新」のチェックボックスを設けることを推奨します。
