承知しました。  
以下は、THP-CLEAR／CLEAR-TAXの国際標準統合を前提にした、**Peppolおよび日本版JP PINT仕様の詳細説明書（完全版）**です。  
技術者・行政両方の視点から参照できるよう、構造化して記載します。

---

# 📘 Peppol / JP PINT 詳細説明書

**対象システム:** THP-CLEAR／CLEAR-TAX  
**作成日:** 2025-11-02  
**作成目的:** 国際電子インボイス標準との完全整合（署名・構文・運用）

---

## 第1章　Peppol BIS Billing 3.0 概要

### 1.1 成立経緯

- **Peppol** ( Pan-European Public Procurement Online ) は、EU委員会主導で整備された**電子調達・電子インボイスの国際標準枠組み**。
    
- 根拠法：EU Directive 2014/55/EU （公共調達における電子インボイス義務化）
    
- 標準仕様：**EN 16931 — European Standard on Electronic Invoicing**
    
- 技術基盤：**UBL (Universal Business Language) 2.1／ISO/IEC 19845**
    

### 1.2 主要目的

- 各国で異なる電子インボイス仕様を統一するための**共通交換プロトコルとデータモデル**を提供。
    
- 相互運用性（Interoperability）を確保し、**国境を越えた電子取引**を可能にする。
    

### 1.3 対象文書

|文書種別|英語名称|説明|
|---|---|---|
|請求書|`Invoice`|売り手が買い手に金銭請求を行う標準文書。|
|取消／返金|`Credit Note`|誤記訂正や返品対応などで金額を減額する訂正文書。|

---

## 第2章　Peppol 仕様構造

### 2.1 XML構文

- ベース：**UBL 2.1 XML Schema**
    
- 文書ルート：`<Invoice>` または `<CreditNote>`
    
- 名前空間：`urn:oasis:names:specification:ubl:schema:xsd:Invoice-2`
    
- コーディング：UTF-8、行末CRLF、署名部はXAdES準拠。
    

### 2.2 主要セクション

|セクション|内容|対応CLEAR要素|
|---|---|---|
|`cbc:ID`|インボイス番号|`invoice_id`|
|`cbc:IssueDate`|発行日|`timestamp`|
|`cac:AccountingSupplierParty`|売り手情報|`seller_id`|
|`cac:AccountingCustomerParty`|買い手情報|`buyer_id`|
|`cac:TaxTotal`|税計算|`tax_rate` / `tax_amount`|
|`cac:LegalMonetaryTotal`|合計金額|`total_amount`|
|`cac:InvoiceLine`|明細行|`line_items[]`|
|`cac:BillingReference`|元請求書参照（Credit Note用）|`replaces` / `tx_link`|

---

## 第3章　Peppol ネットワーク構造

### 3.1 四層モデル

|レイヤ|名称|役割|
|---|---|---|
|L1|**Participant ID**|事業者識別子（ISO 6523形式 e.g. `0088:JP1234567890`）|
|L2|**SMP (Service Metadata Publisher)**|受信者のメタデータ（ドキュメント種別・AP情報）登録|
|L3|**SML (Service Metadata Locator)**|グローバルルートディレクトリ（DNS CNAME方式）|
|L4|**Access Point (AP)**|実際の文書転送（AS4 / SOAP over HTTP）|

### 3.2 技術的要素

- 転送プロトコル：**AS4 (Web Services / SOAP + ebMS 3.0)**
    
- 認証：TLS 1.2 以上 ＋ Peppol PKI 証明書
    
- 署名：**XAdES-BES** または **CAdES-BES**
    
- 検証：OCSP ／ CRL による失効確認
    

---

## 第4章　Peppol BIS Billing 3.0 技術仕様

### 4.1 コア規格 (EN 16931)

- **取引階層**
    
    - `AccountingSupplierParty` (売り手)
        
    - `AccountingCustomerParty` (買い手)
        
    - `PaymentMeans` (支払手段)
        
    - `TaxTotal` / `TaxSubtotal` (税区分)
        
- **金額精度**：最大小数 4 位 （例 `0.1000` = 10 %）
    
- **通貨コード**：ISO 4217 （JPY, USD 等）
    
- **単位コード**：UNECE Rec 20
    
- **税区分コード**：UNCL 5305 （S = 標準税率, Z = 免税 等）
    
- **ID体系**：ISO 6523 / EAS コード（JP 国内では JP PINT 独自拡張あり）
    

### 4.2 エラーハンドリング

- Schematron 検証エラー → 受信拒否 ( `Reject Level 1` )
    
- コードリスト誤り → 警告 ( `Warning Level 2` )
    
- 計算誤差（± 1 円以内）→ 許容 ( JP PINT 特例)
    

---

## 第5章　JP PINT （日本仕様）概要

### 5.1 制定と運用主体

- 制定：**デジタル庁（Digital Agency of Japan）**
    
- 基準：Peppol BIS Billing 3.0 をベースに、日本の**消費税法・電子帳簿保存法**に適合化。
    
- 仕様書：
    
    - _JP PINT Standard Invoice v1.1.1_
        
    - _JP BIS Self-Billing Invoice_
        
    - _JP BIS Invoice for Non-tax Registered Businesses_
        

### 5.2 日本固有の拡張

|項目|内容|備考|
|---|---|---|
|**適格請求書番号**|`cac:SellerSupplierParty/cac:PartyIdentification` に登録|13桁登録番号（国税庁DB照合）|
|**税区分**|標準(10%)、軽減(8%)、非課税、免税|`TaxCategoryCode` に反映|
|**通貨単位**|円固定 (JPY) 、小数2 位まで|金額丸めは小数第 2 位|
|**日付フォーマット**|`YYYY-MM-DD`|タイムゾーン表記省略可|
|**署名ポリシー**|Peppol PKI ＋ 国内JPKI認定証明書併用可|XAdES 署名推奨|
|**Credit Note 処理**|差額計上・元票参照を義務化|元請求書ID必須|
|**電子保存要件**|電子帳簿保存法 (2022改正) に準拠|タイムスタンプ／訂正履歴保存必須|

---

## 第6章　JP PINT データ構造 詳細

### 6.1 Invoice（請求書）

- ルート要素：`<Invoice>`
    
- 必須フィールド（抜粋）
    

|UBL Tag|型|説明|CLEAR 対応|
|---|---|---|---|
|`cbc:ID`|string|インボイス番号|`invoice_id`|
|`cbc:IssueDate`|date|発行日|`timestamp`|
|`cbc:InvoiceTypeCode`|code|標準: 380|固定|
|`cac:AccountingSupplierParty`|Party|売り手情報|`seller`|
|`cac:AccountingCustomerParty`|Party|買い手情報|`buyer`|
|`cac:TaxTotal`|group|税率・税額|`tax_rate` / `tax_amount`|
|`cac:LegalMonetaryTotal`|group|合計金額群|`total_amount` 等|
|`cac:InvoiceLine`|list|明細行|`line_items[]`|

### 6.2 Credit Note（訂正）

- ルート要素：`<CreditNote>`
    
- 元票参照：`cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID`
    
- CLEARの `replaces` フィールドと1 対 1 対応。
    
- 金額は差額のみ、マイナス値表現禁止（正値＋Sign Code S / A 使用）。
    

---

## 第7章　署名・証明構造

|項目|規格|内容|
|---|---|---|
|**署名形式**|XAdES-BES / CAdES-BES|XML/PKCS#7署名。Peppol PKI 証明書を使用。|
|**タイムスタンプ**|ETSI TS 101 903|XAdES-T 拡張可。|
|**証明書階層**|RootCA (PEPPOL Authority) → AP CA → Service CA → End Entity|OCSP/CRL 失効対応。|
|**署名要素**|`<ds:Signature>` 直下に `<SignedInfo>` `<SignatureValue>` `<KeyInfo>` 必須。||
|**日本特例**|JPKI 証明書も登録可能（デジ庁発行のルートCAと相互承認）。||

---

## 第8章　コードリスト および 検証仕様

|区分|規格|備考|
|---|---|---|
|通貨|ISO 4217|`JPY` 固定。|
|税区分|UNCL 5305|`S`, `Z`, `E`, `O` 等。|
|単位|UNECE Rec 20|`EA` (個)、`HUR` (時間) 等。|
|国識別|ISO 3166-1 Alpha-2|`JP` 固定。|
|文書種別|UNCL 1001|380 (Invoice)、381 (Credit Note)。|

---

## 第9章　CLEAR-TAX 統合ポイント

### 9.1 データマッピング概要

|CLEAR フィールド|JP PINT 要素|備考|
|---|---|---|
|`invoice_id`|`cbc:ID`|一意ID。署名ID化可。|
|`timestamp`|`cbc:IssueDate`|ISO 8601日付。|
|`seller_id`|`cac:AccountingSupplierParty`|登録番号 + 住所。|
|`buyer_id`|`cac:AccountingCustomerParty`|同上。|
|`tax_rate` / `tax_amount`|`cac:TaxTotal`|型整合注意。|
|`replaces`|`cac:BillingReference`|Credit Note 参照。|
|`signature`|`<ds:Signature>`|XAdES署名。|
|`witness_hash`|(独自拡張)|CLEAR台帳連携用。|

### 9.2 整合性チェック要件

- JSON ↔ XML 変換で**全項目の損失ゼロ**を保証。
    
- 金額精度 ( float → decimal ) 変換で丸め誤差± 0.01 以内。
    
- 署名検証（XAdES） → 台帳署名（CLEAR KMS） の 2 段階検証。
    
- タイムスタンプ + 署名 + Witness ログ = 電子帳簿保存法の「訂正不能性」要件を充足。
    

---

## 第10章　適用法令・準拠文書

|法令／標準|管轄|適用範囲|
|---|---|---|
|消費税法（昭和63年法律第108号）|国税庁|仕入税額控除等|
|電子帳簿保存法（令和3年改正）|財務省／国税庁|電子的保存の認定|
|EN 16931 Electronic Invoicing|CEN|Peppol BIS 3.0 基準|
|ISO/IEC 19845 UBL 2.1|OASIS|XMLスキーマ規格|
|Peppol BIS Billing 3.0|OpenPeppol AISBL|文書構造・相互運用規範|
|JP PINT 仕様書|デジタル庁|日本ローカルCIUS|

---

## 第11章　運用・導入時の留意事項

1. **署名・証明書管理**：証明書期限・失効リストを自動照合。
    
2. **時刻整合性**：UTC固定、ローカル時刻は別途属性。
    
3. **再発行／訂正**：Credit Note モデルで管理、履歴はすべてWitness 台帳へ。
    
4. **外部連携**：税務署・金融機関等への中継はAS4/Peppol AP を経由。
    
5. **国内準拠確認**：デジタル庁「電子インボイス運用要領」最新版に追随。
    

---

## 第12章　今後の拡張展望

- **JP PINT for Gov Procurement**（公共調達版）対応。
    
- **Cross-Border VAT Reporting (Peppol CEN/ISO Work Item No. WI 003)** への接続。
    
- **Smart Contracts／Blockchain連携**：Witness Ledger をEN 16931 拡張として提案。
    
- **AI自動分類／税区分推定**：THP-CLEAR AI Agentによる会計自動補助。
    

---

### 📎 参考文献／公式資料

- [Peppol Official Site](https://peppol.org/)
    
- [Peppol BIS Billing 3.0 Specification](https://docs.peppol.eu/poac/billing/3.0/)
    
- [JP PINT 仕様書（デジタル庁）](https://www.digital.go.jp/policies/electronic_invoice)
    
- [EN 16931 CEN/TC 434 Electronic Invoicing Standard](https://standards.cen.eu/)
    
- [OASIS UBL 2.1 仕様書](https://docs.oasis-open.org/ubl/UBL-2.1.html)
    

---

この文書は THP-CLEAR 内 `/docs/integration/Peppol_Detailed_Specification.md` として格納可能です。  
CODEX-CLIのスキーマ生成完了後、この仕様書に基づいて **Peppol Mapping Table（B）** を生成し、CLEAR-TAXの完全統合に進みます。