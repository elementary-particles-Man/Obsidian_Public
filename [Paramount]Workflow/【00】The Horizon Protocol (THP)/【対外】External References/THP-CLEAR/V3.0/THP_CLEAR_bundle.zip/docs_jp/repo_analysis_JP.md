# THP-CLEAR リポジトリ分析レポート
作成日: 2025-10-13  
最終確認: ローカルワークツリー（ブランチ名不明）

## 1. プロジェクト全体像
- THP-CLEAR (Closed-Loop Emergency Asset & Relief) は、用途制限付きデジタル残高を安全に配布する人道支援向け決済基盤。命令受付 (`Command`)、外部決済照合 (`Matching`)、監査証跡 (`Witness`) の3段階で整合性と監査性を担保する。
- コードベースは Go 1.24 系を中心に設計済み。単一バイナリ `clear-api` に現行機能を集約しつつ、MQ / WN / DB / KMS のマイクロサービス分割を見据えてモジュールを整理。
- 主要コンポーネントは API サーバー、SQLite を用いたローカル永続化、Ed25519 ベースの署名、Prometheus メトリクス、Append-only Witness ログ出力で構成される。

## 2. 開発状況と成熟度
- `docs/release-notes/v1.0.0-rc1.md` が存在し、v1.0.0 リリース候補段階。`THP-CLEAR_JP.md` では「承認・実装準備フェーズへ移行」と記載。
- GitHub Actions で単体 (`ci.yml`)・統合 (`itest.yml`) テストを実行。`tests/` にはメモリストア／SQLite を使うユニット・統合テストが整備済み。
- `cmd/clear-api` はプロダクション想定の本実装。`cmd/mqd`, `cmd/kmsd`, `cmd/wnd`, `cmd/dbd` は `src/` 配下の PoC 実装を呼び出しつつもログ・監査機能まで備えた実動級。`cmd/clear-witness` は現状スタブ。
- ルートにビルド済みバイナリ `clear-api`（約19MB）と `bin/` 以下のユーティリティバイナリが含まれており、最近のビルド成果物が同梱されている。

## 3. 技術スタックと依存関係
- 言語: Go (メイン), YAML (設定), Markdown (ドキュメント), Make, Dockerfile。
- ランタイム: Go 1.24.8 toolchain, SQLite (modernc.org/sqlite による純Go実装)。
- 主なライブラリ: `github.com/go-chi/chi` (HTTP ルーター), `github.com/google/uuid`, `github.com/prometheus/client_golang`, `gopkg.in/yaml.v3`, `modernc.org/sqlite`。
- インフラ: Dockerfile + docker-compose により `clear-api` コンテナ化、Prometheus ポート (`:9100`) を同梱。Nginx ロードバランサ設定 `deploy/lb/nginx.conf` も提供。
- 鍵管理: `pkg/crypto` で Ed25519 鍵生成／保存、`certs/` には CA・ノード・KMS 用のサンプル証明書／鍵素材。

## 4. 主要ディレクトリとファイル
- `cmd/`: 各サービスの `main`。`clear-api` 本体、`mqd` (メッセージキュー)、`wnd` (ワーカーノード)、`dbd` (DB/監査サービス)、`kmsd` (KMS)、`clear-witness` (スタブ) が並ぶ。
- `internal/`: プロジェクト内部専用ロジック。`domain/` に決済ドメインモデルとユースケース、`adapters/sqlite`・`adapters/memory`・`adapters/witness` に永続化・Witness 出力、`config/` で YAML 読み込み、`httpapi/` に REST ハンドラとメトリクス連携。
- `pkg/`: 再利用可能部品。`crypto/` (Ed25519 署名器)、`monitor/` (Prometheus メトリクス集約)、`netutil/` (ネットワークユーティリティ)。
- `src/`: MQ / WN / DB / KMS / common といったサービス分割を想定した PoC 実装群。`cmd/mqd` など旧来コードが依存しており、認証 (`nodeauth`)、監査 (`audit`)、KeyRing、KMS クライアントなどが格納。
- `configs/`: 運用・検証向け YAML 一式。`example.yaml`（単体ノード用）、`docker.yaml`（コンテナ用）、`node.*.yaml`／`staging.*.yaml`（各ロール別）など。
- `tests/`: `service_unit_test.go` 等のユニット／統合テスト。`go test ./tests`、`go test -tags=integration ./tests` を想定。
- `docs/`, `docs_jp/`: アーキテクチャ資料、API 仕様、運用手順、セキュリティガイド、リリースノート、レビュー記録。`docs_jp/` は日本語訳。
- `Handoff-Codex*.md`, `repository_overview*.md`, `README*`, `CONTRIBUTING*`: プロジェクト共有事項や日本語ドキュメントが完備。
- `Dockerfile`, `docker-compose.yml`: コンテナビルド／起動設定。`docker-compose.yml` は `data/` や `witness_logs/` をホストマウント。
- `Makefile`: `kms`, `mq`, `wn`, `db` ターゲットで各バイナリをビルドし、`start`/`stop`/`status` でローカル実行管理。`run/` に PID・ログ・監査ファイルを保存。
- `bin/`: `Makefile` ビルド済みバイナリ格納場所。`run/` 配下には実行ログや JSONL 監査ファイル、SQLite (`run/clear.db`) が残置。
- `data/`: 稼働中インスタンス向け永続データ (`clear.db`, `private.key`)。`.gitignore` により通常はバージョン管理外だが現状は作業ツリーに存在。
- `witness_logs/`, `var/`: Witness ログと運用ログの配置先。現時点では空もしくは未コミットの前提。
- `dist/SHA256SUMS`: 配布用バイナリに対するハッシュ記録。
- `deploy/lb/nginx.conf`: L7 ロードバランサ設定例。

## 5. ビルド・テスト・運用フロー
- ビルド: `go build ./cmd/clear-api` または `make all`。Docker ビルドは `docker compose build` で `clear-api` の静的バイナリを生成。
- 実行: `./clear-api --config configs/example.yaml` あるいは `docker compose up -d`。Prometheus メトリクスはデフォルト `:9100`。
- テスト: `make test`（ユニット）、`make itest`（`integration` タグ付き）。CI では同等コマンドを GitHub Actions で自動化。
- ログ・監査: Witness 出力は `witness_logs/`（ファイルアペンド）、ノード監査ログは JSONL 形式で `run/` 配下に生成。構成管理の指針は `docs/ops.md` 参照。

## 6. 留意点・補足
- `src/` 配下と `internal/` 配下が共存するため、依存関係の整理（特に `cmd/*` の参照先）が今後のリファクタリングポイント。
- `data/` や `certs/` には秘密鍵・証明書のサンプルが含まれるため、取扱いと監査のルール整備が必要。公開リポジトリへの反映状況を再確認すること。
- `run/` 直下のログ／PID ファイルはデバッグ履歴。クリアが必要な場合は手動で削除する運用を想定。
- ドキュメントは英日双方が揃っている一方、`repository_overview_JP.md` など類似資料が複数あるため、最新情報のソースを一本化する運用が推奨。
- リリース候補段階のため、Witness ログ整合性チェックや KMS クォーラム運用の本番検証フェーズが残タスクとして想定される。
