use std::{env, fs, path::Path, time::Duration};

use anyhow::{anyhow, Context, Result};
use chrono::{SecondsFormat, Utc};
use reqwest::StatusCode;
use serde::{Deserialize, Serialize};
use tracing::{error, info, warn};

use rodio::{source::SineWave, OutputStream, Sink, Source};
use rusqlite::{params, Connection};

#[derive(Serialize)]
struct HealthcheckRequest {
    serial: String,
    request_timestamp: String,
}

#[derive(Deserialize, Debug)]
struct HealthcheckResponse {
    serial: String,
    request_timestamp: String,
    response_timestamp: String,
    status: String,
    details: HealthDetails,
}

#[derive(Deserialize, Debug)]
struct HealthDetails {
    uptime_seconds: u64,
    alerts: Vec<String>,
    #[serde(default)]
    heartbeat_delay_ms: Option<u64>,
}

#[tokio::main]
async fn main() -> Result<()> {
    init_tracing();
    let endpoint = env::var("CSI_AGENT_ENDPOINT")
        .unwrap_or_else(|_| "http://localhost:8443/api/csi/v1/healthcheck".to_string());
    let serial = env::var("CSI_AGENT_SERIAL").unwrap_or_else(|_| "DG-N-0001".to_string());
    let audio_enabled = env_bool("CSI_AGENT_AUDIO", true);
    let db_path = env::var("CSI_AGENT_DB_PATH")
        .unwrap_or_else(|_| "/var/lib/clear-csi-agent/alerts.db".to_string());

    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(5))
        .build()
        .context("failed to build HTTP client")?;

    let payload = HealthcheckRequest {
        serial: serial.clone(),
        request_timestamp: Utc::now().to_rfc3339_opts(SecondsFormat::Millis, true),
    };

    info!(target: "clear_csi.agent", "sending healthcheck: serial={} endpoint={}", serial, endpoint);
    let resp = client
        .post(&endpoint)
        .json(&payload)
        .send()
        .await
        .with_context(|| format!("failed to reach CSI at {endpoint}"))?;

    if !resp.status().is_success() {
        return Err(anyhow!(
            "CSI responded with non-success status {}",
            resp.status()
        ));
    }

    let status = resp.status();
    let body: HealthcheckResponse = resp.json().await.context("invalid JSON response")?;
    let outcome = evaluate_response(&payload, &body, status)?;

    if outcome.severity != Severity::Ok {
        if let Err(err) = maybe_record_alert(&db_path, &payload, &body, &outcome) {
            warn!(target: "clear_csi.agent", "failed to record alert: {err}");
        }
        if audio_enabled {
            if let Err(err) = play_notification(outcome.severity) {
                warn!(target: "clear_csi.agent", "audio playback failed: {err}");
            }
        }
    }

    match outcome.severity {
        Severity::Ok => info!(
            target: "clear_csi.agent",
            "healthcheck ok: latency_ms={} status={} uptime={}s heartbeat_delay_ms={}",
            outcome.latency_ms,
            body.status,
            body.details.uptime_seconds,
            body.details.heartbeat_delay_ms.unwrap_or(0)
        ),
        Severity::Warn => warn!(
            target: "clear_csi.agent",
            "healthcheck warn: latency_ms={} status={} alerts={:?}",
            outcome.latency_ms,
            body.status,
            body.details.alerts
        ),
        Severity::Error => error!(
            target: "clear_csi.agent",
            "healthcheck error: latency_ms={} status={} alerts={:?}",
            outcome.latency_ms,
            body.status,
            body.details.alerts
        ),
    }

    if outcome.severity == Severity::Error {
        return Err(anyhow!(
            "CSI reported ERROR status (latency={}ms)",
            outcome.latency_ms
        ));
    }

    Ok(())
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Severity {
    Ok,
    Warn,
    Error,
}

struct EvaluationOutcome {
    severity: Severity,
    latency_ms: u128,
}

fn evaluate_response(
    request: &HealthcheckRequest,
    response: &HealthcheckResponse,
    status_code: StatusCode,
) -> Result<EvaluationOutcome> {
    if request.serial != response.serial {
        return Err(anyhow!(
            "serial mismatch: sent {} got {}",
            request.serial,
            response.serial
        ));
    }

    if request.request_timestamp != response.request_timestamp {
        warn!(
            target: "clear_csi.agent",
            "timestamp mismatch: sent {} got {}",
            request.request_timestamp,
            response.request_timestamp
        );
    }

    let latency = compute_latency_ms(request, response);

    if !status_code.is_success() {
        return Err(anyhow!("unexpected HTTP status {}", status_code));
    }

    let severity = if response.status.eq_ignore_ascii_case("ERROR") {
        Severity::Error
    } else if response.status.eq_ignore_ascii_case("WARN") || latency >= 3_000 {
        Severity::Warn
    } else {
        Severity::Ok
    };

    Ok(EvaluationOutcome {
        severity,
        latency_ms: latency,
    })
}

fn compute_latency_ms(request: &HealthcheckRequest, response: &HealthcheckResponse) -> u128 {
    let req_ts = chrono::DateTime::parse_from_rfc3339(&request.request_timestamp)
        .map(|dt| dt.with_timezone(&Utc));
    let resp_ts = chrono::DateTime::parse_from_rfc3339(&response.response_timestamp)
        .map(|dt| dt.with_timezone(&Utc));

    match (req_ts, resp_ts) {
        (Ok(req), Ok(resp)) => resp.signed_duration_since(req).num_milliseconds().max(0) as u128,
        _ => 0,
    }
}

fn init_tracing() {
    let subscriber = tracing_subscriber::FmtSubscriber::builder()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env().unwrap_or_else(|_| "info".into()),
        )
        .with_target(false)
        .finish();
    if tracing::subscriber::set_global_default(subscriber).is_err() {
        error!(target: "clear_csi.agent", "tracing already initialized");
    }
}

fn env_bool(var: &str, default: bool) -> bool {
    match env::var(var) {
        Ok(value) => matches!(value.as_str(), "1" | "true" | "TRUE" | "yes" | "YES"),
        Err(_) => default,
    }
}

fn maybe_record_alert(
    db_path: &str,
    request: &HealthcheckRequest,
    response: &HealthcheckResponse,
    outcome: &EvaluationOutcome,
) -> Result<()> {
    if db_path.trim().is_empty() {
        return Ok(());
    }
    if let Some(parent) = Path::new(db_path).parent() {
        if !parent.as_os_str().is_empty() {
            fs::create_dir_all(parent).context("failed to create DB directory")?;
        }
    }

    let conn = Connection::open(db_path).context("failed to open sqlite database")?;
    conn.execute(
        "CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            serial TEXT NOT NULL,
            status TEXT NOT NULL,
            latency_ms INTEGER NOT NULL,
            alerts_json TEXT,
            request_timestamp TEXT NOT NULL,
            response_timestamp TEXT NOT NULL,
            created_at TEXT NOT NULL
        )",
        [],
    )
    .context("failed to ensure alerts table")?;

    conn.execute(
        "INSERT INTO alerts (serial,status,latency_ms,alerts_json,request_timestamp,response_timestamp,created_at)
         VALUES (?1,?2,?3,?4,?5,?6,?7)",
        params![
            response.serial,
            format!("{:?}", outcome.severity),
            i64::try_from(outcome.latency_ms).unwrap_or(i64::MAX),
            serde_json::to_string(&response.details.alerts).unwrap_or_else(|_| "[]".into()),
            request.request_timestamp,
            response.response_timestamp,
            Utc::now().to_rfc3339_opts(SecondsFormat::Millis, true)
        ],
    )
    .context("failed to insert alert row")?;

    Ok(())
}

fn play_notification(severity: Severity) -> Result<()> {
    if severity == Severity::Ok {
        return Ok(());
    }

    let (_stream, handle) = OutputStream::try_default().context("no audio output available")?;
    let sink = Sink::try_new(&handle).context("failed to create audio sink")?;
    let (frequency, duration_ms) = match severity {
        Severity::Warn => (660u32, 250u64),
        Severity::Error => (440u32, 500u64),
        Severity::Ok => unreachable!(),
    };
    let source = SineWave::new(frequency as f32)
        .take_duration(Duration::from_millis(duration_ms))
        .amplify(0.20);
    sink.append(source);
    sink.sleep_until_end();
    Ok(())
}
