fn main() {
    println!("cargo:rerun-if-changed=src/ffi_bindings.rs");
}
