use rand::{rngs::OsRng, RngCore};
use std::sync::{Arc, RwLock};

pub const ISE_KEY_SIZE: usize = 8;
pub const AES_KEY_SIZE: usize = 32;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct KeyMaterial {
    pub version: u64,
    pub ise_key: [u8; ISE_KEY_SIZE],
    pub aes_key: [u8; AES_KEY_SIZE],
}

/// Trait for a source of cryptographic keys.
pub trait KeySource: Send + Sync {
    fn current(&self) -> Result<KeyMaterial, &'static str>;
    fn previous(&self) -> Option<KeyMaterial>;
    fn by_version(&self, version: u64) -> Option<KeyMaterial>;
    fn apply(&self, mat: KeyMaterial);
}

/// A thread-safe, in-memory key store that holds the current and previous keys.
#[derive(Clone, Debug)]
pub struct KeyRing {
    inner: Arc<RwLock<KeyRingInner>>,
}

#[derive(Debug)]
struct KeyRingInner {
    current: Option<KeyMaterial>,
    previous: Option<KeyMaterial>,
}

impl KeyRing {
    /// Creates a new KeyRing, initialized with a random key of version 1.
    pub fn new() -> Result<Self, &'static str> {
        let mat = generate_key_material(1)?;
        let inner = KeyRingInner {
            current: Some(mat),
            previous: None,
        };
        Ok(KeyRing {
            inner: Arc::new(RwLock::new(inner)),
        })
    }
}

impl KeySource for KeyRing {
    fn current(&self) -> Result<KeyMaterial, &'static str> {
        self.inner
            .read()
            .unwrap()
            .current
            .ok_or("keyring: current key not initialised")
    }

    fn previous(&self) -> Option<KeyMaterial> {
        self.inner.read().unwrap().previous
    }

    fn by_version(&self, version: u64) -> Option<KeyMaterial> {
        let inner = self.inner.read().unwrap();
        if let Some(curr) = inner.current {
            if curr.version == version {
                return Some(curr);
            }
        }
        if let Some(prev) = inner.previous {
            if prev.version == version {
                return Some(prev);
            }
        }
        None
    }

    /// Stores externally provided material and shifts the previous entry when needed.
    fn apply(&self, mat: KeyMaterial) {
        let mut inner = self.inner.write().unwrap();

        let current = match inner.current {
            Some(c) => c,
            None => {
                inner.current = Some(mat);
                return;
            }
        };

        if mat.version > current.version {
            inner.previous = inner.current;
            inner.current = Some(mat);
        } else if mat.version == current.version {
            inner.current = Some(mat);
        } else if inner.previous.is_none() || mat.version >= inner.previous.unwrap().version {
            inner.previous = Some(mat);
        }
    }
}

fn generate_key_material(version: u64) -> Result<KeyMaterial, &'static str> {
    let mut mat = KeyMaterial {
        version,
        ise_key: [0; ISE_KEY_SIZE],
        aes_key: [0; AES_KEY_SIZE],
    };

    let mut rng = OsRng;
    rng.try_fill_bytes(&mut mat.ise_key)
        .map_err(|_| "failed to generate ISE key")?;
    rng.try_fill_bytes(&mut mat.aes_key)
        .map_err(|_| "failed to generate AES key")?;

    Ok(mat)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_keyring_initialization() {
        let ring = KeyRing::new().unwrap();
        let current = ring.current().unwrap();
        assert_eq!(current.version, 1);
        assert!(ring.previous().is_none());
    }

    #[test]
    fn test_keyring_apply_and_rotate() {
        let ring = KeyRing::new().unwrap();
        let initial_key = ring.current().unwrap();

        let new_key_v2 = generate_key_material(2).unwrap();
        ring.apply(new_key_v2);

        assert_eq!(ring.current().unwrap().version, 2);
        assert_eq!(ring.previous().unwrap().version, 1);
        assert_eq!(ring.previous().unwrap(), initial_key);

        let new_key_v3 = generate_key_material(3).unwrap();
        ring.apply(new_key_v3);

        assert_eq!(ring.current().unwrap().version, 3);
        assert_eq!(ring.previous().unwrap().version, 2);
        assert_eq!(ring.previous().unwrap(), new_key_v2);
    }

    #[test]
    fn test_by_version() {
        let ring = KeyRing::new().unwrap();
        let key_v1 = ring.current().unwrap();
        let key_v2 = generate_key_material(2).unwrap();
        ring.apply(key_v2);

        assert_eq!(ring.by_version(1).unwrap(), key_v1);
        assert_eq!(ring.by_version(2).unwrap(), key_v2);
        assert!(ring.by_version(3).is_none());
    }
}
