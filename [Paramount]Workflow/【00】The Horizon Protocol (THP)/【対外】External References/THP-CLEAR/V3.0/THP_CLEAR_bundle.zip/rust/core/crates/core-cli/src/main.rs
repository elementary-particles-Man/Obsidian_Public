//! Simple entry point that demonstrates wiring for the Rust workspace.

use core_runtime::hello;

fn main() {
    let message = hello("THP CLEAR");
    println!("{message}");
}
