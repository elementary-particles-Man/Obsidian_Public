# THP CLEAR Rust Workspace

`rust/core` provides the Rust implementation surface for THP CLEAR. The workspace is intentionally minimal right now so crates can be added incrementally.

## Layout

- `Cargo.toml` — workspace manifest shared by all crates.
- `crates/` — location for all workspace members.
  - `core-runtime` — library crate hosting core runtime utilities.
  - `core-cli` — binary crate that currently exercises the runtime crate.

## Next Steps

1. Add new crates under `crates/` and reference them from the workspace manifest if they are not matched by the wildcard.
2. Extend `core-runtime` with actual functionality needed by the project.
3. Replace the sample logic in `core-cli` with the desired executable behavior.
