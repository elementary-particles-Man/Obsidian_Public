//! Core runtime utilities for the THP CLEAR platform.

pub mod emad;
pub mod ffi_bindings;
pub mod witness;

/// Returns a human friendly hello message.
pub fn hello(name: &str) -> String {
    format!("Hello, {}!", name)
}

/// Returns the semantic version of this crate.
pub fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::ffi::CStr;

    #[test]
    fn hello_formats_message() {
        let result = hello("Tester");
        assert!(result.contains("Tester"));
    }

    #[test]
    fn version_matches_cargo_pkg_version() {
        assert_eq!(version(), env!("CARGO_PKG_VERSION"));
    }

    #[test]
    fn ffi_version_matches() {
        let ptr = ffi_bindings::rust_get_version();
        assert!(!ptr.is_null());
        let version_from_c = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("version string should be valid UTF-8");
        assert_eq!(version_from_c, version());
    }
}
