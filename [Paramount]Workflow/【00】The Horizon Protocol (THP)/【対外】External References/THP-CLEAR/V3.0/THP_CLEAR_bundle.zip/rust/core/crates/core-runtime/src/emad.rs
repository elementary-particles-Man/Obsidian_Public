//! EMAD score computation helpers.

/// Computes a heuristic EMAD score in the range [0, 1].
pub fn compute_emad_score(inputs: &[f64]) -> f64 {
    if inputs.is_empty() {
        return 0.0;
    }

    let mean = inputs.iter().sum::<f64>() / inputs.len() as f64;
    let variance = inputs
        .iter()
        .map(|value| (value - mean).powi(2))
        .sum::<f64>()
        / inputs.len() as f64;

    (1.0 / (1.0 + variance)).clamp(0.0, 1.0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn zero_for_empty_slice() {
        assert_eq!(compute_emad_score(&[]), 0.0);
    }

    #[test]
    fn perfect_score_for_zero_variance() {
        let result = compute_emad_score(&[1.0, 1.0, 1.0]);
        assert!((result - 1.0).abs() < f64::EPSILON);
    }
}
