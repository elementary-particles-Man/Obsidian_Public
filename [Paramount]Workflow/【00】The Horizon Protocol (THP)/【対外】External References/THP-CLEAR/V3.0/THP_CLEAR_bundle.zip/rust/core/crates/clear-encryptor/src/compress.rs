use flate2::{read::GzDecoder, write::GzEncoder, Compression};
use std::io::{Read, Write};

pub fn compress_payload(src: &[u8]) -> Result<Vec<u8>, std::io::Error> {
    let mut encoder = GzEncoder::new(Vec::new(), Compression::default());
    encoder.write_all(src)?;
    encoder.finish()
}

pub fn decompress_payload(src: &[u8]) -> Result<Vec<u8>, std::io::Error> {
    let mut decoder = GzDecoder::new(src);
    let mut decompressed = Vec::new();
    decoder.read_to_end(&mut decompressed)?;
    Ok(decompressed)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_gzip_round_trip() {
        let original = b"The quick brown fox jumps over the lazy dog. Repeatedly.".repeat(10);

        let compressed = compress_payload(&original).unwrap();
        assert!(compressed.len() < original.len());

        let decompressed = decompress_payload(&compressed).unwrap();

        assert_eq!(original, decompressed.as_slice());
    }

    #[test]
    fn test_decompress_invalid_data() {
        let invalid_data = b"this is not gzip data";
        let result = decompress_payload(invalid_data);
        assert!(result.is_err());
    }
}
