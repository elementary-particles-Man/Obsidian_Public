//! Witness signature generator utilities.

use sha2::{Digest, Sha256};
use std::time::{SystemTime, UNIX_EPOCH};

/// Generates a witness signature using the provided payload and the current timestamp.
pub fn generate_witness_signature(data: &str) -> String {
    let timestamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("system time must be after UNIX_EPOCH")
        .as_secs();
    let mut hasher = Sha256::new();
    hasher.update(format!("{}:{}", data, timestamp));
    let digest = hasher.finalize();
    format!("{digest:x}:{timestamp}")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn signature_contains_timestamp_separator() {
        let signature = generate_witness_signature("payload");
        assert!(
            signature.contains(':'),
            "signature should include ':' separator"
        );
    }
}
