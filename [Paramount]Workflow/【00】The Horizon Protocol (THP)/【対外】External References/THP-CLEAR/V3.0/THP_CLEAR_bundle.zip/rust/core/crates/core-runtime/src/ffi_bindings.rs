//! FFI bindings exposed for cross-language consumers.

use std::ffi::{CStr, CString};
use std::os::raw::c_char;
use std::slice;
use std::sync::OnceLock;

use crate::{emad, version, witness};

#[no_mangle]
pub extern "C" fn rust_get_version() -> *const c_char {
    static VERSION_CSTRING: OnceLock<CString> = OnceLock::new();

    VERSION_CSTRING
        .get_or_init(|| {
            CString::new(version()).expect("version string must not contain interior NULs")
        })
        .as_ptr()
}

#[no_mangle]
pub extern "C" fn rust_generate_witness_signature(data: *const c_char) -> *const c_char {
    if data.is_null() {
        return std::ptr::null();
    }

    let c_str = unsafe { CStr::from_ptr(data) };
    let input = c_str.to_str().unwrap_or_default();
    let signature = witness::generate_witness_signature(input);
    let c_string = CString::new(signature).expect("signature must not contain interior NUL bytes");
    c_string.into_raw()
}

#[no_mangle]
pub extern "C" fn rust_compute_emad_score(ptr: *const f64, len: usize) -> f64 {
    if ptr.is_null() || len == 0 {
        return 0.0;
    }

    let slice = unsafe { slice::from_raw_parts(ptr, len) };
    emad::compute_emad_score(slice)
}

#[no_mangle]
pub extern "C" fn rust_string_free(pointer: *mut c_char) {
    if pointer.is_null() {
        return;
    }

    unsafe {
        drop(CString::from_raw(pointer));
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn witness_signature_roundtrip() {
        let input = CString::new("payload").unwrap();
        let ptr = rust_generate_witness_signature(input.as_ptr());
        assert!(!ptr.is_null());
        let signature = unsafe { CStr::from_ptr(ptr) }.to_string_lossy().to_string();
        assert!(
            signature.contains(':'),
            "signature should include ':' separator"
        );
        rust_string_free(ptr as *mut c_char);
    }

    #[test]
    fn emad_score_through_ffi_matches() {
        let values = [1.0, 1.0, 1.0];
        let score = rust_compute_emad_score(values.as_ptr(), values.len());
        assert!((score - 1.0).abs() < f64::EPSILON);
    }
}
