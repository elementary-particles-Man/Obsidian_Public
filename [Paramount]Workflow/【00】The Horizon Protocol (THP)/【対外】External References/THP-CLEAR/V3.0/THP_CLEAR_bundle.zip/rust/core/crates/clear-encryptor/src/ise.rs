use std::convert::TryInto;

const ISE_KEY_SIZE: usize = 8;
const ISE_ROUNDS: usize = 8;
const ISE_MIN_SHIFT: u8 = 1;
const ISE_SHIFT_MASK: u64 = 0x07;

/// ISEPlan maps the 64bit ISE鍵 to a deterministic round schedule and order bit.
#[derive(Debug, Clone)]
pub struct IsePlan {
    rounds: Vec<IseRound>,
    seq_id: u32,
    order_forward: bool,
}

#[derive(Debug, Clone, Copy)]
struct IseRound {
    xor_byte: u8,
    shift: u8,
    reverse: bool,
}

impl IsePlan {
    /// Constructs a plan from a raw 8-byte key.
    pub fn new(key: &[u8]) -> Result<Self, &'static str> {
        if key.len() != ISE_KEY_SIZE {
            return Err("ise: key must be 8 bytes");
        }

        let (rounds, seq_id, order_forward) = derive_plan(key);
        Ok(IsePlan {
            rounds,
            seq_id,
            order_forward,
        })
    }

    /// Constructs a plan from a 64-bit integer key.
    pub fn from_u64(key: u64) -> Self {
        let key_bytes = key.to_le_bytes();
        // This unwrap is safe because the key is always 8 bytes.
        Self::new(&key_bytes).unwrap()
    }

    /// Returns the deterministic sequence identifier derived from the key.
    pub fn seq_id(&self) -> u32 {
        self.seq_id
    }

    /// Reports the canonical order bit (true=forward, false=reverse).
    pub fn order_forward(&self) -> bool {
        self.order_forward
    }

    /// Clones input and executes the configured rounds.
    /// `invert_order` = true for initial encryption.
    /// `invert_order` = false for verification/recovery.
    pub fn apply(&self, input: &[u8], invert_order: bool) -> Vec<u8> {
        let mut out = input.to_vec();
        let use_forward = if invert_order {
            !self.order_forward
        } else {
            self.order_forward
        };

        if use_forward {
            for round in &self.rounds {
                round.apply_forward(&mut out);
            }
        } else {
            for round in self.rounds.iter().rev() {
                round.apply_reverse(&mut out);
            }
        }
        out
    }
}

impl IseRound {
    fn apply_forward(&self, buf: &mut [u8]) {
        if self.reverse {
            for byte in buf.iter_mut() {
                *byte = byte.rotate_left(self.shift as u32);
                *byte ^= self.xor_byte;
            }
        } else {
            for byte in buf.iter_mut() {
                *byte = byte.rotate_right(self.shift as u32);
                *byte ^= self.xor_byte;
            }
        }
    }

    fn apply_reverse(&self, buf: &mut [u8]) {
        if self.reverse {
            for byte in buf.iter_mut() {
                *byte ^= self.xor_byte;
                *byte = byte.rotate_right(self.shift as u32);
            }
        } else {
            for byte in buf.iter_mut() {
                *byte ^= self.xor_byte;
                *byte = byte.rotate_left(self.shift as u32);
            }
        }
    }
}

fn derive_plan(key: &[u8]) -> (Vec<IseRound>, u32, bool) {
    let mut state = u64::from_le_bytes(key.try_into().unwrap());
    if state == 0 {
        state = 0x9E3779B97F4A7C15; // golden ratio constant
    }

    let order_forward = (state & 1) == 1;
    let seq_id = ((state >> 1) & 0xffffffff) as u32;

    let mut order: Vec<usize> = (0..ISE_ROUNDS).collect();

    // Fisher-Yates shuffle driven by the key-derived PRNG.
    for i in (1..ISE_ROUNDS).rev() {
        let j = (next_state(&mut state) % (i as u64 + 1)) as usize;
        order.swap(i, j);
    }

    let mut rounds = vec![
        IseRound {
            xor_byte: 0,
            shift: 0,
            reverse: false
        };
        ISE_ROUNDS
    ];
    for (idx, &pos) in order.iter().enumerate() {
        let val = next_state(&mut state);
        let xor_byte = (val as u8) ^ key[pos];
        let shift = ((val >> 8) & ISE_SHIFT_MASK) as u8 + ISE_MIN_SHIFT;
        let reverse = ((val >> 11) & 1) == 1;

        rounds[idx] = IseRound {
            xor_byte,
            shift,
            reverse,
        };
    }

    (rounds, seq_id, order_forward)
}

fn next_state(state: &mut u64) -> u64 {
    let mut x = *state;
    x ^= x << 7;
    x ^= x >> 9;
    x ^= x << 8;
    *state = x;
    x
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ise_apply_round_trip() {
        let key = vec![0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80];
        let p = IsePlan::new(&key).unwrap();

        let plain = b"witness-ledger";
        let ciphertext = p.apply(plain, true); // Initial encryption (invert order)
        assert_eq!(ciphertext.len(), plain.len());

        let recovered = p.apply(&ciphertext, false); // Verification (don't invert)
        assert_eq!(recovered, plain);
    }

    #[test]
    fn test_ise_deterministic_plan() {
        let key = vec![0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF];
        let p = IsePlan::new(&key).unwrap();

        let plain = b"CLEAR-LIFELINE";
        let ciphertext = p.apply(plain, true);

        let expected_hex = "8c6d4cccae416dcd2c4c6dcd2d4c";
        assert_eq!(hex::encode(ciphertext), expected_hex);
    }

    #[test]
    fn test_ise_different_keys_differ() {
        let key1 = vec![0x56, 0x47, 0x38, 0x29, 0x1A, 0x0B, 0xFC, 0xED];
        let key2 = vec![0x56, 0x47, 0x38, 0x29, 0x1A, 0x0B, 0xFC, 0xEE];

        let p1 = IsePlan::new(&key1).unwrap();
        let p2 = IsePlan::new(&key2).unwrap();

        let input = b"mq-sequence-check";

        let out1 = p1.apply(input, true);
        let out2 = p2.apply(input, true);

        assert_ne!(out1, out2);
    }
}
