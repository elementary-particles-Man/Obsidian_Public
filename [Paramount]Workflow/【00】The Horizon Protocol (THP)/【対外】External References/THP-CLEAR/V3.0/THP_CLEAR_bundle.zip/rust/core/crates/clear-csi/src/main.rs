use std::{
    collections::{HashMap, HashSet},
    env, fs, io,
    net::SocketAddr,
    path::{Path, PathBuf},
    process,
    sync::{
        atomic::{AtomicU64, Ordering},
        Arc,
    },
    time::Instant,
};

use async_nats::Client;
use axum::{
    extract::State,
    http::{header, StatusCode},
    response::IntoResponse,
    routing::{get, post, Router},
    Json,
};
use chrono::{DateTime, SecondsFormat, Utc};
use csv::StringRecord;
use futures::StreamExt;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use tokio::{sync::Mutex, task};
use tracing::{error, info, warn, Level};
use tracing_subscriber::FmtSubscriber;

#[derive(Clone)]
struct AppState {
    cluster_name: Arc<Mutex<String>>,
    cluster_epoch: Arc<Mutex<String>>,
    nodes: Arc<Mutex<HashMap<String, RegisteredNode>>>,
    policy: Arc<PolicyState>,
    thresholds: Arc<ThresholdPolicy>,
    metrics: Arc<MetricsState>,
    coin_registry: Arc<Mutex<CoinRegistry>>,
    coin_input_dir: PathBuf,
    coin_registry_path: PathBuf,
    service_started_at: Instant,
}

struct MetricsState {
    heartbeats_total: Mutex<u64>,
    threshold_violations_total: AtomicU64,
    alerts_emitted_total: AtomicU64,
    coins_registered: AtomicU64,
}

impl MetricsState {
    fn new() -> Self {
        Self {
            heartbeats_total: Mutex::new(0),
            threshold_violations_total: AtomicU64::new(0),
            alerts_emitted_total: AtomicU64::new(0),
            coins_registered: AtomicU64::new(0),
        }
    }
}

#[derive(Default)]
struct CoinRegistry {
    coins: Vec<String>,
}

impl CoinRegistry {
    fn update(&mut self, coins: Vec<String>) {
        self.coins = coins;
    }
}

#[derive(Serialize)]
struct HealthResponse {
    status: &'static str,
}

#[derive(Serialize)]
struct NodeStatus {
    cluster: String,
    status: &'static str,
    epoch: String,
    timestamp: String,
    nodes: Vec<RegisteredNode>,
}

#[derive(Debug, Deserialize)]
struct RegisterRequest {
    node_id: String,
    role: String,
    api_port: Option<u16>,
    #[serde(default)]
    tpm_quote: Option<String>,
    #[serde(default)]
    epoch_hint: Option<String>,
}

#[derive(Clone, Serialize)]
struct RegisteredNode {
    node_id: String,
    role: String,
    registered_at: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    last_seen: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    tpm_quote: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    epoch_hint: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    api_port: Option<u16>,
}

#[derive(Serialize)]
struct RegisterResponse {
    status: &'static str,
    cluster_epoch: String,
}

#[derive(Deserialize)]
struct HeartbeatRequest {
    node_id: String,
    #[serde(default)]
    ts: Option<String>,
}

#[derive(Deserialize)]
struct LeaveRequest {
    node_id: String,
}

#[derive(Serialize)]
struct LeaveResponse {
    status: &'static str,
    removed: bool,
    cluster_epoch: String,
}

#[derive(Serialize)]
struct ProcessMapResponse {
    status: &'static str,
    nodes: Vec<ProcessEntry>,
}

#[derive(Serialize)]
struct ProcessEntry {
    node_id: String,
    role: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    last_seen: Option<String>,
    proc_mask: &'static str,
}

#[derive(Serialize)]
struct LoadCoinsResponse {
    status: &'static str,
    loaded: usize,
    file_count: usize,
}

#[derive(Deserialize)]
struct HealthcheckRequest {
    serial: String,
    request_timestamp: String,
}

#[derive(Serialize)]
struct HealthcheckResponse {
    serial: String,
    request_timestamp: String,
    response_timestamp: String,
    status: String,
    details: HealthDetails,
}

#[derive(Clone, Serialize)]
struct HealthDetails {
    uptime_seconds: u64,
    alerts: Vec<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    heartbeat_delay_ms: Option<u64>,
}

#[derive(Clone)]
struct PolicyState {
    allowed_api_ports: HashSet<u16>,
    blacklist_ports: HashSet<u16>,
    #[allow(dead_code)]
    allowed_internal_ports: HashSet<u16>,
    #[allow(dead_code)]
    assignments: HashMap<String, Assignment>,
}

#[derive(Clone)]
struct ThresholdPolicy {
    default_threshold: f64,
    currency_overrides: HashMap<String, f64>,
    categories: HashMap<String, CategoryRule>,
    company_overrides: HashMap<String, CompanyRule>,
}

impl ThresholdPolicy {
    fn resolve(
        &self,
        company_id: Option<&str>,
        category: Option<&str>,
        currency: Option<&str>,
    ) -> f64 {
        let currency_key = currency.map(normalize_currency_key);
        let category_key = category.map(normalize_category_key);

        if let Some(company_id) = company_id {
            if let Some(company) = self.company_overrides.get(company_id) {
                if let Some(ref cat_key) = category_key {
                    if let Some(value) = company.categories.get(cat_key) {
                        if let Some(ref cur_key) = currency_key {
                            if let Some(threshold) = value.currency_overrides.get(cur_key) {
                                return *threshold;
                            }
                        }
                        if let Some(threshold) = value.default_threshold {
                            return threshold;
                        }
                    }
                }
                if let Some(ref cur_key) = currency_key {
                    if let Some(threshold) = company.currency_overrides.get(cur_key) {
                        return *threshold;
                    }
                }
                if let Some(threshold) = company.default_threshold {
                    return threshold;
                }
            }
        }

        if let Some(ref cat_key) = category_key {
            if let Some(category_rule) = self.categories.get(cat_key) {
                if let Some(ref cur_key) = currency_key {
                    if let Some(threshold) = category_rule.currency_overrides.get(cur_key) {
                        return *threshold;
                    }
                }
                if let Some(threshold) = category_rule.default_threshold {
                    return threshold;
                }
            }
        }

        if let Some(ref cur_key) = currency_key {
            if let Some(threshold) = self.currency_overrides.get(cur_key) {
                return *threshold;
            }
        }

        self.default_threshold
    }
}

#[derive(Clone, Default)]
struct CategoryRule {
    default_threshold: Option<f64>,
    currency_overrides: HashMap<String, f64>,
}

#[derive(Clone, Default)]
struct CompanyRule {
    default_threshold: Option<f64>,
    currency_overrides: HashMap<String, f64>,
    categories: HashMap<String, CategoryRule>,
}

#[allow(dead_code)]
#[derive(Clone)]
struct Assignment {
    api_port: u16,
}

#[allow(dead_code)]
#[derive(Deserialize)]
struct RawPolicy {
    version: u32,
    profiles: HashMap<String, RawProfile>,
    default_profile: String,
    assignments: HashMap<String, RawAssignment>,
}

#[derive(Deserialize)]
struct RawProfile {
    #[serde(default)]
    allowed_api_ports: Vec<u16>,
    #[serde(default)]
    allowed_internal_ports: Vec<u16>,
    #[serde(default)]
    blacklist_ports: Vec<u16>,
}

#[derive(Deserialize)]
struct RawAssignment {
    api_port: u16,
}

#[derive(Debug)]
enum PolicyLoadError {
    NotFound(Vec<PathBuf>),
    Io(String),
    Parse(String),
    MissingProfile(String),
    MissingAssignment(String),
    PortViolation(u16),
    InvalidPolicy(String),
}

impl std::fmt::Display for PolicyLoadError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            PolicyLoadError::NotFound(_) => write!(f, "policy file not found"),
            PolicyLoadError::Io(msg)
            | PolicyLoadError::Parse(msg)
            | PolicyLoadError::InvalidPolicy(msg) => write!(f, "{msg}"),
            PolicyLoadError::MissingProfile(name) => {
                write!(f, "policy profile '{}' is missing", name)
            }
            PolicyLoadError::MissingAssignment(name) => {
                write!(f, "assignment for '{}' is missing", name)
            }
            PolicyLoadError::PortViolation(port) => {
                write!(f, "port {} violates LGWAN policy", port)
            }
        }
    }
}

#[derive(Debug)]
enum ThresholdLoadError {
    NotFound(Vec<PathBuf>),
    Io(PathBuf, io::Error),
    Parse(PathBuf, String),
    Invalid(String),
}

impl std::fmt::Display for ThresholdLoadError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ThresholdLoadError::NotFound(paths) => {
                let tried = paths
                    .iter()
                    .map(|p| p.display().to_string())
                    .collect::<Vec<_>>()
                    .join(", ");
                write!(f, "threshold policy file not found (tried: {tried})")
            }
            ThresholdLoadError::Io(path, err) => {
                write!(f, "{}: {}", path.display(), err)
            }
            ThresholdLoadError::Parse(path, msg) => {
                write!(f, "{} parse error: {}", path.display(), msg)
            }
            ThresholdLoadError::Invalid(msg) => write!(f, "{msg}"),
        }
    }
}

fn load_threshold_policy() -> Result<ThresholdPolicy, ThresholdLoadError> {
    let mut attempted: Vec<PathBuf> = Vec::new();

    if let Some(path) = env::var("CSI_THRESHOLD_PATH").ok().map(PathBuf::from) {
        attempted.push(path.clone());
        if path.exists() {
            return parse_threshold_policy(&path);
        }
    }

    for candidate in [
        PathBuf::from("ops/policy/thresholds.json"),
        PathBuf::from("/etc/clear/thresholds.json"),
    ] {
        attempted.push(candidate.clone());
        if candidate.exists() {
            return parse_threshold_policy(&candidate);
        }
    }

    Err(ThresholdLoadError::NotFound(attempted))
}

#[derive(Deserialize)]
struct RawThresholds {
    default_threshold: f64,
    #[serde(default)]
    currency_overrides: HashMap<String, f64>,
    #[serde(default)]
    categories: HashMap<String, RawCategoryEntry>,
    #[serde(default)]
    company_overrides: HashMap<String, RawCompanyEntry>,
}

#[derive(Deserialize)]
struct RawCategoryRule {
    #[serde(default)]
    default_threshold: Option<f64>,
    #[serde(default)]
    currency_overrides: HashMap<String, f64>,
}

#[derive(Deserialize)]
#[serde(untagged)]
enum RawCategoryEntry {
    Simple(f64),
    Detailed(RawCategoryRule),
}

#[derive(Deserialize)]
struct RawCompanyEntry {
    #[serde(default)]
    default_threshold: Option<f64>,
    #[serde(default)]
    currency_overrides: HashMap<String, f64>,
    #[serde(default)]
    categories: HashMap<String, RawCategoryEntry>,
}

fn parse_threshold_policy(path: &Path) -> Result<ThresholdPolicy, ThresholdLoadError> {
    let contents =
        fs::read_to_string(path).map_err(|err| ThresholdLoadError::Io(path.to_path_buf(), err))?;
    let raw: RawThresholds = serde_json::from_str(&contents)
        .map_err(|err| ThresholdLoadError::Parse(path.to_path_buf(), err.to_string()))?;

    if !raw.default_threshold.is_finite() || raw.default_threshold <= 0.0 {
        return Err(ThresholdLoadError::Invalid(
            "default_threshold must be a positive number".into(),
        ));
    }

    let currency_overrides = normalize_currency_map(raw.currency_overrides);
    let categories = raw
        .categories
        .into_iter()
        .map(|(name, entry)| (normalize_category_key(&name), into_category_rule(entry)))
        .collect();

    let mut company_overrides = HashMap::new();
    for (company, entry) in raw.company_overrides {
        let mut rule = CompanyRule::default();
        rule.default_threshold = entry.default_threshold;
        rule.currency_overrides = normalize_currency_map(entry.currency_overrides);
        let categories = entry
            .categories
            .into_iter()
            .map(|(name, category)| (normalize_category_key(&name), into_category_rule(category)))
            .collect();
        rule.categories = categories;
        company_overrides.insert(company, rule);
    }

    Ok(ThresholdPolicy {
        default_threshold: raw.default_threshold,
        currency_overrides,
        categories,
        company_overrides,
    })
}

fn into_category_rule(entry: RawCategoryEntry) -> CategoryRule {
    match entry {
        RawCategoryEntry::Simple(value) => CategoryRule {
            default_threshold: Some(value),
            currency_overrides: HashMap::new(),
        },
        RawCategoryEntry::Detailed(rule) => CategoryRule {
            default_threshold: rule.default_threshold,
            currency_overrides: normalize_currency_map(rule.currency_overrides),
        },
    }
}

fn normalize_currency_map(input: HashMap<String, f64>) -> HashMap<String, f64> {
    input
        .into_iter()
        .filter(|(_, v)| v.is_finite() && *v > 0.0)
        .map(|(key, value)| (normalize_currency_key(&key), value))
        .collect()
}

fn normalize_currency_key(key: &str) -> String {
    key.trim().to_uppercase()
}

fn normalize_category_key(key: &str) -> String {
    key.trim().to_uppercase()
}

#[tokio::main]
async fn main() {
    init_tracing();

    let (policy_state, assigned_port) = match load_policy() {
        Ok(data) => data,
        Err(PolicyLoadError::NotFound(paths)) => {
            let tried = if paths.is_empty() {
                "<none>".to_string()
            } else {
                paths
                    .iter()
                    .map(|p| p.display().to_string())
                    .collect::<Vec<_>>()
                    .join(", ")
            };
            eprintln!("[CSI] port policy file not found. tried: {tried}");
            process::exit(2);
        }
        Err(PolicyLoadError::PortViolation(port)) => {
            eprintln!(
                "[CSI] assigned port {} violates LGWAN policy (not allowed or blacklisted)",
                port
            );
            process::exit(3);
        }
        Err(other) => {
            eprintln!("[CSI] failed to load port policy: {}", other);
            process::exit(2);
        }
    };

    let thresholds = match load_threshold_policy() {
        Ok(policy) => policy,
        Err(err) => {
            eprintln!("[CSI] failed to load thresholds policy: {}", err);
            process::exit(2);
        }
    };

    if let Ok(env_port) = env::var("CSI_PORT") {
        match env_port.parse::<u16>() {
            Ok(port) if port != assigned_port => {
                eprintln!(
                    "[CSI] CSI_PORT={} does not match policy assignment {}",
                    port, assigned_port
                );
                process::exit(3);
            }
            Ok(_) => {}
            Err(_) => {
                eprintln!("[CSI] CSI_PORT env var is malformed: {}", env_port);
                process::exit(2);
            }
        }
    } else {
        env::set_var("CSI_PORT", assigned_port.to_string());
    }

    let cluster_name = env::var("CSI_CLUSTER_NAME").unwrap_or_else(|_| "clear-main".to_string());
    let cluster_epoch = env::var("CSI_EPOCH").unwrap_or_else(|_| "E-2".to_string());
    let coin_input_dir = env::var("CSI_COINS_INPUT_DIR")
        .map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from("ops/input"));
    let coin_registry_path = env::var("CSI_COINS_REGISTRY_PATH")
        .map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from("/var/lib/clear-csi/coin_registry.json"));

    let state = AppState {
        cluster_name: Arc::new(Mutex::new(cluster_name)),
        cluster_epoch: Arc::new(Mutex::new(cluster_epoch)),
        nodes: Arc::new(Mutex::new(HashMap::new())),
        policy: Arc::new(policy_state),
        thresholds: Arc::new(thresholds),
        metrics: Arc::new(MetricsState::new()),
        coin_registry: Arc::new(Mutex::new(CoinRegistry::default())),
        coin_input_dir,
        coin_registry_path,
        service_started_at: Instant::now(),
    };

    spawn_mq_consumer(state.clone());

    let app = build_router(state);

    let addr = SocketAddr::from(([0, 0, 0, 0], assigned_port));
    info!("starting clear-csi service on {addr}");
    axum::serve(tokio::net::TcpListener::bind(addr).await.unwrap(), app)
        .with_graceful_shutdown(shutdown_signal())
        .await
        .unwrap();
}

fn build_router(state: AppState) -> Router {
    Router::new()
        .route("/health", get(health_handler))
        .route("/api/csi/v1/nodes/status", get(status_handler))
        .route("/api/csi/v1/nodes/register", post(register_handler))
        .route("/api/csi/v1/nodes/heartbeat", post(heartbeat_handler))
        .route("/api/csi/v1/nodes/leave", post(leave_handler))
        .route("/api/csi/v1/process/map", get(process_map_handler))
        .route("/api/csi/v1/load/coins", post(load_coins_handler))
        .route("/api/csi/v1/healthcheck", post(healthcheck_handler))
        .route("/metrics", get(metrics_handler))
        .with_state(state)
}

async fn health_handler() -> Json<HealthResponse> {
    Json(HealthResponse { status: "ok" })
}

async fn status_handler(State(state): State<AppState>) -> Json<NodeStatus> {
    let cluster = state.cluster_name.lock().await.clone();
    let epoch = state.cluster_epoch.lock().await.clone();
    let nodes = {
        let guard = state.nodes.lock().await;
        guard.values().cloned().collect::<Vec<_>>()
    };

    Json(NodeStatus {
        cluster,
        status: "ready",
        epoch,
        timestamp: Utc::now().to_rfc3339(),
        nodes,
    })
}

async fn register_handler(
    State(state): State<AppState>,
    Json(payload): Json<RegisterRequest>,
) -> Result<Json<RegisterResponse>, (StatusCode, Json<Value>)> {
    let node_id_trimmed = payload.node_id.trim();
    if node_id_trimmed.is_empty() {
        return Err((
            StatusCode::BAD_REQUEST,
            Json(json!({
                "status": "error",
                "code": "BAD_REQUEST",
                "message": "node_id required"
            })),
        ));
    }
    let node_id = node_id_trimmed.to_string();

    let role = match normalize_role(&payload.role) {
        Some(role) => role,
        None => {
            return Err((
                StatusCode::BAD_REQUEST,
                Json(json!({
                    "status":"error",
                    "code":"BAD_REQUEST",
                    "message":"role not permitted"
                })),
            ))
        }
    };
    let tpm_quote = normalize_optional(payload.tpm_quote);
    let epoch_hint = normalize_optional(payload.epoch_hint);
    let now = Utc::now().to_rfc3339();

    let api_port = match payload.api_port {
        Some(port) => port,
        None => {
            return Err((
                StatusCode::BAD_REQUEST,
                Json(json!({
                    "status":"error",
                    "code":"BAD_REQUEST",
                    "message":"api_port required"
                })),
            ));
        }
    };

    let policy = state.policy.clone();
    if !policy.allowed_api_ports.contains(&api_port) || policy.blacklist_ports.contains(&api_port) {
        return Err((
            StatusCode::CONFLICT,
            Json(json!({
                "status":"error",
                "code":"PORT_POLICY_VIOLATION",
                "message":"api_port not allowed"
            })),
        ));
    }

    {
        let mut guard = state.nodes.lock().await;
        if let Some(existing) = guard.get(&node_id) {
            if existing.role != role || existing.tpm_quote != tpm_quote {
                return Err((
                    StatusCode::CONFLICT,
                    Json(json!({
                        "status":"error",
                        "code":"NODE_CONFLICT",
                        "message":"existing node definition differs"
                    })),
                ));
            }
        }

        guard.insert(
            node_id.clone(),
            RegisteredNode {
                node_id: node_id.clone(),
                role: role.clone(),
                registered_at: now.clone(),
                last_seen: Some(now),
                tpm_quote: tpm_quote.clone(),
                epoch_hint: epoch_hint.clone(),
                api_port: Some(api_port),
            },
        );
    }

    let cluster_epoch = state.cluster_epoch.lock().await.clone();

    Ok(Json(RegisterResponse {
        status: "ok",
        cluster_epoch,
    }))
}

async fn heartbeat_handler(
    State(state): State<AppState>,
    Json(req): Json<HeartbeatRequest>,
) -> impl IntoResponse {
    let HeartbeatRequest { node_id, ts } = req;
    let node_id_trimmed = node_id.trim().to_string();
    if node_id_trimmed.is_empty() {
        return (
            StatusCode::BAD_REQUEST,
            Json(json!({
                "status": "error",
                "code": "BAD_REQUEST",
                "message": "node_id required"
            })),
        );
    }

    let mut nodes = state.nodes.lock().await;
    match nodes.get_mut(&node_id_trimmed) {
        Some(node) => {
            let seen = ts
                .and_then(|v| normalize_optional(Some(v)))
                .unwrap_or_else(|| Utc::now().to_rfc3339());
            node.last_seen = Some(seen);
            drop(nodes);
            {
                let mut hb = state.metrics.heartbeats_total.lock().await;
                *hb += 1;
            }
            (StatusCode::OK, Json(json!({ "status": "ok" })))
        }
        None => {
            tracing::warn!(
                target: "clear_csi.audit",
                "heartbeat rejected for unknown node={}",
                node_id_trimmed
            );
            (
                StatusCode::NOT_FOUND,
                Json(json!({
                    "status":"error",
                    "code":"NODE_NOT_FOUND",
                    "node_id": node_id_trimmed,
                    "message":"heartbeat for unknown node"
                })),
            )
        }
    }
}

async fn leave_handler(
    State(state): State<AppState>,
    Json(payload): Json<LeaveRequest>,
) -> Result<Json<LeaveResponse>, StatusCode> {
    let node_id_trimmed = payload.node_id.trim();
    if node_id_trimmed.is_empty() {
        return Err(StatusCode::BAD_REQUEST);
    }

    let removed = {
        let mut guard = state.nodes.lock().await;
        guard.remove(node_id_trimmed).is_some()
    };

    let epoch = state.cluster_epoch.lock().await.clone();

    Ok(Json(LeaveResponse {
        status: "ok",
        removed,
        cluster_epoch: epoch,
    }))
}

async fn process_map_handler(State(state): State<AppState>) -> Json<ProcessMapResponse> {
    let nodes = {
        let guard = state.nodes.lock().await;
        guard
            .values()
            .map(|node| ProcessEntry {
                node_id: node.node_id.clone(),
                role: node.role.clone(),
                last_seen: node.last_seen.clone(),
                proc_mask: proc_mask_for_role(&node.role),
            })
            .collect::<Vec<_>>()
    };

    Json(ProcessMapResponse {
        status: "ok",
        nodes,
    })
}

async fn load_coins_handler(
    State(state): State<AppState>,
) -> Result<Json<LoadCoinsResponse>, (StatusCode, Json<Value>)> {
    let input_dir = state.coin_input_dir.clone();
    let registry_path = state.coin_registry_path.clone();

    let result = task::spawn_blocking(move || -> Result<CoinLoadOutcome, CoinLoadError> {
        let outcome = load_coin_registry_from_csv(&input_dir)?;
        persist_coin_registry(&registry_path, &outcome.coins)?;
        Ok(outcome)
    })
    .await
    .map_err(|err| {
        error!(
            target: "clear_csi.loader",
            "coin registry loader task join error: {}",
            err
        );
        (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(json!({
                "status": "error",
                "code": "COIN_LOADER_JOIN",
                "message": err.to_string()
            })),
        )
    })?;

    let outcome = match result {
        Ok(outcome) => outcome,
        Err(err) => {
            let (status, payload) = coin_error_response(&err);
            match status {
                StatusCode::BAD_REQUEST => {
                    warn!(
                        target: "clear_csi.loader",
                        "coin registry loader rejected request: {}",
                        err
                    );
                }
                _ => {
                    error!(
                        target: "clear_csi.loader",
                        "coin registry loader failed: {}",
                        err
                    );
                }
            }
            return Err((status, Json(payload)));
        }
    };

    let CoinLoadOutcome { coins, file_count } = outcome;
    let loaded = coins.len();

    {
        let mut registry = state.coin_registry.lock().await;
        registry.update(coins);
    }
    state
        .metrics
        .coins_registered
        .store(loaded as u64, Ordering::Relaxed);
    info!(
        target: "clear_csi.loader",
        "coin registry updated ({} entries)",
        loaded
    );

    Ok(Json(LoadCoinsResponse {
        status: "ok",
        loaded,
        file_count,
    }))
}

async fn healthcheck_handler(
    State(state): State<AppState>,
    Json(payload): Json<HealthcheckRequest>,
) -> Result<Json<HealthcheckResponse>, (StatusCode, Json<Value>)> {
    let serial = payload.serial.trim();
    if serial.is_empty() {
        return Err((
            StatusCode::BAD_REQUEST,
            Json(json!({
                "status": "error",
                "code": "BAD_REQUEST",
                "message": "serial required"
            })),
        ));
    }

    let request_timestamp_raw = payload.request_timestamp.trim();
    if request_timestamp_raw.is_empty() {
        return Err((
            StatusCode::BAD_REQUEST,
            Json(json!({
                "status": "error",
                "code": "BAD_REQUEST",
                "message": "request_timestamp required"
            })),
        ));
    }

    if DateTime::parse_from_rfc3339(request_timestamp_raw).is_err() {
        return Err((
            StatusCode::BAD_REQUEST,
            Json(json!({
                "status": "error",
                "code": "BAD_REQUEST",
                "message": "request_timestamp must be RFC3339"
            })),
        ));
    }

    let now = Utc::now();
    let response_timestamp = now.to_rfc3339_opts(SecondsFormat::Millis, true);
    let uptime_seconds = state.service_started_at.elapsed().as_secs();
    let alerts = collect_alerts(&state.metrics);

    let latest_seen = {
        let nodes = state.nodes.lock().await;
        latest_heartbeat_timestamp(&nodes)
    };
    let heartbeat_delay_ms = latest_seen.map(|seen| {
        let diff = now.signed_duration_since(seen);
        diff.num_milliseconds()
            .max(0)
            .try_into()
            .unwrap_or(u64::MAX)
    });

    let status = determine_status(&alerts, heartbeat_delay_ms).to_string();
    let details = HealthDetails {
        uptime_seconds,
        alerts,
        heartbeat_delay_ms,
    };

    Ok(Json(HealthcheckResponse {
        serial: serial.to_string(),
        request_timestamp: request_timestamp_raw.to_string(),
        response_timestamp,
        status,
        details,
    }))
}

async fn metrics_handler(State(state): State<AppState>) -> impl IntoResponse {
    let (registered, active) = {
        let guard = state.nodes.lock().await;
        let count = guard.len() as u64;
        (count, count)
    };
    let heartbeats = *state.metrics.heartbeats_total.lock().await;
    let threshold_violations = state
        .metrics
        .threshold_violations_total
        .load(Ordering::Relaxed);
    let alerts_emitted = state.metrics.alerts_emitted_total.load(Ordering::Relaxed);
    let coins_registered = state.metrics.coins_registered.load(Ordering::Relaxed);

    let body = format!(
        "# HELP clear_csi_heartbeats_total Total heartbeats accepted\n\
# TYPE clear_csi_heartbeats_total counter\n\
clear_csi_heartbeats_total {}\n\
# HELP clear_csi_nodes_registered Current registered nodes\n\
# TYPE clear_csi_nodes_registered gauge\n\
clear_csi_nodes_registered {}\n\
# HELP clear_csi_nodes_active Current active nodes\n\
# TYPE clear_csi_nodes_active gauge\n\
clear_csi_nodes_active {}\n\
# HELP clear_csi_threshold_violations_total Threshold violations detected\n\
# TYPE clear_csi_threshold_violations_total counter\n\
clear_csi_threshold_violations_total {}\n\
# HELP clear_csi_alerts_emitted_total Alerts emitted to MQ\n\
# TYPE clear_csi_alerts_emitted_total counter\n\
clear_csi_alerts_emitted_total {}\n\
# HELP clear_csi_coins_registered Coins currently registered via loader\n\
# TYPE clear_csi_coins_registered gauge\n\
clear_csi_coins_registered {}\n",
        heartbeats, registered, active, threshold_violations, alerts_emitted, coins_registered
    );

    (
        StatusCode::OK,
        [(header::CONTENT_TYPE, "text/plain; version=0.0.4")],
        body,
    )
}

struct CoinLoadOutcome {
    coins: Vec<String>,
    file_count: usize,
}

#[derive(Debug)]
enum CoinLoadError {
    InputDirNotFound(PathBuf),
    Io(PathBuf, io::Error),
    Csv(PathBuf, csv::Error),
    MissingCoinIdColumn(PathBuf),
    NoCsvFiles(PathBuf),
    Serialize(String),
}

impl std::fmt::Display for CoinLoadError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CoinLoadError::InputDirNotFound(path) => {
                write!(f, "coin input directory not found: {}", path.display())
            }
            CoinLoadError::Io(path, err) => write!(f, "IO error for {}: {}", path.display(), err),
            CoinLoadError::Csv(path, err) => {
                write!(f, "CSV parse error for {}: {}", path.display(), err)
            }
            CoinLoadError::MissingCoinIdColumn(path) => {
                write!(f, "missing COIN-ID column in {}", path.display())
            }
            CoinLoadError::NoCsvFiles(path) => {
                write!(f, "no CSV files found in {}", path.display())
            }
            CoinLoadError::Serialize(msg) => write!(f, "serialization error: {}", msg),
        }
    }
}

fn coin_error_response(err: &CoinLoadError) -> (StatusCode, Value) {
    match err {
        CoinLoadError::MissingCoinIdColumn(path) => (
            StatusCode::BAD_REQUEST,
            json!({
                "status": "error",
                "code": "MISSING_COIN_ID_COLUMN",
                "file": path.display().to_string()
            }),
        ),
        CoinLoadError::NoCsvFiles(path) => (
            StatusCode::BAD_REQUEST,
            json!({
                "status": "error",
                "code": "NO_CSV_FILES",
                "path": path.display().to_string()
            }),
        ),
        CoinLoadError::InputDirNotFound(path) => (
            StatusCode::BAD_REQUEST,
            json!({
                "status": "error",
                "code": "INPUT_DIRECTORY_NOT_FOUND",
                "path": path.display().to_string()
            }),
        ),
        CoinLoadError::Csv(path, err) => (
            StatusCode::BAD_REQUEST,
            json!({
                "status": "error",
                "code": "CSV_PARSE_ERROR",
                "file": path.display().to_string(),
                "message": err.to_string()
            }),
        ),
        CoinLoadError::Io(path, err) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            json!({
                "status": "error",
                "code": "COIN_REGISTRY_IO",
                "path": path.display().to_string(),
                "message": err.to_string()
            }),
        ),
        CoinLoadError::Serialize(message) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            json!({
                "status": "error",
                "code": "COIN_REGISTRY_SERIALIZE",
                "message": message
            }),
        ),
    }
}

fn load_coin_registry_from_csv(input_dir: &Path) -> Result<CoinLoadOutcome, CoinLoadError> {
    if !input_dir.exists() {
        return Err(CoinLoadError::InputDirNotFound(input_dir.to_path_buf()));
    }

    let mut coins = HashSet::new();
    let mut file_count = 0;
    let mut csv_files_found = false;

    let entries =
        fs::read_dir(input_dir).map_err(|err| CoinLoadError::Io(input_dir.to_path_buf(), err))?;
    for entry in entries {
        let entry = entry.map_err(|err| CoinLoadError::Io(input_dir.to_path_buf(), err))?;
        let path = entry.path();
        if !path.is_file() {
            continue;
        }
        if path
            .extension()
            .and_then(|ext| ext.to_str())
            .map(|ext| ext.eq_ignore_ascii_case("csv"))
            .unwrap_or(false)
        {
            csv_files_found = true;
            file_count += 1;
            let mut reader = csv::ReaderBuilder::new()
                .trim(csv::Trim::All)
                .flexible(true)
                .from_path(&path)
                .map_err(|err| CoinLoadError::Csv(path.clone(), err))?;
            let headers = reader
                .headers()
                .map_err(|err| CoinLoadError::Csv(path.clone(), err))?
                .clone();
            let coin_index = find_coin_id_column(&headers)
                .ok_or_else(|| CoinLoadError::MissingCoinIdColumn(path.clone()))?;
            for record in reader.records() {
                let record = record.map_err(|err| CoinLoadError::Csv(path.clone(), err))?;
                if let Some(value) = record.get(coin_index) {
                    let trimmed = value.trim();
                    if !trimmed.is_empty() {
                        coins.insert(trimmed.to_string());
                    }
                }
            }
        }
    }

    if !csv_files_found {
        return Err(CoinLoadError::NoCsvFiles(input_dir.to_path_buf()));
    }

    let mut coins = coins.into_iter().collect::<Vec<_>>();
    coins.sort();
    Ok(CoinLoadOutcome { coins, file_count })
}

fn persist_coin_registry(path: &Path, coins: &[String]) -> Result<(), CoinLoadError> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|err| CoinLoadError::Io(parent.to_path_buf(), err))?;
    }

    let payload = json!({
        "generated_at": Utc::now().to_rfc3339(),
        "total": coins.len(),
        "coins": coins,
    });
    let serialized = serde_json::to_string_pretty(&payload)
        .map_err(|err| CoinLoadError::Serialize(err.to_string()))?;

    fs::write(path, serialized).map_err(|err| CoinLoadError::Io(path.to_path_buf(), err))
}

fn find_coin_id_column(headers: &StringRecord) -> Option<usize> {
    headers.iter().position(|header| header.trim() == "COIN-ID")
}

fn spawn_mq_consumer(state: AppState) {
    let enabled = env::var("CSI_MQ_ENABLED").map(|v| v != "0").unwrap_or(true);
    if !enabled {
        info!(target: "clear_csi.mq", "MQ consumer disabled via CSI_MQ_ENABLED");
        return;
    }

    let mq_url = env::var("CSI_MQ_URL").unwrap_or_else(|_| "nats://127.0.0.1:4222".to_string());
    let subscribe_subject = env::var("CSI_MQ_SUBJECT").unwrap_or_else(|_| "clear.tx".to_string());
    let alert_subject =
        env::var("CSI_MQ_ALERT_SUBJECT").unwrap_or_else(|_| "clear.alert".to_string());

    tokio::spawn(async move {
        match async_nats::connect(&mq_url).await {
            Ok(connection) => {
                info!(
                    target: "clear_csi.mq",
                    "connected to MQ at {} (sub={}, pub={})",
                    mq_url, subscribe_subject, alert_subject
                );
                if let Err(err) =
                    run_mq_loop(state, connection, subscribe_subject, alert_subject).await
                {
                    error!(target: "clear_csi.mq", "MQ loop terminated: {}", err);
                }
            }
            Err(err) => {
                error!(
                    target: "clear_csi.mq",
                    "failed to connect to MQ at {}: {}",
                    mq_url, err
                );
            }
        }
    });
}

async fn run_mq_loop(
    state: AppState,
    connection: Client,
    subscribe_subject: String,
    alert_subject: String,
) -> Result<(), String> {
    let mut subscription = connection
        .subscribe(subscribe_subject.clone())
        .await
        .map_err(|err| format!("subscription error: {}", err))?;

    while let Some(message) = subscription.next().await {
        match serde_json::from_slice::<TransactionEvent>(&message.payload) {
            Ok(event) => {
                if let Err(err) =
                    handle_transaction_event(&state, &connection, &alert_subject, event).await
                {
                    warn!(
                        target: "clear_csi.mq",
                        "failed to handle transaction event: {}",
                        err
                    );
                }
            }
            Err(err) => {
                warn!(
                    target: "clear_csi.mq",
                    "discarding invalid transaction payload: {}",
                    err
                );
            }
        }
    }

    Ok(())
}

#[derive(Debug, Deserialize)]
struct TransactionEvent {
    tx_id: String,
    amount: f64,
    #[serde(default)]
    coin_id: Option<String>,
    #[serde(default)]
    company_id: Option<String>,
    #[serde(default)]
    category: Option<String>,
    #[serde(default)]
    currency: Option<String>,
}

#[derive(Serialize)]
struct AlertMessage {
    tx_id: String,
    severity: &'static str,
    message: String,
    amount: f64,
    threshold: f64,
    #[serde(skip_serializing_if = "Option::is_none")]
    coin_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    company_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    category: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    currency: Option<String>,
    detected_by: &'static str,
}

async fn handle_transaction_event(
    state: &AppState,
    connection: &Client,
    alert_subject: &str,
    event: TransactionEvent,
) -> Result<(), String> {
    if !event.amount.is_finite() || event.amount <= 0.0 {
        warn!(
            target: "clear_csi.mq",
            "ignoring non-positive amount for tx_id={}",
            event.tx_id
        );
        return Ok(());
    }

    let threshold = state.thresholds.resolve(
        event.company_id.as_deref(),
        event.category.as_deref(),
        event.currency.as_deref(),
    );

    if event.amount > threshold {
        state
            .metrics
            .threshold_violations_total
            .fetch_add(1, Ordering::Relaxed);
        let alert = AlertMessage {
            tx_id: event.tx_id.clone(),
            severity: "warning",
            message: format!("Amount {} exceeds threshold {}", event.amount, threshold),
            amount: event.amount,
            threshold,
            coin_id: event.coin_id.clone(),
            company_id: event.company_id.clone(),
            category: event.category.clone(),
            currency: event.currency.clone(),
            detected_by: "CSI-MQ-Analyzer",
        };

        let payload = serde_json::to_vec(&alert)
            .map_err(|err| format!("alert serialization error: {}", err))?;
        connection
            .publish(alert_subject.to_string(), payload.into())
            .await
            .map_err(|err| format!("alert publish error: {}", err))?;
        state
            .metrics
            .alerts_emitted_total
            .fetch_add(1, Ordering::Relaxed);
        info!(
            target: "clear_csi.mq",
            "alert emitted for tx_id={} amount={} threshold={}",
            alert.tx_id, alert.amount, alert.threshold
        );
    }

    Ok(())
}

fn collect_alerts(metrics: &MetricsState) -> Vec<String> {
    let mut alerts = Vec::new();
    let threshold = metrics.threshold_violations_total.load(Ordering::Relaxed);
    if threshold > 0 {
        alerts.push(format!("threshold_violations_total={threshold}"));
    }
    let emitted = metrics.alerts_emitted_total.load(Ordering::Relaxed);
    if emitted > 0 {
        alerts.push(format!("alerts_emitted_total={emitted}"));
    }
    alerts
}

fn latest_heartbeat_timestamp(nodes: &HashMap<String, RegisteredNode>) -> Option<DateTime<Utc>> {
    nodes
        .values()
        .filter_map(|node| node.last_seen.as_deref())
        .filter_map(|ts| DateTime::parse_from_rfc3339(ts).ok())
        .map(|dt| dt.with_timezone(&Utc))
        .max()
}

fn determine_status(alerts: &[String], heartbeat_delay_ms: Option<u64>) -> &'static str {
    if alerts
        .iter()
        .any(|msg| msg.contains("error") || msg.contains("critical"))
    {
        "ERROR"
    } else if !alerts.is_empty() {
        "WARN"
    } else if heartbeat_delay_ms.map_or(false, |delay| delay >= 3_000) {
        "WARN"
    } else {
        "OK"
    }
}

fn init_tracing() {
    let level = env::var("CSI_LOG_LEVEL")
        .unwrap_or_else(|_| "info".into())
        .parse::<Level>()
        .unwrap_or(Level::INFO);

    let subscriber = FmtSubscriber::builder()
        .with_max_level(level)
        .with_target(false)
        .finish();
    let _ = tracing::subscriber::set_global_default(subscriber);
}

async fn shutdown_signal() {
    let _ = tokio::signal::ctrl_c().await;
    info!("received shutdown signal");
}

fn normalize_role(role: &str) -> Option<String> {
    let upper = role.trim().to_uppercase();
    match upper.as_str() {
        "MQ" | "WN" | "DB" | "DBE" | "TAX" | "MULTI" | "KMS" | "TPM" | "CSI" => Some(upper),
        _ => None,
    }
}

fn normalize_optional(value: Option<String>) -> Option<String> {
    value
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
}

fn proc_mask_for_role(role: &str) -> &'static str {
    match role.to_ascii_lowercase().as_str() {
        "mq" => "02",
        "wn" => "04",
        "db" => "08",
        "dbe" => "10",
        "tax" => "20",
        "multi" => "FF",
        _ => "00",
    }
}

fn load_policy() -> Result<(PolicyState, u16), PolicyLoadError> {
    let mut attempted: Vec<PathBuf> = Vec::new();

    if let Some(path) = env::var("CSI_POLICY_PATH").ok().map(PathBuf::from) {
        attempted.push(path.clone());
        if path.exists() {
            return parse_policy(&path);
        }
    }

    for candidate in [
        PathBuf::from("ops/lgwan/port-policy.json"),
        PathBuf::from("/etc/clear/port-policy.json"),
    ] {
        attempted.push(candidate.clone());
        if candidate.exists() {
            return parse_policy(&candidate);
        }
    }

    Err(PolicyLoadError::NotFound(attempted))
}

fn parse_policy(path: &Path) -> Result<(PolicyState, u16), PolicyLoadError> {
    let contents = fs::read_to_string(path)
        .map_err(|err| PolicyLoadError::Io(format!("{}: {}", path.display(), err)))?;

    let raw: RawPolicy =
        serde_json::from_str(&contents).map_err(|err| PolicyLoadError::Parse(err.to_string()))?;

    let profile = raw
        .profiles
        .get(&raw.default_profile)
        .ok_or_else(|| PolicyLoadError::MissingProfile(raw.default_profile.clone()))?;

    if profile.allowed_api_ports.is_empty() {
        return Err(PolicyLoadError::InvalidPolicy(
            "allowed_api_ports may not be empty".into(),
        ));
    }

    let allowed_api_ports: HashSet<u16> = profile.allowed_api_ports.iter().copied().collect();
    let allowed_internal_ports: HashSet<u16> =
        profile.allowed_internal_ports.iter().copied().collect();
    let blacklist_ports: HashSet<u16> = profile.blacklist_ports.iter().copied().collect();

    let mut assignments = HashMap::new();
    for (name, assignment) in &raw.assignments {
        assignments.insert(
            name.clone(),
            Assignment {
                api_port: assignment.api_port,
            },
        );
    }

    let csi_assignment = raw
        .assignments
        .get("clear-csi")
        .ok_or_else(|| PolicyLoadError::MissingAssignment("clear-csi".into()))?;

    if !allowed_api_ports.contains(&csi_assignment.api_port)
        || blacklist_ports.contains(&csi_assignment.api_port)
    {
        return Err(PolicyLoadError::PortViolation(csi_assignment.api_port));
    }

    let policy_state = PolicyState {
        allowed_api_ports,
        blacklist_ports,
        allowed_internal_ports,
        assignments,
    };

    Ok((policy_state, csi_assignment.api_port))
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::{body::Body, http::Request};
    use http_body_util::BodyExt;
    use serde_json::{json, Value};
    use tempfile::tempdir;
    use tower::ServiceExt;

    fn test_state() -> AppState {
        let metrics = Arc::new(MetricsState::new());
        AppState {
            cluster_name: Arc::new(Mutex::new("clear-main".into())),
            cluster_epoch: Arc::new(Mutex::new("E-2".into())),
            nodes: Arc::new(Mutex::new(HashMap::new())),
            policy: Arc::new(PolicyState {
                allowed_api_ports: [8443u16, 9443u16, 9555u16].into_iter().collect(),
                blacklist_ports: HashSet::new(),
                allowed_internal_ports: HashSet::new(),
                assignments: HashMap::new(),
            }),
            thresholds: Arc::new(ThresholdPolicy {
                default_threshold: 1_000_000.0,
                currency_overrides: HashMap::new(),
                categories: HashMap::new(),
                company_overrides: HashMap::new(),
            }),
            metrics,
            coin_registry: Arc::new(Mutex::new(CoinRegistry::default())),
            coin_input_dir: PathBuf::from("ops/input"),
            coin_registry_path: PathBuf::from("var/test_coin_registry.json"),
            service_started_at: Instant::now(),
        }
    }

    #[tokio::test]
    async fn register_heartbeat_leave_flow() {
        let app_state = test_state();
        let app = build_router(app_state.clone());

        // register node
        let req = Request::post("/api/csi/v1/nodes/register")
            .header("content-type", "application/json")
            .body(Body::from(
                json!({
                    "node_id": "node-1",
                    "role": "DBE",
                    "api_port": 9443,
                    "tpm_quote": "q1",
                    "epoch_hint": "E-1"
                })
                .to_string(),
            ))
            .unwrap();
        let resp = app.clone().oneshot(req).await.unwrap();
        assert_eq!(resp.status(), StatusCode::OK);

        // duplicate register with different TPM quote should conflict
        let req = Request::post("/api/csi/v1/nodes/register")
            .header("content-type", "application/json")
            .body(Body::from(
                json!({
                    "node_id": "node-1",
                    "role": "DBE",
                    "api_port": 9443,
                    "tpm_quote": "q2"
                })
                .to_string(),
            ))
            .unwrap();
        let resp = app.clone().oneshot(req).await.unwrap();
        assert_eq!(resp.status(), StatusCode::CONFLICT);

        // heartbeat updates last_seen and increments metrics
        let req = Request::post("/api/csi/v1/nodes/heartbeat")
            .header("content-type", "application/json")
            .body(Body::from(
                json!({
                    "node_id": "node-1",
                    "ts": "2025-11-07T00:00:00Z"
                })
                .to_string(),
            ))
            .unwrap();
        let resp = app.clone().oneshot(req).await.unwrap();
        assert_eq!(resp.status(), StatusCode::OK);

        // unknown heartbeat should return 404 with audit body
        let req = Request::post("/api/csi/v1/nodes/heartbeat")
            .header("content-type", "application/json")
            .body(Body::from(json!({ "node_id": "unknown" }).to_string()))
            .unwrap();
        let resp = app.clone().oneshot(req).await.unwrap();
        assert_eq!(resp.status(), StatusCode::NOT_FOUND);
        let body = resp.into_body().collect().await.unwrap().to_bytes();
        let value: Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(value["code"], "NODE_NOT_FOUND");

        // process map reflects node and proc mask
        let resp = app
            .clone()
            .oneshot(
                Request::get("/api/csi/v1/process/map")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let body = resp.into_body().collect().await.unwrap().to_bytes();
        let value: Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(value["nodes"].as_array().unwrap()[0]["proc_mask"], "10");

        // metrics endpoint returns counters
        let resp = app
            .clone()
            .oneshot(Request::get("/metrics").body(Body::empty()).unwrap())
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let metrics = resp.into_body().collect().await.unwrap().to_bytes();
        let metrics_str = String::from_utf8(metrics.to_vec()).unwrap();
        assert!(metrics_str.contains("clear_csi_heartbeats_total 1"));
        assert!(metrics_str.contains("clear_csi_threshold_violations_total 0"));
        assert!(metrics_str.contains("clear_csi_alerts_emitted_total 0"));
        assert!(metrics_str.contains("clear_csi_coins_registered 0"));

        // leave removes node
        let req = Request::post("/api/csi/v1/nodes/leave")
            .header("content-type", "application/json")
            .body(Body::from(json!({ "node_id": "node-1" }).to_string()))
            .unwrap();
        let resp = app.clone().oneshot(req).await.unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let body = resp.into_body().collect().await.unwrap().to_bytes();
        let value: Value = serde_json::from_slice(&body).unwrap();
        assert!(value["removed"].as_bool().unwrap());

        // status now empty
        let resp = app
            .oneshot(
                Request::get("/api/csi/v1/nodes/status")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let body = resp.into_body().collect().await.unwrap().to_bytes();
        let value: Value = serde_json::from_slice(&body).unwrap();
        assert!(value["nodes"].as_array().unwrap().is_empty());
    }

    #[tokio::test]
    async fn load_coins_requires_coin_id_column() {
        let temp = tempdir().unwrap();
        let invalid_csv = temp.path().join("invalid.csv");
        fs::write(&invalid_csv, "ID,NAME\n1,Alpha\n").unwrap();

        let mut app_state = test_state();
        app_state.coin_input_dir = temp.path().to_path_buf();
        app_state.coin_registry_path = temp.path().join("coin_registry.json");

        let app = build_router(app_state);
        let req = Request::post("/api/csi/v1/load/coins")
            .header("content-type", "application/json")
            .body(Body::empty())
            .unwrap();
        let resp = app.clone().oneshot(req).await.unwrap();
        assert_eq!(resp.status(), StatusCode::BAD_REQUEST);
        let body = resp.into_body().collect().await.unwrap().to_bytes();
        let value: Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(value["code"], "MISSING_COIN_ID_COLUMN");
    }

    #[tokio::test]
    async fn load_coins_success_updates_registry_and_metrics() {
        let temp = tempdir().unwrap();
        let coins_csv = temp.path().join("coins.csv");
        fs::write(&coins_csv, "COIN-ID,NAME\nAAA,Alpha\nBBB,Beta\nAAA,Alpha\n").unwrap();

        let mut app_state = test_state();
        app_state.coin_input_dir = temp.path().to_path_buf();
        app_state.coin_registry_path = temp.path().join("coin_registry.json");

        let app = build_router(app_state);

        let req = Request::post("/api/csi/v1/load/coins")
            .header("content-type", "application/json")
            .body(Body::empty())
            .unwrap();

        let resp = app.clone().oneshot(req).await.unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let body = resp.into_body().collect().await.unwrap().to_bytes();
        let value: Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(value["status"], "ok");
        assert_eq!(value["loaded"], 2);
        assert_eq!(value["file_count"], 1);

        // metrics should reflect coin registry count
        let resp = app
            .clone()
            .oneshot(Request::get("/metrics").body(Body::empty()).unwrap())
            .await
            .unwrap();
        let body = resp.into_body().collect().await.unwrap().to_bytes();
        let metrics_str = String::from_utf8(body.to_vec()).unwrap();
        assert!(metrics_str.contains("clear_csi_coins_registered 2"));

        // registry file written
        let registry_path = temp.path().join("coin_registry.json");
        let registry_contents = fs::read_to_string(&registry_path).unwrap();
        let registry_json: Value = serde_json::from_str(&registry_contents).unwrap();
        assert_eq!(registry_json["total"], 2);
        let coins = registry_json["coins"].as_array().unwrap();
        assert_eq!(coins.len(), 2);
        assert!(coins.iter().any(|v| v == "AAA"));
        assert!(coins.iter().any(|v| v == "BBB"));
    }

    #[tokio::test]
    async fn healthcheck_returns_expected_payload() {
        let state = test_state();
        {
            let mut nodes = state.nodes.lock().await;
            nodes.insert(
                "node-1".into(),
                RegisteredNode {
                    node_id: "node-1".into(),
                    role: "DBE".into(),
                    registered_at: Utc::now().to_rfc3339(),
                    last_seen: Some(Utc::now().to_rfc3339()),
                    tpm_quote: None,
                    epoch_hint: None,
                    api_port: Some(9443),
                },
            );
        }
        let app = build_router(state);
        let req_body = json!({
            "serial": "DG-N-0001",
            "request_timestamp": "2025-11-07T13:30:00.125Z"
        });
        let resp = app
            .oneshot(
                Request::post("/api/csi/v1/healthcheck")
                    .header("content-type", "application/json")
                    .body(Body::from(req_body.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let bytes = resp.into_body().collect().await.unwrap().to_bytes();
        let value: Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(value["serial"], "DG-N-0001");
        assert_eq!(value["request_timestamp"], "2025-11-07T13:30:00.125Z");
        assert_eq!(value["status"], "OK");
        assert!(value["response_timestamp"].as_str().unwrap().contains("T"));
        assert!(value["details"]["uptime_seconds"].as_u64().is_some());
    }

    #[tokio::test]
    async fn healthcheck_rejects_invalid_timestamp() {
        let state = test_state();
        let app = build_router(state);
        let req_body = json!({
            "serial": "DG-N-0001",
            "request_timestamp": "not-a-time"
        });
        let resp = app
            .oneshot(
                Request::post("/api/csi/v1/healthcheck")
                    .header("content-type", "application/json")
                    .body(Body::from(req_body.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::BAD_REQUEST);
    }
}
