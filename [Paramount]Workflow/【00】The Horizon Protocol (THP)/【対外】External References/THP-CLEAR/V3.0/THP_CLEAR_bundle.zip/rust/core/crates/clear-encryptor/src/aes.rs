use aes_gcm::{
    aead::{Aead, AeadCore, KeyInit, OsRng},
    Aes256Gcm, Key, Nonce,
};

const AES_KEY_SIZE: usize = 32;
const AES_NONCE_SIZE: usize = 12;

pub fn seal_aes256_gcm(key: &[u8], plaintext: &[u8]) -> Result<(Vec<u8>, Vec<u8>), &'static str> {
    if key.len() != AES_KEY_SIZE {
        return Err("aes: key must be 32 bytes for AES-256");
    }
    let key: &Key<Aes256Gcm> = key.into();
    let cipher = Aes256Gcm::new(key);

    // Nonce is generated randomly
    let nonce = Aes256Gcm::generate_nonce(&mut OsRng);

    let ciphertext = cipher
        .encrypt(&nonce, plaintext)
        .map_err(|_| "aes: encryption failure")?;

    Ok((nonce.to_vec(), ciphertext))
}

pub fn open_aes256_gcm(
    key: &[u8],
    nonce: &[u8],
    ciphertext: &[u8],
) -> Result<Vec<u8>, &'static str> {
    if key.len() != AES_KEY_SIZE {
        return Err("aes: key must be 32 bytes for AES-256");
    }
    if nonce.len() != AES_NONCE_SIZE {
        return Err("aes: nonce must be 12 bytes for GCM");
    }

    let key: &Key<Aes256Gcm> = key.into();
    let mut nonce_bytes = [0u8; AES_NONCE_SIZE];
    nonce_bytes.copy_from_slice(nonce);
    let nonce = Nonce::from(nonce_bytes);
    let cipher = Aes256Gcm::new(key);

    let plaintext = cipher
        .decrypt(&nonce, ciphertext)
        .map_err(|_| "aes: decryption failure")?;

    Ok(plaintext)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_aes_gcm_round_trip() {
        let key = [42u8; AES_KEY_SIZE];
        let plaintext = b"this is a secret message";

        // Seal
        let (nonce, ciphertext) = seal_aes256_gcm(&key, plaintext).unwrap();

        // Open
        let recovered_plaintext = open_aes256_gcm(&key, &nonce, &ciphertext).unwrap();

        assert_eq!(plaintext.as_ref(), recovered_plaintext.as_slice());
    }

    #[test]
    fn test_open_with_wrong_key() {
        let key1 = [42u8; AES_KEY_SIZE];
        let key2 = [43u8; AES_KEY_SIZE]; // Different key
        let plaintext = b"this is a secret message";

        let (nonce, ciphertext) = seal_aes256_gcm(&key1, plaintext).unwrap();

        // Attempt to open with the wrong key
        let result = open_aes256_gcm(&key2, &nonce, &ciphertext);

        assert!(result.is_err());
    }
}
