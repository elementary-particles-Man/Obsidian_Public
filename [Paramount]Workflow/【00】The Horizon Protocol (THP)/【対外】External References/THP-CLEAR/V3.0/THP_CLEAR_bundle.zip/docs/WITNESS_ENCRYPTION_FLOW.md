# Witness Encryption and Ingestion Flow

This document defines the post-processing pipeline that converts plaintext witness logs into encrypted envelopes.

1. **Encryptor (encrypt-witness)** reads `witness/logs/*.log` and wraps each record into a Rust-backed `crypto.Envelope`. The envelope now contains the key epoch, ISE ordering flags, AES-GCM nonce/ciphertext, SHA-256 hashes of the plain and cipher payloads, plus the Commit/Operational HMAC signatures emitted by the pipeline.
2. **Ingest Daemon (ingestd)** monitors `witness/logs/` for new `.log` files, runs encryption if needed, and pushes the envelopes into the DB (`witness_envelopes`). The SQLite table acts as a *hot cache / rendezvous buffer* for SSD-friendly seeks; the append-only JSONL under `witness/logs/` remains the canonical source of truth referenced by audits.
3. **Retention Policy**
   - Plain logs: 7–30 days in `witness/logs`
   - Encrypted envelopes: 7 years in DB (`witness_envelopes`)
   - Archive rotation: `witness/archive/YYYYMM/`
4. **E2E Validation**: `go test -run TestWitnessIngestE2E` verifies envelope integrity, hash match, and DB persistence. `go test ./src/common/kmsclient` executes a Rust FFI seal/open round-trip.
5. **DB Replication (v2.2)**: `replicator_v2` exchanges resealed chunks between DB nodes using the KMS triple-key window (Current / Old1 / Old2). Each chunk performs **AES decrypt → GZIP decompress → TPM ISE decrypt → TPM ISE re-encrypt → GZIP compress → AES reseal**, tracks a Merkle root, and zeros plaintext buffers before leaving scope. Receivers request a resend when all three keysets fail.

The flow ensures plaintext never leaves the node, replicated payloads stay consistent across key rotations, and all persisted records are AEAD-sealed with per-record SHA-256 signatures.
