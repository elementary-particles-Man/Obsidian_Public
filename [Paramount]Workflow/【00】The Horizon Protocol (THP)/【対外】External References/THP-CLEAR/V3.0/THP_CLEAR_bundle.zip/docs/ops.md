# Operations Procedures
## KPI / Monitoring
`thp_clear_api_requests_total{path,method,status}`: API traffic

`thp_clear_api_latency_seconds`: Latency (maintain p95 within 1 second)

`thp_clear_commands_issued_total`, `thp_clear_commands_settled_total`: Daily monitoring

Witness update rate: Periodically get `/witness?limit=` and check if there are any updates that have not been made across days. **JSONL (`internal/adapters/witness/file_writer.go`) is the canonical source**, while SQLite `witness_envelopes` functions as the hot cache for fast queries and ingestion spooling.

KeyHub / Witness / E-MAD メトリクス:
- `keyhub_sign_total`, `keyhub_epoch_current` (署名頻度と現在エポック)
- `witness_append_total`, `witness_verify_success` (WORM 追記と検証成功数)
- `emad_score_average` (統合テストから報告される平均 E-MAD スコア)

Grafana テンプレート: `dashboards/keyhub_witness_ops.json`, `dashboards/e20_emad_overview.json`

## KMS / Node Operations
### Audit Log (JSONL)
KMS appends to `/var/log/clear/kms_audit.jsonl` (permission 600). Records events such as `key_request` / `key_respond` / `spy_alert_emit` and the `kid` of the `sig_bundle`.

The MQ node appends to `/var/log/clear/mq-audit.jsonl`, WN to `/var/log/clear/wn-audit.jsonl`, and DB to `/var/log/clear/db-audit.jsonl`. The success/failure of `key_fetch`, the applied epoch, and SPY reception are left in one line of JSON.

In the event of a failure (if file generation fails), an error will be output to the daemon log, so use systemd journal monitoring as well. Rotation is set by size/daily with logrotate.

The signed SHA256SUMS (`dist/SHA256SUMS`) also follows the same storage policy and is backed up daily.

### Prometheus Metrics
KMS: `http://kms:9100/metrics` (when TLS is enabled, `curl -k https://kms:9100/metrics`). The main counters are `kms_keyreq_total{node}`, `kms_challenge_fail_total{node}`, `kms_decoy_issued_total{node}`, `kms_spy_alert_total{level}`, `kms_rate_limited_total{node}`.

Node: The `metrics.listen` port is different for each role (MQ:9201 / DB:9202 / WN:9203). Monitor `node_key_fetch_total{status}`, `node_key_ticket_fail_total{reason}`, `node_spy_alert_total{level}`.

Example: `sum(rate(kms_keyreq_total[5m]))` for the key request frequency in the last 5 minutes, `max_over_time(node_key_ticket_fail_total{reason="decoy"}[1h])` to detect a sudden increase in ticket failures.

SLO guideline: "Key request success rate 99.9% / 5 minutes", "429 response rate < 1% / 1 hour", "SPY(block) 0 per month (= anomaly detection)". Trigger Pager when violated.

Grafana panel example: E/E-1/E-2 decryption ratio (DB ingestor metrics), 429/min, SPY level histogram, delta of `kms_rate_limited_total`.

### Rate Control
If `ratelimit.per_node_per_min` and `burst` are exceeded, `/keys/request` returns `429 Too Many Requests` and presents `Retry-After`.

If verification fails on the same node more than `block_after_fails`, it automatically broadcasts `SPY_ALERT(level=block)` and temporarily isolates it on the KMS side.

The node side suppresses `EnsureEpoch` according to `spy_warn_backoff_sec` / `block_ttl_sec`. The alert is POSTed as JSON to the `/control/spy` endpoint.

At the initial launch, relax `per_node_per_min` (e.g., 6→12) and tighten it after confirming stability. When adjusting, check the change in `status=rate_limited` in the audit log.

### TLS Certificate/CRL
All KMS/node communication is TLS1.3+mTLS. The certificate validity period is recommended to be 90 days or less, and automatic renewal is performed 30 days in advance with reference to `docs/ops.md#TLS`.

When introducing CRL or OCSP Stapling, distribute it together with the update of `tls.ca` of KMS, and check the reflection on the node with `journalctl`.

The secret key rotation is in the order of "distribute new certificate → operate in parallel → revoke old certificate". The `certs/` directory maintains `root:clear owning 0600`.

### KMS Quorum Key Rotation
Register at least 3 signers to maintain a 2-of-3 signature bundle. Rotation is performed in the following order.

1. Generate a new signer's private key/public key and add it to `signers` in `configs/kms.yaml` and `kms.signers` of the node.
2. Restart KMS sequentially to expand the quorum (3→4).
3. Check that the new kid appears in the `kids` of the `key_request` in the audit log.
4. Remove the old signer from `configs` and restart, and also clean up the public key on the node side.

Maintain `threshold=2` during the rotation period. In case of an emergency withdrawal, audit whether the target signature is used with `sig_bundle.Contains(kid)`.

### Management of Sensitive Information
Instead of embedding it in plain text in `configs/*.yaml`, prioritize environment variables such as `THPCLEAR_DB_DSN` `THPCLEAR_KEY_PATH`, and use the value of YAML only when it is not specified.

In Docker Compose, it is recommended to use the `secrets:` function referenced by `docker compose config --profiles prod` instead of `.env`, and in Kubernetes, it is recommended to mount the Secret as a `ProjectedVolume`.

Please consider as a first candidate a configuration in which the signing key is generated by KMS/HSM and only the handle for delegation is passed to the CLEAR side.

### Daily Operations
- Create a quantity summary from the Witness log by 20:00 JST
- Check the expiration of the blacklist (those with `expires_at` < now are automatically released)
- Create a difference report of the account balance and collate it with the funding layer

### Failure Response Runbook
| Scenario | Detection Method | Isolation | Recovery Command / Procedure | Escalation |
|---|---|---|---|---|
| API response stop | `thp_clear_api_latency_seconds` surges / `/healthz` returns 500 | Check the process status with `systemctl status clear-api` or `docker compose logs`. Check the integrity of the latest Witness log. | 1) Restart with `systemctl restart clear-api` or `docker compose restart`. <br> 2) Immediately after restarting, check `/healthz` and `/metrics`. | Operations team → Development team |
| DB corruption/unbootable | `thp_clear_api_latency_seconds` surges / `/healthz` returns 500 / `database disk image is malformed` in SQLite log | Check with the result of `sqlite3 data/clear.db "PRAGMA integrity_check;"`. If a storage failure is suspected, check the host's `dmesg`. | 1) Switch to the latest hot backup: `sqlite3 data/clear.db ".recover" > /tmp/recover.sql` for a logical dump → import to a new file. <br> 2) Reconstruct with the `witness_replay` tool from Witness JSONL. <br> 3) Run `make itest` after recovery to verify integrity. | Notify in the order of DB team (on-call) → infrastructure team → product owner. |
| Witness log inconsistency / append failure | The audit job reports a hash difference between JSONL and SQLite / `thp_clear_witness_append_fail_total` increases | Run `scripts/check_witness_integrity` to identify which block the difference occurred in. If it is already recorded in the DB, manually add it to JSON Lines and audit the hash integrity. | 1) Evacuate the difference section locally and regenerate with `witness_replay --from <seq>`. <br> 2) Recalculate the signature hash and redistribute it to the audit node. <br> 3) Pause the MQ queue (`nats stream pause witness`) to prevent re-inflow. | Immediate contact with the security team and audit team. |
| Signing key leak | `kms_spy_alert_total{level="block"}` of KMS increases / Incident contact from the certificate authority | Wash out the usage history of the target kid in the audit log. Cut out the same kid section in the Witness log. | 1) Invalidate the key in KMS and issue a new key pair. <br> 2) Update `crypto.key_path` in `configs/*.yaml` and `systemctl restart clear-api`. <br> 3) Isolate and save the Witness of the old key section with the `Compromised` tag. | Immediate report to CISO / legal affairs. In some cases, disclose to the regulatory authority within 24 hours. |
| SPY(block) detection | `node_spy_alert_total{level="block"}` increases / reception log of `/control/spy` | Check the IP and timestamp of the Blocked node. Match it with the KMS audit log to identify an illegal request pattern (e.g., continuous challenge failure). | 1) Check the reception log of `/control/spy` and record the recovery timeline (`block_ttl_sec`) of the Blocked node. <br> 2) Manually retry `nodeauth.Manager` after investigating the cause. | Security operations team → Incident response team |
| KMS node stop drill (periodic verification) | (Planned test) | Check that the monitoring alert is triggered normally. Check with the audit log that the quorum (2-of-3) is maintained and the signature bundle is continuously generated. | 1) Stop one KMS node. <br> 2) Check that the key request continues to be processed normally. <br> 3) Return the node and check that it is resynchronized with the cluster. | (Periodic report only) |

### Backup
SQLite DB gets a hot copy (`.backup`) every 15 minutes.

Witness JSON Lines is append-only, so it is stored in multiple layers with `rsync`.

It is recommended to back up the signing key to KMS/HSM + a physically sealed medium.

KMS audit log / node audit / `dist/SHA256SUMS` are uploaded to S3 etc. daily. Assuming RPO 15 minutes and RTO 30 minutes, the recovery procedure is made into a Runbook.

Recovery test: Monthly, verify `dist/SHA256SUMS` → expand binary → re-run `go test ./...` to confirm that the same build can be reproduced reliably.
