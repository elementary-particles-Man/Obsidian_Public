# THP-CLEAR Design Overview

## Architecture Policy

- **Progressive division starting from a single binary**: Currently, `cmd/clear-api` handles API, queue integration, and Witness generation in a single process. In the future, if latency requirements or organizational structure change, the code is modularized into use case units under `internal/` so that it can be migrated to a microservice configuration where `cmd/mqd`, `cmd/wnd`, and `cmd/dbd` are deployed individually and integrated with gRPC + NATS.
- **Layer separation**: The Port/Adapter pattern is adopted to explicitly define Layer0 (Account)/Layer1 (Command)/Layer2 (Matching)/Layer3 (Witness) and prevent each layer from directly accessing other layers.
- **Public auditability**: Witness logs are basically duplicated in SQLite and JSON Lines, and continuity is guaranteed by leaving `kid` in the log even when the signing key is rotated.

When choosing to use microservices, the following responsibilities are assumed.

| Service | Responsibility | Communication | Discovery |
|---|---|---|---|
| `mqd` | Receives encrypted commands from the API and relays them to the NATS subject. Holds KeyRing and rate control. | REST → NATS | Static configuration (`configs/mq.yaml`) + Introduce Consul/etcd in the future |
| `wnd` | Monitors the horizontal layer and blockchain RPC, and constructs a Witness payload from the confirmed transaction. | NATS → gRPC | Heartbeat on NATS channel |
| `dbd` | Verifies the signature of the Witness payload, decrypts the ISE, and writes to SQLite/external DB. | gRPC → SQL | Kubernetes Service / Static IP |

Even if a single binary (`clear-api`) is maintained, the responsibilities in the table above are cut out as packages, so placeholders such as `cmd/mqd` that are no longer needed can be deleted in the migration phase. The PoC under `src/` is a template for the cryptographic workflow and storage that should be referenced during the split migration.

## Layer Configuration

THP-CLEAR consists of the following four layers.

1. **Layer0 (Currency I/O)**: Centered on yen-based accounts, other currencies are connected as horizontal mirrors.
2. **Layer1 (Command)**: Payment commands with F/M/E (Food/Medicine/Energy) purpose tags.
3. **Layer2 (Matching)**: Normalizes and executes commands while absorbing buyer/seller choices.
4. **Layer3 (Witness)**: Publicly discloses quantity logs protected by hash chains and signatures in an append-only manner.

Each layer corresponds to the following roles in the Go service.

| Layer | Implementation Component |
|---|---|
| Layer0 | Account table (balance management) in `internal/adapters/sqlite` |
| Layer1 | Command issuance and settlement logic in `internal/domain.Service` |
| Layer2 | `/command` `/settle` API provided by `internal/httpapi` |
| Layer3 | Witness log (SQLite + `internal/adapters/witness` file output) |

## Payment Command Data Flow

```mermaid
sequenceDiagram
    participant C as Client (Operator UI)
    participant API as clear-api
    participant MQ as Message Queue
    participant WN as Worker Node
    participant DB as DB Adapter
    participant WL as Witness Log

    C->>API: POST /command
    API->>API: Domain validation<br/>Balance/purpose tag check
    API->>MQ: Publish encrypted Envelope
    MQ-->>API: Ack + Trace ID
    MQ->>WN: Envelope Dispatch (NATS)
    WN->>WN: ISE decryption / EVM finality confirmation
    WN->>DB: Witness Payload (gRPC)
    DB->>DB: Signature verification / Transaction update
    DB->>WL: JSON Lines Append + SQLite insert
    DB-->>API: Success response
    API-->>C: 202 Accepted
```

- **Asynchronous processing**: The API returns 202 when the Envelope is queued. The progress is queried from `/command/{id}` with the trace ID.
- **Consistency model**: The Command table and Witness log are updated in the same transaction. If the DB write fails, a retry request is returned to the MQ and the Envelope is redelivered.
- **Retry strategy**: The MQ retransmits up to 5 times with exponential backoff. If the EVM finality is not confirmed, the WN returns a Nack to NATS with `Retry-After`.
- **Rollback**: If the DB write fails, the SQLite transaction is rolled back and not appended to the Witness file. If the file append fails, it tries to append again as a compensation process, and if it finally fails, it sends an alert and switches to manual recovery.

## Persistence/Data Model

- **accounts**: Account ID / Display name / Currency / Balance / Status
- **commands**: Command ID / Account ID / Amount / Purpose tag / Status / Witness hash
- **blacklist**: Account ID / Reason / Expiration / active flag
- **witness_entries**: Quantity log with hash chain and signature

The database is SQLite using the `modernc.org/sqlite` module. Since it can be distributed as a single binary, it is suitable for emergency deployment.

## Horizontal Layers

`src/WN/e20` is a PoC implementation for incorporating token transfers that occurred on an EVM-compatible chain into the balance of Layer0.

- **Role of Worker Node**: Connects to the RPC endpoint through `e20.Adapter` to confirm the finality of the transaction hash (`Confirmed`) and acquire the `Transfer` event.
- **Connection method**: Specify HTTPS RPC or WebSocket RPC in `configs/wn.yaml`. The Adapter has a chain ID and block depth, and can make finality confirmation variable.
- **Finality confirmation**: Waits until the Depth (e.g., 12 blocks) is exceeded, and if a Reorg is detected, queries `Confirmed` again and aborts.
- **Balance reflection**: After confirmation, stores `source_tx`, `token_address`, `amount`, and `recipient_account` in the Witness payload and posts it to the DB.

In the future, you can add horizontal layers by implementing the Adapter interface.

## Domain Service

`internal/domain.Service` centrally manages payment commands and Witness processing.

- Issues commands after checking the balance, account status, and blacklist.
- At settlement, the Witness payload is converted to JSON → hashed with SHA-256 → signed with Ed25519.
- Atomically executes Command update + Witness addition in a DB transaction.
- The file writer appends with JSON Lines in a WORM-like manner.

## Monitoring and Operation

- `pkg/monitor` provides Prometheus metrics (number of requests, latency, number of commands).
- Exposes API `/healthz` and a separate port `/metrics`. Restart monitoring is possible with systemd, etc.
- Witness logs and signing keys are saved under `./data/` (the path can be changed in the settings).
