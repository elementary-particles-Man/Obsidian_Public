運用手順
KPI / モニタリング
thp_clear_api_requests_total{path,method,status}: API トラフィック

thp_clear_api_latency_seconds: レイテンシ (p95 を 1 秒以内に維持)

thp_clear_commands_issued_total, thp_clear_commands_settled_total: 日量監視

Witness 更新率: /witness?limit= を定期取得し、日跨ぎで未更新がないか確認

KMS / ノード運用
監査ログ (JSONL)
KMS は /var/log/clear/kms_audit.jsonl に追記（権限 600）。key_request / key_respond / spy_alert_emit などのイベントと sig_bundle の kid を記録。

MQ ノードは /var/log/clear/mq-audit.jsonl、WN は /var/log/clear/wn-audit.jsonl、DB は /var/log/clear/db-audit.jsonl に追記。key_fetch の成否・適用したエポック・SPY 受信を JSON1行で残す。

障害時（ファイル生成に失敗した場合）は daemon ログへエラーが出るため、systemd ジャーナルの監視を併用する。ローテーションは logrotate でサイズ/日次を設定。

署名済み SHA256SUMS（dist/SHA256SUMS）も同じ保管ポリシーに従い日次バックアップする。

Prometheus メトリクス
KMS: http://kms:9100/metrics（TLS 有効時は curl -k https://kms:9100/metrics）。主要カウンタは kms_keyreq_total{node}, kms_challenge_fail_total{node}, kms_decoy_issued_total{node}, kms_spy_alert_total{level}, kms_rate_limited_total{node}。

ノード: 各ロールで metrics.listen ポートが異なる（MQ:9201 / DB:9202 / WN:9203）。node_key_fetch_total{status}, node_key_ticket_fail_total{reason}, node_spy_alert_total{level} を監視する。

例: sum(rate(kms_keyreq_total[5m])) で直近5分の鍵リクエスト頻度、max_over_time(node_key_ticket_fail_total{reason="decoy"}[1h]) でチケット失敗急増を検出。

SLO 目安: 「鍵要求成功率 99.9% / 5分」「429 応答率 < 1% / 1時間」「SPY(block) 月次0件（=異常検知）」。違反時は Pager を発火させる。

Grafana パネル例: E/E-1/E-2 復号比率（DB ingestor メトリクス）、429/分、SPY レベル別ヒストグラム、kms_rate_limited_total のデルタ。

レート制御
ratelimit.per_node_per_min と burst を超えると /keys/request は 429 Too Many Requests を返し Retry-After を提示。

同一ノードで検証失敗が block_after_fails を超えると自動で SPY_ALERT(level=block) をブロードキャストし、KMS 側でも一時隔離する。

ノード側は spy_warn_backoff_sec / block_ttl_sec に従い EnsureEpoch を抑制。アラートは /control/spy エンドポイントに JSON として POST される。

初期ローンチ時は per_node_per_min を緩和（例: 6→12）し、安定を確認後に引き締める。調整時は監査ログで status=rate_limited の変化を確認する。

TLS 証明書・CRL
すべての KMS/ノード通信は TLS1.3+mTLS。証明書有効期限は 90 日以下を推奨し、docs/ops.md#TLS を参照しながら 30 日前に自動更新を実行。

CRL もしくは OCSP Stapling を導入する場合は KMS の tls.ca 更新と合わせて配布し、ノードでの反映を journalctl で確認。

秘密鍵のローテは「新証明書配布 → 並行稼働 → 旧証明書失効」の順。certs/ ディレクトリは root:clear owning 0600 を維持。

KMS クォーラム鍵ローテ
2-of-3 の署名束を維持するため、最低 3 名の signer を登録。ローテは次の順序で実施する。

新 signer の秘密鍵/公開鍵を生成し、configs/kms.yaml の signers とノードの kms.signers に追加。

KMS を順次再起動してクォーラムを拡張（3→4）。

監査ログで key_request の kids に新 kid が出現することを確認。

旧 signer を configs から削除し再起動、ノード側の公開鍵も片付ける。

ローテ期間中は threshold=2 を維持。緊急撤退時は sig_bundle.Contains(kid) で対象署名が使われていないか監査する。

機微情報の管理
configs/*.yaml に平文で埋め込むのではなく、THPCLEAR_DB_DSN THPCLEAR_KEY_PATH などの環境変数を優先し、未指定の場合のみ YAML の値を使います。

Docker Compose では .env ではなく docker compose config --profiles prod で参照される secrets: 機能、Kubernetes では Secret を ProjectedVolume としてマウントする構成を推奨します。

署名鍵は KMS/HSM で生成し、CLEAR 側にはデリゲーション用のハンドルのみ渡す構成を第一候補に検討してください。

日次オペレーション
20:00 JST までに Witness ログから数量集計を作成

ブラックリストの期限切れ確認 (expires_at < now は自動解除)

口座残高の差分レポートを作成し、資金供給レイヤと照合

障害対応ランブック
シナリオ

検知方法

切り分け

復旧コマンド / 手順

エスカレーション

API 応答停止

thp_clear_api_latency_seconds が急増 / /healthz が 500 を返す

systemctl status clear-api や docker compose logs でプロセス状態を確認。直近の Witness ログの整合性をチェック。

1) systemctl restart clear-api または docker compose restart で再起動。
2) 再起動後、直ちに /healthz と /metrics を確認。

運用チーム → 開発チーム

DB 破損・起動不可

thp_clear_api_latency_seconds が急増 / /healthz が 500 を返す / SQLite ログで database disk image is malformed

sqlite3 data/clear.db "PRAGMA integrity_check;" の結果で確認。ストレージ障害が疑われる場合はホストの dmesg を確認。

1) 最新ホットバックアップに切替: sqlite3 data/clear.db ".recover" > /tmp/recover.sql で論理ダンプ → 新ファイルにインポート。
2) Witness JSONL から witness_replay ツールで再構築。
3) 復旧後に make itest を実行して整合性検証。

DB チーム（オンコール）→ インフラチーム → プロダクト責任者の順で通知。

Witness ログ不整合 / 追記失敗

監査ジョブが JSONL と SQLite のハッシュ差異を報告 / thp_clear_witness_append_fail_total が増加

scripts/check_witness_integrity を実行し、差異がどのブロックで発生したか特定。DBに記録済みの場合は手動でJSON Linesに補記しハッシュ整合性を監査。

1) 差異区間をローカルに退避し、witness_replay --from <seq> で再生成。
2) 署名ハッシュを再計算し、監査ノードに再配布。
3) MQ キューを一時停止 (nats stream pause witness) して再流入を防止。

セキュリティチームと監査チームへ即時連絡。

署名鍵漏洩

KMS の kms_spy_alert_total{level="block"} が増加 / 認証局からインシデント連絡

監査ログで対象 kid の使用履歴を洗い出す。Witness ログで同 kid 区間を切り出し。

1) KMS で鍵を無効化し、新しい鍵ペアを発行。
2) configs/*.yaml の crypto.key_path を更新し、systemctl restart clear-api. 
3) 旧鍵区間の Witness を Compromised タグ付きで隔離保存。

CISO / 法務へ即時報告。場合によっては規制当局へ 24h 以内に開示。

SPY(block) 検出

node_spy_alert_total{level="block"} が増加 / /control/spy の受信ログ

Blocked ノードのIPとタイムスタンプを確認。KMS監査ログと突き合わせ、不正なリクエストパターン（例：連続チャレンジ失敗）を特定。

1) /control/spy の受信ログを確認し、Blocked ノードの復旧タイムライン（block_ttl_sec）を記録。
2) 原因調査後に nodeauth.Manager を手動で再試行。

セキュリティ運用チーム → インシデントレスポンスチーム

KMS ノード停止ドリル（定期検証）

(計画されたテスト)

監視アラートが正常に発火することを確認。クォーラム（2-of-3）が維持され、署名束が継続して生成されることを監査ログで確認。

1) 1台のKMSノードを停止。
2) 鍵要求が正常に処理され続けることを確認。
3) ノードを復帰させ、クラスタに再同期されることを確認。

(定期レポートのみ)

バックアップ
SQLite DB は 15 分間隔でホットコピー（.backup）を取得。

Witness JSON Lines は append-only なので rsync で多重保管。

署名鍵は KMS/HSM へのバックアップ + 物理封印媒体を推奨。

KMS 監査ログ / ノード audit / dist/SHA256SUMS は日次で S3 等へアップロード。RPO 15 分、RTO 30 分を想定し復旧手順を Runbook 化。

復旧テスト: 月次で dist/SHA256SUMS の検証→バイナリ展開→go test ./... を再実行し、確実に同じビルドが再現できることを確認。