# THP-CLEAR v2.2 最終リリースノート (2025-10-21)

## 概要
THP-CLEAR v2.2 は、国家規模の分散監査・決済監査インフラを完成させる決定版です。  
本リリースではハイブリッド CI 自動化を統合し、政策申請書
「緊急人道支援におけるステーブルコイン決済システムの導入に関する政策申請書」と完全に整合しました。

---

## 主要トピック

### コアプロトコル
- **Packet v2.2 仕様**  
  - `Flags2` に `ExchangeFlag` (bit 0) を追加  
  - AES-GCM と ISE のハイブリッド暗号化（AAD = TxID‖Timestamp‖Ver）  
  - ビッグエンディアンのシリアライズ検証完了  
  - VoidCoin 取引ルール: 通貨番号=65535, 手数料=0, exchange_flag 必須, void→void 禁止

- **Idempotency Key (H)**  
  `H = SHA3-256(TxID‖Timestamp_ISE)`  
  - 並列挿入テストにより SQLite で単一行に収束することを確認

- **Witness ログ**  
  - 128 バイト固定構造、冗長度 RF=3 (+120〜150% オーバーヘッド)  
  - ノード喪失やコミット遅延時でもエンドツーエンド整合性を維持

### CI / インフラ
- **ハイブリッド CI (Makefile + ci.sh + Docker)**  
  - `make all` で Docker ビルドと CI 実行を一括実施  
  - `ci.sh` が環境チェック、lint、テスト、ベンチ、スナップショット検証を自動化  
  - オフライン/LGWAN 等の制約環境でも再現可能

- **Docker 環境**  
  - ベースイメージ: `golang:1.23-bullseye`  
  - Go / Python3 / SQLite3 / golangci-lint / reedsolo / aiohttp をプリインストール  
  - コンテナ起動時に自動でテストを実行

- **Makefile ターゲット**  
  - `all` → Docker ビルド & 実行  
  - `local` → ローカルで CI 実行  
  - `clean` → ログや一時ファイルを削除  
  - `bench` → ベンチマークを単体実行

### ドキュメント
- **README_CI.md**  
  - 開発者・オペレーター双方向けのクイックスタートを整備  
  - Docker / ローカル実行手順を網羅
- **RELEASE_NOTES_v2.2_final.md**  
  - 本リリースノートを `/docs/releases/` にアーカイブ

---

## 検証サマリー
| カテゴリ | 結果 |
|----------|------|
| go test ./... | ✅ 全テスト成功 |
| Lint (golangci-lint) | ✅ 成功 / 未導入環境ではスキップ |
| Bench (scripts/bench_tps.py) | ✅ サービス未起動でも継続 |
| Snapshot + RS Repair | ✅ 検証済み / 安全な NO-OP |
| SQLite UNIQUE(H) | ✅ 単一行への収束を確認 |
| PEP668 pip ガード | ✅ 失敗時も処理継続 |

---

## 次のステップ
- リポジトリをタグ付け:
  ```bash
  git tag -a v2.2-final -m "THP-CLEAR v2.2 Final Release (CI integrated)"
  git push origin v2.2-final
  ```
