# THP-CLEAR Docker Operations Guide

Last updated: 2025-10-30

This guide explains the minimal Docker workflow for THP-CLEAR, from image builds to pushing images to a registry.
It is written for engineers who are new to Docker and uses explicit commands plus short explanations.

---

## 1. Prerequisites

- Docker & Docker Compose v2 installed
- Permissions to run `docker build` / `docker push`
- Optional: logged in (`docker login`) to the registry you plan to push to

---

## 2. Building Images

Run from the repository root. You can pass `IMAGE_TAG` (default: `local`).

```bash
make docker-build IMAGE_TAG=v0.1.0
```

Internally this is equivalent to:

```bash
docker build -t thp-clear:v0.1.0 .
```

To change the image name:

```bash
make docker-build IMAGE_NAME=thp-clear-api IMAGE_TAG=latest
```

---

## 3. Local Execution (docker compose)

Use the provided Make targets:

```bash
make docker-up       # docker compose up --build -d
make docker-logs     # Tail container logs
make docker-down     # Stop / remove containers
```

The compose file now builds the multi-stage image (target `runtime`) and provisions persistent named volumes for data, logs, and keys. To run without the Make wrapper:

```bash
docker compose up --build -d
docker compose logs -f
# When finished
docker compose down
```

Volumes created automatically:

- `thpclear-data` → `/var/thpclear/data`
- `thpclear-logs` → `/var/thpclear/logs`
- `thpclear-keys` → `/var/thpclear/keys`

Configuration within the container defaults to `/app/configs/docker.yaml`.

---

## 4. Pushing to a Registry

1. Log in to the registry (example: GitHub Container Registry).
   ```bash
   docker login ghcr.io
   ```
2. Build and push:
   ```bash
   make docker-push REGISTRY=ghcr.io/your-org IMAGE_TAG=v0.1.0
   ```
   This performs:
   - `docker build -t thp-clear:v0.1.0 .`
   - `docker tag thp-clear:v0.1.0 ghcr.io/your-org/thp-clear:v0.1.0`
   - `docker push ghcr.io/your-org/thp-clear:v0.1.0`
3. Pull and run:
   ```bash
   docker pull ghcr.io/your-org/thp-clear:v0.1.0
   docker run --rm -p 8080:8080 ghcr.io/your-org/thp-clear:v0.1.0
   ```

---

## 5. FAQ

### Q1. `make docker-push` fails.
- Ensure `REGISTRY` is set (e.g. `REGISTRY=registry.example.com/team`).
- Authenticate with `docker login` if required.

### Q2. `docker compose up` reports port conflicts.
- `docker-compose.yml` exposes `8080` and `9100`. Edit `ports` or override them as needed.

### Q3. Build cache needs to be disabled.
- Run `DOCKER_BUILDKIT=1 docker build --no-cache -t thp-clear:dev .` directly instead of `make docker-build`.

---

## 6. References

- `Dockerfile`: production API container definition
- `docker-compose.yml`: exposes API (8080) and Prometheus metrics (9100)
- `Makefile`: contains all commands used in this guide (`make -n <target>` shows the underlying command)
