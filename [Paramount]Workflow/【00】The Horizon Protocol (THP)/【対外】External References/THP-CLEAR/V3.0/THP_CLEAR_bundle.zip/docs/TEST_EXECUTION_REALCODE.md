# THP-CLEAR RealCode System Testing Guide

This guide describes how to execute the integrated THP-CLEAR / CLEAR-TAX system tests using the production code paths.

## 1. Environment Preparation
```powershell
cd U:\Develop\THP-CLEAR
$env:CGO_ENABLED = '1'
$env:PATH = "$env:USERPROFILE\.cargo\bin;U:\Develop\THP-CLEAR\rust\core\target\debug;C:\ProgramData\mingw64\mingw64\bin;$env:PATH"
```

## 2. Data Sets
The following files are used to drive the scenarios:
- `tests/data/vendors_full.json`
- `tests/data/transactions_full.json`
- `tests/data/expected_outputs.json`

## 3. Manual Execution
```powershell
pwsh -ExecutionPolicy Bypass -File tests/system/run_system_tests.ps1
pwsh -ExecutionPolicy Bypass -File tests/system/verify_system_tests.ps1
```

## 4. Codex Automation
To run the same workflow through Codex CLI, reference the bundled pipeline JSON:
```powershell
codex exec -C U:\Develop\THP-CLEAR -c task='@./tests/system/codex_full_pipeline.json'
```

## 5. Review Artifacts
- `tests/output/go_test_output.log`
- `tests/output/systemtest_witness.log`
- `tests/output/witness_log_index.txt`
- `tests/output/invoice_index.txt`
- `tests/output/error_summary.log`

## 6. Success Criteria
Validate the conditions defined in `tests/system/success_criteria.json` (pass rate, witness hash integrity, absence of unexpected errors, etc.) to confirm completion.
