# THP-CLEAR Docker 運用ガイド

最終更新日: 2025-10-30

THP-CLEAR を Docker / Docker Compose で取り扱うための最小限の手順をまとめています。ビルドからコンテナ起動、レジストリへの push までを順を追って説明します。

---

## 1. 前提条件

- Docker / Docker Compose v2 がインストール済み
- `docker build` / `docker push` を実行できる権限
- （任意）利用するレジストリに `docker login` 済み

---

## 2. イメージのビルド

リポジトリ直下で以下を実行します。`IMAGE_TAG` を指定するとタグを付与できます（未指定時は `local`）。

```bash
make docker-build IMAGE_TAG=v0.1.0
```

内部的には下記を実行しています。

```bash
docker build -t thp-clear:v0.1.0 .
```

イメージ名を変更したい場合は `IMAGE_NAME` を併用してください。

```bash
make docker-build IMAGE_NAME=thp-clear-api IMAGE_TAG=latest
```

---

## 3. ローカル実行（docker compose）

API サービスをコンテナ上で起動する場合は以下の Make ターゲットを利用できます。

```bash
make docker-up       # docker compose up --build -d
make docker-logs     # コンテナログを追尾
make docker-down     # コンテナ停止・削除
```

`docker-compose.yml` は multi-stage ビルドの `runtime` ターゲットを利用し、データ／ログ／キー用の名前付きボリュームを自動で割り当てます。Make ターゲットを使わずに手動で操作する場合は次のコマンドを参考にしてください。

```bash
docker compose up --build -d
docker compose logs -f
# 停止する場合
docker compose down
```

作成される主なボリュームとコンテナ内パス:

- `thpclear-data` → `/var/thpclear/data`
- `thpclear-logs` → `/var/thpclear/logs`
- `thpclear-keys` → `/var/thpclear/keys`

コンテナ内のデフォルト設定ファイルは `/app/configs/docker.yaml` に配置されています。

---

## 4. レジストリへの Push

1. 利用するレジストリにログインします（例: GitHub Container Registry）。
   ```bash
   docker login ghcr.io
   ```
2. `REGISTRY` と `IMAGE_TAG` を指定して push します。
   ```bash
   make docker-push REGISTRY=ghcr.io/your-org IMAGE_TAG=v0.1.0
   ```
   上記では以下の処理を順番に実行しています。
   - `docker build -t thp-clear:v0.1.0 .`
   - `docker tag thp-clear:v0.1.0 ghcr.io/your-org/thp-clear:v0.1.0`
   - `docker push ghcr.io/your-org/thp-clear:v0.1.0`
3. pull して実行する例:
   ```bash
   docker pull ghcr.io/your-org/thp-clear:v0.1.0
   docker run --rm -p 8080:8080 ghcr.io/your-org/thp-clear:v0.1.0
   ```

---

## 5. よくある質問 (FAQ)

### Q1. `make docker-push` が失敗します。
- `REGISTRY` が指定されているか確認してください（例: `REGISTRY=registry.example.com/team`）。
- 必要であれば `docker login` を再実行してください。

### Q2. `docker compose up` でポート競合が発生します。
- `docker-compose.yml` では `8080` / `9100` を公開しています。必要に応じて `ports` セクションを書き換えてください。

### Q3. ビルドキャッシュを無効にしたいです。
- `make docker-build` を使わず、直接 `DOCKER_BUILDKIT=1 docker build --no-cache -t thp-clear:dev .` を実行してください。

---

## 6. 参照情報

- `Dockerfile`: 本番用 API コンテナの定義（Go + multi-stage ビルド）
- `docker-compose.yml`: API（8080）と Prometheus メトリクス（9100）を公開
- `Makefile`: 本ガイドで紹介したターゲットをまとめています（`make -n <target>` で実コマンドを確認可能）
