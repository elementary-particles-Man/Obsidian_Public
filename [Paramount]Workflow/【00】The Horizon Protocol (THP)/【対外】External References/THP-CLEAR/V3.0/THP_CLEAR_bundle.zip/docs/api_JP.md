# API 仕様

ベースURLに対して以下のエンドポイントを提供します。エラー時は原則 `application/json` で `{ "error": "message" }` を返します。

## POST `/command`

- **用途**: F/M/E タグ付きの決済命令を発行。残高から即時控除。
- **リクエスト**

```json
{
  "account_id": "acct-1",
  "amount": 1200,
  "currency": "JPY",
  "purpose": "F",
  "metadata": {
    "supplier": "Example Co"
  },
  "reference": "optional-reference"
}
```

- **レスポンス例 (201)**

```json
{
  "id": "cmd-uuid",
  "account_id": "acct-1",
  "amount": 1200,
  "currency": "JPY",
  "purpose": "F",
  "status": "pending",
  "requested_at": "2025-01-01T00:00:00Z"
}
```

- **代表エラー**: `404 account not found`, `422 invalid input`, `403 account blacklisted`, `423 account frozen`。

## GET `/command/{id}`

- **用途**: 命令の現在ステータス確認。
- **レスポンス**: `POST /command` と同型（`settled_at` `quantity` `unit` `witness_hash` などが付与される場合あり）。

## POST `/settle`

- **用途**: 命令を数量確定し Witness ログを生成。
- **リクエスト**

```json
{
  "command_id": "cmd-uuid",
  "quantity": 42.5,
  "unit": "t",
  "metadata": {
    "origin": "Yokohama",
    "destination": "Manila"
  }
}
```

- **レスポンス例 (200)**

```json
{
  "command": { "id": "cmd-uuid", "status": "settled", "witness_hash": "..." },
  "witness": {
    "id": 15,
    "command_id": "cmd-uuid",
    "hash": "...",
    "previous_hash": "...",
    "recorded_at": "2025-01-01T00:05:00Z",
    "payload": {
      "command_id": "cmd-uuid",
      "quantity": 42.5,
      "unit": "t"
    }
  }
}
```

- **代表エラー**: `404 command not found`, `409 command already settled`, `422 invalid input`。

## GET `/witness?limit=50`

- **用途**: 最新 Witness ログを時系列降順で取得。
- **レスポンス**: Witness エントリ配列（署名は Base64）。

## 管理系エンドポイント (`/admin`)

### POST `/admin/accounts`

- 口座を新規登録または更新。
- リクエスト：`{ "id", "display_name", "currency", "balance", "status" }`
- レスポンス：登録済み口座情報。

### POST `/admin/blacklist`

- ブラックDBへ登録。
- リクエスト：`{ "account_id", "reason", "expires_at" }` (`expires_at` は RFC3339, 任意)。
- レスポンス：`{"status":"ok"}`。

### DELETE `/admin/blacklist/{account_id}`

- 指定口座のブラック登録を解除。
- レスポンス：`{"status":"ok"}`。

## ヘルス/監視

- `GET /healthz` : API サーバ生存確認。
- 別ポート `/metrics` : Prometheus 互換メトリクス (`thp_clear_*`)。
