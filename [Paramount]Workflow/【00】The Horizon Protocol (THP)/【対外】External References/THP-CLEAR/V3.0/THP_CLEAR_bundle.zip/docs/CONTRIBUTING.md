# CONTRIBUTING

Thank you for your interest in contributing to THP-CLEAR. This guide is intended to provide a consistent development flow, from bug reporting to creating pull requests and coding conventions.

## Bug Reporting

1. Check [GitHub Issues](https://github.com/elementary-particles-Man/THP-CLEAR/issues) and search for existing tickets.
2. When creating a new report, please follow the template below.
   - Summary of the phenomenon that occurred
   - Steps to reproduce (commands and settings used)
   - Expected and actual results
   - Attachments such as logs and metrics (mask sensitive information)
3. For sensitive information such as security incidents or key leaks, please report it by encrypted email to the security@ domain, not in the issues.

## Branching

- `main`: Always maintain a deployable state. Direct pushes are prohibited as it is a protected branch.
- `feature/<topic>`: New features or major improvements.
- `fix/<topic>`: Bug fixes.
- `docs/<topic>`: Documentation maintenance. Please create a dedicated branch for large updates like this one.

## Coding Conventions

- Conforms to Go's standard formatter (`gofmt`) and linter (`golangci-lint`).
- Package structure:
  - The entry point for the application is `cmd/<binary>/main.go`
  - Domain logic is placed in `internal/` and imports from outside are prohibited.
  - Reusable common processing goes to `pkg/`.
- Error handling:
  - Classify using `errors.Is/As` and wrap the context with `%w`.
  - When outputting logs, use a structured logger and do not output personal information.
- Testing:
  - Describe the intent of the scenario in comments in the test file.
  - Add the `//go:build integration` tag to integration tests.

## Pull Requests

1. Run `go test ./...` and make sure all tests are successful.
2. Consider whether it is necessary to reflect the changes in README or docs.
3. Describe the summary, test results, and related Issues according to the PR template.
4. We recommend responding to reviewer feedback within 2 business days.
5. After the review is passed, perform a squash merge to organize the commit history.

## Version Control

- Releases are managed with `vX.Y.Z` tags, and the differences are added to `CHANGELOG.md`.
- Changes that break API compatibility will be accompanied by a minor or higher version upgrade.
- After deployment, monitor the Witness log and metrics for 24 hours to check for regressions.

## Communication

- Daily discussions are held on the `#thp-clear-dev` channel on Slack.
- For specification changes or major architecture discussions, please add the decisions to `docs/ADR`.

Thank you for your cooperation. Let's build a secure payment network together while maintaining transparency and consistency.
