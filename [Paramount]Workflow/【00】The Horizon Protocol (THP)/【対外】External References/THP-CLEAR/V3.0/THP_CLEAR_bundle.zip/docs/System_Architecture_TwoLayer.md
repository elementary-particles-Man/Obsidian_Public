# System Architecture (Two-Layer Model)

```
      ┌───────────────────────────────┐
      │           THP-CLEAR           │
      │ Witness / MQ / DB-E / KMS     │
      │ Policy / PeppolLink           │
      └──────────────┬────────────────┘
                     │  mTLS / JSON API
      ┌──────────────┴────────────────┐
      │          CLEAR-TAX            │
      │ Tax Ledger / Invoice DB (AES) │
      │ AI-TAX Engine / UI / CSV      │
      └───────────────────────────────┘
```

- 証跡は CLEAR 層、詳細は TAX 層で保持。
- 双方 Prometheus 監視統合。