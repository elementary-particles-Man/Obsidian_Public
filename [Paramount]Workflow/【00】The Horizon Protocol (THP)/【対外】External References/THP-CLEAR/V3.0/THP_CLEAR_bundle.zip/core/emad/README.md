# E-MAD Core Specification

E-MAD (Ethical Monitoring & Anomaly Detection) quantifies whether command settlements comply with humanitarian constraints (e.g., E20 relief flows). The Go layer currently exposes gauges through `internal/monitoring.Exporter` and integration tests in `tests/e20_integration_test.go`. This document defines the Rust contract.

## Functional Scope

- Accept settlement context (quantity/unit, external references, blockchain finality flags).
- Compute a violation score in the range `[0,1]` where 0 = no violation.
- Surface the score to the Go metrics sink so Prometheus gauge `emad_violation_score` reflects the latest measurement.
- Provide optional explanations to be embedded into the Witness payload metadata (e.g., `emad_score`, `e20_tx`).

## Input Envelope (draft)

```c
typedef struct {
    double quantity;
    const char* unit;           // UTF-8, null-terminated
    const char* external_ref;   // e.g., E20 tx hash
    bool finalized;             // horizontal layer finality
    double previous_score_avg;  // optional, 0 if unused
} thp_emad_context;
```

## Output Contract

```c
typedef struct {
    double score;       // 0.0 (best) to 1.0 (worst)
    bool violation;     // true if score exceeds configured threshold
    char explanation[128]; // optional human-readable note
    int32_t status;     // 0 success, >0 error (e.g., input invalid)
} thp_emad_result;

int thp_emad_evaluate(const thp_emad_context* ctx, thp_emad_result* out);
```

The Go integration will call `SetEMADViolationScore` on the shared `monitoring.Exporter` to push the resulting score into Prometheus (`internal/monitoring/exporter.go`).

## Alignment with Go Implementation

- The integration test `tests/e20_integration_test.go` seeds a mock E20 adapter and expects `exporter.SetEMADViolationScore(mock.Score())` to update the gauge. Rust must drive the same hook once the calculation completes.
- Witness metadata should include `emad_score` to keep auditing parity with the Go flow.
- Error handling follows Go conventions: invalid input -> `ErrInvalidInput` equivalent propagated back to the API via domain service.

## Telemetry & Thresholds

- Thresholds are defined in `ops/kpi/README.md` (see "E-MAD Monitoring" section). The Rust module should expose configuration knobs so SRE can tune alert levels without recompiling.
- For DR drillbacks, the module must support deterministic replays given the same context (no RNG).

By capturing the scoring semantics here, the Rust implementation can be reviewed independently and still guarantee the Go observability surface remains unchanged.
