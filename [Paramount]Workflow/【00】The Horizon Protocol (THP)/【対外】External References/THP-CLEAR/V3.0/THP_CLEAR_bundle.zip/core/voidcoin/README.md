# VoidCoin Core Specification

The VoidCoin module validates and decrypts high-security payment envelopes before they enter the Witness chain. The current Go reference is `src/WN/processor_v2.go`; this document translates the behaviour into a Rust-ready contract.

## Processing Pipeline

1. **Packet structure** – Input must match `model.PacketTotalSize`. The header CRC is verified before decryption (`packet.ValidateCRC`).
2. **Preview decrypt** – AES-CTR decrypt of the header exposes `tx_id`, `timestamp`, and `version`. The module rejects packets whose version does not match `model.PacketVersion`.
3. **AES-GCM decrypt** – Using the 12-byte IV and AES-256 key, decrypt the ciphertext + tag with associated data derived from the preview (`buildAAD`).
4. **Signature validation** – If management or payment public keys are present, verify Ed25519 signatures over the plaintext body (`crypto.VerifyEd25519`).
5. **VoidCoin policy enforcement** – Apply `VoidRules`:
   - Currency number must match.
   - Fee must equal the configured zero-fee value.
   - Exchange flag must be set, and either sender or receiver must belong to the exchange node set.
   - If `ForbidVoidToVoid` is true, disallow exchange-to-exchange transfers.
6. **Witness preparation** – Produce a `model.WitnessRecord128` with the sequence number and OK flag, mirroring `model.WitnessFromPacket`.

## Inputs

```c
typedef struct {
    const uint8_t* packet_bytes; // length = model.PacketTotalSize
    size_t packet_len;
    uint8_t aes_key[32];
    const uint8_t* mgmt_pubkey; // optional (32 bytes) or NULL
    const uint8_t* pay_pubkey;  // optional (32 bytes) or NULL
    uint64_t seq_no;
    uint16_t currency_num;
    int32_t fee_minor;
    const uint64_t* exchange_node_ids;
    size_t exchange_node_count;
    bool forbid_void_to_void;
} thp_voidcoin_input;
```

## Outputs

```c
typedef struct {
    uint8_t body[model.PacketBodySize]; // serialized PacketBody
    size_t body_len;
    uint8_t witness[model.WitnessRecordSize];
    size_t witness_len;
    int32_t status; // 0 success, non-zero error code (align with errVoid*)
} thp_voidcoin_output;
```

Error codes should map to the existing Go errors (`errVoidCurrencyMismatch`, `errVoidFeeInvalid`, `errVoidExchangeRequired`, `errVoidExchangeToExchange`, `errHeaderMalformed`, `errVersionMismatch`).

## Deterministic Behaviour

- IV counter handling uses CTR with counter initialised to `IV || 0x00000002`; reproducing this is necessary to match the preview decrypt semantics.
- Associated data is a 17-byte buffer of `tx_id`, `timestamp`, and `version` in big endian (`buildAAD`).
- Idempotency hash validation must reject packets whose body control hash does not match `PacketBody.IdempotencyHash()`.

## Integration Points

- Sequence numbers and witness metadata must line up with `Store.RecordSettlement` so the Witness chain remains consistent.
- Policy configuration is sourced from Go configs (`ProcessRequest.VoidRules`). The Rust ABI should accept simple arrays so Go can marshal maps into vectors easily.
- Telemetry hooks propagate to `internal/monitoring.Exporter` once Rust emits verification results.

By documenting the exact cryptographic steps and policy checks, the Rust implementation can be certified against the same regression suite that currently validates the Go processor.
