# Witness Core Specification

The Witness core is responsible for constructing the append-only hash chain that certifies every settled command. The Go implementation lives in `internal/domain` and `internal/adapters/witness`, and this document freezes the behaviour for the upcoming Rust port.

## Responsibilities

1. **Payload construction** – Convert the `domain.Command` and settlement input into a canonical JSON payload (Go: `buildWitnessPayload`).
2. **Hash chaining** – Concatenate the previous hash with the new payload, hash with SHA-256, and persist the resulting hexadecimal digest (`domain.Service.SettleCommand`).
3. **Signing** – Sign the digest using Ed25519 and attach the signature and public key to the `domain.WitnessEntry` (Signer interface).
4. **Persistence** – Append entries to both the SQL store (`internal/adapters/sqlite`) and the JSONL file writer (`internal/adapters/witness.FileWriter`).
5. **Metrics** – Emit Prometheus counters/histograms via `internal/monitoring.Exporter` (`ObserveWitnessAppend`, `ObserveWitnessLatency`).

## Data Contracts

| Field | Description | Source |
| --- | --- | --- |
| `command_id` | UUID generated during `IssueCommand` | `domain.Service.IssueCommand` |
| `payload` | JSON Lines encoded witness payload (UTF-8) | `buildWitnessPayload` |
| `hash` | Hex string of SHA-256 digest over `previous_hash || payload` | `SettleCommand` |
| `previous_hash` | Latest hash from store, empty string if none | `Store.LatestWitnessHash` |
| `signature` | Ed25519 signature bytes | `Signer.Sign` |
| `recorded_at` | UTC timestamp (RFC3339Nano) | `Service.now()` |

The JSONL representation used by `FileWriter.Append` must remain stable so audit tooling can replay logs across language implementations.

## Rust FFI Contract (draft)

```c
// Inputs mirror domain.SettleCommand requirements.
typedef struct {
    const uint8_t* payload_json;
    size_t payload_len;
    const uint8_t* prev_hash_hex; // ASCII hex, length 64 or 0
    const uint8_t* signer_sk;     // 64-byte Ed25519 secret key
    uint64_t recorded_at_ns;      // UnixNano UTC
} thp_witness_input;

typedef struct {
    uint8_t hash_hex[64];
    uint8_t signature[64];
    uint8_t payload_digest[32];
    int32_t status; // 0=ok, non-zero=error code
} thp_witness_output;

int thp_witness_build(const thp_witness_input* in, thp_witness_output* out);
```

Go wrappers are expected to translate between `domain.SettleCommandInput` and the FFI struct, preserving the same hash and signature as the current Go path.

## Testing Requirements

- Extend `tests/e20_integration_test.go` to compare Go-generated witness entries with Rust-generated ones once available.
- Include deterministic fixtures (sample commands, expected hash/signature) under `core/witness/testdata/` (to be added) for regression.
- Fail the build if Rust results diverge from Go when `-tags rustcore` is enabled.

## Operational Hooks

- Witness append success increments `witness_append_total`; verification success/failure increments `witness_verify_{success,failed}_total` (`internal/monitoring/exporter.go`).
- File appends are flushed to disk via `fd.Sync()` ensuring WORM semantics for DR recovery (`internal/adapters/witness/file_writer.go`).

The Rust module must honour the exact payload layout and hashing rules described above so that regulatory audits can cross-verify Witness chains regardless of implementation language.
