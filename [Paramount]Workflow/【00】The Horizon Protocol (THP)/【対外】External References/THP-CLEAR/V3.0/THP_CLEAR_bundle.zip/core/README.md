# THP-CLEAR Core Modules (Rust Specification Layer)

## Overview

The `core/` directory defines the specification contract for the three Rust modules that will back the high-assurance features of THP-CLEAR while the Go surface remains the operational entry point. Each module pairs with an existing Go PoC under `src/` and `internal/` until the Rust implementation is introduced. The objectives are:

- Provide a stable ABI for Go ↔ Rust integration through cgo bindings.
- Document the stateful artifacts (Witness log, VoidCoin packets, E-MAD scoring) that must remain compatible across language boundaries.
- Describe fallbacks and test fixtures so that DR rehearsals can compare Go outputs with Rust outputs deterministically.

| Module | Responsibility | Go Reference (current PoC) | Rust Deliverable |
| --- | --- | --- | --- |
| [`witness/`](witness/README.md) | Hash-chained quantity log generation, Ed25519 signing, append-only persistence | `internal/domain`, `internal/adapters/witness` | Static library exporting Witness build/verify APIs |
| [`voidcoin/`](voidcoin/README.md) | VoidCoin packet decryption, rule enforcement, witness metadata extraction | `src/WN/processor_v2.go` | Rust AES-GCM + policy engine callable from Go | 
| [`emad/`](emad/README.md) | Ethical Monitoring & Anomaly Detection (E-MAD) scoring and Prometheus feed | `internal/monitoring`, `tests/e20_integration_test.go` | Deterministic scoring engine with FFI-friendly structs |

The Rust implementation will mirror the data contracts defined in Go (`internal/domain/types.go`, `src/model`), guaranteeing that a Witness record produced by either language yields identical hashes and signatures.

## Directory Guide

- `witness/README.md`: ABI, payload schema, and signing workflow. Includes test vectors that must pass on both Go and Rust implementations.
- `voidcoin/README.md`: Describes packet header validation, AES-GCM decryption, and policy hooks (exchange nodes, fee enforcement).
- `emad/README.md`: Details the scoring envelope shared with the operations KPI exporter and how to surface gauges via Prometheus.
- `ffi/` *(planned)*: Shared C header files once Rust artifacts are produced. Go modules will import this package to bind against the Rust core.

## FFI Design Principles

1. **Versioned ABI**: Each module publishes a semantic version. Breaking changes require synchronized bumps in both Rust crate tags and Go `internal` consumers.
2. **Zero-copy payloads**: Witness payloads and VoidCoin packets are exchanged as byte slices; ownership stays with Go, and Rust only borrows via `const uint8_t*` pointers to avoid extra allocations.
3. **Deterministic hashing**: Hash and signature helpers must produce identical outputs to Go's `sha256.Sum256` and `crypto/ed25519`. Integration tests (`tests/e20_integration_test.go`) remain the oracle.
4. **Observability**: Rust modules emit counters/gauges via a lightweight C ABI that forwards to Go's `monitoring.Exporter`, ensuring Prometheus names stay consistent (`witness_append_total`, `emad_violation_score`).

## Migration Path

1. **Specification freeze**: Update the docs in this directory (and linked module READMEs) to match the Go PoC behaviour. Approved signatures become the contract.
2. **Rust implementation**: Develop the crates with the same structs and encode/decode rules. Provide C headers and static archives.
3. **Binding rollout**: Introduce Go wrappers under `internal/crypto` or new packages that call into `core/ffi`. Toggle with build tags until Rust is the default.
4. **Parity testing**: Extend `tests/` to execute both Go and Rust paths (using `-tags rustcore`) and compare Witness hashes, VoidCoin rule verdicts, and E-MAD scores.

This directory intentionally remains documentation-first until the Rust crates are added. Keeping the contracts explicit enables DR teams to validate that future Rust releases preserve the guarantees already proven with the Go implementation.
