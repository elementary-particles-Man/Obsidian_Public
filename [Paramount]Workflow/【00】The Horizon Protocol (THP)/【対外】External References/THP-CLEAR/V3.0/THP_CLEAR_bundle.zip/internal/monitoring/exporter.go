package monitoring

import (
	"sync"
	"time"

	"github.com/prometheus/client_golang/prometheus"
)

// MetricsSink はドメイン層から監視メトリクスを報告するためのインターフェース。
type MetricsSink interface {
	ObserveWitnessAppend()
	ObserveWitnessVerification(success bool)
	ObserveWitnessLatency(d time.Duration)
	SetEMADViolationScore(score float64)
}

// Exporter はKeyHub / Witness / E-MAD 各層のKPIをPrometheusへ公開する。
type Exporter struct {
	witnessAppend        prometheus.Counter
	witnessVerifySuccess prometheus.Counter
	witnessVerifyFailure prometheus.Counter
	witnessLatency       prometheus.Histogram
	emadScore            prometheus.Gauge
}

// NewExporter を生成し、Prometheusのデフォルトレジストリへ登録する。
func NewExporter() *Exporter {
	registerOnce.Do(func() {
		prometheus.MustRegister(
			exporterSingleton.witnessAppend,
			exporterSingleton.witnessVerifySuccess,
			exporterSingleton.witnessVerifyFailure,
			exporterSingleton.witnessLatency,
			exporterSingleton.emadScore,
		)
	})
	return exporterSingleton
}

var (
	registerOnce      sync.Once
	exporterSingleton = &Exporter{
		witnessAppend: prometheus.NewCounter(prometheus.CounterOpts{
			Name: "witness_append_total",
			Help: "Number of witness entries appended to WORM storage",
		}),
		witnessVerifySuccess: prometheus.NewCounter(prometheus.CounterOpts{
			Name: "witness_verify_success_total",
			Help: "Successful witness verification operations",
		}),
		witnessVerifyFailure: prometheus.NewCounter(prometheus.CounterOpts{
			Name: "witness_verify_failed_total",
			Help: "Failed witness verification operations",
		}),
		witnessLatency: prometheus.NewHistogram(prometheus.HistogramOpts{
			Name:    "witness_verify_latency_seconds",
			Help:    "Latency for witness settlement operations",
			Buckets: prometheus.DefBuckets,
		}),
		emadScore: prometheus.NewGauge(prometheus.GaugeOpts{
			Name: "emad_violation_score",
			Help: "Latest E-MAD violation score reported by integration tests",
		}),
	}
)

// ObserveWitnessAppend はWitness追記の成功をカウントする。
func (e *Exporter) ObserveWitnessAppend() {
	e.witnessAppend.Inc()
}

// ObserveWitnessVerification はWitness検証結果をカウントする。
func (e *Exporter) ObserveWitnessVerification(success bool) {
	if success {
		e.witnessVerifySuccess.Inc()
	} else {
		e.witnessVerifyFailure.Inc()
	}
}

// ObserveWitnessLatency はWitness処理レイテンシを記録する。
func (e *Exporter) ObserveWitnessLatency(d time.Duration) {
	e.witnessLatency.Observe(d.Seconds())
}

// SetEMADViolationScore はE-MAD違反スコアを更新する。
func (e *Exporter) SetEMADViolationScore(score float64) {
	e.emadScore.Set(score)
}

// WitnessAppendCounter はテスト用に内部カウンタを公開する。
func (e *Exporter) WitnessAppendCounter() prometheus.Counter {
	return e.witnessAppend
}

// WitnessVerifySuccessCounter はテスト用アクセサ。
func (e *Exporter) WitnessVerifySuccessCounter() prometheus.Counter {
	return e.witnessVerifySuccess
}

// WitnessVerifyFailureCounter はテスト用アクセサ。
func (e *Exporter) WitnessVerifyFailureCounter() prometheus.Counter {
	return e.witnessVerifyFailure
}

// WitnessLatencyHistogram はテスト用アクセサ。
func (e *Exporter) WitnessLatencyHistogram() prometheus.Histogram {
	return e.witnessLatency
}

// EMADScoreGauge はテスト用アクセサ。
func (e *Exporter) EMADScoreGauge() prometheus.Gauge {
	return e.emadScore
}
