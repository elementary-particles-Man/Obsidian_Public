package config

import (
	"errors"
	"fmt"
	"io"
	"net/url"
	"os"
	"strings"

	"gopkg.in/yaml.v3"
)

// Config はアプリケーション設定。
type Config struct {
	App struct {
		Name          string `yaml:"name"`
		Environment   string `yaml:"environment"`
		ListenAddress string `yaml:"listen_address"`
	} `yaml:"app"`

	Database struct {
		Driver string `yaml:"driver"`
		DSN    string `yaml:"dsn"`
	} `yaml:"database"`

	Witness struct {
		LogPath    string `yaml:"log_path"`
		PublishURL string `yaml:"publish_url"`
	} `yaml:"witness"`

	Crypto CryptoConfig `yaml:"crypto"`

	Monitoring struct {
		PrometheusPort int `yaml:"prometheus_port"`
	} `yaml:"monitoring"`
}

type CryptoConfig struct {
	KeyPath string       `yaml:"key_path"`
	KeyHub  KeyHubConfig `yaml:"keyhub"`
}

type KeyHubConfig struct {
	Mode          string `yaml:"mode"`
	Endpoint      string `yaml:"endpoint"`
	EpochSeconds  int    `yaml:"epoch_seconds"`
	MasterSeedRef string `yaml:"master_seed_ref"`
	AuditPath     string `yaml:"audit_path"`
}

// Load は指定パスから設定を読み込む。
func Load(path string) (*Config, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	data, err := io.ReadAll(f)
	if err != nil {
		return nil, err
	}

	var cfg Config
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		return nil, err
	}

	if err := cfg.validate(); err != nil {
		return nil, err
	}
	return &cfg, nil
}

func (c *Config) validate() error {
	if c.App.ListenAddress == "" {
		c.App.ListenAddress = "127.0.0.1:8080"
	}
	if c.Monitoring.PrometheusPort == 0 {
		c.Monitoring.PrometheusPort = 9100
	}
	if c.Database.DSN == "" {
		return errors.New("database.dsn is required")
	}
	if c.Crypto.KeyPath == "" {
		return errors.New("crypto.key_path is required")
	}
	if err := c.Crypto.KeyHub.normalize(); err != nil {
		return err
	}
	if c.Witness.LogPath == "" {
		return errors.New("witness.log_path is required")
	}
	return nil
}

func (k *KeyHubConfig) normalize() error {
	if k == nil {
		return nil
	}
	if k.Mode == "" {
		k.Mode = "internal"
	}
	k.Mode = strings.ToLower(k.Mode)
	switch k.Mode {
	case "internal", "external":
	default:
		return fmt.Errorf("crypto.keyhub.mode must be 'internal' or 'external', got %q", k.Mode)
	}
	if k.EpochSeconds <= 0 {
		k.EpochSeconds = 600
	}
	if k.Endpoint == "" {
		if k.Mode == "internal" {
			k.Endpoint = "http://127.0.0.1:9108"
		}
	}
	if k.Endpoint != "" {
		if _, err := url.Parse(k.Endpoint); err != nil {
			return fmt.Errorf("invalid crypto.keyhub.endpoint: %w", err)
		}
	}
	return nil
}
