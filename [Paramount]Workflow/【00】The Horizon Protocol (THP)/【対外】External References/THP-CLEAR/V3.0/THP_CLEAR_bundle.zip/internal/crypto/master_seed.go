package crypto

import (
	"crypto/ed25519"
	"errors"
	"fmt"
	"log"
	"strings"
)

// LoadMasterSeed は masterSeedRef に基づき KeyHub のマスターシードを取得する。
// ref が空の場合、fallback を利用する。取得できなければエラー。
func LoadMasterSeed(masterSeedRef string, fallback []byte) ([]byte, error) {
	var seed []byte
	var err error

	ref := strings.TrimSpace(masterSeedRef)
	switch {
	case strings.HasPrefix(ref, "tpm://"):
		seed, err = LoadTPMSeed(ref)
		if err != nil {
			log.Printf("[WARN] LoadTPMSeed failed: %v", err)
		}
	case ref == "" && len(fallback) >= ed25519.SeedSize:
		seed = make([]byte, ed25519.SeedSize)
		copy(seed, fallback[:ed25519.SeedSize])
	default:
		err = fmt.Errorf("unsupported master_seed_ref %q", masterSeedRef)
	}

	if len(seed) >= ed25519.SeedSize {
		return seed[:ed25519.SeedSize], nil
	}

	if len(fallback) >= ed25519.SeedSize {
		out := make([]byte, ed25519.SeedSize)
		copy(out, fallback[:ed25519.SeedSize])
		return out, nil
	}

	if err != nil {
		return nil, err
	}
	return nil, errors.New("master seed not available")
}
