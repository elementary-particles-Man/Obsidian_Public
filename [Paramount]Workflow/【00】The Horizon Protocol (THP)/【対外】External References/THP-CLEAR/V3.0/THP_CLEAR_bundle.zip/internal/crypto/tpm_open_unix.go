//go:build !windows

package crypto

import (
	"io"

	"github.com/google/go-tpm/legacy/tpm2"
)

func openTPM(device string) (io.ReadWriteCloser, error) {
	return tpm2.OpenTPM(device)
}
