package crypto

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

type keyHubSignRequest struct {
	PayloadHash string `json:"payload_hash"`
	Epoch       int64  `json:"epoch,omitempty"`
}

type keyHubSignResponse struct {
	Sig    string `json:"sig"`
	PubKey string `json:"pubkey"`
	Epoch  int64  `json:"epoch"`
}

type keyHubPubResponse struct {
	PubKey string `json:"pubkey"`
	Epoch  int64  `json:"epoch"`
}

// KeyHubSign は KeyHub の /internal/kms/sign エンドポイントを呼び出し署名を取得する。
func KeyHubSign(endpoint string, payload []byte) ([]byte, []byte, int64, error) {
	endpoint = strings.TrimSuffix(strings.TrimSpace(endpoint), "/")
	if endpoint == "" {
		return nil, nil, 0, fmt.Errorf("keyhub endpoint is empty")
	}

	req := keyHubSignRequest{PayloadHash: hex.EncodeToString(payload)}
	body, err := json.Marshal(req)
	if err != nil {
		return nil, nil, 0, fmt.Errorf("encode request: %w", err)
	}

	client := &http.Client{Timeout: 2 * time.Second}
	resp, err := client.Post(endpoint+"/internal/kms/sign", "application/json", bytes.NewReader(body))
	if err != nil {
		return nil, nil, 0, fmt.Errorf("post to keyhub: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		msg, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
		return nil, nil, 0, fmt.Errorf("keyhub sign status %d: %s", resp.StatusCode, strings.TrimSpace(string(msg)))
	}

	var out keyHubSignResponse
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return nil, nil, 0, fmt.Errorf("decode keyhub sign response: %w", err)
	}

	sig, err := hex.DecodeString(out.Sig)
	if err != nil {
		return nil, nil, 0, fmt.Errorf("decode signature: %w", err)
	}
	pub, err := hex.DecodeString(out.PubKey)
	if err != nil {
		return nil, nil, 0, fmt.Errorf("decode pubkey: %w", err)
	}
	return sig, pub, out.Epoch, nil
}

// KeyHubGetPubKey は KeyHub の /internal/kms/pubkey から最新の公開鍵を取得する。
func KeyHubGetPubKey(endpoint string) ([]byte, int64, error) {
	endpoint = strings.TrimSuffix(strings.TrimSpace(endpoint), "/")
	if endpoint == "" {
		return nil, 0, fmt.Errorf("keyhub endpoint is empty")
	}

	client := &http.Client{Timeout: 2 * time.Second}
	resp, err := client.Get(endpoint + "/internal/kms/pubkey")
	if err != nil {
		return nil, 0, fmt.Errorf("get keyhub pubkey: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		msg, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
		return nil, 0, fmt.Errorf("keyhub pubkey status %d: %s", resp.StatusCode, strings.TrimSpace(string(msg)))
	}

	var out keyHubPubResponse
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return nil, 0, fmt.Errorf("decode keyhub pubkey response: %w", err)
	}
	pub, err := hex.DecodeString(out.PubKey)
	if err != nil {
		return nil, 0, fmt.Errorf("decode pubkey: %w", err)
	}
	return pub, out.Epoch, nil
}
