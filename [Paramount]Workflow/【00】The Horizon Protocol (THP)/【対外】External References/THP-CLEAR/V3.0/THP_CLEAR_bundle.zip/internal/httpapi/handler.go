package httpapi

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"

	"thp-clear/internal/domain"
	"thp-clear/pkg/monitor"
)

// Handler はTHP-CLEARのHTTP API。
type Handler struct {
	service *domain.Service
	metrics *monitor.Metrics
}

// New は新しいハンドラを作成する。
func New(service *domain.Service, metrics *monitor.Metrics) *Handler {
	return &Handler{service: service, metrics: metrics}
}

// Router はAPIルーターを初期化する。
func (h *Handler) Router() http.Handler {
	r := chi.NewRouter()
	r.Use(middleware.RequestID)
	r.Use(middleware.RealIP)
	r.Use(middleware.Recoverer)
	r.Use(h.metricsMiddleware)
	r.Use(jsonContentType)

	r.Get("/healthz", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
	})

	r.Post("/command", h.handleIssueCommand)
	r.Get("/command/{id}", h.handleGetCommand)
	r.Post("/settle", h.handleSettleCommand)
	r.Get("/witness", h.handleListWitness)

	r.Route("/admin", func(r chi.Router) {
		r.Post("/accounts", h.handleUpsertAccount)
		r.Post("/blacklist", h.handleAddBlacklist)
		r.Delete("/blacklist/{account_id}", h.handleClearBlacklist)
	})

	return r
}

func (h *Handler) metricsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if h.metrics == nil {
			next.ServeHTTP(w, r)
			return
		}
		start := time.Now()
		ww := middleware.NewWrapResponseWriter(w, r.ProtoMajor)
		next.ServeHTTP(ww, r)
		path := chi.RouteContext(r.Context()).RoutePattern()
		if path == "" {
			path = r.URL.Path
		}
		h.metrics.ObserveRequest(path, r.Method, strconv.Itoa(ww.Status()), time.Since(start))
	})
}

func jsonContentType(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json; charset=utf-8")
		next.ServeHTTP(w, r)
	})
}

func (h *Handler) handleIssueCommand(w http.ResponseWriter, r *http.Request) {
	var req issueCommandRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid json")
		return
	}

	cmd, err := h.service.IssueCommand(r.Context(), domain.IssueCommandInput{
		AccountID: req.AccountID,
		Amount:    req.Amount,
		Currency:  req.Currency,
		Purpose:   domain.Purpose(req.Purpose),
		Metadata:  req.Metadata,
		Reference: req.Reference,
	})
	if err != nil {
		status, msg := mapDomainError(err)
		writeError(w, status, msg)
		return
	}

	if h.metrics != nil {
		h.metrics.IncIssued()
	}
	writeJSON(w, http.StatusCreated, commandResponse(cmd))
}

func (h *Handler) handleGetCommand(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	cmd, err := h.service.GetCommand(r.Context(), id)
	if err != nil {
		status, msg := mapDomainError(err)
		writeError(w, status, msg)
		return
	}
	writeJSON(w, http.StatusOK, commandResponse(cmd))
}

func (h *Handler) handleSettleCommand(w http.ResponseWriter, r *http.Request) {
	var req settleCommandRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid json")
		return
	}

	cmd, entry, err := h.service.SettleCommand(r.Context(), domain.SettleCommandInput{
		CommandID: req.CommandID,
		Quantity:  req.Quantity,
		Unit:      req.Unit,
		Extra:     req.Metadata,
	})
	if err != nil {
		status, msg := mapDomainError(err)
		writeError(w, status, msg)
		return
	}

	if h.metrics != nil {
		h.metrics.IncSettled()
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"command": commandResponse(cmd),
		"witness": witnessResponse(entry),
	})
}

func (h *Handler) handleListWitness(w http.ResponseWriter, r *http.Request) {
	limitStr := r.URL.Query().Get("limit")
	limit := 50
	if limitStr != "" {
		if v, err := strconv.Atoi(limitStr); err == nil && v > 0 {
			limit = v
		}
	}
	entries, err := h.service.ListWitnessEntries(r.Context(), limit)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to fetch witness entries")
		return
	}
	resp := make([]any, 0, len(entries))
	for i := range entries {
		resp = append(resp, witnessResponse(&entries[i]))
	}
	writeJSON(w, http.StatusOK, resp)
}

func (h *Handler) handleUpsertAccount(w http.ResponseWriter, r *http.Request) {
	var req accountRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid json")
		return
	}
	account, err := h.service.UpsertAccount(r.Context(), domain.AccountInput{
		ID:          req.ID,
		DisplayName: req.DisplayName,
		Currency:    req.Currency,
		Balance:     req.Balance,
		Status:      domain.AccountStatus(req.Status),
	})
	if err != nil {
		status, msg := mapDomainError(err)
		writeError(w, status, msg)
		return
	}
	writeJSON(w, http.StatusOK, accountResponse(account))
}

func (h *Handler) handleAddBlacklist(w http.ResponseWriter, r *http.Request) {
	var req blacklistRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid json")
		return
	}
	var expires *time.Time
	if req.ExpiresAt != "" {
		t, err := time.Parse(time.RFC3339, req.ExpiresAt)
		if err != nil {
			writeError(w, http.StatusBadRequest, "invalid expires_at format")
			return
		}
		expires = &t
	}
	if err := h.service.AddBlacklistEntry(r.Context(), domain.BlacklistInput{
		AccountID: req.AccountID,
		Reason:    req.Reason,
		ExpiresAt: expires,
	}); err != nil {
		status, msg := mapDomainError(err)
		writeError(w, status, msg)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

func (h *Handler) handleClearBlacklist(w http.ResponseWriter, r *http.Request) {
	accountID := chi.URLParam(r, "account_id")
	if err := h.service.ClearBlacklist(r.Context(), accountID); err != nil {
		status, msg := mapDomainError(err)
		writeError(w, status, msg)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

type issueCommandRequest struct {
	AccountID string         `json:"account_id"`
	Amount    int64          `json:"amount"`
	Currency  string         `json:"currency"`
	Purpose   string         `json:"purpose"`
	Metadata  map[string]any `json:"metadata"`
	Reference string         `json:"reference"`
}

type settleCommandRequest struct {
	CommandID string         `json:"command_id"`
	Quantity  float64        `json:"quantity"`
	Unit      string         `json:"unit"`
	Metadata  map[string]any `json:"metadata"`
}

type accountRequest struct {
	ID          string `json:"id"`
	DisplayName string `json:"display_name"`
	Currency    string `json:"currency"`
	Balance     int64  `json:"balance"`
	Status      string `json:"status"`
}

type blacklistRequest struct {
	AccountID string `json:"account_id"`
	Reason    string `json:"reason"`
	ExpiresAt string `json:"expires_at"`
}

func commandResponse(cmd *domain.Command) map[string]any {
	if cmd == nil {
		return nil
	}
	resp := map[string]any{
		"id":           cmd.ID,
		"account_id":   cmd.AccountID,
		"amount":       cmd.Amount,
		"currency":     cmd.Currency,
		"purpose":      cmd.Purpose,
		"status":       cmd.Status,
		"requested_at": cmd.RequestedAt,
	}
	if cmd.Metadata != nil {
		resp["metadata"] = cmd.Metadata
	}
	if cmd.SettledAt != nil {
		resp["settled_at"] = cmd.SettledAt
	}
	if cmd.Quantity != nil {
		resp["quantity"] = *cmd.Quantity
	}
	if cmd.Unit != nil {
		resp["unit"] = *cmd.Unit
	}
	if cmd.WitnessHash != nil {
		resp["witness_hash"] = *cmd.WitnessHash
	}
	return resp
}

func witnessResponse(entry *domain.WitnessEntry) map[string]any {
	if entry == nil {
		return nil
	}
	return map[string]any{
		"id":            entry.ID,
		"command_id":    entry.CommandID,
		"hash":          entry.Hash,
		"previous_hash": entry.PreviousHash,
		"recorded_at":   entry.RecordedAt,
		"signature":     entry.Signature,
		"payload":       json.RawMessage(entry.Payload),
	}
}

func accountResponse(acc *domain.Account) map[string]any {
	if acc == nil {
		return nil
	}
	return map[string]any{
		"id":           acc.ID,
		"display_name": acc.DisplayName,
		"currency":     acc.Currency,
		"balance":      acc.Balance,
		"status":       acc.Status,
		"created_at":   acc.CreatedAt,
		"updated_at":   acc.UpdatedAt,
	}
}

func writeJSON(w http.ResponseWriter, status int, body any) {
	w.WriteHeader(status)
	if body == nil {
		return
	}
	_ = json.NewEncoder(w).Encode(body)
}

func writeError(w http.ResponseWriter, status int, message string) {
	writeJSON(w, status, map[string]string{"error": message})
}

func mapDomainError(err error) (int, string) {
	switch {
	case errors.Is(err, domain.ErrAccountNotFound):
		return http.StatusNotFound, "account not found"
	case errors.Is(err, domain.ErrAccountFrozen):
		return http.StatusLocked, "account frozen"
	case errors.Is(err, domain.ErrInsufficientFunds):
		return http.StatusUnprocessableEntity, "insufficient funds"
	case errors.Is(err, domain.ErrBlacklisted):
		return http.StatusForbidden, "account blacklisted"
	case errors.Is(err, domain.ErrInvalidPurpose):
		return http.StatusUnprocessableEntity, "invalid purpose"
	case errors.Is(err, domain.ErrCommandNotFound):
		return http.StatusNotFound, "command not found"
	case errors.Is(err, domain.ErrCommandSettled):
		return http.StatusConflict, "command already settled"
	case errors.Is(err, domain.ErrCommandRejected):
		return http.StatusConflict, "command rejected"
	case errors.Is(err, domain.ErrInvalidInput):
		msg := err.Error()
		if idx := strings.Index(msg, ":"); idx >= 0 && idx+1 < len(msg) {
			msg = strings.TrimSpace(msg[idx+1:])
		}
		return http.StatusUnprocessableEntity, msg
	default:
		return http.StatusInternalServerError, "internal server error"
	}
}
