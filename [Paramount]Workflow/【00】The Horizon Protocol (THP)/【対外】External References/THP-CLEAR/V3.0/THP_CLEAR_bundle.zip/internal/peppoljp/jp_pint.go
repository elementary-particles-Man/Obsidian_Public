package peppoljp

import (
	"bytes"
	"encoding/xml"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"time"
)

const (
	NamespaceJP  = "urn:jp:pint:billing:1.0"
	namespaceCAC = "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
	namespaceCBC = "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
)

// Party represents supplier/customer data within JP PINT invoices.
type Party struct {
	PartyName string `xml:"cac:PartyName>cbc:Name"`
	ID        string `xml:"cac:PartyIdentification>cbc:ID"`
}

// Amount encodes numeric amounts along with their currency.
type Amount struct {
	Value    string `xml:",chardata"`
	Currency string `xml:"currencyID,attr,omitempty"`
}

// TaxTotal models cac:TaxTotal.
type TaxTotal struct {
	TaxAmount Amount `xml:"cbc:TaxAmount"`
}

// MonetaryTotal models cac:LegalMonetaryTotal.
type MonetaryTotal struct {
	PayableAmount Amount `xml:"cbc:PayableAmount"`
}

// InvoiceData captures the elements needed to build a JP PINT compliant invoice.
type InvoiceData struct {
	ID                 string
	IssueDate          time.Time
	ProfileID          string
	DocumentCurrency   string
	AccountingSupplier Party
	AccountingCustomer Party
	Tax                TaxTotal
	Total              MonetaryTotal
}

// AmountFromInt helper for Yen-based representations.
func AmountFromInt(value int64, currency string) Amount {
	if currency == "" {
		currency = "JPY"
	}
	return Amount{
		Value:    strconv.FormatInt(value, 10),
		Currency: currency,
	}
}

// BuildInvoice marshals an InvoiceData structure into JP PINT compliant XML.
func BuildInvoice(inv InvoiceData) ([]byte, error) {
	if inv.ID == "" {
		return nil, errors.New("invoice id is required")
	}
	if inv.DocumentCurrency == "" {
		inv.DocumentCurrency = "JPY"
	}
	if inv.ProfileID == "" {
		inv.ProfileID = "JP-PINT"
	}
	if inv.IssueDate.IsZero() {
		inv.IssueDate = time.Now().UTC()
	}
	if inv.Tax.TaxAmount.Currency == "" {
		inv.Tax.TaxAmount.Currency = inv.DocumentCurrency
	}
	if inv.Total.PayableAmount.Currency == "" {
		inv.Total.PayableAmount.Currency = inv.DocumentCurrency
	}

	doc := struct {
		XMLName              xml.Name      `xml:"Invoice"`
		Xmlns                string        `xml:"xmlns,attr"`
		XmlnsCac             string        `xml:"xmlns:cac,attr"`
		XmlnsCbc             string        `xml:"xmlns:cbc,attr"`
		ProfileID            string        `xml:"cbc:ProfileID"`
		ID                   string        `xml:"cbc:ID"`
		IssueDate            string        `xml:"cbc:IssueDate"`
		DocumentCurrencyCode string        `xml:"cbc:DocumentCurrencyCode"`
		AccountingSupplier   Party         `xml:"cac:AccountingSupplierParty"`
		AccountingCustomer   Party         `xml:"cac:AccountingCustomerParty"`
		TaxTotal             TaxTotal      `xml:"cac:TaxTotal"`
		LegalMonetaryTotal   MonetaryTotal `xml:"cac:LegalMonetaryTotal"`
	}{
		Xmlns:                NamespaceJP,
		XmlnsCac:             namespaceCAC,
		XmlnsCbc:             namespaceCBC,
		ProfileID:            inv.ProfileID,
		ID:                   inv.ID,
		IssueDate:            inv.IssueDate.Format("2006-01-02"),
		DocumentCurrencyCode: inv.DocumentCurrency,
		AccountingSupplier:   inv.AccountingSupplier,
		AccountingCustomer:   inv.AccountingCustomer,
		TaxTotal:             inv.Tax,
		LegalMonetaryTotal:   inv.Total,
	}

	return xml.MarshalIndent(doc, "", "  ")
}

// SendToPeppol issues an HTTP POST towards the provided endpoint with JP PINT XML payload.
func SendToPeppol(endpoint string, payload []byte) error {
	return SendWithClient(http.DefaultClient, endpoint, payload)
}

// SendWithClient mirrors SendToPeppol but allows custom HTTP clients (timeouts, tracing, etc.).
func SendWithClient(client *http.Client, endpoint string, payload []byte) error {
	if client == nil {
		client = http.DefaultClient
	}
	req, err := http.NewRequest(http.MethodPost, endpoint, bytes.NewReader(payload))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/xml; charset=utf-8")

	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("Peppol send failed: %s", resp.Status)
	}
	return nil
}
