package keyhub

import (
	"github.com/prometheus/client_golang/prometheus"
)

var (
	KeyhubSignTotal = prometheus.NewCounter(prometheus.CounterOpts{
		Name: "keyhub_sign_total",
		Help: "total KeyHub sign operations",
	})
	KeyhubCurrentEpoch = prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "keyhub_epoch_current",
		Help: "current KeyHub epoch derived from master seed",
	})
)

func init() {
	prometheus.MustRegister(KeyhubSignTotal, KeyhubCurrentEpoch)
}
