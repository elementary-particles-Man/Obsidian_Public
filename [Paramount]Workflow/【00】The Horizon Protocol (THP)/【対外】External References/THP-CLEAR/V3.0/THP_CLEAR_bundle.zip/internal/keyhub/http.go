package keyhub

import (
	"encoding/json"
	"errors"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
)

// NewHTTPServer はKeyHubサービス向けのHTTPサーバーを生成する。
func NewHTTPServer(endpoint string, svc *Service) (*http.Server, error) {
	if svc == nil {
		return nil, errors.New("keyhub service is nil")
	}
	addr, err := listenAddress(endpoint)
	if err != nil {
		return nil, err
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/internal/kms/sign", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		var req struct {
			PayloadHash string `json:"payload_hash"`
			Epoch       int64  `json:"epoch"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "invalid json", http.StatusBadRequest)
			return
		}
		sig, epoch, pub, err := svc.SignHex(req.PayloadHash, req.Epoch)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		writeJSON(w, map[string]any{
			"sig":    sig,
			"epoch":  epoch,
			"pubkey": pub,
		})
	})

	mux.HandleFunc("/internal/kms/pubkey", func(w http.ResponseWriter, r *http.Request) {
		var epochHint int64
		if v := strings.TrimSpace(r.URL.Query().Get("epoch")); v != "" {
			if parsed, err := strconv.ParseInt(v, 10, 64); err == nil {
				epochHint = parsed
			} else {
				http.Error(w, "invalid epoch", http.StatusBadRequest)
				return
			}
		}
		pub, epoch, err := svc.PublicKey(epochHint)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		writeJSON(w, map[string]any{
			"pubkey": pub,
			"epoch":  epoch,
		})
	})

	server := &http.Server{
		Addr:         addr,
		Handler:      mux,
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
	}
	return server, nil
}

func listenAddress(endpoint string) (string, error) {
	if endpoint == "" {
		return "", errors.New("endpoint is empty")
	}
	u, err := url.Parse(endpoint)
	if err != nil || u.Host == "" {
		return endpoint, nil
	}
	host := u.Host
	if !strings.Contains(host, ":") {
		defaultPort := "80"
		if u.Scheme == "https" {
			defaultPort = "443"
		}
		host = net.JoinHostPort(host, defaultPort)
	}
	return host, nil
}

func writeJSON(w http.ResponseWriter, payload any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	_ = json.NewEncoder(w).Encode(payload)
}
