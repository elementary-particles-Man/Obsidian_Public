package keyhub

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const defaultEpochSeconds = 600

// Config はKeyHubサービスの初期化パラメータ。
type Config struct {
	MasterSeed   []byte
	EpochSeconds int
	AuditPath    string
}

// Service はKMS-in-DBの鍵派生と署名を提供する。
type Service struct {
	seed         []byte
	epochSeconds int64
	auditPath    string
	auditMu      sync.Mutex
}

// New はサービスを初期化する。
func New(cfg Config) (*Service, error) {
	seed := cfg.MasterSeed
	if len(seed) == 0 {
		seed = make([]byte, ed25519.SeedSize)
		if _, err := rand.Read(seed); err != nil {
			return nil, fmt.Errorf("generate default master seed: %w", err)
		}
	}
	if len(seed) < ed25519.SeedSize {
		return nil, errors.New("master seed must be at least 32 bytes")
	}
	normalized := make([]byte, ed25519.SeedSize)
	copy(normalized, seed[:ed25519.SeedSize])
	epoch := cfg.EpochSeconds
	if epoch <= 0 {
		epoch = defaultEpochSeconds
	}
	return &Service{
		seed:         normalized,
		epochSeconds: int64(epoch),
		auditPath:    cfg.AuditPath,
	}, nil
}

// SignHex はペイロードハッシュを受け取り、署名と公開鍵を返す。
func (s *Service) SignHex(payloadHex string, epochHint int64) (sigHex string, epoch int64, pubHex string, err error) {
	raw, err := decodeHash(payloadHex)
	if err != nil {
		return "", 0, "", err
	}
	epoch = s.resolveEpoch(epochHint, time.Now())
	priv := deriveKey(s.seed, epoch)
	pub := priv.Public().(ed25519.PublicKey)
	signature := ed25519.Sign(priv, raw)
	KeyhubSignTotal.Inc()
	KeyhubCurrentEpoch.Set(float64(epoch))
	s.audit("sign", fmt.Sprintf("epoch=%d hash=%s", epoch, payloadHex))
	return hex.EncodeToString(signature), epoch, hex.EncodeToString(pub), nil
}

// PublicKey は指定したエポックの公開鍵を返す。epochHint<=0なら現在時刻を用いる。
func (s *Service) PublicKey(epochHint int64) (pubHex string, epoch int64, err error) {
	epoch = s.resolveEpoch(epochHint, time.Now())
	priv := deriveKey(s.seed, epoch)
	pub := priv.Public().(ed25519.PublicKey)
	KeyhubCurrentEpoch.Set(float64(epoch))
	return hex.EncodeToString(pub), epoch, nil
}

func (s *Service) resolveEpoch(epochHint int64, t time.Time) int64 {
	if epochHint > 0 {
		return epochHint
	}
	return t.Unix() / s.epochSeconds
}

func deriveKey(seed []byte, epoch int64) ed25519.PrivateKey {
	var epochBytes [8]byte
	binary.BigEndian.PutUint64(epochBytes[:], uint64(epoch))
	data := make([]byte, len(seed)+len(epochBytes))
	copy(data, seed)
	copy(data[len(seed):], epochBytes[:])
	sum := sha256.Sum256(data)
	return ed25519.NewKeyFromSeed(sum[:ed25519.SeedSize])
}

func decodeHash(hexStr string) ([]byte, error) {
	clean := strings.TrimPrefix(strings.TrimSpace(hexStr), "0x")
	if clean == "" {
		return nil, errors.New("payload_hash is required")
	}
	raw, err := hex.DecodeString(clean)
	if err != nil {
		return nil, fmt.Errorf("decode payload_hash: %w", err)
	}
	return raw, nil
}

func (s *Service) audit(kind, msg string) {
	if s.auditPath == "" {
		return
	}
	if err := os.MkdirAll(filepath.Dir(s.auditPath), 0o750); err != nil {
		return
	}
	s.auditMu.Lock()
	defer s.auditMu.Unlock()
	f, err := os.OpenFile(s.auditPath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o640)
	if err != nil {
		return
	}
	defer f.Close()
	entry := fmt.Sprintf(`{"ts":"%s","kind":"%s","msg":"%s"}`+"\n", time.Now().UTC().Format(time.RFC3339Nano), kind, msg)
	_, _ = f.WriteString(entry)
}
