package memory

import (
	"context"
	"encoding/json"
	"errors"
	"sync"
	"time"

	"thp-clear/internal/domain"
)

// Store はメモリ上で domain.Store を満たす実装。テストや開発用。
type Store struct {
	mu          sync.RWMutex
	accounts    map[string]*domain.Account
	commands    map[string]*domain.Command
	witnesses   []*domain.WitnessEntry
	blacklist   map[string]*domain.BlacklistEntry
	latestHash  string
	nextWitness int64
}

// New は空のメモリストアを返す。
func New() *Store {
	return &Store{
		accounts:  make(map[string]*domain.Account),
		commands:  make(map[string]*domain.Command),
		blacklist: make(map[string]*domain.BlacklistEntry),
	}
}

// IssueCommand は口座残高を減算し、決済命令を登録する。
func (s *Store) IssueCommand(_ context.Context, input domain.IssueCommandStoreInput) (*domain.Command, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	account, ok := s.accounts[input.AccountID]
	if !ok {
		return nil, domain.ErrAccountNotFound
	}
	if account.Status == domain.AccountFrozen {
		return nil, domain.ErrAccountFrozen
	}
	if account.Currency != input.Currency {
		return nil, errors.New("currency mismatch")
	}
	if account.Balance < input.Amount {
		return nil, domain.ErrInsufficientFunds
	}
	if entry, ok := s.blacklist[input.AccountID]; ok && entry.Active && (entry.ExpiresAt == nil || entry.ExpiresAt.After(input.Requested)) {
		return nil, domain.ErrBlacklisted
	}

	account = cloneAccount(account)
	account.Balance -= input.Amount
	account.UpdatedAt = input.Requested
	s.accounts[input.AccountID] = account

	cmd := &domain.Command{
		ID:          input.CommandID,
		AccountID:   input.AccountID,
		Amount:      input.Amount,
		Currency:    input.Currency,
		Purpose:     input.Purpose,
		Status:      domain.CommandPending,
		RequestedAt: input.Requested,
		Metadata:    bytesToMetadata(input.Metadata),
	}
	if input.Reference != "" {
		if cmd.Metadata == nil {
			cmd.Metadata = map[string]any{}
		}
		cmd.Metadata["reference"] = input.Reference
	}
	s.commands[input.CommandID] = cloneCommand(cmd)

	return cloneCommand(cmd), nil
}

// GetCommand はIDで命令を取得。
func (s *Store) GetCommand(_ context.Context, id string) (*domain.Command, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	cmd, ok := s.commands[id]
	if !ok {
		return nil, domain.ErrCommandNotFound
	}
	return cloneCommand(cmd), nil
}

// RecordSettlement は命令を更新し、Witness を追記する。
func (s *Store) RecordSettlement(_ context.Context, cmd *domain.Command, entry *domain.WitnessEntry) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	current, ok := s.commands[cmd.ID]
	if !ok {
		return domain.ErrCommandNotFound
	}
	if current.Status == domain.CommandSettled {
		return domain.ErrCommandSettled
	}

	copiedCmd := cloneCommand(cmd)
	s.commands[cmd.ID] = copiedCmd

	s.nextWitness++
	copiedEntry := cloneWitness(entry)
	copiedEntry.ID = s.nextWitness
	s.witnesses = append(s.witnesses, copiedEntry)
	s.latestHash = copiedEntry.Hash

	entry.ID = copiedEntry.ID
	return nil
}

// LatestWitnessHash は最新ハッシュを返す。
func (s *Store) LatestWitnessHash(context.Context) (string, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.latestHash, nil
}

// ListWitnessEntries は最新のWitnessを降順で返す。
func (s *Store) ListWitnessEntries(_ context.Context, limit int) ([]domain.WitnessEntry, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	if limit <= 0 {
		limit = len(s.witnesses)
	}
	if limit > len(s.witnesses) {
		limit = len(s.witnesses)
	}
	out := make([]domain.WitnessEntry, 0, limit)
	for i := len(s.witnesses) - 1; i >= 0 && len(out) < limit; i-- {
		out = append(out, *cloneWitness(s.witnesses[i]))
	}
	return out, nil
}

// UpsertAccount は口座を登録または更新する。
func (s *Store) UpsertAccount(_ context.Context, account domain.Account) (*domain.Account, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	now := account.UpdatedAt
	if now.IsZero() {
		now = time.Now().UTC()
		account.UpdatedAt = now
	}
	if account.CreatedAt.IsZero() {
		account.CreatedAt = now
	}
	if account.Status == "" {
		account.Status = domain.AccountActive
	}

	s.accounts[account.ID] = cloneAccount(&account)
	return cloneAccount(&account), nil
}

// AddBlacklistEntry はブラックDBに登録する。
func (s *Store) AddBlacklistEntry(_ context.Context, entry domain.BlacklistEntry) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if entry.CreatedAt.IsZero() {
		entry.CreatedAt = time.Now().UTC()
	}
	entry.Active = true
	s.blacklist[entry.AccountID] = cloneBlacklist(&entry)
	return nil
}

// ClearBlacklist はブラック登録を解除する。
func (s *Store) ClearBlacklist(_ context.Context, accountID string, removedAt time.Time) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if entry, ok := s.blacklist[accountID]; ok {
		entry.Active = false
		if entry.ExpiresAt == nil {
			entry.ExpiresAt = &removedAt
		}
		entry = cloneBlacklist(entry)
		s.blacklist[accountID] = entry
	}
	return nil
}

func bytesToMetadata(b []byte) map[string]any {
	if len(b) == 0 {
		return nil
	}
	var out map[string]any
	if err := json.Unmarshal(b, &out); err != nil {
		return map[string]any{
			"_raw": string(b),
			"_err": err.Error(),
		}
	}
	return out
}

func cloneAccount(acc *domain.Account) *domain.Account {
	if acc == nil {
		return nil
	}
	c := *acc
	return &c
}

func cloneCommand(cmd *domain.Command) *domain.Command {
	if cmd == nil {
		return nil
	}
	c := *cmd
	if cmd.Metadata != nil {
		meta := make(map[string]any, len(cmd.Metadata))
		for k, v := range cmd.Metadata {
			meta[k] = v
		}
		c.Metadata = meta
	}
	if cmd.Quantity != nil {
		val := *cmd.Quantity
		c.Quantity = &val
	}
	if cmd.Unit != nil {
		val := *cmd.Unit
		c.Unit = &val
	}
	if cmd.WitnessHash != nil {
		val := *cmd.WitnessHash
		c.WitnessHash = &val
	}
	if cmd.SettledAt != nil {
		t := *cmd.SettledAt
		c.SettledAt = &t
	}
	return &c
}

func cloneWitness(entry *domain.WitnessEntry) *domain.WitnessEntry {
	if entry == nil {
		return nil
	}
	c := *entry
	if entry.Payload != nil {
		c.Payload = append([]byte(nil), entry.Payload...)
	}
	if entry.Signature != nil {
		c.Signature = append([]byte(nil), entry.Signature...)
	}
	return &c
}

func cloneBlacklist(entry *domain.BlacklistEntry) *domain.BlacklistEntry {
	if entry == nil {
		return nil
	}
	c := *entry
	if entry.ExpiresAt != nil {
		t := *entry.ExpiresAt
		c.ExpiresAt = &t
	}
	return &c
}
