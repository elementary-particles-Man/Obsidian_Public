package adapters

// TODO: DB や外部サービスとの接続コードを実装。
