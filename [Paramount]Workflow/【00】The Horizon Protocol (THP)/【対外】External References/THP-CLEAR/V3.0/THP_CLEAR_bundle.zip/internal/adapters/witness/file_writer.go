package witness

import (
	"encoding/base64"
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
	"time"

	"thp-clear/internal/domain"
)

// FileWriter はWitnessログをJSON Lines形式で追記する。
type FileWriter struct {
	path string
	mu   sync.Mutex
}

// NewFileWriter はファイル出力用のライターを生成する。
func NewFileWriter(path string) (*FileWriter, error) {
	if err := os.MkdirAll(filepath.Dir(path), 0o750); err != nil {
		return nil, err
	}
	return &FileWriter{path: path}, nil
}

// Append はWitnessエントリを1行JSONで追記する。
func (w *FileWriter) Append(entry *domain.WitnessEntry) error {
	if entry == nil {
		return nil
	}
	record := struct {
		ID           int64  `json:"id"`
		CommandID    string `json:"command_id"`
		Hash         string `json:"hash"`
		PreviousHash string `json:"previous_hash,omitempty"`
		RecordedAt   string `json:"recorded_at"`
		Signature    string `json:"signature"`
		Payload      string `json:"payload"`
	}{
		ID:           entry.ID,
		CommandID:    entry.CommandID,
		Hash:         entry.Hash,
		PreviousHash: entry.PreviousHash,
		RecordedAt:   entry.RecordedAt.UTC().Format(time.RFC3339Nano),
		Signature:    base64.StdEncoding.EncodeToString(entry.Signature),
		Payload:      string(entry.Payload),
	}

	line, err := json.Marshal(record)
	if err != nil {
		return err
	}

	w.mu.Lock()
	defer w.mu.Unlock()

	f, err := os.OpenFile(w.path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o640)
	if err != nil {
		return err
	}
	defer f.Close()

	if _, err := f.Write(append(line, '\n')); err != nil {
		return err
	}
	return f.Sync()
}
