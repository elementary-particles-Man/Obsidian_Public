package sqlite

import (
	"context"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"errors"
	"time"

	_ "modernc.org/sqlite"

	"thp-clear/internal/domain"
)

// Store はSQLiteをバックエンドにした永続化実装。
type Store struct {
	db *sql.DB
}

// New はSQLiteデータベースを開く。
func New(dsn string) (*Store, error) {
	db, err := sql.Open("sqlite", dsn)
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(1) // SQLiteは単一コネクション運用が安定
	return &Store{db: db}, nil
}

// Close はDBを閉じる。
func (s *Store) Close() error {
	if s.db == nil {
		return nil
	}
	return s.db.Close()
}

// InitSchema は必要なテーブルを作成。
func (s *Store) InitSchema(ctx context.Context) error {
	schema := []string{
		`CREATE TABLE IF NOT EXISTS accounts (
			id TEXT PRIMARY KEY,
			display_name TEXT NOT NULL,
			currency TEXT NOT NULL,
			balance INTEGER NOT NULL,
			status TEXT NOT NULL,
			created_at TIMESTAMP NOT NULL,
			updated_at TIMESTAMP NOT NULL
		);`,
		`CREATE TABLE IF NOT EXISTS commands (
			id TEXT PRIMARY KEY,
			account_id TEXT NOT NULL,
			amount INTEGER NOT NULL,
			currency TEXT NOT NULL,
			purpose TEXT NOT NULL,
			status TEXT NOT NULL,
			metadata TEXT,
			reference TEXT,
			requested_at TIMESTAMP NOT NULL,
			settled_at TIMESTAMP,
			quantity REAL,
			unit TEXT,
			witness_hash TEXT,
			FOREIGN KEY(account_id) REFERENCES accounts(id)
		);`,
		`CREATE TABLE IF NOT EXISTS blacklist (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			account_id TEXT NOT NULL,
			reason TEXT NOT NULL,
			expires_at TIMESTAMP,
			created_at TIMESTAMP NOT NULL,
			active INTEGER NOT NULL,
			FOREIGN KEY(account_id) REFERENCES accounts(id)
		);`,
		`CREATE TABLE IF NOT EXISTS witness_entries (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			command_id TEXT NOT NULL,
			payload TEXT NOT NULL,
			hash TEXT NOT NULL,
			previous_hash TEXT,
			signature TEXT NOT NULL,
			recorded_at TIMESTAMP NOT NULL,
			FOREIGN KEY(command_id) REFERENCES commands(id)
		);`,
		`CREATE INDEX IF NOT EXISTS idx_commands_account_id ON commands(account_id);`,
		`CREATE INDEX IF NOT EXISTS idx_blacklist_account ON blacklist(account_id, active);`,
		`CREATE INDEX IF NOT EXISTS idx_witness_recorded ON witness_entries(recorded_at);`,
	}

	for _, stmt := range schema {
		if _, err := s.db.ExecContext(ctx, stmt); err != nil {
			return err
		}
	}
	return nil
}

// IssueCommand は新しい命令を登録し、残高を減算する。
func (s *Store) IssueCommand(ctx context.Context, input domain.IssueCommandStoreInput) (*domain.Command, error) {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	account, err := getAccount(ctx, tx, input.AccountID)
	if err != nil {
		return nil, err
	}

	if account.Status == domain.AccountFrozen {
		_ = tx.Rollback()
		return nil, domain.ErrAccountFrozen
	}
	if account.Currency != input.Currency {
		_ = tx.Rollback()
		return nil, errors.New("currency mismatch")
	}
	if account.Balance < input.Amount {
		_ = tx.Rollback()
		return nil, domain.ErrInsufficientFunds
	}

	blacklisted, err := isBlacklisted(ctx, tx, input.AccountID, input.Requested)
	if err != nil {
		return nil, err
	}
	if blacklisted {
		_ = tx.Rollback()
		return nil, domain.ErrBlacklisted
	}

	newBalance := account.Balance - input.Amount
	if _, err = tx.ExecContext(
		ctx,
		`UPDATE accounts SET balance = ?, updated_at = ? WHERE id = ?`,
		newBalance,
		input.Requested,
		input.AccountID,
	); err != nil {
		return nil, err
	}

	if _, err = tx.ExecContext(
		ctx,
		`INSERT INTO commands (id, account_id, amount, currency, purpose, status, metadata, reference, requested_at)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		input.CommandID,
		input.AccountID,
		input.Amount,
		input.Currency,
		string(input.Purpose),
		string(domain.CommandPending),
		bytesToNullableString(input.Metadata),
		nullableString(input.Reference),
		input.Requested,
	); err != nil {
		return nil, err
	}

	if err = tx.Commit(); err != nil {
		return nil, err
	}

	cmd := &domain.Command{
		ID:          input.CommandID,
		AccountID:   input.AccountID,
		Amount:      input.Amount,
		Currency:    input.Currency,
		Purpose:     input.Purpose,
		Status:      domain.CommandPending,
		RequestedAt: input.Requested,
		Metadata:    bytesToMetadata(input.Metadata),
	}
	if input.Reference != "" {
		if cmd.Metadata == nil {
			cmd.Metadata = map[string]any{}
		}
		cmd.Metadata["reference"] = input.Reference
	}
	return cmd, nil
}

// GetCommand はIDから命令を取得。
func (s *Store) GetCommand(ctx context.Context, id string) (*domain.Command, error) {
	row := s.db.QueryRowContext(ctx, `SELECT id, account_id, amount, currency, purpose, status, metadata, reference, requested_at, settled_at, quantity, unit, witness_hash FROM commands WHERE id = ?`, id)
	var (
		cmd                          domain.Command
		metadataStr, reference, unit sql.NullString
		settledAt                    sql.NullTime
		quantity                     sql.NullFloat64
		witnessHash                  sql.NullString
	)
	err := row.Scan(
		&cmd.ID,
		&cmd.AccountID,
		&cmd.Amount,
		&cmd.Currency,
		(*string)(&cmd.Purpose),
		(*string)(&cmd.Status),
		&metadataStr,
		&reference,
		&cmd.RequestedAt,
		&settledAt,
		&quantity,
		&unit,
		&witnessHash,
	)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, domain.ErrCommandNotFound
	}
	if err != nil {
		return nil, err
	}
	cmd.Metadata = bytesToMetadata([]byte(metadataStr.String))
	if reference.Valid {
		if cmd.Metadata == nil {
			cmd.Metadata = map[string]any{}
		}
		cmd.Metadata["reference"] = reference.String
	}
	if settledAt.Valid {
		cmd.SettledAt = &settledAt.Time
	}
	if quantity.Valid {
		cmd.Quantity = &quantity.Float64
	}
	if unit.Valid {
		cmd.Unit = &unit.String
	}
	if witnessHash.Valid {
		cmd.WitnessHash = &witnessHash.String
	}
	return &cmd, nil
}

// RecordSettlement は命令更新とWitness記録をトランザクションで反映する。
func (s *Store) RecordSettlement(ctx context.Context, cmd *domain.Command, entry *domain.WitnessEntry) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	if _, err = tx.ExecContext(
		ctx,
		`UPDATE commands SET status = ?, settled_at = ?, quantity = ?, unit = ?, witness_hash = ? WHERE id = ?`,
		string(cmd.Status),
		nullableTime(cmd.SettledAt),
		nullableFloat(cmd.Quantity),
		nullableString(ptrValue(cmd.Unit)),
		nullableString(ptrValue(cmd.WitnessHash)),
		cmd.ID,
	); err != nil {
		return err
	}

	res, err := tx.ExecContext(
		ctx,
		`INSERT INTO witness_entries (command_id, payload, hash, previous_hash, signature, recorded_at)
		 VALUES (?, ?, ?, ?, ?, ?)`,
		cmd.ID,
		string(entry.Payload),
		entry.Hash,
		nullableString(entry.PreviousHash),
		base64.StdEncoding.EncodeToString(entry.Signature),
		entry.RecordedAt,
	)
	if err != nil {
		return err
	}

	insertID, err := res.LastInsertId()
	if err != nil {
		return err
	}
	entry.ID = insertID

	return tx.Commit()
}

// LatestWitnessHash は最新のWitnessハッシュを返す。
func (s *Store) LatestWitnessHash(ctx context.Context) (string, error) {
	row := s.db.QueryRowContext(ctx, `SELECT hash FROM witness_entries ORDER BY id DESC LIMIT 1`)
	var hash sql.NullString
	if err := row.Scan(&hash); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return "", nil
		}
		return "", err
	}
	if hash.Valid {
		return hash.String, nil
	}
	return "", nil
}

// ListWitnessEntries は最新のWitnessログを取得する。
func (s *Store) ListWitnessEntries(ctx context.Context, limit int) ([]domain.WitnessEntry, error) {
	if limit <= 0 {
		limit = 50
	}
	rows, err := s.db.QueryContext(ctx, `SELECT id, command_id, payload, hash, previous_hash, signature, recorded_at FROM witness_entries ORDER BY id DESC LIMIT ?`, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var entries []domain.WitnessEntry
	for rows.Next() {
		var (
			entry        domain.WitnessEntry
			payload      string
			prevHash     sql.NullString
			signatureStr string
		)
		if err := rows.Scan(
			&entry.ID,
			&entry.CommandID,
			&payload,
			&entry.Hash,
			&prevHash,
			&signatureStr,
			&entry.RecordedAt,
		); err != nil {
			return nil, err
		}
		entry.Payload = []byte(payload)
		if prevHash.Valid {
			entry.PreviousHash = prevHash.String
		}
		sig, err := base64.StdEncoding.DecodeString(signatureStr)
		if err != nil {
			return nil, err
		}
		entry.Signature = sig
		entries = append(entries, entry)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return entries, nil
}

// UpsertAccount は口座を作成または更新する。
func (s *Store) UpsertAccount(ctx context.Context, account domain.Account) (*domain.Account, error) {
	if account.Status == "" {
		account.Status = domain.AccountActive
	}
	if account.CreatedAt.IsZero() {
		account.CreatedAt = time.Now().UTC()
	}
	if account.UpdatedAt.IsZero() {
		account.UpdatedAt = time.Now().UTC()
	}

	_, err := s.db.ExecContext(
		ctx,
		`INSERT INTO accounts (id, display_name, currency, balance, status, created_at, updated_at)
		 VALUES (?, ?, ?, ?, ?, ?, ?)
		 ON CONFLICT(id) DO UPDATE SET
		   display_name = excluded.display_name,
		   currency = excluded.currency,
		   balance = excluded.balance,
		   status = excluded.status,
		   updated_at = excluded.updated_at`,
		account.ID,
		account.DisplayName,
		account.Currency,
		account.Balance,
		string(account.Status),
		account.CreatedAt,
		account.UpdatedAt,
	)
	if err != nil {
		return nil, err
	}
	return s.GetAccount(ctx, account.ID)
}

// AddBlacklistEntry は口座をブラックリストに追加する。
func (s *Store) AddBlacklistEntry(ctx context.Context, entry domain.BlacklistEntry) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	if _, err = tx.ExecContext(ctx, `UPDATE blacklist SET active = 0 WHERE account_id = ? AND active = 1`, entry.AccountID); err != nil {
		return err
	}
	if entry.CreatedAt.IsZero() {
		entry.CreatedAt = time.Now().UTC()
	}
	_, err = tx.ExecContext(
		ctx,
		`INSERT INTO blacklist (account_id, reason, expires_at, created_at, active)
		 VALUES (?, ?, ?, ?, 1)`,
		entry.AccountID,
		entry.Reason,
		nullableTime(entry.ExpiresAt),
		entry.CreatedAt,
	)
	if err != nil {
		return err
	}
	return tx.Commit()
}

// ClearBlacklist は口座のブラック登録を解除する。
func (s *Store) ClearBlacklist(ctx context.Context, accountID string, removedAt time.Time) error {
	if removedAt.IsZero() {
		removedAt = time.Now().UTC()
	}
	_, err := s.db.ExecContext(
		ctx,
		`UPDATE blacklist SET active = 0, expires_at = COALESCE(expires_at, ?) WHERE account_id = ? AND active = 1`,
		removedAt,
		accountID,
	)
	return err
}

// GetAccount はIDで口座を取得する。
func (s *Store) GetAccount(ctx context.Context, id string) (*domain.Account, error) {
	row := s.db.QueryRowContext(ctx, `SELECT id, display_name, currency, balance, status, created_at, updated_at FROM accounts WHERE id = ?`, id)
	return scanAccount(row)
}

// Helper functions

func getAccount(ctx context.Context, tx *sql.Tx, id string) (*domain.Account, error) {
	return scanAccount(tx.QueryRowContext(ctx, `SELECT id, display_name, currency, balance, status, created_at, updated_at FROM accounts WHERE id = ?`, id))
}

func isBlacklisted(ctx context.Context, tx *sql.Tx, accountID string, now time.Time) (bool, error) {
	row := tx.QueryRowContext(ctx, `SELECT COUNT(1) FROM blacklist WHERE account_id = ? AND active = 1 AND (expires_at IS NULL OR expires_at > ?)`, accountID, now)
	var count int
	if err := row.Scan(&count); err != nil {
		return false, err
	}
	return count > 0, nil
}

func bytesToMetadata(b []byte) map[string]any {
	if len(b) == 0 {
		return nil
	}
	var out map[string]any
	if err := json.Unmarshal(b, &out); err != nil {
		return map[string]any{
			"_raw": string(b),
			"_err": err.Error(),
		}
	}
	return out
}

func bytesToNullableString(b []byte) any {
	if len(b) == 0 {
		return nil
	}
	return string(b)
}

func nullableString(v string) any {
	if v == "" {
		return nil
	}
	return v
}

func nullableTime(t *time.Time) any {
	if t == nil {
		return nil
	}
	return *t
}

func nullableFloat(v *float64) any {
	if v == nil {
		return nil
	}
	return *v
}

func ptrValue(p *string) string {
	if p == nil {
		return ""
	}
	return *p
}

func scanAccount(row *sql.Row) (*domain.Account, error) {
	var acc domain.Account
	if err := row.Scan(
		&acc.ID,
		&acc.DisplayName,
		&acc.Currency,
		&acc.Balance,
		(*string)(&acc.Status),
		&acc.CreatedAt,
		&acc.UpdatedAt,
	); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, domain.ErrAccountNotFound
		}
		return nil, err
	}
	return &acc, nil
}

// EnableTestOptimizations はテスト実行時のみ利用する SQLite PRAGMA を適用する。
func (s *Store) EnableTestOptimizations(ctx context.Context) error {
	statements := []string{
		`PRAGMA journal_mode=MEMORY;`,
		`PRAGMA synchronous=OFF;`,
	}
	for _, stmt := range statements {
		if _, err := s.db.ExecContext(ctx, stmt); err != nil {
			return err
		}
	}
	return nil
}
