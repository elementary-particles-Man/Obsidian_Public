package domain

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"time"

	"github.com/google/uuid"
)

// Signer はWitnessログに署名するためのインターフェース。
type Signer interface {
	Sign(data []byte) ([]byte, error)
	PublicKey() []byte
}

// WitnessWriter はWORMファイルなどへの追記を担う。
type WitnessWriter interface {
	Append(entry *WitnessEntry) error
}

// MetricsSink はドメインイベントを監視層へ通知するためのインターフェース。
type MetricsSink interface {
	ObserveWitnessAppend()
	ObserveWitnessVerification(success bool)
	ObserveWitnessLatency(d time.Duration)
	SetEMADViolationScore(score float64)
}

// Store はドメイン操作に必要な永続化インターフェース。
type Store interface {
	IssueCommand(ctx context.Context, input IssueCommandStoreInput) (*Command, error)
	GetCommand(ctx context.Context, id string) (*Command, error)
	RecordSettlement(ctx context.Context, command *Command, entry *WitnessEntry) error
	LatestWitnessHash(ctx context.Context) (string, error)
	ListWitnessEntries(ctx context.Context, limit int) ([]WitnessEntry, error)
	UpsertAccount(ctx context.Context, account Account) (*Account, error)
	AddBlacklistEntry(ctx context.Context, entry BlacklistEntry) error
	ClearBlacklist(ctx context.Context, accountID string, removedAt time.Time) error
}

// IssueCommandInput はAPI層から渡される命令発行のリクエスト。
type IssueCommandInput struct {
	AccountID string
	Amount    int64
	Currency  string
	Purpose   Purpose
	Metadata  map[string]any
	Reference string
}

// IssueCommandStoreInput はストア層へ受け渡す形。
type IssueCommandStoreInput struct {
	CommandID string
	AccountID string
	Amount    int64
	Currency  string
	Purpose   Purpose
	Metadata  []byte
	Requested time.Time
	Reference string
}

// SettleCommandInput は命令を確定させるためのリクエスト。
type SettleCommandInput struct {
	CommandID string
	Quantity  float64
	Unit      string
	Extra     map[string]any
}

// AccountInput は口座登録・更新用。
type AccountInput struct {
	ID          string
	DisplayName string
	Currency    string
	Balance     int64
	Status      AccountStatus
}

// BlacklistInput はブラックDB登録用。
type BlacklistInput struct {
	AccountID string
	Reason    string
	ExpiresAt *time.Time
}

// Service はドメイン操作のファサード。
type Service struct {
	store   Store
	signer  Signer
	writer  WitnessWriter
	now     func() time.Time
	metrics MetricsSink
}

// NewService を生成。
func NewService(store Store, signer Signer, writer WitnessWriter) *Service {
	return &Service{
		store:  store,
		signer: signer,
		writer: writer,
		now:    time.Now,
	}
}

// WithMetrics は任意のメトリクスシンクを設定する。
func (s *Service) WithMetrics(metrics MetricsSink) {
	s.metrics = metrics
}

// WithNow allows injecting custom clock (mainly for tests).
func (s *Service) WithNow(now func() time.Time) {
	if now != nil {
		s.now = now
	}
}

// IssueCommand は新しい決済命令を作成する。
func (s *Service) IssueCommand(ctx context.Context, in IssueCommandInput) (*Command, error) {
	if err := validatePurpose(in.Purpose); err != nil {
		return nil, err
	}
	if in.Amount <= 0 {
		return nil, fmt.Errorf("%w: amount must be positive", ErrInvalidInput)
	}
	if in.AccountID == "" {
		return nil, fmt.Errorf("%w: account_id is required", ErrInvalidInput)
	}
	if in.Currency == "" {
		return nil, fmt.Errorf("%w: currency is required", ErrInvalidInput)
	}

	cmdID := uuid.NewString()
	metadataBytes, err := marshalMetadata(in.Metadata)
	if err != nil {
		return nil, err
	}
	input := IssueCommandStoreInput{
		CommandID: cmdID,
		AccountID: in.AccountID,
		Amount:    in.Amount,
		Currency:  in.Currency,
		Purpose:   in.Purpose,
		Metadata:  metadataBytes,
		Requested: s.now(),
		Reference: in.Reference,
	}
	return s.store.IssueCommand(ctx, input)
}

// SettleCommand は命令を確定させ、Witnessログを生成する。
func (s *Service) SettleCommand(ctx context.Context, in SettleCommandInput) (*Command, *WitnessEntry, error) {
	start := time.Now()
	success := false
	defer func() {
		if s.metrics != nil {
			s.metrics.ObserveWitnessLatency(time.Since(start))
			s.metrics.ObserveWitnessVerification(success)
		}
	}()

	if in.CommandID == "" {
		return nil, nil, fmt.Errorf("%w: command_id is required", ErrInvalidInput)
	}
	if in.Quantity <= 0 {
		return nil, nil, fmt.Errorf("%w: quantity must be positive", ErrInvalidInput)
	}
	if in.Unit == "" {
		return nil, nil, fmt.Errorf("%w: unit is required", ErrInvalidInput)
	}

	cmd, err := s.store.GetCommand(ctx, in.CommandID)
	if err != nil {
		return nil, nil, err
	}
	if cmd.Status == CommandSettled {
		return nil, nil, ErrCommandSettled
	}
	if cmd.Status == CommandRejected {
		return nil, nil, ErrCommandRejected
	}

	recordedAt := s.now().UTC()
	prevHash, err := s.store.LatestWitnessHash(ctx)
	if err != nil {
		return nil, nil, err
	}

	payload, err := buildWitnessPayload(cmd, in, recordedAt)
	if err != nil {
		return nil, nil, err
	}

	digest := sha256.Sum256(append([]byte(prevHash), payload...))
	signature, err := s.signer.Sign(digest[:])
	if err != nil {
		return nil, nil, err
	}

	hashHex := hex.EncodeToString(digest[:])
	cmd.Status = CommandSettled
	cmd.SettledAt = &recordedAt
	cmd.Quantity = ptrFloat64(in.Quantity)
	cmd.Unit = ptrString(in.Unit)
	cmd.WitnessHash = ptrString(hashHex)

	entry := &WitnessEntry{
		CommandID:    cmd.ID,
		Payload:      payload,
		Hash:         hashHex,
		PreviousHash: prevHash,
		Signature:    signature,
		RecordedAt:   recordedAt,
	}

	if err := s.store.RecordSettlement(ctx, cmd, entry); err != nil {
		return nil, nil, err
	}

	if s.writer != nil {
		if err := s.writer.Append(entry); err != nil {
			return nil, nil, err
		}
	}

	success = true
	if s.metrics != nil {
		s.metrics.ObserveWitnessAppend()
	}

	return cmd, entry, nil
}

// GetCommand はIDで命令を取得する。
func (s *Service) GetCommand(ctx context.Context, id string) (*Command, error) {
	if id == "" {
		return nil, fmt.Errorf("%w: id is required", ErrInvalidInput)
	}
	return s.store.GetCommand(ctx, id)
}

// ListWitnessEntries は最新のWitnessログを返す。
func (s *Service) ListWitnessEntries(ctx context.Context, limit int) ([]WitnessEntry, error) {
	if limit <= 0 {
		limit = 50
	}
	if limit > 500 {
		limit = 500
	}
	return s.store.ListWitnessEntries(ctx, limit)
}

// UpsertAccount は口座を登録または更新する。
func (s *Service) UpsertAccount(ctx context.Context, in AccountInput) (*Account, error) {
	if in.ID == "" {
		return nil, fmt.Errorf("%w: id is required", ErrInvalidInput)
	}
	if in.DisplayName == "" {
		return nil, fmt.Errorf("%w: display_name is required", ErrInvalidInput)
	}
	if in.Currency == "" {
		return nil, fmt.Errorf("%w: currency is required", ErrInvalidInput)
	}
	if in.Balance < 0 {
		return nil, fmt.Errorf("%w: balance must be non-negative", ErrInvalidInput)
	}

	status := in.Status
	if status == "" {
		status = AccountActive
	}
	if status != AccountActive && status != AccountFrozen {
		return nil, fmt.Errorf("%w: invalid status", ErrInvalidInput)
	}

	now := s.now().UTC()
	account := Account{
		ID:          in.ID,
		DisplayName: in.DisplayName,
		Currency:    in.Currency,
		Balance:     in.Balance,
		Status:      status,
		CreatedAt:   now,
		UpdatedAt:   now,
	}
	return s.store.UpsertAccount(ctx, account)
}

// AddBlacklistEntry は口座をブラックDBに追加する。
func (s *Service) AddBlacklistEntry(ctx context.Context, in BlacklistInput) error {
	if in.AccountID == "" {
		return fmt.Errorf("%w: account_id is required", ErrInvalidInput)
	}
	if in.Reason == "" {
		return fmt.Errorf("%w: reason is required", ErrInvalidInput)
	}
	entry := BlacklistEntry{
		AccountID: in.AccountID,
		Reason:    in.Reason,
		CreatedAt: s.now().UTC(),
		Active:    true,
	}
	if in.ExpiresAt != nil {
		t := in.ExpiresAt.UTC()
		entry.ExpiresAt = &t
	}
	return s.store.AddBlacklistEntry(ctx, entry)
}

// ClearBlacklist は口座のブラック登録を解除する。
func (s *Service) ClearBlacklist(ctx context.Context, accountID string) error {
	if accountID == "" {
		return fmt.Errorf("%w: account_id is required", ErrInvalidInput)
	}
	return s.store.ClearBlacklist(ctx, accountID, s.now().UTC())
}

func validatePurpose(p Purpose) error {
	switch p {
	case PurposeFood, PurposeMedicine, PurposeEnergy:
		return nil
	default:
		return ErrInvalidPurpose
	}
}

func marshalMetadata(meta map[string]any) ([]byte, error) {
	if meta == nil || len(meta) == 0 {
		return nil, nil
	}
	return json.Marshal(meta)
}

type witnessPayload struct {
	CommandID string         `json:"command_id"`
	AccountID string         `json:"account_id"`
	Amount    int64          `json:"amount"`
	Currency  string         `json:"currency"`
	Purpose   Purpose        `json:"purpose"`
	Quantity  float64        `json:"quantity"`
	Unit      string         `json:"unit"`
	Recorded  time.Time      `json:"recorded_at"`
	Metadata  map[string]any `json:"metadata,omitempty"`
}

func buildWitnessPayload(cmd *Command, in SettleCommandInput, recordedAt time.Time) ([]byte, error) {
	payload := witnessPayload{
		CommandID: cmd.ID,
		AccountID: cmd.AccountID,
		Amount:    cmd.Amount,
		Currency:  cmd.Currency,
		Purpose:   cmd.Purpose,
		Quantity:  in.Quantity,
		Unit:      in.Unit,
		Recorded:  recordedAt,
	}
	if len(in.Extra) > 0 {
		payload.Metadata = in.Extra
	}
	return json.Marshal(payload)
}

func ptrFloat64(v float64) *float64 {
	return &v
}

func ptrString(v string) *string {
	return &v
}
