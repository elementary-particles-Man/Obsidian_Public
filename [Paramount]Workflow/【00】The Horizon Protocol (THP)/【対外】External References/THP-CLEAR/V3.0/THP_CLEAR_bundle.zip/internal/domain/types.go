package domain

import (
	"time"
)

// Purpose は用途タグ (Food / Medicine / Energy) を表す。
type Purpose string

const (
	PurposeFood     Purpose = "F"
	PurposeMedicine Purpose = "M"
	PurposeEnergy   Purpose = "E"
)

// AccountStatus は決済口座の状態。
type AccountStatus string

const (
	AccountActive AccountStatus = "active"
	AccountFrozen AccountStatus = "frozen"
)

// CommandStatus は命令の状態。
type CommandStatus string

const (
	CommandPending  CommandStatus = "pending"
	CommandSettled  CommandStatus = "settled"
	CommandRejected CommandStatus = "rejected"
)

// Account は決済残高を保持するデビット口座。
type Account struct {
	ID          string
	DisplayName string
	Currency    string
	Balance     int64 // 通貨の最小単位（例: 円なら1円）
	Status      AccountStatus
	CreatedAt   time.Time
	UpdatedAt   time.Time
}

// BlacklistEntry はブラックリスト登録。
type BlacklistEntry struct {
	ID        int64
	AccountID string
	Reason    string
	ExpiresAt *time.Time
	CreatedAt time.Time
	Active    bool
}

// Command は用途別の決済命令を表す。
type Command struct {
	ID          string
	AccountID   string
	Amount      int64
	Currency    string
	Purpose     Purpose
	Status      CommandStatus
	Metadata    map[string]any
	RequestedAt time.Time
	SettledAt   *time.Time
	Quantity    *float64
	Unit        *string
	WitnessHash *string
}

// WitnessEntry はWitness台帳に記録される改ざん防止ログ。
type WitnessEntry struct {
	ID           int64
	CommandID    string
	Payload      []byte
	Hash         string
	PreviousHash string
	Signature    []byte
	RecordedAt   time.Time
}
