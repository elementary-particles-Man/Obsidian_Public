package domain

import "errors"

var (
	ErrAccountNotFound   = errors.New("account not found")
	ErrAccountFrozen     = errors.New("account frozen")
	ErrInsufficientFunds = errors.New("insufficient funds")
	ErrBlacklisted       = errors.New("account blacklisted")
	ErrInvalidPurpose    = errors.New("invalid purpose")
	ErrCommandNotFound   = errors.New("command not found")
	ErrCommandSettled    = errors.New("command already settled")
	ErrCommandRejected   = errors.New("command rejected")
	ErrInvalidInput      = errors.New("invalid input")
)
