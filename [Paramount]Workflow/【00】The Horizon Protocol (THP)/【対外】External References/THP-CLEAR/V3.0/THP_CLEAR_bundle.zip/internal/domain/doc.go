package domain

// TODO: Command, Settlement, Witness のドメインモデルを実装。
