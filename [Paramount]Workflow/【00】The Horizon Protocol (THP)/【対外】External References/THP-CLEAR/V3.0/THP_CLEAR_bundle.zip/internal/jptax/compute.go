package jptax

import (
	"errors"
	"math"
	"strings"
)

var (
	ErrInvalidBaseAmount = errors.New("invalid base amount")
	ErrInvalidTaxRate    = errors.New("invalid tax rate")
)

// Mode represents the rounding strategy mandated by JP tax regulations.
type Mode string

const (
	ModeRound Mode = "round"
	ModeFloor Mode = "floor"
	ModeCeil  Mode = "ceil"
)

// ComputationInput captures the values required to perform a JP consumption tax computation.
type ComputationInput struct {
	BaseAmount float64
	TaxRate    float64
}

// ComputationResult contains the rounded amounts derived from a ComputationInput.
type ComputationResult struct {
	RoundedBase int64
	TaxAmount   int64
	TotalAmount int64
}

// Round applies the requested rounding mode to the provided value.
func Round(value float64, mode Mode) int64 {
	switch Mode(strings.ToLower(string(mode))) {
	case ModeFloor:
		return int64(math.Floor(value))
	case ModeCeil:
		return int64(math.Ceil(value))
	default:
		return int64(math.Round(value))
	}
}

// ComputeTax applies the 国税庁 rounding rules:
//   - Base amount: 四捨五入 (ModeRound)
//   - Consumption tax: 切り捨て (ModeFloor)
//   - Total display: 四捨五入 (ModeRound)
func ComputeTax(input ComputationInput) (ComputationResult, error) {
	if err := validate(input); err != nil {
		return ComputationResult{}, err
	}

	roundedBase := Round(input.BaseAmount, ModeRound)
	tax := Round(float64(roundedBase)*input.TaxRate, ModeFloor)
	total := Round(float64(roundedBase)+float64(tax), ModeRound)

	return ComputationResult{
		RoundedBase: roundedBase,
		TaxAmount:   tax,
		TotalAmount: total,
	}, nil
}

func validate(input ComputationInput) error {
	switch {
	case math.IsNaN(input.BaseAmount), math.IsInf(input.BaseAmount, 0):
		return ErrInvalidBaseAmount
	case math.IsNaN(input.TaxRate), math.IsInf(input.TaxRate, 0):
		return ErrInvalidTaxRate
	case input.TaxRate < 0:
		return ErrInvalidTaxRate
	default:
		return nil
	}
}
