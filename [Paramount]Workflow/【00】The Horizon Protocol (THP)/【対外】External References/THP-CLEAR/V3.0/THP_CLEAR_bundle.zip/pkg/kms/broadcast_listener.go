package kms

import (
  "encoding/json"
  "log"
)

type KeyRotateMsg struct {
  Event string `json:"event"`
  KidNew string `json:"kid_new"`
  AAD string `json:"aad"`
  Wrap string `json:"wrap"`
  Ts string `json:"ts"`
}

func HandleBroadcast(msg []byte, unwrap func(wrapB64,aadB64 string) ([]byte,error)) (string, error) {
  var m KeyRotateMsg
  if err := json.Unmarshal(msg,&m); err != nil { return "", err }
  kNew, err := unwrap(m.Wrap, m.AAD)
  if err != nil { return "", err }
  log.Printf("[KMS] Key rotated: %s (%d bytes)", m.KidNew, len(kNew))
  return m.KidNew, nil
}
