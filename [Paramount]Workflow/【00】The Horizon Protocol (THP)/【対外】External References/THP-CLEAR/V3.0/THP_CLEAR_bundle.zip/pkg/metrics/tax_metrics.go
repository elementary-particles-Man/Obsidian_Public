package metrics

import (
	"net/http"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

var (
	TaxBatchBytes       = prometheus.NewGauge(prometheus.GaugeOpts{Name: "tax_batch_bytes", Help: "current batch size in bytes"})
	TaxFlushCount       = prometheus.NewCounter(prometheus.CounterOpts{Name: "tax_flush_total", Help: "total flush operations"})
	TaxWarnTotal        = prometheus.NewCounterVec(prometheus.CounterOpts{Name: "tax_warn_total", Help: "total warnings emitted during tax processing"}, []string{"code"})
	CreditNoteLinkTotal = prometheus.NewCounterVec(prometheus.CounterOpts{Name: "creditnote_link_total", Help: "total credit note link operations"}, []string{})
	TaxDuplicateTotal   = prometheus.NewCounterVec(prometheus.CounterOpts{Name: "duplicate_total", Help: "total duplicate message detections"}, []string{})
)

func Init() {
	prometheus.MustRegister(
		TaxBatchBytes,
		TaxFlushCount,
		TaxWarnTotal,
		CreditNoteLinkTotal,
		TaxDuplicateTotal,
	)
}

func Handler() http.Handler {
	return promhttp.Handler()
}

// Ensure Init() is called from main if metrics are used standalone
func EnsureInit() { Init() }
