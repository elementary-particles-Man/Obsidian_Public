package monitor

import (
	"net/http"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

// Metrics はPrometheusメトリクス管理を行う。
type Metrics struct {
	registry        *prometheus.Registry
	commandsIssued  prometheus.Counter
	commandsSettled prometheus.Counter
	apiRequests     *prometheus.CounterVec
	apiLatency      *prometheus.HistogramVec
}

// New はメトリクスを初期化する。
func New() *Metrics {
	reg := prometheus.NewRegistry()

	m := &Metrics{
		registry: reg,
		commandsIssued: prometheus.NewCounter(prometheus.CounterOpts{
			Name: "thp_clear_commands_issued_total",
			Help: "Number of commands issued",
		}),
		commandsSettled: prometheus.NewCounter(prometheus.CounterOpts{
			Name: "thp_clear_commands_settled_total",
			Help: "Number of commands settled",
		}),
		apiRequests: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "thp_clear_api_requests_total",
				Help: "API request count",
			},
			[]string{"path", "method", "status"},
		),
		apiLatency: prometheus.NewHistogramVec(
			prometheus.HistogramOpts{
				Name:    "thp_clear_api_latency_seconds",
				Help:    "Latency of API handlers",
				Buckets: prometheus.DefBuckets,
			},
			[]string{"path", "method"},
		),
	}

	reg.MustRegister(m.commandsIssued, m.commandsSettled, m.apiRequests, m.apiLatency)
	return m
}

// Handler はPrometheusエンドポイントを返す。
func (m *Metrics) Handler() http.Handler {
	gatherer := prometheus.Gatherers{
		m.registry,
		prometheus.DefaultGatherer,
	}
	return promhttp.HandlerFor(gatherer, promhttp.HandlerOpts{})
}

// IncIssued increments command issuance metric.
func (m *Metrics) IncIssued() {
	m.commandsIssued.Inc()
}

// IncSettled increments settlement metric.
func (m *Metrics) IncSettled() {
	m.commandsSettled.Inc()
}

// ObserveRequest records API request metrics.
func (m *Metrics) ObserveRequest(path, method, status string, duration time.Duration) {
	m.apiRequests.WithLabelValues(path, method, status).Inc()
	m.apiLatency.WithLabelValues(path, method).Observe(duration.Seconds())
}
