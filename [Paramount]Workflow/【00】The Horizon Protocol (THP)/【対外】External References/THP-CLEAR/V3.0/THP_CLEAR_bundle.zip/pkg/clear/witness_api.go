package clear

import (
  "bytes"
  "encoding/json"
  "log"
  "net/http"
)

type WitnessRecord struct {
  Type string `json:"type"`
  CommitID string `json:"commit_id"`
  Kid string `json:"kid"`
  Sha256Plain string `json:"sha256_plain"`
  Sha256Cipher string `json:"sha256_cipher"`
  DBENode string `json:"dbe_node"`
  Epoch int64 `json:"epoch"`
}

func PostWitness(endpoint string, wr WitnessRecord){
  b,_ := json.Marshal(wr)
  _,err := http.Post(endpoint,"application/json",bytes.NewReader(b))
  if err!=nil{log.Println("[CLEAR] post failed",err)} else {log.Println("[CLEAR] witness recorded")}
}
