package util

import (
  "crypto/sha256"
  "sync"
  "time"
)

type IdempotencySet struct {
  mu sync.Mutex
  data map[[32]byte]int64
  ttl time.Duration
}

func NewIdempotencySet(ttl time.Duration) *IdempotencySet {
  return &IdempotencySet{data: make(map[[32]byte]int64), ttl: ttl}
}

func (s *IdempotencySet) Seen(b []byte) bool {
  h := sha256.Sum256(b)
  s.mu.Lock(); defer s.mu.Unlock()
  now := time.Now().Unix()
  if exp, ok := s.data[h]; ok && exp > now { return true }
  s.data[h] = now + int64(s.ttl.Seconds())
  return false
}

func (s *IdempotencySet) Cleanup() {
  now := time.Now().Unix()
  s.mu.Lock()
  for k,v := range s.data { if v < now { delete(s.data,k) } }
  s.mu.Unlock()
}
