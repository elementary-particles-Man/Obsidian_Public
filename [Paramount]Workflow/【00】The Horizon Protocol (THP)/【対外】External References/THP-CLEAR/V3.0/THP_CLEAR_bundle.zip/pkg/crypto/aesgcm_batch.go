package crypto

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/sha256"
	"encoding/base64"
)

type AesGcmEnvelope struct {
	Kid        string   `json:"kid"`
	Nonce      []byte   `json:"nonce"`
	AAD        []byte   `json:"aad"`
	Ciphertext []byte   `json:"ciphertext"`
	Tag        []byte   `json:"tag"`
	PlainHash  [32]byte `json:"sha256_plain"`
}

func EncryptAESGCM(key, nonce, aad, plain []byte) (AesGcmEnvelope, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return AesGcmEnvelope{}, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return AesGcmEnvelope{}, err
	}
	cipherText := gcm.Seal(nil, nonce, plain, aad)
	tag := cipherText[len(cipherText)-16:]
	body := cipherText[:len(cipherText)-16]
	h := sha256.Sum256(plain)
	return AesGcmEnvelope{Nonce: nonce, AAD: aad, Ciphertext: body, Tag: tag, PlainHash: h}, nil
}

func DecryptAESGCM(key []byte, env AesGcmEnvelope) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	full := append(env.Ciphertext, env.Tag...)
	plain, err := gcm.Open(nil, env.Nonce, full, env.AAD)
	if err != nil {
		return nil, err
	}
	return plain, nil
}

func (e AesGcmEnvelope) ToBase64() map[string]string {
	m := map[string]string{
		"nonce":      base64.StdEncoding.EncodeToString(e.Nonce),
		"aad":        base64.StdEncoding.EncodeToString(e.AAD),
		"ciphertext": base64.StdEncoding.EncodeToString(append(e.Ciphertext, e.Tag...)),
	}
	if e.Kid != "" {
		m["kid"] = e.Kid
	}
	if e.PlainHash != ([32]byte{}) {
		m["sha256_plain"] = base64.StdEncoding.EncodeToString(e.PlainHash[:])
	}
	return m
}
