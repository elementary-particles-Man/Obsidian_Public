package crypto

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"os"
)

// Signer はEd25519秘密鍵に基づく署名器。
type Signer struct {
	priv ed25519.PrivateKey
}

// Generate は新しい署名器を生成する。
func Generate() (*Signer, error) {
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, err
	}
	return &Signer{priv: priv}, nil
}

// FromPrivateKey はEd25519秘密鍵（64バイト）から署名器を生成する。
func FromPrivateKey(priv ed25519.PrivateKey) (*Signer, error) {
	if len(priv) != ed25519.PrivateKeySize {
		return nil, errors.New("invalid private key length")
	}
	cp := make(ed25519.PrivateKey, len(priv))
	copy(cp, priv)
	return &Signer{priv: cp}, nil
}

// LoadOrCreate はファイルから秘密鍵を読み込み、存在しなければ新規生成する。
// ファイル形式はbase64エンコードされたEd25519秘密鍵。
func LoadOrCreate(path string) (*Signer, error) {
	if _, err := os.Stat(path); err == nil {
		return load(path)
	} else if !errors.Is(err, os.ErrNotExist) {
		return nil, err
	}

	s, err := Generate()
	if err != nil {
		return nil, err
	}
	if err := save(path, s.priv); err != nil {
		return nil, err
	}
	return s, nil
}

func load(path string) (*Signer, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	raw := make([]byte, base64.StdEncoding.DecodedLen(len(data)))
	n, err := base64.StdEncoding.Decode(raw, data)
	if err != nil {
		return nil, err
	}
	raw = raw[:n]
	return FromPrivateKey(ed25519.PrivateKey(raw))
}

func save(path string, priv ed25519.PrivateKey) error {
	encoded := base64.StdEncoding.EncodeToString(priv)
	return os.WriteFile(path, []byte(encoded), 0o600)
}

// Sign はデータに署名する。
func (s *Signer) Sign(data []byte) ([]byte, error) {
	if s == nil || len(s.priv) == 0 {
		return nil, errors.New("signer not initialized")
	}
	sig := ed25519.Sign(s.priv, data)
	return sig, nil
}

// PublicKey は公開鍵を返す。
func (s *Signer) PublicKey() []byte {
	if s == nil || len(s.priv) == 0 {
		return nil
	}
	pub := make([]byte, ed25519.PublicKeySize)
	copy(pub, s.priv[32:])
	return pub
}

// PrivateKey は内部保持している秘密鍵のコピーを返す。
func (s *Signer) PrivateKey() []byte {
	if s == nil {
		return nil
	}
	out := make([]byte, len(s.priv))
	copy(out, s.priv)
	return out
}
