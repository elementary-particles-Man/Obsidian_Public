package witness

import (
  "crypto/hmac"
  "crypto/sha256"
  "encoding/binary"
  "time"
)

type TaxPointer struct {
  Version [8]byte
  Epoch uint64
  CommitHash [16]byte
  KidHash [16]byte
  PlainHash [16]byte
  CipherHash [16]byte
  DBENodeHash [16]byte
  Reserved [16]byte
  HMAC [16]byte
}

func NewTaxPointer(clearKey []byte, commitID, kid, plain, cipher, dbeNode string) TaxPointer {
  tp := TaxPointer{}
  copy(tp.Version[:], []byte("WTX1.0\x00"))
  tp.Epoch = uint64(time.Now().Unix())
  tp.CommitHash = shortHash(commitID)
  tp.KidHash = shortHash(kid)
  tp.PlainHash = shortHash(plain)
  tp.CipherHash = shortHash(cipher)
  tp.DBENodeHash = shortHash(dbeNode)
  mac := hmac.New(sha256.New, clearKey)
  mac.Write(append(tp.Version[:], byteSlice(tp.Epoch)...))
  mac.Write(tp.CommitHash[:]); mac.Write(tp.KidHash[:]); mac.Write(tp.PlainHash[:]); mac.Write(tp.CipherHash[:]); mac.Write(tp.DBENodeHash[:])
  copy(tp.HMAC[:], mac.Sum(nil)[:16])
  return tp
}

func shortHash(s string) [16]byte {
  h := sha256.Sum256([]byte(s))
  var out [16]byte
  copy(out[:], h[:16])
  return out
}

func byteSlice(v uint64) []byte { b := make([]byte,8); binary.BigEndian.PutUint64(b,v); return b }
