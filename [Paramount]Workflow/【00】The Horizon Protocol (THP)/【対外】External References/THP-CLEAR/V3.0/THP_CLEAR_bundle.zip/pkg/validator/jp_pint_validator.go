package validator

import "strings"

func Validate(xml string) []string {
	if strings.Contains(xml, "MissingTaxId") {
		return []string{"MISSING_TAXID"}
	}
	return nil
}
