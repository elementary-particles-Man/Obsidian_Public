package peppol

import (
  "crypto/sha256"
  "encoding/base64"
)

func SignPupeleStub(data []byte, certID string) string {
  h := sha256.Sum256(data)
  sig := base64.StdEncoding.EncodeToString(h[:])
  return "PupeleStub-"+certID+"-"+sig
}
