package peppol

import (
  "bytes"
  "log"
  "net/http"
)

func SendAS4(endpoint string, xmlData []byte) error {
  resp,err := http.Post(endpoint,"application/xml",bytes.NewReader(xmlData))
  if err!=nil { return err }
  defer resp.Body.Close()
  log.Printf("[Peppol-AS4] sent to %s status=%s",endpoint,resp.Status)
  return nil
}

// SendAS4WithSig posts XML with signature header for verification demo.
func SendAS4WithSig(endpoint string, xmlData []byte, sig string) error {
  req, err := http.NewRequest("POST", endpoint, bytes.NewReader(xmlData))
  if err != nil { return err }
  req.Header.Set("Content-Type", "application/xml")
  if sig != "" { req.Header.Set("X-Peppol-Signature", sig) }
  resp, err := http.DefaultClient.Do(req)
  if err != nil { return err }
  defer resp.Body.Close()
  log.Printf("[Peppol-AS4] sent(sig) to %s status=%s", endpoint, resp.Status)
  return nil
}