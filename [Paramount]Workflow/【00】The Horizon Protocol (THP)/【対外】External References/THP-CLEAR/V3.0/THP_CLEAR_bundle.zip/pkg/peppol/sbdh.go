package peppol

import (
  "encoding/xml"
  "time"
)

type StandardBusinessDocument struct {
  XMLName xml.Name `xml:"StandardBusinessDocument"`
  Header  SBDHHeader `xml:"StandardBusinessDocumentHeader"`
  Payload []byte     `xml:",innerxml"`
}

type SBDHHeader struct {
  Sender string `xml:"Sender>Identifier"`
  Receiver string `xml:"Receiver>Identifier"`
  DocumentID string `xml:"DocumentIdentification>InstanceIdentifier"`
  CreationDateAndTime string `xml:"DocumentIdentification>CreationDateAndTime"`
}

func WrapSBDH(sender,receiver,docid string,payload []byte) ([]byte,error){
  sbd := StandardBusinessDocument{
    Header: SBDHHeader{Sender:sender,Receiver:receiver,DocumentID:docid,CreationDateAndTime:time.Now().Format(time.RFC3339)},
    Payload: payload,
  }
  return xml.MarshalIndent(sbd,"","  ")
}
