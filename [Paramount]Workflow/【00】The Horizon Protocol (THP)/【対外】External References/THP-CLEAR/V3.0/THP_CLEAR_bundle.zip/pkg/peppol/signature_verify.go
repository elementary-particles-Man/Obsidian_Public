package peppol

import (
  "crypto/sha256"
  "encoding/base64"
  "strings"
)

// VerifyPupeleStub recomputes SHA-256 over payload and checks PupeleStub-<cert>-<b64sha256>
func VerifyPupeleStub(data []byte, certID, sig string) bool {
  if !strings.HasPrefix(sig, "PupeleStub-"+certID+"-") { return false }
  want := sig[len("PupeleStub-"+certID+"-"):]
  h := sha256.Sum256(data)
  got := base64.StdEncoding.EncodeToString(h[:])
  return got == want
}
