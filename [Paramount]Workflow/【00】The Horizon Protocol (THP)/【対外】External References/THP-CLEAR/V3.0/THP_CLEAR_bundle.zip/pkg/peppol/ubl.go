package peppol

import (
  "encoding/xml"
  "time"
  "fmt"
)

type Invoice struct {
  XMLName xml.Name `xml:"Invoice"`
  XMLNs   string   `xml:"xmlns,attr"`
  ID      string   `xml:"cbc:ID"`
  IssueDate string   `xml:"cbc:IssueDate"`
  InvoiceTypeCode string `xml:"cbc:InvoiceTypeCode"`
  DocumentCurrencyCode string `xml:"cbc:DocumentCurrencyCode"`
  AccountingSupplierParty Party `xml:"cac:AccountingSupplierParty"`
  AccountingCustomerParty Party `xml:"cac:AccountingCustomerParty"`
  LegalMonetaryTotal MonetaryTotal `xml:"cac:LegalMonetaryTotal"`
}

type Party struct {
  PartyName string `xml:"cac:PartyName>cbc:Name"`
  ID string `xml:"cac:PartyIdentification>cbc:ID"`
}

type MonetaryTotal struct {
  PayableAmount string `xml:"cbc:PayableAmount"`
}

func GenerateUBLInvoice(id string, supplier, customer string, amount float64) ([]byte,error){
  inv := Invoice{
    XMLNs: "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2",
    ID: id,
    IssueDate: time.Now().Format("2006-01-02"),
    InvoiceTypeCode: "380",
    DocumentCurrencyCode: "JPY",
    AccountingSupplierParty: Party{PartyName:supplier,ID:"JP-SUP-001"},
    AccountingCustomerParty: Party{PartyName:customer,ID:"JP-CUS-001"},
    LegalMonetaryTotal: MonetaryTotal{PayableAmount: fmt.Sprintf("%.2f",amount)},
  }
  return xml.MarshalIndent(inv,"","  ")
}