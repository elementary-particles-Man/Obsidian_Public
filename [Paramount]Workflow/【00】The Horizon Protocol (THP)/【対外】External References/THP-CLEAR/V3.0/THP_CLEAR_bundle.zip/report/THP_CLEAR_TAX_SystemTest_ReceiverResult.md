# Peppol Receiver E2E Analysis

- **listening**: 1
- **verified_true**: 5
- **ack**: 5
