# THP-CLEAR-TAX Document Generation Summary

## Roadmap

# THP-CLEAR / CLEAR-TAX Roadmap

| Phase | 名称 | 目的 | 状況 |
|-------|------|------|------|
| 0 | 税務事務自動化基盤 | インボイス制度・帳簿保存完全自動化 | 実装中 |
| 1 | 税務証跡連携 | CLEAR Witness ↔ TAX Ledger 双方向同期 | 設計済 |
| 2 | 対外連携 (Peppol/JPIC) | 国際電子インボイス標準適合 | 進行中 |
| 3 | 政府・自治体統合 | KMS GOV層・自治体NW統合 | 設計予定 |
| 4 | グローバル展開 | 1000ノード構成・人道支援決済基盤 | 予定 |

## System Architecture

# System Architecture (Two-Layer Model)

```
      ┌───────────────────────────────┐
      │           THP-CLEAR           │
      │ Witness / MQ / DB-E / KMS     │
      │ Policy / PeppolLink           │
      └──────────────┬────────────────┘
                     │  mTLS / JSON API
      ┌──────────────┴────────────────┐
      │          CLEAR-TAX            │
      │ Tax Ledger / Invoice DB (AES) │
      │ AI-TAX Engine / UI / CSV      │
      └───────────────────────────────┘
```

- 証跡は CLEAR 層、詳細は TAX 層で保持。
- 双方 Prometheus 監視統合。

## AI-TAX Design Objective

# AI-TAX Design Objective

**目的:** THP-CLEAR の透明性を維持しつつ、税務事務の完全自動化を達成する。

**基本方針:**
- CLEAR-TAX (AI-TAX) は証跡層 CLEAR と連携。
- 税務処理ロジックは AES 暗号化で保持、Witness は ISE 封緘。
- 法改正不要・省令改訂のみで導入可能。
- 対外呼称 AI-TAX としてデジ庁電子インボイスと衝突しない互換運用。
