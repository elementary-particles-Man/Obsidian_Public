# THP_CLEAR_TAX_SystemTest_v31: DBE-TAX Ingest Timeline

- 10:25:39 JST — `[DBE-TAX] start HTTP server on :9443`
- 10:25:39 JST — `[DBE-TAX] start metrics exporter on :9100`
- 10:25:41 JST — `[DBE-TAX] received 194 bytes for ingest`
- 10:25:41 JST — `[DBE-TAX] flush fallback to /tmp/dbe-tax` (permission denied on `/zfs`, fallback engaged)
- 10:25:41 JST — `[DBE-TAX] flushed /tmp/dbe-tax/wn-tax-1762133141531468625.bin (14 bytes)`
- 10:25:41 JST — `[DBE-TAX] stub complete for wn-tax-1762133141531468625`

`tax_flush_total` counter incremented to `1` and `tax_batch_bytes` reported `14` bytes at scrape `http://localhost:9100/metrics`.
