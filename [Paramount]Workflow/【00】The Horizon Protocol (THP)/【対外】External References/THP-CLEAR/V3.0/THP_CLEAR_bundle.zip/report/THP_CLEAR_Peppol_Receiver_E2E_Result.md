# Peppol Receiver E2E Analysis

- **listening**: 1
- **sent**: 1
- **verified_true**: 1
- **ack**: 1
