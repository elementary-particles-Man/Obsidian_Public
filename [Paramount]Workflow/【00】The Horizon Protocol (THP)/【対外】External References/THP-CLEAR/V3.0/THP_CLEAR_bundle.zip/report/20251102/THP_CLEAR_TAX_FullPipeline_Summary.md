# THP-CLEAR-TAX Full Pipeline Summary

## Analysis

# TAX Pipeline Analysis

- **ok**: 1
- **dup**: 0
- **error**: 0
- **fail**: 0

## Metrics

```
# HELP tax_batch_bytes current batch size in bytes
# TYPE tax_batch_bytes gauge
tax_batch_bytes 0
# HELP tax_flush_total total flush operations
# TYPE tax_flush_total counter
tax_flush_total 0
```

## Raw Logs

```
2025/11/03 06:21:30 [WN-TAX] starting client batch sender ...
2025/11/03 06:21:30 Post "https://dbe-03:9443/tax/ingest": dial tcp: lookup dbe-03 on 192.168.234.1:53: no such host
2025/11/03 06:13:51 [DBE-TAX] launching server daemon on :9443 ...
2025/11/03 06:13:51 [DBE-TAX] HTTP server listening :9443
```
