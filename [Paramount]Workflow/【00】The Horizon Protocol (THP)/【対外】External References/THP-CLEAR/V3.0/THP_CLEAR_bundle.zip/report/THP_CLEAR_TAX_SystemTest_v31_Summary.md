# THP_CLEAR_TAX_SystemTest_v31 Summary

- `report/dbe-tax.log`: DBE-TAX サーバー起動、/tax/ingest 受信、ZFS フォールバック保存、メトリクスエクスポーター起動を確認。
- `report/receiver.log`: モック Peppol 受信サーバーが署名付き AS4 メッセージを受信し `/tmp/peppol` に保存したことを確認。
- `report/metrics_snapshot_v31.txt`: `tax_batch_bytes 14` と `tax_flush_total 1` がスクレイプされ、バッチサイズとフラッシュ回数が更新されていることを確認。
- `report/THP_CLEAR_TAX_SystemTest_v31_Result.md`: 起動からバッチ処理完了までのタイムラインを記録し、ZFS 書き込み権限がない環境では `/tmp/dbe-tax` へフォールバックした旨をドキュメント化。
