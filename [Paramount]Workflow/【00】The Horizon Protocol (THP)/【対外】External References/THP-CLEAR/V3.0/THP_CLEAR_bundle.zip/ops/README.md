# THP-CLEAR Operations Overview

This directory gathers operational policies that complement the main design policy. Detailed procedures continue to live in `docs/ops*.md`; the files here normalise the KPI definitions and aftermath processes for engineering teams.

- [`kpi/README.md`](kpi/README.md): Metric catalogue for the Ops-KPI dashboard, mapped to Prometheus names exposed by Go services.
- [`aftermath/README.md`](aftermath/README.md): Recovery and replay guidance aligned with DR specifications.

Refer to `docs/ops.md` and `docs/ops_JP.md` for full runbooks. The documents under `ops/` provide concise extracts that keep the repository structure synchronised with the latest metrics and recovery strategy.
