# Ops KPI & Metrics Catalogue

This document consolidates the Prometheus metrics used by the Ops-KPI dashboard and ties them to the E-MAD and DR monitoring requirements.

## API & Command Layer (Go surface)

Source: `pkg/monitor/metrics.go`

| Metric | Labels | Purpose |
| --- | --- | --- |
| `thp_clear_api_requests_total` | `path`, `method`, `status` | Request rate / success ratio for `clear-api`. |
| `thp_clear_api_latency_seconds` | `path`, `method` | Latency histogram for REST handlers (p95 < 1s target). |
| `thp_clear_commands_issued_total` | – | Number of commands issued via `/command`. |
| `thp_clear_commands_settled_total` | – | Number of commands settled via `/settle`. |

## Witness & E-MAD Layer

Source: `internal/monitoring/exporter.go`

| Metric | Purpose |
| --- | --- |
| `witness_append_total` | Count of successful witness appends (WORM). |
| `witness_verify_success_total` / `witness_verify_failed_total` | Signature verification outcomes during settlement. |
| `witness_verify_latency_seconds` | Histogram of witness settlement latency. |
| `emad_violation_score` | Latest E-MAD score injected by integration tests / Rust core. |

**E-MAD Thresholds**

- Alert when `emad_violation_score > 0.25` for more than 5 minutes (ethical anomaly risk).
- DR drillback target: restore the score to <= previous baseline within 30 minutes after recovery.

## KeyHub / KMS

Source: `internal/keyhub/metrics.go`, `src/kms/metrics.go`

| Metric | Labels | Purpose |
| --- | --- | --- |
| `keyhub_sign_total` | – | Total KeyHub signature operations. |
| `keyhub_epoch_current` | – | Current epoch derived from KeyHub master seed. |
| `kms_keyreq_total` | `node` | Accepted key requests per node. |
| `kms_challenge_fail_total` | `node` | Challenge verification failures. |
| `kms_decoy_issued_total` | `node` | Decoy signatures issued for SPY detection. |
| `kms_spy_alert_total` | `level` | SPY alerts by severity (`warn`, `block`). |
| `kms_rate_limited_total` | `node` | Requests rejected due to rate limiting. |

**Operational checks**:
- Success rate (`1 - rate(kms_rate_limited_total)/rate(kms_keyreq_total)`) must stay above 99.9% / 5 min.
- Trigger security response if `kms_spy_alert_total{level="block"}` increments.

## Node Authentication Metrics

Source: `src/common/nodeauth/metrics.go`

| Metric | Labels | Purpose |
| --- | --- | --- |
| `node_key_fetch_total` | `status` | KMS ticket fetch outcome (`ok`, `error`, `blocked`). |
| `node_key_ticket_fail_total` | `reason` | Ticket verification failures (e.g., `decoy`). |
| `node_spy_alert_total` | `level` | SPY alerts received by each node. |
| `kms_multi_inflight` | `node_role` | Current number of in-flight KMS quorum requests. |
| `kms_challenge_failover_total` | `node_role` | Failovers during challenge phase. |
| `kms_submit_retry_total` | `node_role` | Submit retries triggered by nodes. |
| `kms_sessions_in_use` | `node_role` | Pending KMS sessions awaiting completion. |
| `kms_quorum_met_total` / `kms_quorum_failed_total` | `node_role` | Quorum success/failure counters. |

These metrics feed the Ops-KPI dashboard panels for MQD, WND, and DBD health.

## Dashboard Alignment

- Grafana dashboards `dashboards/keyhub_witness_ops.json` and `dashboards/e20_emad_overview.json` should map directly to the metrics listed above.
- Incident response (`ops/aftermath/README.md`) references the same metrics when defining recovery RTO/RPO targets.
- Maintain metric names when implementing Rust FFI modules; Prometheus queries form part of the DR acceptance tests.

By curating the metric catalogue here, Ops teams can keep dashboards, alerts, and documentation synchronized with the actual Go instrumentation.
