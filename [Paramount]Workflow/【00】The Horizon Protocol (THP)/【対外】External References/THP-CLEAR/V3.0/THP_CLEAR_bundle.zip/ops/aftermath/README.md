# Aftermath Recovery Guide

Aftermath operations cover incident response, manual replay, and reconciliation activities after a DR event. Full runbooks live in `docs/ops.md`; this document distils the critical steps and metrics for quick reference.

## Recovery Objectives

- **RTO**: 30 minutes from incident detection to restored API availability.
- **RPO**: 15 minutes (SQLite hot backup cadence + Witness JSONL replication).
- **Integrity**: Witness hash continuity verified against both SQLite and JSONL copies.

## Core Steps

1. **Quarantine & Alerting**
   - Monitor `node_spy_alert_total{level="block"}` for tamper signals.
   - Pause queue intake (`nats stream pause witness`) before replay.
2. **Data Replay**
   - Use deterministic replay scripts (planned: `ops/aftermath/replay.md`) to hydrate SQLite from Witness JSONL.
   - Validate with `sqlite3 data/clear.db "PRAGMA integrity_check;"` and compare witness hashes.
3. **Key Material Checks**
   - Inspect KMS audit logs for compromised key IDs (`kms_spy_alert_total`).
   - Rotate keys via `/internal/kms/sign`/`/internal/kms/pubkey` if necessary.
4. **Metrics Verification**
   - Confirm `witness_append_total` and `witness_verify_success_total` resume incrementing post-replay.
   - Ensure `emad_violation_score` returns to pre-incident baseline.
5. **Operational Sign-off**
   - Document timeline and remediation in the audit log; notify DR stakeholders per `docs/ops.md` escalation matrix.

## Dependencies

- Relies on the metric catalogue defined in `ops/kpi/README.md` for alert thresholds.
- Requires Go services (`cmd/dbd`, `cmd/mqd`, `cmd/wnd`) to expose `/control/spy` endpoints for incident signalling.
- Witness reconstruction must remain compatible with the hash/signature rules defined in `core/witness/README.md`.

Keeping these touchpoints synchronized ensures that Aftermath procedures remain aligned with the evolving Go/Rust architecture.
