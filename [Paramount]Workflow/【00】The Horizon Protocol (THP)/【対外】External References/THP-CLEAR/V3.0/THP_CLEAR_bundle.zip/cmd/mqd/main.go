package main

import (
	"encoding/json"
	"flag"
	"log/slog"
	"net/http"
	"os"
	"time"

	"thp-clear/src/MQ/encryptor"
	"thp-clear/src/common/audit"
	"thp-clear/src/common/kmsclient"
	"thp-clear/src/common/kmsproto"
	"thp-clear/src/common/nodeauth"
)

func main() {
	configPath := flag.String("config", "configs/node.mq.yaml", "path to node config")
	flag.Parse()

	logger := slog.New(slog.NewTextHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelInfo}))

	cfg, err := loadNodeConfig(*configPath)
	if err != nil {
		logger.Error("load config", "error", err)
		os.Exit(1)
	}

	auditLogger, err := audit.NewJSONL(cfg.Audit.Path)
	if err != nil {
		logger.Error("init audit logger", "error", err)
		os.Exit(1)
	}
	defer auditLogger.Close()

	nodeID, commitEntries, err := nodeauth.LoadCommitFile(cfg.RegStore)
	if err != nil {
		logger.Error("load commit file", "error", err)
		os.Exit(1)
	}

	store := nodeauth.NewStore(nodeID, commitEntries)
	ring, err := encryptor.NewKeyRing()
	if err != nil {
		logger.Error("init keyring", "error", err)
		os.Exit(1)
	}

	httpClient, err := cfg.NewHTTPClient()
	if err != nil {
		logger.Error("init http client", "error", err)
		os.Exit(1)
	}

	nodeMetrics := nodeauth.NewPromMetrics(cfg.Role)

	kmsClient := kmsclient.NewMulti(cfg.KMSURLs, cfg.Quorum,
		kmsclient.WithHTTPClient(httpClient),
		kmsclient.WithHooks(nodeMetrics.KMSHooks()),
	)
	defer kmsClient.Close()

	pubKeys, err := cfg.LoadPublicKeys()
	if err != nil {
		logger.Error("load kms public keys", "error", err)
		os.Exit(1)
	}

	manager, err := nodeauth.NewManager(store, ring, kmsClient, nodeauth.ManagerConfig{
		NodeID:        nodeID,
		KeyType:       cfg.Key.Type,
		MaxRetry:      cfg.Key.MaxRetry,
		Backoff:       cfg.Key.BackoffDurations(),
		WarnBackoff:   cfg.Spy.WarnBackoff(),
		BlockDuration: cfg.Spy.BlockDuration(),
		PublicKeys:    pubKeys,
		Threshold:     cfg.Threshold,
		Metrics:       nodeMetrics.AsRecorder(),
		Audit:         auditLogger,
	})
	if err != nil {
		logger.Error("init key manager", "error", err)
		os.Exit(1)
	}

	metricsServer := &http.Server{Addr: cfg.Metrics.Listen, Handler: nodeMetrics.Handler()}
	go func() {
		logger.Info("metrics listening", "addr", cfg.Metrics.Listen)
		if err := metricsServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Error("metrics server error", "error", err)
		}
	}()

	go func() {
		ticker := time.NewTicker(30 * time.Second)
		defer ticker.Stop()
		for {
			epoch := currentEpoch(cfg.EpochMinutes)
			ctx, cancel := httpRequestContext()
			if err := manager.EnsureEpoch(ctx, epoch); err != nil {
				logger.Warn("key rotation failed", "error", err)
			}
			cancel()
			<-ticker.C
		}
	}()

	mux := http.NewServeMux()
	mux.HandleFunc("/control/spy", func(w http.ResponseWriter, r *http.Request) {
		var alert kmsproto.SpyAlert
		if err := json.NewDecoder(r.Body).Decode(&alert); err != nil {
			http.Error(w, "invalid json", http.StatusBadRequest)
			return
		}
		manager.HandleSpyAlert(&alert)
		w.WriteHeader(http.StatusAccepted)
	})

	server := &http.Server{Addr: cfg.Listen, Handler: mux}
	logger.Info("mqd control listening", "addr", cfg.Listen)
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		logger.Error("control server error", "error", err)
		os.Exit(1)
	}
}
