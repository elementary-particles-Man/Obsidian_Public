package main

import (
	"encoding/json"
	"flag"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"thp-clear/pkg/peppol"
)

type ack struct {
	Status   string `json:"status"`
	Verified bool   `json:"verified"`
}

func main() {
	listen := flag.String("listen", ":9555", "address to listen on, e.g. :9555")
	flag.Parse()

	http.HandleFunc("/peppol/receive", handleRecv)
	log.Printf("[Peppol-Receiver] listening %s /peppol/receive", *listen)
	log.Fatal(http.ListenAndServe(*listen, nil))
}

func handleRecv(w http.ResponseWriter, r *http.Request) {
	defer r.Body.Close()
	b, _ := io.ReadAll(r.Body)
	sig := r.Header.Get("X-Peppol-Signature")
	ok := peppol.VerifyPupeleStub(b, "CERT-DEMO-001", sig)
	_ = os.MkdirAll("/tmp/peppol", 0o755)
	fn := filepath.Join("/tmp/peppol", "incoming-"+time.Now().UTC().Format("20060102-150405")+".xml")
	_ = os.WriteFile(fn, b, 0o644)
	log.Printf("[Peppol-Receiver] len=%d verified=%v saved=%s", len(b), ok, fn)
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(ack{Status: "ACK", Verified: ok})
}
