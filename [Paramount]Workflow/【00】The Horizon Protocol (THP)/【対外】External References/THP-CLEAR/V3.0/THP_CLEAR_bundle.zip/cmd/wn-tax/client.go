package main

import (
	"bytes"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"

	"thp-clear/internal/jptax"
	"thp-clear/pkg/crypto"
)

var (
	dbeEndpoint    = "http://clear-dbe-tax:9101/tax/ingest"
	peppolEndpoint = "http://localhost:9555/peppol/receive"
	httpClient     = &http.Client{Timeout: 30 * time.Second}
	keyOnce        sync.Once
	keyMaterial    []byte
)

const (
	defaultInvoiceBase = 125000.0
	defaultTaxRate     = 0.1
)

func configureEndpoints(dbeURL, peppolURL string) {
	if dbe := strings.TrimSpace(dbeURL); dbe != "" {
		dbeEndpoint = dbe
	}
	if pep := strings.TrimSpace(peppolURL); pep != "" {
		peppolEndpoint = pep
	}
}

func postTaxBatch() (string, []byte, error) {
	key := currentAESKey()
	nonce := make([]byte, 12)
	aad := []byte("tax")
	plain := []byte("sample payload")
	env, err := crypto.EncryptAESGCM(key, nonce, aad, plain)
	if err != nil {
		return "", nil, fmt.Errorf("encrypt payload: %w", err)
	}
	env.Kid = fmt.Sprintf("wn-tax-%d", time.Now().UTC().UnixNano())
	data, err := json.Marshal(env.ToBase64())
	if err != nil {
		return "", nil, fmt.Errorf("marshal envelope: %w", err)
	}
	resp, err := httpClient.Post(dbeEndpoint, "application/json", bytes.NewReader(data))
	if err != nil {
		return "", nil, fmt.Errorf("POST %s: %w", dbeEndpoint, err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 2048))
	if resp.StatusCode >= 300 {
		return resp.Status, bytes.TrimSpace(body), fmt.Errorf("unexpected response status %s", resp.Status)
	}
	return resp.Status, bytes.TrimSpace(body), nil
}

func postPeppolInvoiceWithSig() (string, []byte, error) {
	taxResult, err := jptax.ComputeTax(jptax.ComputationInput{
		BaseAmount: defaultInvoiceBase,
		TaxRate:    defaultTaxRate,
	})
	if err != nil {
		return "", nil, fmt.Errorf("compute tax for invoice: %w", err)
	}

	invoiceID := fmt.Sprintf("INV-%d", time.Now().UTC().UnixNano())
	payload, err := buildJP_PINT_Invoice(InvoiceData{
		ID:               invoiceID,
		DocumentCurrency: "JPY",
		AccountingSupplier: Party{
			PartyName: "ACME Corp",
			ID:        "JP-SUP-001",
		},
		AccountingCustomer: Party{
			PartyName: "Tokyo Trading",
			ID:        "JP-CUS-001",
		},
		Tax: TaxTotal{
			TaxAmount: amountFromInt(taxResult.TaxAmount, "JPY"),
		},
		Total: MonetaryTotal{
			PayableAmount: amountFromInt(taxResult.TotalAmount, "JPY"),
		},
		ProfileID: "JP-PINT",
		IssueDate: time.Now().UTC(),
	})
	if err != nil {
		return "", nil, fmt.Errorf("build JP PINT invoice: %w", err)
	}
	if err := SendToPeppol(peppolEndpoint, payload); err != nil {
		return "", nil, fmt.Errorf("send JP PINT invoice: %w", err)
	}
	return postTaxBatch()
}

func currentAESKey() []byte {
	keyOnce.Do(func() {
		keyMaterial = deriveAESKey()
	})
	if len(keyMaterial) != 32 {
		return make([]byte, 32)
	}
	buf := make([]byte, 32)
	copy(buf, keyMaterial)
	return buf
}

func deriveAESKey() []byte {
	candidates := []string{
		strings.TrimSpace(os.Getenv("WN_TAX_AES_KEY")),
		strings.TrimSpace(os.Getenv("DBE_TAX_AES_KEY")),
	}
	for _, candidate := range candidates {
		if candidate == "" {
			continue
		}
		raw, err := decodeKeyString(candidate)
		if err != nil {
			log.Printf("[WN-TAX] AES key decode failed: %v", err)
			continue
		}
		return raw
	}
	return nil
}

func decodeKeyString(val string) ([]byte, error) {
	val = strings.TrimSpace(val)
	if val == "" {
		return nil, fmt.Errorf("empty key")
	}
	if raw, err := hex.DecodeString(val); err == nil && len(raw) == 32 {
		return raw, nil
	}
	if raw, err := base64.StdEncoding.DecodeString(val); err == nil && len(raw) == 32 {
		return raw, nil
	}
	if len(val) == 32 {
		return []byte(val), nil
	}
	return nil, fmt.Errorf("unsupported key format or length %d", len(val))
}
