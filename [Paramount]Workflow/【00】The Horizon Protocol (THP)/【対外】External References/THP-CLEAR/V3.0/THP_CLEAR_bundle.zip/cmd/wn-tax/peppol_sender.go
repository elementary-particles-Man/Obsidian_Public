package main

import (
	"time"

	"thp-clear/internal/peppoljp"
)

// --- DR-20251106 対応: JP PINT / Peppol BIS Billing 3.0 準拠送信 ---
// XML生成部を修正し、要素IDおよびNamespaceをJP PINT仕様に統一。
// https://www.digital.go.jp/policies/jp-pint に準拠。

const jpPintNS = peppoljp.NamespaceJP

type (
	InvoiceData   = peppoljp.InvoiceData
	Party         = peppoljp.Party
	TaxTotal      = peppoljp.TaxTotal
	MonetaryTotal = peppoljp.MonetaryTotal
	Amount        = peppoljp.Amount
)

func buildJP_PINT_Invoice(inv InvoiceData) ([]byte, error) {
	if inv.IssueDate.IsZero() {
		inv.IssueDate = time.Now().UTC()
	}
	return peppoljp.BuildInvoice(inv)
}

func SendToPeppol(endpoint string, payload []byte) error {
	return peppoljp.SendWithClient(httpClient, endpoint, payload)
}

func amountFromInt(value int64, currency string) Amount {
	return peppoljp.AmountFromInt(value, currency)
}
