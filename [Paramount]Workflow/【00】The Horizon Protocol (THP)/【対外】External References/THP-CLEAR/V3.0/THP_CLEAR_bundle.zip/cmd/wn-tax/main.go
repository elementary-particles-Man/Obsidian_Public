package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync/atomic"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

var (
	as4SendTotal    = promauto.NewCounter(prometheus.CounterOpts{Name: "as4_send_total", Help: "Total successful Peppol AS4 sends"})
	as4SendFailures = promauto.NewCounter(prometheus.CounterOpts{Name: "as4_send_failures_total", Help: "Total failed Peppol AS4 send attempts"})
	lastSendOK      atomic.Bool
	lastSendError   atomic.Value
	lastSendAt      atomic.Int64
)

type runtimeConfig struct {
	sendInterval   time.Duration
	httpAddr       string
	dbeEndpoint    string
	peppolEndpoint string
	oneShot        bool
}

func main() {
	cfg := loadRuntimeConfig()

	configureEndpoints(cfg.dbeEndpoint, cfg.peppolEndpoint)
	lastSendError.Store("initializing")

	if cfg.oneShot || cfg.sendInterval <= 0 {
		log.Println("[WN-TAX] starting client batch sender ...")
		if ok := sendOnce(); !ok {
			log.Println("[WN-TAX] batch send failed; exiting with status 1")
			os.Exit(1)
		}
		return
	}

	log.Printf("[WN-TAX] starting client batch sender loop interval=%s", cfg.sendInterval)
	go startSender(cfg.sendInterval)

	if cfg.httpAddr == "" {
		select {}
	}
	if err := serveHTTP(cfg.httpAddr); err != nil {
		log.Fatalf("[WN-TAX] http server error: %v", err)
	}
}

func startSender(interval time.Duration) {
	time.Sleep(5 * time.Second)
	sendOnce()
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for range ticker.C {
		sendOnce()
	}
}

func sendOnce() bool {
	status, body, err := postPeppolInvoiceWithSig()
	now := time.Now()
	lastSendAt.Store(now.Unix())
	if err != nil {
		as4SendFailures.Inc()
		lastSendOK.Store(false)
		lastSendError.Store(fmt.Sprintf("send failed: %v", err))
		log.Printf("[WN-TAX] send failed status=%s err=%v body=%q", status, err, body)
		return false
	}
	as4SendTotal.Inc()
	lastSendOK.Store(true)
	lastSendError.Store("")
	log.Printf("[WN-TAX] send ok status=%s body=%q", status, body)
	return true
}

func healthHandler(w http.ResponseWriter, _ *http.Request) {
	if lastSendOK.Load() {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
		return
	}
	w.WriteHeader(http.StatusServiceUnavailable)
	if errMsg, ok := lastSendError.Load().(string); ok && errMsg != "" {
		_, _ = w.Write([]byte(errMsg))
		return
	}
	_, _ = w.Write([]byte("sender not ready"))
}

func sendInterval() time.Duration {
	const fallback = 30 * time.Second
	raw := os.Getenv("WN_TAX_SEND_INTERVAL")
	if raw == "" {
		return fallback
	}
	if dur, err := time.ParseDuration(raw); err == nil && dur > 0 {
		return dur
	}
	if secs, err := strconv.Atoi(raw); err == nil && secs > 0 {
		return time.Duration(secs) * time.Second
	}
	return fallback
}

func loadRuntimeConfig() runtimeConfig {
	cfg := runtimeConfig{
		sendInterval:   sendInterval(),
		httpAddr:       envOrDefault("WN_TAX_HTTP_ADDR", ":9103"),
		dbeEndpoint:    envOrDefault("WN_TAX_DBE_ENDPOINT", "http://localhost:9443/tax/ingest"),
		peppolEndpoint: envOrDefault("WN_TAX_PEPPOL_ENDPOINT", "http://localhost:9555/peppol/receive"),
	}

	mode := strings.ToLower(strings.TrimSpace(os.Getenv("WN_TAX_MODE")))
	if mode == "oneshot" || mode == "one-shot" {
		cfg.oneShot = true
	}
	if v := strings.TrimSpace(os.Getenv("WN_TAX_ONESHOT")); v != "" && v != "0" && strings.ToLower(v) != "false" {
		cfg.oneShot = true
	}
	if cfg.sendInterval <= 0 {
		cfg.oneShot = true
	}

	return cfg
}

func serveHTTP(addr string) error {
	mux := http.NewServeMux()
	mux.HandleFunc("/health", healthHandler)
	mux.Handle("/metrics", promhttp.Handler())
	log.Printf("[WN-TAX] http server listening %s", addr)
	return http.ListenAndServe(addr, mux)
}

func envOrDefault(name, fallback string) string {
	if val := strings.TrimSpace(os.Getenv(name)); val != "" {
		return val
	}
	return fallback
}
