package main

import (
	"testing"

	"gopkg.in/yaml.v3"
)

func TestNormalizeLegacyKMSURLs(t *testing.T) {
	const legacyYAML = `
listen: ":8081"
reg_store: "data/reg/mq-legacy.json"
kms_url: "https://legacy.example"
kms_public_keys:
  - id: "kms-1"
    pem: "certs/kms-1.pub"
threshold: 3
audit:
  path: "./run/legacy_audit.jsonl"
metrics:
  listen: ":9101"
`
	var cfg nodeConfig
	if err := yaml.Unmarshal([]byte(legacyYAML), &cfg); err != nil {
		t.Fatalf("unexpected unmarshal error: %v", err)
	}
	cfg.normalizeLegacy()
	if len(cfg.KMSURLs) != 1 {
		t.Fatalf("expected 1 KMS URL, got %d", len(cfg.KMSURLs))
	}
	if cfg.KMSURLs[0] != "https://legacy.example" {
		t.Fatalf("unexpected KMS URL: %s", cfg.KMSURLs[0])
	}
	if cfg.Quorum != 3 {
		t.Fatalf("expected quorum to inherit from threshold (3), got %d", cfg.Quorum)
	}
}
