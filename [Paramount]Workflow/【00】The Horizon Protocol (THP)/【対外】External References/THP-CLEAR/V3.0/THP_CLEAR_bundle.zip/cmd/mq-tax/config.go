package main

import (
	"context"
	"crypto/ed25519"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"errors"
	"fmt"
	"net/http"
	"os"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

type nodeConfig struct {
	Role          string         `yaml:"role"`
	Listen        string         `yaml:"listen"`
	RegStore      string         `yaml:"reg_store"`
	KMSURL        string         `yaml:"kms_url"`
	KMSURLs       []string       `yaml:"kms_urls"`
	Quorum        int            `yaml:"quorum"`
	TLS           tlsSection     `yaml:"tls"`
	KMSPublicKeys []signerEntry  `yaml:"kms_public_keys"`
	Threshold     int            `yaml:"threshold"`
	Key           keySection     `yaml:"key_fetch"`
	Spy           spySection     `yaml:"spy"`
	EpochMinutes  int            `yaml:"epoch_minutes"`
	Audit         auditSection   `yaml:"audit"`
	Metrics       metricsSection `yaml:"metrics"`

	LegacyKMS kmsSection `yaml:"kms"`
}

type kmsSection struct {
	URL       string        `yaml:"url"`
	TLS       tlsSection    `yaml:"tls"`
	Signers   []signerEntry `yaml:"signers"`
	Threshold int           `yaml:"threshold"`
}

type signerEntry struct {
	ID        string `yaml:"id"`
	PublicKey string `yaml:"public_key"`
	PEM       string `yaml:"pem"`
}

type keySection struct {
	Type      string `yaml:"type"`
	MaxRetry  int    `yaml:"max_retry"`
	BackoffMS []int  `yaml:"backoff_ms"`
}

type spySection struct {
	WarnBackoffSec int `yaml:"warn_backoff_sec"`
	BlockTTLSec    int `yaml:"block_ttl_sec"`
}

type tlsSection struct {
	CA   string `yaml:"ca"`
	Cert string `yaml:"cert"`
	Key  string `yaml:"key"`
}

type auditSection struct {
	Path string `yaml:"path"`
}

type metricsSection struct {
	Listen string `yaml:"listen"`
}

func (c *nodeConfig) LoadPublicKeys() (map[string]ed25519.PublicKey, error) {
	keys := make(map[string]ed25519.PublicKey)
	for _, entry := range c.KMSPublicKeys {
		if entry.ID == "" {
			return nil, errors.New("kms public key entry missing id")
		}
		path := entry.PEM
		if path == "" {
			path = entry.PublicKey
		}
		if path == "" {
			return nil, fmt.Errorf("kms public key entry %q missing pem path", entry.ID)
		}
		raw, err := os.ReadFile(path)
		if err != nil {
			return nil, err
		}
		data := bytesTrimSpace(raw)
		if decoded, err := base64.StdEncoding.DecodeString(string(data)); err == nil {
			data = decoded
		}
		if len(data) != ed25519.PublicKeySize {
			return nil, errors.New("invalid public key length for " + entry.ID)
		}
		keys[entry.ID] = ed25519.PublicKey(data)
	}
	return keys, nil
}

func loadNodeConfig(path string) (*nodeConfig, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var cfg nodeConfig
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		return nil, err
	}
	cfg.normalizeLegacy()
	if cfg.Listen == "" {
		cfg.Listen = "127.0.0.1:8081"
	}
	if cfg.RegStore == "" {
		return nil, errors.New("reg_store is required")
	}
	if len(cfg.KMSURLs) == 0 {
		return nil, errors.New("kms_urls is required")
	}
	if len(cfg.KMSPublicKeys) == 0 {
		return nil, errors.New("kms_public_keys is required")
	}
	if cfg.EpochMinutes == 0 {
		cfg.EpochMinutes = 10
	}
	if cfg.Threshold == 0 {
		cfg.Threshold = 2
	}
	if cfg.Quorum <= 0 {
		cfg.Quorum = 2
	}
	if cfg.Quorum > len(cfg.KMSURLs) {
		cfg.Quorum = len(cfg.KMSURLs)
	}
	if cfg.Audit.Path == "" {
		return nil, errors.New("audit.path is required")
	}
	if cfg.Metrics.Listen == "" {
		cfg.Metrics.Listen = "127.0.0.1:9101"
	}
	return &cfg, nil
}

func (c *nodeConfig) NewHTTPClient() (*http.Client, error) {
	if c.TLS.CA == "" && c.TLS.Cert == "" {
		return &http.Client{Timeout: 10 * time.Second}, nil
	}
	tlsCfg := &tls.Config{MinVersion: tls.VersionTLS13}
	if c.TLS.CA != "" {
		caPEM, err := os.ReadFile(c.TLS.CA)
		if err != nil {
			return nil, err
		}
		pool := x509.NewCertPool()
		if !pool.AppendCertsFromPEM(caPEM) {
			return nil, errors.New("invalid CA cert")
		}
		tlsCfg.RootCAs = pool
	}
	if c.TLS.Cert != "" && c.TLS.Key != "" {
		cert, err := tls.LoadX509KeyPair(c.TLS.Cert, c.TLS.Key)
		if err != nil {
			return nil, err
		}
		tlsCfg.Certificates = []tls.Certificate{cert}
	}
	tr := &http.Transport{TLSClientConfig: tlsCfg}
	return &http.Client{Transport: tr, Timeout: 10 * time.Second}, nil
}

func (k keySection) BackoffDurations() []time.Duration {
	out := make([]time.Duration, 0, len(k.BackoffMS))
	for _, ms := range k.BackoffMS {
		out = append(out, time.Duration(ms)*time.Millisecond)
	}
	return out
}

func (s spySection) WarnBackoff() time.Duration {
	if s.WarnBackoffSec == 0 {
		return 60 * time.Second
	}
	return time.Duration(s.WarnBackoffSec) * time.Second
}

func (s spySection) BlockDuration() time.Duration {
	if s.BlockTTLSec == 0 {
		return 60 * time.Second
	}
	return time.Duration(s.BlockTTLSec) * time.Second
}

func currentEpoch(minutes int) uint64 {
	if minutes <= 0 {
		minutes = 10
	}
	step := time.Duration(minutes) * time.Minute
	return uint64(time.Now().Unix() / int64(step.Seconds()))
}

func httpRequestContext() (context.Context, context.CancelFunc) {
	return context.WithTimeout(context.Background(), 10*time.Second)
}

func bytesTrimSpace(b []byte) []byte {
	return []byte(strings.TrimSpace(string(b)))
}

func (c *nodeConfig) normalizeLegacy() {
	if len(c.KMSURLs) == 0 {
		switch {
		case len(c.LegacyKMS.Signers) > 0 && c.LegacyKMS.URL != "":
			c.KMSURLs = []string{c.LegacyKMS.URL}
		case c.KMSURL != "":
			c.KMSURLs = []string{c.KMSURL}
		}
	}
	if (c.TLS == tlsSection{}) && (c.LegacyKMS.TLS != tlsSection{}) {
		c.TLS = c.LegacyKMS.TLS
	}
	if len(c.KMSPublicKeys) == 0 && len(c.LegacyKMS.Signers) > 0 {
		c.KMSPublicKeys = c.LegacyKMS.Signers
	}
	if c.Threshold == 0 && c.LegacyKMS.Threshold != 0 {
		c.Threshold = c.LegacyKMS.Threshold
	}
	if c.Quorum == 0 && c.LegacyKMS.Threshold != 0 {
		c.Quorum = c.LegacyKMS.Threshold
	}
	if c.Quorum == 0 && c.Threshold != 0 {
		c.Quorum = c.Threshold
	}
}
