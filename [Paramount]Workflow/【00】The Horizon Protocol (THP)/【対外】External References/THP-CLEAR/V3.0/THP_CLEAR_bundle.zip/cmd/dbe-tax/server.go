package main

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"thp-clear/pkg/crypto"
	"thp-clear/pkg/metrics"
	"thp-clear/pkg/util"
)

var (
	idset      = util.NewIdempotencySet(24 * 3600)
	key        = make([]byte, 32)
	flushDir   = "/zfs/dbe/tax"
	listenAddr = ":9101"
)

func ingestHandler(w http.ResponseWriter, r *http.Request) {
	defer r.Body.Close()
	body, _ := io.ReadAll(r.Body)
	log.Printf("[DBE-TAX] received %d bytes for ingest", len(body))
	var env map[string]string
	if err := json.Unmarshal(body, &env); err != nil {
		http.Error(w, err.Error(), 400)
		return
	}

	nonce, _ := base64.StdEncoding.DecodeString(env["nonce"])
	aad, _ := base64.StdEncoding.DecodeString(env["aad"])
	ciphertext, _ := base64.StdEncoding.DecodeString(env["ciphertext"])

	if idset.Seen(ciphertext) {
		http.Error(w, "duplicate", 409)
		return
	}

	tag := ciphertext[len(ciphertext)-16:]
	cipher := ciphertext[:len(ciphertext)-16]

	decrypted, err := crypto.DecryptAESGCM(key, crypto.AesGcmEnvelope{Nonce: nonce, AAD: aad, Ciphertext: cipher, Tag: tag})
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	metrics.TaxBatchBytes.Set(float64(len(decrypted)))

	kid := env["kid"]
	if kid == "" {
		kid = fmt.Sprintf("batch-%d", time.Now().UTC().UnixNano())
	}

	path, err := writeBatchManifest(decrypted, flushDir, kid)
	if err != nil {
		log.Printf("[DBE-TAX] flush error: %v", err)
		http.Error(w, err.Error(), 500)
		return
	}

	metrics.TaxFlushCount.Inc()
	log.Printf("[DBE-TAX] flushed %s (%d bytes)", path, len(decrypted))
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	resp := map[string]string{
		"status":        "committed",
		"kid":           kid,
		"manifest_path": path,
	}
	_ = json.NewEncoder(w).Encode(resp)
	log.Printf("[DBE-TAX] stub complete for %s", kid)
}

func startServer() {
	metrics.Init()
	mux := http.NewServeMux()
	mux.HandleFunc("/tax/ingest", ingestHandler)
	mux.HandleFunc("/tax/query", handleQuery)
	mux.HandleFunc("/peppol/credit-note", handleCredit)
	mux.Handle("/metrics", metrics.Handler())

	log.Printf("[DBE-TAX] HTTP server listening %s", listenAddr)
	if err := http.ListenAndServe(listenAddr, mux); err != nil {
		log.Printf("[DBE-TAX] server error: %v", err)
	}
}

func writeBatchManifest(payload []byte, dir, kid string) (string, error) {
	if dir == "" {
		dir = os.TempDir()
	}
	targetDir := dir
	if err := os.MkdirAll(targetDir, 0755); err != nil {
		fallback := filepath.Join(os.TempDir(), "dbe-tax")
		log.Printf("[DBE-TAX] flush fallback to %s due to: %v", fallback, err)
		targetDir = fallback
		if err := os.MkdirAll(targetDir, 0755); err != nil {
			return "", err
		}
	}
	file := filepath.Join(targetDir, "batch_commit.json")
	manifest := map[string]interface{}{
		"kid":            kid,
		"payload_base64": base64.StdEncoding.EncodeToString(payload),
		"payload_size":   len(payload),
		"received_at":    time.Now().UTC().Format(time.RFC3339),
	}
	data, err := json.MarshalIndent(manifest, "", "  ")
	if err != nil {
		return "", err
	}
	if err := os.WriteFile(file, data, 0644); err != nil {
		return "", err
	}
	return file, nil
}
