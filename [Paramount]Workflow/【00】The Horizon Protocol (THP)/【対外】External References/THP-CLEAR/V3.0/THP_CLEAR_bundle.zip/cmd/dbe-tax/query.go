package main

import (
	"encoding/json"
	"errors"
	"net/http"

	"thp-clear/internal/jptax"
)

type taxQueryRequest struct {
	BaseAmount float64 `json:"base_amount"`
	TaxRate    float64 `json:"tax_rate"`
}

type taxQueryResponse struct {
	BaseRoundingMode   string  `json:"base_rounding_mode"`
	TaxRoundingMode    string  `json:"tax_rounding_mode"`
	TotalRoundingMode  string  `json:"total_rounding_mode"`
	RoundedBaseAmount  int64   `json:"rounded_base_amount"`
	ComputedTaxAmount  int64   `json:"computed_tax_amount"`
	ComputedTotalValue int64   `json:"computed_total_amount"`
	TaxRate            float64 `json:"tax_rate"`
}

func handleQuery(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`{"results":[]}`))
		return
	}
	defer r.Body.Close()

	var req taxQueryRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid request body", http.StatusBadRequest)
		return
	}

	result, err := computeTax(req.BaseAmount, req.TaxRate)
	if err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, jptax.ErrInvalidTaxRate) || errors.Is(err, jptax.ErrInvalidBaseAmount) {
			status = http.StatusBadRequest
		}
		http.Error(w, err.Error(), status)
		return
	}

	resp := taxQueryResponse{
		BaseRoundingMode:   "round",
		TaxRoundingMode:    "floor",
		TotalRoundingMode:  "round",
		RoundedBaseAmount:  result.RoundedBase,
		ComputedTaxAmount:  result.TaxAmount,
		ComputedTotalValue: result.TotalAmount,
		TaxRate:            req.TaxRate,
	}

	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(resp)
}
