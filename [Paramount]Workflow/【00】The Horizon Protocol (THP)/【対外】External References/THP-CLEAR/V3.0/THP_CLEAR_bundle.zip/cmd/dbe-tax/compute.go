package main

import "thp-clear/internal/jptax"

// --- DR-20251106 対応: 端数処理方式の明示化 ---
// CLEAR-TAX は国税庁告示に準拠し、金額端数処理を以下とする:
// ・課税標準額計算時: 四捨五入
// ・消費税額計算時: 切り捨て（floor）
// ・総額表示: 四捨五入
// 端数処理関数 taxRound() を定義し、既存 computeTax() 内で利用。

func taxRound(v float64, mode string) int64 {
	return jptax.Round(v, jptax.Mode(mode))
}

// computeTax 内部で:
// taxable = taxRound(base * rate, "floor")
// total = taxRound(base + float64(taxable), "round")
func computeTax(base float64, rate float64) (jptax.ComputationResult, error) {
	return jptax.ComputeTax(jptax.ComputationInput{
		BaseAmount: base,
		TaxRate:    rate,
	})
}
