package main

import (
	"bytes"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
)

type serverConfig struct {
	listenAddr string
	flushDir   string
	aesKey     string
	keyHex     string
	keyFile    string
}

func main() {
	cfg := loadServerConfig()

	absFlushDir, err := prepareFlushDir(cfg.flushDir)
	if err != nil {
		log.Fatalf("[DBE-TAX] unable to prepare flush dir %q: %v", cfg.flushDir, err)
	}
	flushDir = absFlushDir

	if err := applyKeyConfig(cfg); err != nil {
		log.Fatalf("[DBE-TAX] invalid key material: %v", err)
	}

	listenAddr = cfg.listenAddr
	log.Printf("[DBE-TAX] launching server daemon on %s ...", listenAddr)
	startServer()
}

func loadServerConfig() serverConfig {
	return serverConfig{
		listenAddr: envOrDefault("DBE_TAX_LISTEN_ADDR", ":9443"),
		flushDir:   envOrDefault("DBE_TAX_FLUSH_DIR", filepath.Join("var", "dbe-tax")),
		aesKey:     strings.TrimSpace(os.Getenv("DBE_TAX_AES_KEY")),
		keyHex:     strings.TrimSpace(os.Getenv("DBE_TAX_KEY_HEX")),
		keyFile:    strings.TrimSpace(os.Getenv("DBE_TAX_KEY_FILE")),
	}
}

func prepareFlushDir(dir string) (string, error) {
	if dir == "" {
		dir = filepath.Join("var", "dbe-tax")
	}
	abs, err := filepath.Abs(dir)
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(abs, 0o755); err != nil {
		return "", err
	}
	return abs, nil
}

func applyKeyConfig(cfg serverConfig) error {
	var raw []byte
	var err error

	switch {
	case cfg.aesKey != "":
		raw, err = decodeKeyString(cfg.aesKey)
		if err != nil {
			return fmt.Errorf("decode DBE_TAX_AES_KEY: %w", err)
		}
	case cfg.keyHex != "":
		val, err := hex.DecodeString(cfg.keyHex)
		if err != nil {
			return fmt.Errorf("decode DBE_TAX_KEY_HEX: %w", err)
		}
		raw = val
	case cfg.keyFile != "":
		contents, err := os.ReadFile(cfg.keyFile)
		if err != nil {
			return fmt.Errorf("read DBE_TAX_KEY_FILE: %w", err)
		}
		contents = bytes.TrimSpace(contents)
		raw, err = decodeKeyString(string(contents))
		if err != nil {
			return fmt.Errorf("decode key file contents: %w", err)
		}
	default:
		return nil
	}

	if len(raw) != len(key) {
		return fmt.Errorf("expected %d bytes of key material, got %d", len(key), len(raw))
	}
	copy(key, raw)
	return nil
}

func decodeKeyString(val string) ([]byte, error) {
	val = strings.TrimSpace(val)
	if val == "" {
		return nil, fmt.Errorf("empty key")
	}
	if raw, err := hex.DecodeString(val); err == nil && len(raw) == len(key) {
		return raw, nil
	}
	if raw, err := base64.StdEncoding.DecodeString(val); err == nil && len(raw) == len(key) {
		return raw, nil
	}
	if len(val) == len(key) {
		return []byte(val), nil
	}
	return nil, fmt.Errorf("unsupported key format or length %d", len(val))
}

func envOrDefault(name, fallback string) string {
	if val := strings.TrimSpace(os.Getenv(name)); val != "" {
		return val
	}
	return fallback
}
