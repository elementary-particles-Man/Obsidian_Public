package main

import "net/http"

func handleCredit(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write([]byte(`{"credit_note":"ok"}`))
}
