package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"log"
	"os"

	"thp-clear/src/common/crypto"
	"thp-clear/src/common/kmsclient"
)

type WitnessRecord map[string]interface{}

func main() {
	in := flag.String("in", "", "input file")
	out := flag.String("out", "", "output file")
	flag.Parse()

	if *in == "" || *out == "" {
		log.Fatal("Usage: encrypt-witness -in <input file> -out <output file>")
	}

	data, err := ioutil.ReadFile(*in)
	if err != nil {
		log.Fatalf("Failed to read input file: %v", err)
	}

	var records []WitnessRecord
	if err := json.Unmarshal(data, &records); err != nil {
		log.Fatalf("Failed to unmarshal input file: %v", err)
	}

	var envelopes []crypto.Envelope
	for _, rec := range records {
		b, err := json.Marshal(rec)
		if err != nil {
			log.Printf("Failed to marshal record: %v", err)
			continue
		}
		env, err := kmsclient.EncryptToEnvelope(b)
		if err != nil {
			log.Printf("Failed to encrypt record: %v", err)
			continue
		}
		envelopes = append(envelopes, env)
	}

	f, err := os.Create(*out)
	if err != nil {
		log.Fatalf("Failed to create output file: %v", err)
	}
	defer f.Close()

	enc, err := json.MarshalIndent(envelopes, "", "  ")
	if err != nil {
		log.Fatalf("Failed to marshal envelopes: %v", err)
	}

	if _, err := f.Write(enc); err != nil {
		log.Fatalf("Failed to write to output file: %v", err)
	}

	fmt.Println("Encrypted", len(envelopes), "records ->", *out)
}
