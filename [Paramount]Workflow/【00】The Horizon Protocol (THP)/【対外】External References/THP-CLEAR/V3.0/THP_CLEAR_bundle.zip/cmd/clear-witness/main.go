package main

import "fmt"

func main() {
	fmt.Println("THP-CLEAR Witness stub")
}
