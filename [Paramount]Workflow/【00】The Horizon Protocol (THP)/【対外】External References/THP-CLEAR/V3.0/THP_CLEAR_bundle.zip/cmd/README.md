# Command Layer API Catalogue

This document extracts the REST/gRPC-facing surfaces implemented (or planned) in the `cmd/` binaries. It complements `docs/THP-CLEAR_Design_Policy.md` by listing endpoint schemas, request bodies, and response shapes.

## clear-api (planned entrypoint)

`clear-api` will wrap `internal/httpapi.Handler`. The following REST endpoints are defined in `internal/httpapi/handler.go`.

| Method | Path | Request | Response |
| --- | --- | --- | --- |
| `GET` | `/healthz` | – | `{ "status": "ok" }` |
| `POST` | `/command` | `{ account_id, amount, currency, purpose, metadata?, reference? }` | `201 Created` with command object (ID, status, metadata). |
| `GET` | `/command/{id}` | – | `200 OK` with command details including settlement info if available. |
| `POST` | `/settle` | `{ command_id, quantity, unit, metadata? }` | `200 OK` with `{ command, witness }` payload; witness contains hash, signature, payload JSON. |
| `GET` | `/witness?limit=` | – | Array of witness entries (hash chain, signature, payload). |
| `POST` | `/admin/accounts` | `{ id, display_name, currency, balance, status }` | `200 OK` with account snapshot. |
| `POST` | `/admin/blacklist` | `{ account_id, reason, expires_at? }` | `200 OK` `{ "status":"ok" }`. |
| `DELETE` | `/admin/blacklist/{account_id}` | – | `200 OK` `{ "status":"ok" }`. |

All responses are JSON with `Content-Type: application/json; charset=utf-8`. Validation errors return `4xx` with `{ "error": "message" }`. Internal errors emit `500` per `mapDomainError`.

## mqd / wnd / dbd

These daemons share the same control plane (`cmd/mqd/main.go`, `cmd/wnd/main.go`, `cmd/dbd/main.go`).

- **Config**: YAML loaded via `-config` flag (`configs/node.<role>.yaml`).
- **Control endpoint**: `POST /control/spy` accepting `kmsproto.SpyAlert` JSON. Returns `202 Accepted`.
- **Metrics**: Prometheus exposed on `metrics.listen` (default `127.0.0.1:9101` for MQD, etc.) via `nodeauth.NewPromMetrics`.
- **Audit logging**: JSONL files defined in config (`audit.path`).
- **Key rotation loop**: Periodic `/keys/request` invocations through KMS client quorum.

## kmsd

KMS daemon (see `cmd/kmsd/main.go`, `src/kms/http.go`).

| Method | Path | Request | Response |
| --- | --- | --- | --- |
| `POST` | `/commits/register` | `{ node_id, commit_id, digest }` | `201 Created` or `409 Conflict` if commit exists. |
| `POST` | `/keys/request` | `kmsproto.KeyRequest` JSON (node_id, req_id, signature bundle) | `200 OK` with challenge bundle, `429` with `Retry-After` on rate limit. |
| `POST` | `/keys/respond` | `kmsproto.ChallengeResponse` JSON | `200 OK` with signature bundle ticket. |
| `POST` | `/spy/broadcast` | `kmsproto.SpyAlert` JSON | `202 Accepted` (relays alert). |
| `GET` | `/metrics` | – | Prometheus metrics from `kms.NewPromMetrics`. |

TLS settings are loaded from `configs/kms.yaml`. Successful operations append audit entries via `audit.JSONL` (see `cmd/kmsd/main.go`).

## KeyHub internal service

Exposed when KeyHub is embedded (`internal/keyhub/http.go`).

| Method | Path | Request | Response |
| --- | --- | --- | --- |
| `POST` | `/internal/kms/sign` | `{ payload_hash, epoch? }` | `{ sig, epoch, pubkey }` |
| `GET` | `/internal/kms/pubkey?epoch=` | – | `{ pubkey, epoch }` |

These endpoints are used by Go services during settlement and by Aftermath tooling for key rotation.

## clear-witness

`cmd/clear-witness` currently prints a stub message. It remains as a placeholder for future CLI tooling that will inspect Witness logs and invoke the Rust core once available.

Keeping this catalogue up to date ensures the control plane and REST schema remain aligned with the implementation policy and the documentation in `docs/THP-CLEAR_Design_Policy.md`.
