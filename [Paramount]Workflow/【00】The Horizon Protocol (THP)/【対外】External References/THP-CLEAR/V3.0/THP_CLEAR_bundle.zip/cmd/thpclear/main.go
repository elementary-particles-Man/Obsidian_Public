package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"
	"time"

	"thp-clear/internal/adapters/sqlite"
	"thp-clear/internal/adapters/witness"
	"thp-clear/internal/config"
	"thp-clear/internal/domain"
	"thp-clear/internal/httpapi"
	mon "thp-clear/internal/monitoring"
	"thp-clear/pkg/crypto"
	"thp-clear/pkg/monitor"
)

func main() {
	cfgPath := getenv("THPCLEAR_CONFIG", "/app/configs/docker.yaml")
	cfg, err := config.Load(cfgPath)
	if err != nil {
		log.Fatalf("failed to load config %q: %v", cfgPath, err)
	}

	if err := ensureStorageLayout(cfg); err != nil {
		log.Fatalf("failed to prepare storage layout: %v", err)
	}

	ctx := context.Background()

	store, err := sqlite.New(cfg.Database.DSN)
	if err != nil {
		log.Fatalf("failed to open sqlite store: %v", err)
	}
	defer func() {
		_ = store.Close()
	}()
	if err := store.InitSchema(ctx); err != nil {
		log.Fatalf("failed to initialise sqlite schema: %v", err)
	}

	signer, err := crypto.LoadOrCreate(cfg.Crypto.KeyPath)
	if err != nil {
		log.Fatalf("failed to load or create signing key: %v", err)
	}

	writer, err := witness.NewFileWriter(cfg.Witness.LogPath)
	if err != nil {
		log.Fatalf("failed to initialise witness writer: %v", err)
	}

	svc := domain.NewService(store, signer, writer)

	domainMetrics := mon.NewExporter()
	svc.WithMetrics(domainMetrics)

	apiMetrics := monitor.New()
	handler := httpapi.New(svc, apiMetrics)

	mux := http.NewServeMux()
	mux.Handle("/metrics", apiMetrics.Handler())
	mux.Handle("/", handler.Router())

	srv := &http.Server{
		Addr:              cfg.App.ListenAddress,
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       15 * time.Second,
		WriteTimeout:      30 * time.Second,
		IdleTimeout:       120 * time.Second,
	}

	shutdownCh := make(chan os.Signal, 1)
	signal.Notify(shutdownCh, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		sig := <-shutdownCh
		log.Printf("received signal %s, shutting down", sig)
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := srv.Shutdown(ctx); err != nil {
			log.Printf("server shutdown error: %v", err)
		}
	}()

	log.Printf("THP-CLEAR core listening on %s", cfg.App.ListenAddress)
	if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("server error: %v", err)
	}
	log.Println("THP-CLEAR core stopped")
}

func ensureStorageLayout(cfg *config.Config) error {
	if cfg == nil {
		return fmt.Errorf("nil config")
	}
	dbPath := sqlitePath(cfg.Database.DSN)
	if dbPath != "" {
		if err := os.MkdirAll(filepath.Dir(dbPath), 0o750); err != nil {
			return fmt.Errorf("create database dir: %w", err)
		}
	}
	if cfg.Witness.LogPath != "" {
		if err := os.MkdirAll(filepath.Dir(cfg.Witness.LogPath), 0o750); err != nil {
			return fmt.Errorf("create witness dir: %w", err)
		}
	}
	if cfg.Crypto.KeyPath != "" {
		if err := os.MkdirAll(filepath.Dir(cfg.Crypto.KeyPath), 0o750); err != nil {
			return fmt.Errorf("create key dir: %w", err)
		}
	}
	if cfg.Crypto.KeyHub.AuditPath != "" {
		if err := os.MkdirAll(filepath.Dir(cfg.Crypto.KeyHub.AuditPath), 0o750); err != nil {
			return fmt.Errorf("create audit dir: %w", err)
		}
	}
	return nil
}

func sqlitePath(dsn string) string {
	if dsn == "" {
		return ""
	}
	path := strings.TrimPrefix(dsn, "file:")
	if path == dsn {
		return ""
	}
	if idx := strings.IndexByte(path, '?'); idx >= 0 {
		path = path[:idx]
	}
	return path
}

func getenv(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}
