package main

import (
	"crypto/ed25519"
	"errors"
	"flag"
	"log/slog"
	"net/http"
	"os"
	"time"

	"thp-clear/src/common/audit"
	"thp-clear/src/kms"
)

type fileSigner struct {
	id string
	sk ed25519.PrivateKey
	pk ed25519.PublicKey
}

func (f *fileSigner) KeyID() string                { return f.id }
func (f *fileSigner) PublicKey() ed25519.PublicKey { return f.pk }
func (f *fileSigner) Sign(msg []byte) ([]byte, error) {
	return ed25519.Sign(f.sk, msg), nil
}

func main() {
	configPath := flag.String("config", "configs/kms.yaml", "path to kms config")
	flag.Parse()

	logger := slog.New(slog.NewTextHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelInfo}))

	cfg, err := loadConfig(*configPath)
	if err != nil {
		logger.Error("load config", "error", err)
		os.Exit(1)
	}

	auditLogger, err := audit.NewJSONL(cfg.Audit.Path)
	if err != nil {
		logger.Error("init audit logger", "error", err)
		os.Exit(1)
	}
	defer auditLogger.Close()

	signers := make([]kms.Signer, 0, len(cfg.Signers))
	for _, sc := range cfg.Signers {
		raw, err := readPrivateKey(sc.KeyPath)
		if err != nil {
			logger.Error("read signer key", "id", sc.ID, "error", err)
			os.Exit(1)
		}
		if len(raw) != ed25519.PrivateKeySize {
			logger.Error("invalid signer key length", "id", sc.ID)
			os.Exit(1)
		}
		sk := ed25519.PrivateKey(raw)
		pk := sk.Public().(ed25519.PublicKey)
		signers = append(signers, &fileSigner{id: sc.ID, sk: sk, pk: pk})
	}

	epochClock := newEpochClock(cfg.Epoch.Minutes)
	issuer := kms.NewEpochKeyIssuer(epochClock, 2)

	timeout := time.Duration(cfg.Challenge.TimeoutMS) * time.Millisecond
	if timeout <= 0 {
		timeout = 3 * time.Second
	}

	metrics := kms.NewPromMetrics()

	svc, err := kms.NewService(kms.Config{
		Rounds:          cfg.Challenge.Rounds,
		RealRatio:       cfg.Challenge.RealRatioPct / 100,
		Timeout:         timeout,
		FailureWindow:   time.Duration(cfg.Epoch.GracePrevMinutes) * time.Minute,
		BlockAfterFails: 2,
		Threshold:       cfg.Threshold,
		Signers:         signers,
		KeyIssuer:       issuer,
		Metrics:         metrics.AsRecorder(),
		RateLimit: kms.RateLimitConfig{
			PerNodePerMin:   cfg.RateLimit.PerNodePerMin,
			Burst:           cfg.RateLimit.Burst,
			BlockAfterFails: cfg.RateLimit.BlockAfterFails,
			FailWindowMin:   cfg.RateLimit.FailWindowMin,
		},
	})
	if err != nil {
		logger.Error("create service", "error", err)
		os.Exit(1)
	}

	handler := kms.NewHandler(svc, kms.NoopBroadcaster{}, auditLogger)

	server := &http.Server{
		Addr:         cfg.Listen,
		Handler:      handler,
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	tlsCfg, err := loadTLSConfig(cfg.TLS)
	if err != nil {
		logger.Error("load tls config", "error", err)
		os.Exit(1)
	}
	server.TLSConfig = tlsCfg

	metricsSrv := &http.Server{Addr: cfg.Metrics.Listen, Handler: metrics.Handler()}
	go func() {
		logger.Info("metrics listening", "addr", cfg.Metrics.Listen)
		if err := metricsSrv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Error("metrics server error", "error", err)
		}
	}()

	logger.Info("kmsd listening", "addr", cfg.Listen, "tls", tlsCfg != nil)

	var serveErr error
	if tlsCfg != nil {
		serveErr = server.ListenAndServeTLS("", "")
	} else {
		serveErr = server.ListenAndServe()
	}
	if serveErr != nil && !errors.Is(serveErr, http.ErrServerClosed) {
		logger.Error("server error", "error", serveErr)
		os.Exit(1)
	}
}
