package main

import (
	"bytes"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"errors"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type signerConfig struct {
	ID      string `yaml:"id"`
	KeyPath string `yaml:"key_path"`
}

type tlsConfig struct {
	Enable            bool   `yaml:"enable"`
	CA                string `yaml:"ca"`
	Cert              string `yaml:"cert"`
	Key               string `yaml:"key"`
	RequireClientCert bool   `yaml:"require_client_cert"`
}

type challengeConfig struct {
	Rounds       int     `yaml:"rounds"`
	RealRatioPct float64 `yaml:"real_ratio_pct"`
	TimeoutMS    int     `yaml:"timeout_ms"`
}

type epochConfig struct {
	Minutes          int `yaml:"minutes"`
	GracePrevMinutes int `yaml:"grace_prev_minutes"`
}

type rateLimitConfig struct {
	PerNodePerMin   int `yaml:"per_node_per_min"`
	Burst           int `yaml:"burst"`
	BlockAfterFails int `yaml:"block_after_fails"`
	FailWindowMin   int `yaml:"fail_window_min"`
}

type config struct {
	Listen    string          `yaml:"listen"`
	TLS       tlsConfig       `yaml:"tls"`
	Signers   []signerConfig  `yaml:"signers"`
	Challenge challengeConfig `yaml:"challenge"`
	Epoch     epochConfig     `yaml:"epoch"`
	RateLimit rateLimitConfig `yaml:"ratelimit"`
	Threshold int             `yaml:"threshold"`
	Audit     auditConfig     `yaml:"audit"`
	Metrics   metricsConfig   `yaml:"metrics"`
}

type auditConfig struct {
	Path string `yaml:"path"`
}

type metricsConfig struct {
	Listen string `yaml:"listen"`
}

func loadConfig(path string) (*config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var cfg config
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		return nil, err
	}
	if cfg.Listen == "" {
		cfg.Listen = "127.0.0.1:9443"
	}
	if cfg.Challenge.Rounds == 0 {
		cfg.Challenge.Rounds = 7
	}
	if cfg.Challenge.RealRatioPct == 0 {
		cfg.Challenge.RealRatioPct = 80
	}
	if cfg.Epoch.Minutes == 0 {
		cfg.Epoch.Minutes = 10
	}
	if cfg.Epoch.GracePrevMinutes == 0 {
		cfg.Epoch.GracePrevMinutes = 10
	}
	if len(cfg.Signers) == 0 {
		return nil, errors.New("at least one signer is required")
	}
	if cfg.TLS.Enable {
		if cfg.TLS.Cert == "" || cfg.TLS.Key == "" {
			return nil, errors.New("tls enabled but cert/key not provided")
		}
	}
	if cfg.Audit.Path == "" {
		return nil, errors.New("audit.path is required")
	}
	if cfg.Metrics.Listen == "" {
		cfg.Metrics.Listen = "127.0.0.1:9100"
	}
	if cfg.RateLimit.Burst == 0 {
		cfg.RateLimit.Burst = cfg.RateLimit.PerNodePerMin
	}
	if cfg.RateLimit.BlockAfterFails == 0 {
		cfg.RateLimit.BlockAfterFails = 2
	}
	if cfg.RateLimit.FailWindowMin == 0 {
		cfg.RateLimit.FailWindowMin = cfg.Epoch.GracePrevMinutes
		if cfg.RateLimit.FailWindowMin == 0 {
			cfg.RateLimit.FailWindowMin = 10
		}
	}
	return &cfg, nil
}

func loadTLSConfig(conf tlsConfig) (*tls.Config, error) {
	if !conf.Enable {
		return nil, nil
	}
	cert, err := tls.LoadX509KeyPair(conf.Cert, conf.Key)
	if err != nil {
		return nil, err
	}
	tlsCfg := &tls.Config{MinVersion: tls.VersionTLS13, Certificates: []tls.Certificate{cert}}
	if conf.CA != "" {
		caPEM, err := os.ReadFile(conf.CA)
		if err != nil {
			return nil, err
		}
		pool := x509.NewCertPool()
		if !pool.AppendCertsFromPEM(caPEM) {
			return nil, errors.New("failed to append CA certificate")
		}
		tlsCfg.ClientCAs = pool
		if conf.RequireClientCert {
			tlsCfg.ClientAuth = tls.RequireAndVerifyClientCert
		}
	} else if conf.RequireClientCert {
		return nil, errors.New("client cert verification requested but CA is missing")
	}
	return tlsCfg, nil
}

func readPrivateKey(path string) ([]byte, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	trimmed := bytes.TrimSpace(raw)
	if decoded, err := base64.StdEncoding.DecodeString(string(trimmed)); err == nil {
		return decoded, nil
	}
	return trimmed, nil
}

type epochClock struct {
	step time.Duration
}

func newEpochClock(minutes int) *epochClock {
	if minutes <= 0 {
		minutes = 10
	}
	return &epochClock{step: time.Duration(minutes) * time.Minute}
}

func (e *epochClock) CurrentEpoch() uint64 {
	return uint64(time.Now().Unix() / int64(e.step.Seconds()))
}
