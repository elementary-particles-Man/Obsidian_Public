package main

import (
	"log"
	"os"
	"path/filepath"
	"time"

	"thp-clear/src/DB"
	"thp-clear/src/common/kmsclient"
)

func main() {
	dir := "witness/logs"
	db := DB.Connect()
	defer db.Close()

	for {
		files, err := filepath.Glob(filepath.Join(dir, "*.log"))
		if err != nil {
			log.Printf("Failed to glob files: %v", err)
			time.Sleep(5 * time.Second)
			continue
		}

		for _, f := range files {
			data, err := os.ReadFile(f)
			if err != nil {
				log.Printf("Failed to read file %s: %v", f, err)
				continue
			}

			env, err := kmsclient.EncryptToEnvelope(data)
			if err != nil {
				log.Printf("Failed to encrypt data for file %s: %v", f, err)
				continue
			}
			if err := DB.InsertEnvelope(db, env); err != nil {
				log.Printf("Failed to insert envelope for file %s: %v", f, err)
				continue
			}

			if err := os.Rename(f, f+".done"); err != nil {
				log.Printf("Failed to rename file %s: %v", f, err)
			}

			log.Println("Ingested", f)
		}

		time.Sleep(5 * time.Second)
	}
}
