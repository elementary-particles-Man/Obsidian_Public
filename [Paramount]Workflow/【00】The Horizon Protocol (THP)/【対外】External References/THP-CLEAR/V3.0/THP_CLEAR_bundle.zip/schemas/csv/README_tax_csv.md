# TAX CSV Catalogs (Human-editable)

## tax_rates.csv
`tax_code,name_ja,basis_law,rate,category,valid_from,valid_to`

## tax_rules.csv
`rule_id,description,formula,rounding,precision_money,precision_rate,applies_to,valid_from,valid_to`

## tax_mapping.csv
`item_code,tax_code,rule_id,notes`

- UTF-8, comma-separated, date=YYYY-MM-DD, money=2 decimals, rate up to 3 decimals.
- No encryption; served as-is for transparency and speed.
