package main

import (
	"context"
	"crypto/ed25519"
	"errors"
	"flag"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"
	"time"

	"thp-clear/internal/adapters/sqlite"
	"thp-clear/internal/adapters/witness"
	"thp-clear/internal/config"
	internalcrypto "thp-clear/internal/crypto"
	"thp-clear/internal/domain"
	"thp-clear/internal/httpapi"
	"thp-clear/internal/keyhub"
	"thp-clear/internal/monitoring"
	pkgcrypto "thp-clear/pkg/crypto"
	"thp-clear/pkg/monitor"
)

func main() {
	configPath := flag.String("config", "configs/example.yaml", "path to config file")
	flag.Parse()

	logger := slog.New(slog.NewTextHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelInfo}))

	cfg, err := config.Load(*configPath)
	if err != nil {
		logger.Error("failed to load config", "error", err)
		os.Exit(1)
	}
	if cfg.Database.Driver != "" && cfg.Database.Driver != "sqlite" {
		logger.Error("unsupported database driver", "driver", cfg.Database.Driver)
		os.Exit(1)
	}

	if err := ensurePath(cfg.Crypto.KeyPath, 0o700); err != nil {
		logger.Error("failed to prepare crypto path", "error", err)
		os.Exit(1)
	}
	if err := ensurePath(cfg.Witness.LogPath, 0o750); err != nil {
		logger.Error("failed to prepare witness path", "error", err)
		os.Exit(1)
	}

	store, err := sqlite.New(cfg.Database.DSN)
	if err != nil {
		logger.Error("failed to open database", "error", err)
		os.Exit(1)
	}
	defer store.Close()

	ctx := context.Background()
	if err := store.InitSchema(ctx); err != nil {
		logger.Error("failed to init schema", "error", err)
		os.Exit(1)
	}

	signer, err := pkgcrypto.LoadOrCreate(cfg.Crypto.KeyPath)
	if err != nil {
		logger.Error("failed to load signer", "error", err)
		os.Exit(1)
	}

	witnessWriter, err := witness.NewFileWriter(cfg.Witness.LogPath)
	if err != nil {
		logger.Error("failed to create witness writer", "error", err)
		os.Exit(1)
	}

	service := domain.NewService(store, signer, witnessWriter)
	metrics := monitor.New()
	exporter := monitoring.NewExporter()
	service.WithMetrics(exporter)
	apiHandler := httpapi.New(service, metrics)

	var (
		keyHubServer *http.Server
	)

	if strings.EqualFold(cfg.Crypto.KeyHub.Mode, "internal") {
		masterSeed, err := internalcrypto.LoadMasterSeed(cfg.Crypto.KeyHub.MasterSeedRef, signer.PrivateKey())
		if err != nil {
			logger.Error("failed to load keyhub master seed", "error", err)
			os.Exit(1)
		}
		if len(masterSeed) < ed25519.SeedSize {
			logger.Error("master seed too short", "length", len(masterSeed))
			os.Exit(1)
		}
		khService, err := keyhub.New(keyhub.Config{
			MasterSeed:   masterSeed,
			EpochSeconds: cfg.Crypto.KeyHub.EpochSeconds,
			AuditPath:    cfg.Crypto.KeyHub.AuditPath,
		})
		if err != nil {
			logger.Error("failed to init keyhub", "error", err)
			os.Exit(1)
		}
		server, err := keyhub.NewHTTPServer(cfg.Crypto.KeyHub.Endpoint, khService)
		if err != nil {
			logger.Error("failed to create keyhub server", "error", err)
			os.Exit(1)
		}
		keyHubServer = server
	}

	apiServer := &http.Server{
		Addr:         cfg.App.ListenAddress,
		Handler:      apiHandler.Router(),
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 30 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	metricsMux := http.NewServeMux()
	metricsMux.Handle("/metrics", metrics.Handler())
	metricsMux.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})

	metricsServer := &http.Server{
		Addr:    fmt.Sprintf(":%d", cfg.Monitoring.PrometheusPort),
		Handler: metricsMux,
	}

	errCh := make(chan error, 3)

	go func() {
		logger.Info("API server listening", "address", cfg.App.ListenAddress)
		if err := apiServer.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			errCh <- err
		}
	}()

	go func() {
		logger.Info("Metrics server listening", "port", cfg.Monitoring.PrometheusPort)
		if err := metricsServer.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			errCh <- err
		}
	}()

	if keyHubServer != nil {
		go func() {
			logger.Info("KeyHub server listening", "endpoint", cfg.Crypto.KeyHub.Endpoint)
			if err := keyHubServer.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
				errCh <- err
			}
		}()
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	select {
	case <-ctx.Done():
		logger.Info("shutdown signal received")
	case err := <-errCh:
		if err != nil {
			logger.Error("server error", "error", err)
		}
	}

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := apiServer.Shutdown(shutdownCtx); err != nil {
		logger.Error("failed to shutdown api server", "error", err)
	}
	if err := metricsServer.Shutdown(shutdownCtx); err != nil {
		logger.Error("failed to shutdown metrics server", "error", err)
	}
	if keyHubServer != nil {
		if err := keyHubServer.Shutdown(shutdownCtx); err != nil {
			logger.Error("failed to shutdown keyhub server", "error", err)
		}
	}

	logger.Info("shutdown complete")
}

func ensurePath(filePath string, perm os.FileMode) error {
	dir := filepath.Dir(filePath)
	if dir == "." || dir == "" {
		return nil
	}
	return os.MkdirAll(dir, perm)
}
