# THP-CLEAR v2.2 Hybrid CI Environment

## Quick Start (no local setup)
```bash
git clone <repo>
cd thpclear
make all
```

This builds Docker image, runs ci.sh inside it, executes lint/tests/benchmarks, and prints results.

## Local run (no Docker)
```bash
bash ci.sh
```

## What it does
- Installs Go, Python deps, linters, and Codex CLI if present.
- Runs lint, tests, optional bench, snapshot + RS repair verification.

## Troubleshooting
- On Windows: use WSL2 or Docker Desktop.
- On macOS/Linux: Docker Engine or Podman compatible.

## Result logs
- Test output: `test.log`
- Benchmark logs: `bench.log` (if enabled)
- All results printed to console.
