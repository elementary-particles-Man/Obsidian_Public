#!/usr/bin/env bash
set -e

echo '--- [THP-CLEAR CI start] ---'
echo 'Step 1: Environment check'
go version || echo 'Go not found'
python3 --version || echo 'Python not found'

echo 'Installing dependencies (safe to rerun)...'
pip3 install -q reedsolo aiohttp || true

echo '--- Step 2: Lint ---'
if command -v golangci-lint >/dev/null 2>&1; then
  golangci-lint run ./... || true
else
  echo 'golangci-lint missing; skipped'
fi

echo '--- Step 3: Unit tests ---'
go test ./... -v | tee test.log

echo '--- Step 4: Bench (optional) ---'
if [ -f scripts/bench_tps.py ]; then
  python3 scripts/bench_tps.py --url http://127.0.0.1:8080 --concurrency 50 --requests 1000 || true
else
  echo 'Bench script not found; skipped'
fi

echo '--- Step 5: Snapshot verification ---'
bash scripts/snapshot_cron.sh || true
python3 scripts/rs_repair.py || true

echo '--- [THP-CLEAR CI complete] ---'
