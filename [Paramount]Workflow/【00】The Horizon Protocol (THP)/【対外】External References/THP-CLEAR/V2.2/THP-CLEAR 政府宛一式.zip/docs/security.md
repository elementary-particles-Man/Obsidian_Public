# Security Policy

## Position of ISE (Indistinguishable Signed Encryption)

ISE is a cryptographic scheme in which "a plausible plaintext appears no matter which key is used for decryption, and legitimacy is determined only by the signature." In THP-CLEAR, ISE is applied to the Witness payload delivered between MQ and DB so that an attacker cannot identify the true data even if the key is leaked.

### Conceptual Diagram

```mermaid
graph LR
    Plain[True Payload] -->|Encrypt (Active Key)| Cipher[Envelope]
    Decoy1[Dummy Data] -->|Encrypt (Decoy Key)| Cipher
    Decoy2[Decryption result with old key]|-->|Decrypt| Cipher
    Cipher -->|Verify Signature| Sign[Signature Verification]
    Sign -->|Valid?| Output[True Plaintext]
    Sign -.Invalid.-> Reject[Discard]
```

- Manages multiple key versions (Active/Previous/Decoy) with KeyRing.
- The payload is adopted only when the signature (`signbundle.Signature`) can be verified with Ed25519.
- If the decryption is successful but the signature does not match, it is treated as dummy data and not saved in the DB.

### Pseudocode

```go
func ProcessEnvelope(env *encryptor.Envelope) ([]byte, error) {
    plain, usedPrev, err := pipeline.Open(env) // ISE decryption
    if errors.Is(err, encryptor.ErrKeyVersionUnavailable) {
        return nil, ErrEpochMismatch
    }
    if err != nil {
        return nil, err
    }
    if !signature.Verify(plain, env.Signature) {
        return nil, errors.New("invalid payload: decoy")
    }
    if usedPrev {
        logger.Warn("using previous key", "version", env.KeyVersion)
    }
    return plain, nil
}
```

For implementation details, see `src/MQ/encryptor/ise.go` and `src/DB/ingest.go`. `ise.go` provides random number stretching and decoy generation for each key version, and `ingest.go` provides a decryption and signature verification flow using KeyRing.

## Private Key Management

- Witness signature is Ed25519. Uses the base64 private key saved in `crypto.key_path`.
- The key file is saved with `0600` permission and migrated to HSM/KMS in actual operation.
- When updating the key, it is assumed that the service will be stopped → a new key will be issued → the public key will be replaced → the key ID will be added to the Witness log.

## Witness Log Integrity

- Duplicated in the `witness_entries` table of SQLite and the JSON Lines file.
- The file is appended with `append+sync` as WORM (Write Once Read Many).
- A hash summary is published daily so that an external audit node can verify the match.

## Blacklist Operation

- The `blacklist` table holds the reason and expiration date, and all updates are executed atomically in a transaction.
- To release, supplement `expires_at` and update to `active=0`. The history is retained instead of being deleted.

## API Security

- All endpoints only allow JSON, and information leakage is suppressed with 422/403/409, etc.
- Authentication is assumed to be implemented outside Layer0 (reverse proxy/IDP). Access token verification will be added as Middleware in the future.

## Logging/Auditing

- Monitor API authentication success rate, Witness update rate, etc. with Prometheus metrics in `pkg/monitor`.
- For important operations (such as blacklist registration), there is a plan to add a separate operation log table and record the signer ID.
