# セキュリティ方針

## ISE (Indistinguishable Signed Encryption) の位置づけ

ISE は「どの鍵で復号してももっともらしいプレーンテキストが出現し、正当性は署名のみで確定させる」暗号スキームです。THP-CLEAR では MQ → DB 間で配送される Witness ペイロードに対して ISE を適用し、鍵漏洩時でも攻撃者が真のデータを特定できないようにしています。

### 概念図

```mermaid
graph LR
    Plain[真のペイロード] -->|Encrypt (Active Key)| Cipher[Envelope]
    Decoy1[ダミーデータ] -->|Encrypt (Decoy Key)| Cipher
    Decoy2[古い鍵での復号結果]|-->|Decrypt| Cipher
    Cipher -->|Verify Signature| Sign[署名検証]
    Sign -->|Valid?| Output[真のプレーンテキスト]
    Sign -.Invalid.-> Reject[破棄]
```

- 複数の鍵バージョン（Active/Previous/Decoy）を KeyRing で管理します。
- 署名 (`signbundle.Signature`) が Ed25519 で検証できた場合のみペイロードを採用します。
- 復号が成功しても署名が一致しない場合はダミーデータとして扱い、DB には保存しません。

### 擬似コード

```go
func ProcessEnvelope(env *encryptor.Envelope) ([]byte, error) {
    plain, usedPrev, err := pipeline.Open(env) // ISE 復号
    if errors.Is(err, encryptor.ErrKeyVersionUnavailable) {
        return nil, ErrEpochMismatch
    }
    if err != nil {
        return nil, err
    }
    if !signature.Verify(plain, env.Signature) {
        return nil, errors.New("invalid payload: decoy")
    }
    if usedPrev {
        logger.Warn("using previous key", "version", env.KeyVersion)
    }
    return plain, nil
}
```

実装の詳細は `src/MQ/encryptor/ise.go` と `src/DB/ingest.go` を参照してください。`ise.go` では鍵バージョンごとの乱数ストレッチ・デコイ生成、`ingest.go` では KeyRing を利用した復号と署名検証フローを提供します。

## 秘密鍵管理

- Witness 署名は Ed25519。`crypto.key_path` に保存した base64 秘密鍵を使用。
- キーファイルは `0600` 権限で保存し、実運用では HSM/KMS に移行する。
- キー更新時はサービス停止 → 新キー発行 → 公開鍵差し替え → Witness ログにキーIDを追記する運用を想定。

## Witness ログ保全

- SQLite の `witness_entries` テーブルと JSON Lines ファイルで二重化。
- ファイルは WORM (Write Once Read Many) として `append+sync` で追記。
- 日次でハッシュサマリを公開し、外部監査ノードが一致を検証できるようにする。

## ブラックリスト運用

- `blacklist` テーブルは理由・期限を保持し、全更新はトランザクションで原子的に実行。
- 解除は `expires_at` を補完し `active=0` に更新。削除ではなく履歴を保持。

## API セキュリティ

- 全エンドポイントは JSON のみ許容し、422/403/409 などで情報漏洩を抑える。
- 認証は Layer0 外部（リバースプロキシ/IDP）で実装する想定。アクセストークン検証は将来的に Middleware を追加。

## ログ・監査

- `pkg/monitor` の Prometheus メトリクスで API 認証成功率・Witness 更新率などを監視。
- 重要操作（ブラック登録など）は別途操作ログテーブルを追加し、署名者IDを記録する計画。
