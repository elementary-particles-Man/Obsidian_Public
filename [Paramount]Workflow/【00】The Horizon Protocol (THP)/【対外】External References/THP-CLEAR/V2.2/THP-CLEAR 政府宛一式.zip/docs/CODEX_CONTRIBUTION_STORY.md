THP-CLEAR Multi-KMS Evolution
==============================

## Prologue

In 2025, THP-CLEAR's KMS multiplexing was based on the design philosophy of "Ring + Quorum," but its implementation was still halfway there. The theory was to use three KMS instances in the Challenge phase and acquire a key in the Submit phase, which was robust in theory. However, the implementation depended on a single KMS, and the boundaries of a session were ambiguous.

This is where CODEX came in. This agent, equipped with the OpenAI/GPT-5 algorithm, descended into the THP-CLEAR repository with the goal of "breaking the SPOF."

## Chapter 1: Reclaiming the Session

The first mission was to complete the Challenge and Submit within the same KMS. CODEX noticed the following issues:

1. When `RequestChallenges` fails over to multiple KMS instances, each KMS generates a different nonce.
2. If the Submit reaches a different KMS, it fails signature verification because the information generated in the Challenge does not match.

Here, CODEX introduced the principle of a **"Challenge-bound session."** The selected KMS endpoint is fixed until the Submit is complete, and if it fails, a re-Challenge is requested. Failover is only performed during the Challenge, and the KMS is not switched during the Submit.

Furthermore, CODEX added the following mechanisms:

- LRU discard based on session TTL and upper limit
- Recording of `session_id`, `kms_endpoint`, `challenge_latency_ms`, `submit_latency_ms`, and `challenge_failover_count` in the audit log
- Exposure of new metrics such as `kms_challenge_failover_total`, `kms_submit_retry_total`, and `kms_sessions_in_use` to Prometheus

In this way, "failover is allowed only during the Challenge, and the Submit is fixed to a KMS" was guaranteed at the implementation level.

## Chapter 2: Enhancing Observability and Operability

CODEX also focused on observability.

- Session information and latency are always recorded in the audit log, allowing for immediate failure analysis.
- Prometheus metrics now allow for real-time monitoring of failover rates, quorum failures, and the number of sessions.
- In addition to `go test ./...`, `go test -race ./...` was also passed to confirm parallel safety.

## Chapter 3: Documentation and Solution Guide

CODEX clarified the principle of **"using the KMS selected in the Challenge until the Submit"** in the documentation. Furthermore, it prepared an operational handbook that includes Docker builds, Compose startup, and Prometheus alerts, and finished it in a state where verification equivalent to production can be performed immediately.

## Chapter 4: Quality Assurance and Release Judgment

After clearing all the checklists, CODEX declared the release after confirming the following:

- Failover occurs only in the Challenge phase, and the Submit operates stably on the same KMS.
- Re-Challenge is forced when the TTL is exceeded or the session upper limit is exceeded.
- Session behavior is fully observable with audit logs and metrics.
- The metrics and logs are consistent in the one-stop and two-stop drills.
- Production preparation is complete, including the Docker image and Compose startup procedure.

## Epilogue: What CODEX Left Behind

The multi-session support for KMS in THP-CLEAR was not just a refactoring, but was elevated to a robust system design that supports the operational field. Challenge-bound sessions, session TTL, and the enrichment of audit logs and metrics are all contributions of CODEX.

CODEX concludes with the following words:

> "Trust the KMS you chose in the Challenge until the Submit. If the Submit wavers, start over from the Challenge. The metrics and logs will tell you the truth. This is the law of distributed KMS."

THP-CLEAR has now achieved a level of robustness and observability comparable to a national audit infrastructure and has embarked on a new frontier.
