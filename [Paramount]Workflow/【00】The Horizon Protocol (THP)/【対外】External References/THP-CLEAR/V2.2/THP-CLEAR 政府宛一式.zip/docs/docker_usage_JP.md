# THP-CLEAR Docker 運用ガイド

最終更新: 2025-10-14

THP-CLEAR を Docker で取り扱う際の最小セットアップと、コンテナイメージをレジストリへ Push する手順をまとめたガイドです。Docker を最近使い始めた方向けに、コマンドと補足を具体的に記載しています。

---

## 1. 前提条件

- Docker / Docker Compose (v2) がインストールされていること
- `docker` コマンドで通常の `build` / `push` が行える権限があること
- （任意）プライベートレジストリへ push する場合は `docker login` 済みであること

---

## 2. イメージのビルド

リポジトリ直下で以下を実行します。`IMAGE_TAG` を指定するとタグが付与されます（既定は `local`）。

```bash
make docker-build IMAGE_TAG=v0.1.0
```

内部的には以下と同じ操作を行います。

```bash
docker build -t thp-clear:v0.1.0 .
```

イメージ名を変えたい場合は `IMAGE_NAME` を併せて指定してください。

```bash
make docker-build IMAGE_NAME=thp-clear-api IMAGE_TAG=latest
```

---

## 3. ローカル実行（docker compose）

コンテナで API を起動する場合は次のコマンドを使用します。

```bash
make docker-up       # docker compose up --build -d
make docker-logs     # コンテナログを追いかける
make docker-down     # コンテナ停止・削除
```

`docker-compose.yml` ではホストの `./data` と `./witness_logs` をマウントしています。初回起動前に必要に応じてディレクトリを作成しておいてください。

---

## 4. レジストリへ Push する

1. Push 先のレジストリへログインします（例: GitHub Container Registry）。
   ```bash
   docker login ghcr.io
   ```

2. `REGISTRY` と `IMAGE_TAG` を指定して push します。
   ```bash
   make docker-push REGISTRY=ghcr.io/your-org IMAGE_TAG=v0.1.0
   ```

   上記コマンドは以下の操作を自動で行います。
   - `docker build -t thp-clear:v0.1.0 .`
   - `docker tag thp-clear:v0.1.0 ghcr.io/your-org/thp-clear:v0.1.0`
   - `docker push ghcr.io/your-org/thp-clear:v0.1.0`

3. push 済みのイメージを pull して起動する場合:
   ```bash
   docker pull ghcr.io/your-org/thp-clear:v0.1.0
   docker run --rm -p 8080:8080 ghcr.io/your-org/thp-clear:v0.1.0
   ```

---

## 5. よくある質問 (FAQ)

### Q1. `make docker-push` でエラーが出る
- `REGISTRY` を指定しているか確認してください。例えば `REGISTRY=registry.example.com/team` のように組織パスまでを含めます。
- 認証が必要な場合は事前に `docker login REGISTRY_URL` を実施してください。

### Q2. `docker compose up` でポートが競合する
- `docker-compose.yml` の `ports` セクションで `8080` / `9100` を使用しています。別のポートが必要な場合は compose ファイルを編集するか `ports` を上書きしてください。

### Q3. ビルドキャッシュを無効化したい
- `make docker-build` の代わりに `DOCKER_BUILDKIT=1 docker build --no-cache -t thp-clear:dev .` のように直接コマンドを実行します。

---

## 6. 参考

- `Dockerfile`: プロダクション向け API コンテナの定義
- `docker-compose.yml`: API（8080）とメトリクス（9100）を同時に立ち上げる構成
- `Makefile`: 本ガイドのコマンドが登録されています

何か不明点があれば `make -n <target>` で実行内容を確認するか、チームチャネルにてご相談ください。
