package nodeauth

import (
	"net/http"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"

	"thp-clear/src/common/kmsclient"
)

type MetricsRecorder interface {
	RecordKeyFetch(status string)
	RecordTicketFail(reason string)
	RecordSpyAlert(level string)
}

type promMetrics struct {
	registry         *prometheus.Registry
	keyFetch         *prometheus.CounterVec
	ticketFail       *prometheus.CounterVec
	spyAlerts        *prometheus.CounterVec
	kmsInflight      *prometheus.GaugeVec
	kmsChallengeFail *prometheus.CounterVec
	kmsSubmitRetry   *prometheus.CounterVec
	kmsSessions      *prometheus.GaugeVec
	kmsQuorumMet     *prometheus.CounterVec
	kmsQuorumFailed  *prometheus.CounterVec
	role             string
}

func NewPromMetrics(role string) *promMetrics {
	if role == "" {
		role = "unknown"
	}
	reg := prometheus.NewRegistry()
	m := &promMetrics{
		registry: reg,
		keyFetch: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "node_key_fetch_total",
				Help: "Key fetch attempts by status",
			},
			[]string{"status"},
		),
		ticketFail: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "node_key_ticket_fail_total",
				Help: "Key ticket verification failures by reason",
			},
			[]string{"reason"},
		),
		spyAlerts: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "node_spy_alert_total",
				Help: "SPY alerts processed",
			},
			[]string{"level"},
		),
		kmsInflight: prometheus.NewGaugeVec(
			prometheus.GaugeOpts{
				Name: "kms_multi_inflight",
				Help: "Number of in-flight KMS quorum requests",
			},
			[]string{"node_role"},
		),
		kmsChallengeFail: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "kms_challenge_failover_total",
				Help: "Count of challenge-phase failovers",
			},
			[]string{"node_role"},
		),
		kmsSubmitRetry: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "kms_submit_retry_total",
				Help: "Count of submit-phase retries",
			},
			[]string{"node_role"},
		),
		kmsSessions: prometheus.NewGaugeVec(
			prometheus.GaugeOpts{
				Name: "kms_sessions_in_use",
				Help: "Number of pending KMS sessions awaiting submit",
			},
			[]string{"node_role"},
		),
		kmsQuorumMet: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "kms_quorum_met_total",
				Help: "Times KMS quorum was satisfied",
			},
			[]string{"node_role"},
		),
		kmsQuorumFailed: prometheus.NewCounterVec(
			prometheus.CounterOpts{
				Name: "kms_quorum_failed_total",
				Help: "Times KMS quorum failed",
			},
			[]string{"node_role"},
		),
		role: role,
	}
	reg.MustRegister(m.keyFetch, m.ticketFail, m.spyAlerts, m.kmsInflight, m.kmsChallengeFail, m.kmsSubmitRetry, m.kmsSessions, m.kmsQuorumMet, m.kmsQuorumFailed)
	return m
}

func (m *promMetrics) Handler() http.Handler {
	return promhttp.HandlerFor(m.registry, promhttp.HandlerOpts{})
}

func (m *promMetrics) RecordKeyFetch(status string) {
	m.keyFetch.WithLabelValues(status).Inc()
}

func (m *promMetrics) RecordTicketFail(reason string) {
	m.ticketFail.WithLabelValues(reason).Inc()
}

func (m *promMetrics) RecordSpyAlert(level string) {
	m.spyAlerts.WithLabelValues(level).Inc()
}

func (m *promMetrics) KMSHooks() kmsclient.Hooks {
	return kmsclient.Hooks{
		IncInflight: func() {
			m.kmsInflight.WithLabelValues(m.role).Inc()
		},
		DecInflight: func() {
			m.kmsInflight.WithLabelValues(m.role).Dec()
		},
		RecordChallengeFailover: func() {
			m.kmsChallengeFail.WithLabelValues(m.role).Inc()
		},
		RecordSubmitRetry: func() {
			m.kmsSubmitRetry.WithLabelValues(m.role).Inc()
		},
		RecordQuorumMet: func() {
			m.kmsQuorumMet.WithLabelValues(m.role).Inc()
		},
		RecordQuorumFail: func() {
			m.kmsQuorumFailed.WithLabelValues(m.role).Inc()
		},
		SetSessionsInUse: func(v int) {
			m.kmsSessions.WithLabelValues(m.role).Set(float64(v))
		},
	}
}

type nopNodeMetrics struct{}

func (nopNodeMetrics) RecordKeyFetch(string)   {}
func (nopNodeMetrics) RecordTicketFail(string) {}
func (nopNodeMetrics) RecordSpyAlert(string)   {}

func (m *promMetrics) AsRecorder() MetricsRecorder { return m }
