package kmsclient

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"thp-clear/src/common/kmsproto"
)

// Client abstracts interactions with one or more KMS endpoints.
type Client interface {
	RequestChallenges(ctx context.Context, req kmsproto.KeyRequest) (*kmsproto.ChallengeSet, Metadata, error)
	SubmitResponses(ctx context.Context, resp kmsproto.ChallengeResponse) (*kmsproto.KeyResult, Metadata, error)
	Close() error
}

// Metadata captures transport-level details about a KMS quorum attempt.
type Metadata struct {
	Members            []string
	Primary            string
	PrimaryIndex       int
	FailoverCount      int
	Attempts           int
	ChallengeFailovers int
	ChallengeLatency   time.Duration
	SubmitLatency      time.Duration
}

// New creates a single-endpoint client (deprecated: prefer NewMulti).
func New(baseURL string, httpClient *http.Client) Client {
	if httpClient == nil {
		httpClient = &http.Client{Timeout: 10 * time.Second}
	}
	return &singleClient{baseURL: strings.TrimRight(baseURL, "/"), http: httpClient}
}

type singleClient struct {
	baseURL string
	http    *http.Client
}

func (c *singleClient) RequestChallenges(ctx context.Context, req kmsproto.KeyRequest) (*kmsproto.ChallengeSet, Metadata, error) {
	var challenge kmsproto.ChallengeSet
	if err := c.postJSON(ctx, "/keys/request", req, &challenge); err != nil {
		return nil, Metadata{Attempts: 1, PrimaryIndex: -1}, err
	}
	return &challenge, Metadata{Members: []string{c.baseURL}, Primary: c.baseURL, PrimaryIndex: 0, Attempts: 1}, nil
}

func (c *singleClient) SubmitResponses(ctx context.Context, resp kmsproto.ChallengeResponse) (*kmsproto.KeyResult, Metadata, error) {
	var result kmsproto.KeyResult
	if err := c.postJSON(ctx, "/keys/respond", resp, &result); err != nil {
		return nil, Metadata{Attempts: 1, PrimaryIndex: -1}, err
	}
	return &result, Metadata{Members: []string{c.baseURL}, Primary: c.baseURL, PrimaryIndex: 0, Attempts: 1}, nil
}

func (c *singleClient) Close() error { return nil }

func (c *singleClient) postJSON(ctx context.Context, path string, payload interface{}, out interface{}) error {
	body, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.baseURL+path, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		buf, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("kms error: %s", bytes.TrimSpace(buf))
	}
	if out == nil {
		return nil
	}
	return json.NewDecoder(resp.Body).Decode(out)
}
