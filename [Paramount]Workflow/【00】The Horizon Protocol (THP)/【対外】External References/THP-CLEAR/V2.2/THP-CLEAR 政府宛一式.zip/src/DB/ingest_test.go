package DB

import (
	"testing"

	"thp-clear/src/MQ/encryptor"
)

type staticKeySource struct {
	current encryptor.KeyMaterial
}

func (s *staticKeySource) Current() (encryptor.KeyMaterial, error) { return s.current, nil }
func (s *staticKeySource) Previous() (encryptor.KeyMaterial, bool) {
	return encryptor.KeyMaterial{}, false
}
func (s *staticKeySource) ByVersion(version uint64) (encryptor.KeyMaterial, bool) {
	if version == s.current.Version {
		return s.current, true
	}
	return encryptor.KeyMaterial{}, false
}
func (s *staticKeySource) Rotate() (encryptor.KeyMaterial, error) { return s.current, nil }
func (s *staticKeySource) Apply(mat encryptor.KeyMaterial)        { s.current = mat }

func TestIngestorDecodeCurrentAndPrevious(t *testing.T) {
	ring, err := encryptor.NewKeyRing()
	if err != nil {
		t.Fatalf("new keyring: %v", err)
	}

	prev := makeMaterial(1, 0x11, 0x21)
	current := makeMaterial(2, 0x31, 0x41)
	ring.Apply(prev)
	ring.Apply(current)

	ingestor, err := NewIngestor(ring)
	if err != nil {
		t.Fatalf("new ingestor: %v", err)
	}

	envCurrent := sealWith(t, current, []byte("payload-current"))
	plain, usedPrev, err := ingestor.DecodeEnvelope(envCurrent)
	if err != nil {
		t.Fatalf("decode current: %v", err)
	}
	if usedPrev {
		t.Fatalf("expected current key usage")
	}
	if string(plain) != "payload-current" {
		t.Fatalf("unexpected plaintext: %s", plain)
	}

	envPrev := sealWith(t, prev, []byte("payload-prev"))
	plainPrev, usedPrev, err := ingestor.DecodeEnvelope(envPrev)
	if err != nil {
		t.Fatalf("decode prev: %v", err)
	}
	if !usedPrev {
		t.Fatalf("expected previous key usage")
	}
	if string(plainPrev) != "payload-prev" {
		t.Fatalf("unexpected plaintext: %s", plainPrev)
	}
}

func TestIngestorDecodeEpochMismatch(t *testing.T) {
	ring, err := encryptor.NewKeyRing()
	if err != nil {
		t.Fatalf("new keyring: %v", err)
	}
	current := makeMaterial(3, 0x51, 0x61)
	ring.Apply(current)

	ingestor, err := NewIngestor(ring)
	if err != nil {
		t.Fatalf("new ingestor: %v", err)
	}

    oldMat := makeMaterial(100, 0x01, 0x02)
	env := sealWith(t, oldMat, []byte("old"))

	if _, _, err := ingestor.DecodeEnvelope(env); err == nil {
		t.Fatalf("expected epoch mismatch error")
	} else if err != ErrEpochMismatch {
		t.Fatalf("unexpected error: %v", err)
	}
}

func sealWith(t *testing.T, mat encryptor.KeyMaterial, payload []byte) *encryptor.Envelope {
	t.Helper()
	src := &staticKeySource{current: mat}
	pipeline, err := encryptor.NewPipeline(encryptor.Config{Keys: src})
	if err != nil {
		t.Fatalf("new pipeline: %v", err)
	}
	env, err := pipeline.Seal(payload, true)
	if err != nil {
		t.Fatalf("seal: %v", err)
	}
	return env
}

func makeMaterial(version uint64, iseSeed, aesSeed byte) encryptor.KeyMaterial {
	var mat encryptor.KeyMaterial
	mat.Version = version
	for i := range mat.ISEKey {
		mat.ISEKey[i] = iseSeed + byte(i)
	}
	for i := range mat.AESKey {
		mat.AESKey[i] = aesSeed + byte(i)
	}
	return mat
}
