package DB

import (
	"errors"

	"thp-clear/src/MQ/encryptor"
)

var ErrEpochMismatch = errors.New("db: key epoch mismatch")

type Ingestor struct {
	ring     *encryptor.KeyRing
	pipeline *encryptor.Pipeline
}

func NewIngestor(ring *encryptor.KeyRing) (*Ingestor, error) {
	if ring == nil {
		return nil, errors.New("db: key ring is required")
	}
	pipeline, err := encryptor.NewPipeline(encryptor.Config{Keys: ring})
	if err != nil {
		return nil, err
	}
	return &Ingestor{ring: ring, pipeline: pipeline}, nil
}

func (i *Ingestor) DecodeEnvelope(env *encryptor.Envelope) ([]byte, bool, error) {
	if i == nil {
		return nil, false, errors.New("db: ingestor not initialised")
	}
	plain, err := i.pipeline.Open(env)
	if err != nil {
		if errors.Is(err, encryptor.ErrKeyVersionUnavailable) {
			return nil, false, ErrEpochMismatch
		}
		return nil, false, err
	}
	usedPrev := false
	if prev, ok := i.ring.Previous(); ok && env != nil && env.KeyVersion == prev.Version {
		usedPrev = true
	}
	return plain, usedPrev, nil
}
