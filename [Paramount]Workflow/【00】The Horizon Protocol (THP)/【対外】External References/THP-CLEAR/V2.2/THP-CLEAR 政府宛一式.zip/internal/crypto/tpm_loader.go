package crypto

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"strconv"
	"strings"

	"github.com/google/go-tpm/legacy/tpm2"
	"github.com/google/go-tpm/tpmutil"
)

const (
	defaultTPMDevice = "/dev/tpm0"
	defaultNVIndex   = 0x1500000
)

// LoadTPMSeed は master_seed_ref に従って TPM NV からシードを読み込み、
// フォールバックとして環境変数 CLEAR_MASTER_SEED_HEX を利用する。
func LoadTPMSeed(ref string) ([]byte, error) {
	device := defaultTPMDevice
	index := defaultNVIndex

	if ref != "" {
		trimmed := strings.TrimPrefix(ref, "tpm://")
		if trimmed != ref && trimmed != "" {
			parts := strings.Split(trimmed, "?")
			if parts[0] != "" {
				device = parts[0]
			}
			if len(parts) > 1 {
				for _, q := range strings.Split(parts[1], "&") {
					if strings.HasPrefix(q, "index=") {
						raw := strings.TrimPrefix(q, "index=")
						if v, err := strconv.ParseUint(raw, 0, 32); err == nil {
							index = int(v)
						}
					}
				}
			}
		}
	}

	if _, err := os.Stat(device); err == nil {
		rw, err := tpm2.OpenTPM(device)
		if err == nil {
			defer rw.Close()
			data, err := tpm2.NVReadEx(rw, tpmutil.Handle(index), tpmutil.Handle(index), "", 0)
			if err == nil && len(data) >= 32 {
				return data[:32], nil
			}
		}
	}

	env := strings.TrimSpace(os.Getenv("CLEAR_MASTER_SEED_HEX"))
	if env == "" {
		return nil, fmt.Errorf("no TPM seed available and CLEAR_MASTER_SEED_HEX unset")
	}
	raw, err := hex.DecodeString(env)
	if err != nil {
		return nil, fmt.Errorf("decode CLEAR_MASTER_SEED_HEX: %w", err)
	}
	if len(raw) == 0 {
		return nil, fmt.Errorf("CLEAR_MASTER_SEED_HEX is empty")
	}
	sum := sha256.Sum256(raw)
	return sum[:], nil
}
