# THP-CLEAR Repository Overview

This document describes the structure of the THP-CLEAR project's source code repository and the role of each file and directory.

## 1. Project Purpose

**THP-CLEAR (Closed-Loop Emergency Asset & Relief)** is a payment infrastructure aimed at securely distributing legal tender as "use-restricted digital balances." It is specifically designed for humanitarian aid and the maintenance of living infrastructure, and is distinct from speculative crypto assets.

The main ideas and features are as follows:

- **Fiat Maximum**: Instead of digitally amplifying the value of legal tender, it prioritizes transparency and auditability of balances and usage restrictions.
- **Layered Structure**: The system's integrity and robustness are ensured by a phased process of `Command` -> `Matching` -> `Witness`.
- **Components**: The main roles are `MQ` (Message Queue), `WN` (Worker Node), and `DB` (Database), which are loosely coupled.
- **Robustness and Low Cost**: By avoiding complex technologies like blockchain and combining consumer hardware (such as mini PCs) and simple software (Go, SQLite), it achieves high fault tolerance and cost efficiency.

## 2. Architecture Overview

Currently, a single Go binary called `clear-api` handles all major functions such as the API server, queuing, and Witness generation. However, the codebase is modularized for each responsibility so that it can be migrated to microservices in the future.

- **Data Flow**: Payment orders from clients are received by `clear-api`, and after verification, they are processed via an asynchronous message queue. The final transaction records are persisted as an immutable `Witness Log`.
    - **Technology Stack**:
        - **Backend**: Go
        - **Database**: SQLite (because it is easy to operate with a single file)
        - **Deployment**: Docker / Docker Compose
        - **Build**: Makefile

### Data Layer Design Philosophy

The data layer of THP-CLEAR is thoroughly designed to have no SPOF. The execution of payments depends on external systems, and CLEAR functions as an "audit system" that verifies and records their execution logs. The System of Record is an append-only Witness log, and SQLite is treated as a "Materialized View" that is independently located locally on each node. This avoids the SPOF of a shared DB, and data can be regenerated from the Witness log in the event of a node failure. For details, please refer to [THP-CLEAR Data Concept](./docs/architecture/THP-CLEAR_Data_Concept.md).

### KMS Redundancy (Staging/Production) CLEAR operates KMS not as a single node but as a **ring + quorum (2-of-3)**.
It is recommended to list **3 or more** in `kms_urls` and set `quorum: 2`.
The session established in the Challenge phase is fixed to the same endpoint until the Submit phase, and failover occurs only when the Challenge is retried. If a Submit error occurs, it is necessary to retry from the Challenge.

Example:
```yaml
kms:
  kms_urls:
    - "https://kms-01:9443"
    - "https://kms-02:9444"
    - "https://kms-03:9445"
  quorum: 2
# The old format (kms_url) is accepted for backward compatibility.
```

Metrics:

* `kms_multi_failover_total` … Number of failovers
* `kms_quorum_met_total` … Number of times quorum was met
* `kms_quorum_failed_total` … Number of times quorum failed

## 3. Directory Structure and File Descriptions

The following describes the roles of the main directories and files in this repository.

```
/
├─── cmd/ ... Entry points for major applications
├─── configs/ ... Configuration files
├─── data/ ... Persistent data (DB, keys, etc.)
├─── docs/ ... Design and operation documents
├─── internal/ ... Core logic used only within the project
├─── pkg/ ... Common libraries that can be provided outside the project
├─── src/ ... PoC (Proof of Concept) code assuming microservices
├─── tests/ ... Test code
├─── witness_logs/ ... Witness logs for public audit
├─── go.mod, go.sum ... Go language dependency definitions
├─── Dockerfile, docker-compose.yml ... Docker container definitions
└─── Makefile ... Automation scripts for building and running tests
```

### Details

| Path | Description |
| --- | --- |
| **`/cmd`** | The `main` package for each executable binary is located here.<br>・`/cmd/clear-api`: The current main application. Provides a REST API.<br>・`/cmd/dbd`, `kmsd`, `mqd`, `wnd`: Each daemon for when splitting into microservices in the future. |
| **`/configs`** | Contains configuration files for various environments (production, development, Docker), such as `docker.yaml` and `example.yaml`. |
| **`/data`** | Persistent data such as `clear.db` (SQLite database file) and the private key used for signing (`private.key`) are stored here. It is registered in `.gitignore` and is not included in the repository. |
| **`/deploy`** | Contains files related to deployment, such as Nginx load balancer settings. |
| **`/docs`** | Contains project-related documents such as `design.md` (design overview), `api.md` (API specification), and release notes. |
| **`/internal`** | This is the heart of the project and contains application-specific code such as domain logic, adapters to the database, and HTTP handlers. According to Go's conventions, it cannot be imported from external repositories. |
| **`/pkg`** | Contains general-purpose libraries that can be reused in other projects, such as encryption processing (`/pkg/crypto`) and monitoring (`/pkg/monitor`). |
| **`/src`** | Contains past PoC (Proof of Concept) code from when each component of MQ, WN, and DB was developed as a separate service. It is considered a reference material for migrating to microservices. |
| **`/tests`** | Contains various test codes such as `service_unit_test.go` (unit tests) and `integration_test.go` (integration tests). |
| **`/var`** | A directory where volatile files generated at runtime, such as log files, are stored. |
| **`/witness_logs`** | A directory where all transaction records are stored in an append-only format. It is an important element that guarantees the transparency and auditability of the system. |
| `docker-compose.yml` | Defines the configuration of services (API, DB, etc.) in the Docker environment. It is used with the `docker compose up` command. |
| `Makefile` | A script for automating routine tasks in development, such as `make run` (execution), `make test` (testing), and `make build` (building). |
