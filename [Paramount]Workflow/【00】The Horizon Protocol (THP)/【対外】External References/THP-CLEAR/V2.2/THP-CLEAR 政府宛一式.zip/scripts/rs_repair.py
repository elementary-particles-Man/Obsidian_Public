#!/usr/bin/env python3
"""Reed-Solomon (10,2) parity helper for THP-CLEAR snapshots.

Requires the `reedsolo` package (`pip install reedsolo`).
Encodes snapshot directories into k+m shard files and repairs
missing shards when recovering from media loss.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Dict, List

try:
    from reedsolo import RSCodec
except ImportError:  # pragma: no cover - handled at runtime
    RSCodec = None  # type: ignore


def ensure_rs_codec(m: int) -> RSCodec:
    if RSCodec is None:
        raise RuntimeError("reedsolo module not available. Install with `pip install reedsolo`. ")
    return RSCodec(m)


def encode_directory(directory: Path, k: int, m: int, chunk_hint: int) -> Dict:
    rs = ensure_rs_codec(m)
    shards_root = directory / "rs_shards"
    shards_root.mkdir(exist_ok=True)

    manifest = {
        "k": k,
        "m": m,
        "chunk_hint": chunk_hint,
        "files": [],
    }

    for entry in sorted(directory.iterdir()):
        if entry.is_dir():
            if entry.name == "rs_shards":
                continue
            # skip directories other than shards
            continue
        if entry.name == "erasure_manifest.json":
            continue
        info = encode_file(entry, shards_root, rs, k, m)
        manifest["files"].append(info)

    return manifest


def encode_file(file_path: Path, shards_root: Path, rs: RSCodec, k: int, m: int) -> Dict:
    data = file_path.read_bytes()
    size = len(data)
    pad = (-size) % k
    if pad:
        data += b"\x00" * pad

    shards: List[bytearray] = [bytearray() for _ in range(k + m)]
    for offset in range(0, len(data), k):
        block = data[offset : offset + k]
        codeword = rs.encode(block)
        for idx, shard in enumerate(shards):
            shard.append(codeword[idx])

    shard_paths: List[str] = []
    for idx, shard in enumerate(shards):
        shard_path = shards_root / f"{file_path.name}.shard{idx:02d}"
        shard_path.write_bytes(shard)
        shard_paths.append(os.path.relpath(shard_path, file_path.parent))

    return {
        "path": file_path.name,
        "size": size,
        "padding": pad,
        "shards": shard_paths,
    }


def repair_directory(directory: Path, manifest: Dict) -> None:
    rs = ensure_rs_codec(manifest["m"])
    for entry in manifest["files"]:
        repair_file(directory, entry, rs, manifest["k"], manifest["m"])


def repair_file(base_dir: Path, entry: Dict, rs: RSCodec, k: int, m: int) -> None:
    shards: Dict[int, bytes] = {}
    shard_len: int | None = None

    for idx, rel in enumerate(entry["shards"]):
        shard_path = base_dir / rel
        if shard_path.exists():
            data = shard_path.read_bytes()
            shards[idx] = data
            if shard_len is None:
                shard_len = len(data)
            else:
                shard_len = min(shard_len, len(data))

    if len(shards) < k:
        raise RuntimeError(f"insufficient shards for {entry['path']}: have {len(shards)}, need {k}")

    stripe_len = shard_len if shard_len is not None else 0
    output = bytearray()

    for stripe in range(stripe_len):
        codeword = bytearray(k + m)
        erasures: List[int] = []
        for idx in range(k + m):
            shard_data = shards.get(idx)
            if shard_data is not None and stripe < len(shard_data):
                codeword[idx] = shard_data[stripe]
            else:
                codeword[idx] = 0
                erasures.append(idx)
        if len(erasures) > m:
            raise RuntimeError(f"too many erasures in stripe {stripe} for {entry['path']}")
        decoded, _, _ = rs.decode(bytes(codeword), erase_pos=erasures)
        output.extend(decoded)

    output = output[: entry["size"]]
    target = base_dir / entry["path"]
    target.write_bytes(output)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="RS(10,2) helper for THP-CLEAR snapshots")
    sub = parser.add_subparsers(dest="command")

    enc = sub.add_parser("encode", help="generate parity shards for a snapshot directory")
    enc.add_argument("directory", type=Path, help="snapshot directory (contains witness/key dumps)")
    enc.add_argument("--k", type=int, default=10, help="data shards count (default: 10)")
    enc.add_argument("--m", type=int, default=2, help="parity shards count (default: 2)")
    enc.add_argument("--chunk-bytes", type=int, default=134_217_728, help="chunk hint for operators (informational)")

    dec = sub.add_parser("repair", help="recover files from shards")
    dec.add_argument("directory", type=Path, help="snapshot directory containing manifest and shards")

    return parser.parse_args()


def main() -> None:
    args = parse_args()

    if args.command is None:
        print("[rs] no operation requested; use encode/repair for actions")
        return

    if args.command == "encode":
        manifest = encode_directory(args.directory.resolve(), args.k, args.m, args.chunk_bytes)
        manifest_path = args.directory / "erasure_manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2))
        print(f"[rs] manifest written to {manifest_path}")
    elif args.command == "repair":
        manifest_path = args.directory / "erasure_manifest.json"
        if not manifest_path.exists():
            raise RuntimeError(f"manifest not found: {manifest_path}")
        manifest = json.loads(manifest_path.read_text())
        repair_directory(args.directory.resolve(), manifest)
        print("[rs] repair completed")


if __name__ == "__main__":  # pragma: no cover
    main()
