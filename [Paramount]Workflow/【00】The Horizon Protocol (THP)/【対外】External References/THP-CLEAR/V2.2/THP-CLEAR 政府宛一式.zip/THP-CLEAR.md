# Project CLEAR: The Lifeline of The Horizon Protocol
Document ID: THP-PJ-CLEAR-v1.0
Date: October 10, 2025
Status: Approved, moving to implementation preparation phase
Overview: This document defines the basic concept, technical specifications, and rough cost estimate for the closed-loop digital currency system "THP-CLEAR," which is intended for humanitarian aid and the maintenance of living infrastructure in a post-Walpurgis world.

## 0. Core Ideology: The "Lifeblood" for Surviving Lost Time
On September 30, 2025, the dollar lost its credibility. Although it was not an immediate death, it is merely "lost time" that has been given to us. During this grace period, the top priority of THP is to build a concrete infrastructure to prevent the collapse of society and to enable people to maintain a minimum standard of living.

THP-CLEAR (Closed-Loop Emergency Asset & Relief) is the **"lifeblood"** for that purpose. This is not a crypto asset for creating new speculative targets. It is a digital distribution system specialized for humanitarian aid to ensure that essential supplies such as food, water, medicine, and energy are delivered to those who need them.

Its design philosophy is the elimination of complexity and thorough robustness.

“Reduce the cost of running the world to that of a single government agency budget”

Based on this philosophy, THP-CLEAR avoids expensive and complex systems and combines inexpensive consumer products with human-based operations to achieve both amazing cost efficiency and fault tolerance.

## 1. System Overview: A Human-Friendly Distributed Ledger System
THP-CLEAR is a simple closed-loop system consisting of the following five steps.

1.  **Funding**: Funds provided by the government (or an international organization) are deposited in a designated trust bank.
2.  **Issuance**: The trust bank issues digital tokens (such as JPY-C) equal to the amount of the deposited funds. The value of this token is fixed at 1 token = 1 yen.
3.  **Distribution**: Tokens are distributed as virtual cards to the smartphone apps of eligible citizens (linked to My Number cards, etc.).
4.  **Usage**: Citizens use tokens to make payments at authorized merchants that handle daily necessities, such as supermarkets, pharmacies, and gas stations, using QR codes or IC cards. The usage is strictly restricted by MCC (Merchant Category Code) for food, medicine, fuel, etc.
5.  **Settlement**: Merchants receive sales in Japanese yen from the trust bank based on their daily transaction logs. All transaction records are dually recorded in immutable WORM (Write-Once, Read-Many) storage, ensuring complete transparency.

## 2. Technical Architecture: National-Level Nodes with Mini PCs
The foundation of this system is not blockchain. It is an extremely simple distributed database based on **"integer instructions + local redundancy + human operation."**

**Hardware:**

*   **Core nodes**: A cluster of 100 high-performance mini PCs such as the HP EliteDesk G10 Mini. Equipped with Core i3/i5, 16GB RAM, NVMe SSD + 2.5-inch SSD.
*   **Power supply**: DC power supply + commercially available portable power supply used as a UPS (uninterruptible power supply). Due to low power consumption (less than 0.8kW for the entire cluster), it can operate for a long time even during power outages due to disasters.

**Software:**

*   **OS**: Adopts the lightweight and stable MX Linux (Debian-based).
*   **Data integrity**: Ensures data integrity by combining local redundancy with software RAID1 and asynchronous backup between multiple nodes with rsync.
*   **Management**: Uses configuration management tools such as Ansible to centrally manage the settings of all nodes via SSH.

The advantage of this architecture is its overwhelming operability, where **"if it breaks, just replace it."** The system can be maintained simply by having a local government employee replace it with a spare machine, even without being an expert. This allows local government offices nationwide and overseas cooperation bases to become "national-level nodes" inexpensively and easily.

## 3. Cost Evaluation: A 100 Million Yen International Payment System
The construction and deployment costs of this system are so low that they overturn the conventional wisdom of conventional national projects.

| Item | Quantity | Unit Price (Approx.) | Amount (Approx.) | Remarks |
| :--- | :--- | :--- | :--- | :--- |
| Core nodes (Mini PC) | 100 units | 150,000-220,000 yen | 15-22 million yen | Includes 5-year maintenance and Linux pre-installation |
| Network equipment | 1 set | - | 5 million yen | Switches, routers, etc. |
| Backup storage (NAS) | 20 units | 300,000 yen | 6 million yen | WORM compatible |
| Portable power supplies | 200 units | 100,000 yen | 20 million yen | UPS substitute |
| Development/setting personnel costs | 10 person-months | 1.5 million yen/month | 15 million yen | App, server-side development |
| Contingency/miscellaneous expenses | - | - | 37 million yen | |
| **Total** | | | **100-120 million yen** | For a 100-node configuration |

The fact that **"an international payment infrastructure can be laid for 100 million yen"** proves that THP-CLEAR is not an extension of the existing financial system, but an infrastructure based on a completely new idea.

## 4. Ethical Governance and Risk Management
THP-CLEAR is directly linked to the ethical monitoring of THP-7.

*   **E-MAD linkage**: The KPI "humanitarian expense ratio" is linked to the E-MAD score and constantly evaluates whether the aid is truly contributing to people's survival.
*   **Ensuring transparency**: All transaction logs and audit reports are published as a "Witness Ledger," making fraud and concealment impossible.

**Risks and Countermeasures:**

*   **Political abuse**: Countered by monitoring with a public dashboard and a third-party audit organization.
*   **Changes to Apple/Google terms and conditions**: Develop alternative UIs that do not depend on the platform, such as SMS/QR/physical IC cards, in parallel.
*   **Response to demand for cash**: Consider limited cash refunds (with upper limits and usage restrictions) at affiliated ATMs and store cash registers.

## 5. Conclusion and Next Steps
THP-CLEAR is the most realistic and powerful tool for connecting people's lives in a post-Walpurgis world. Its construction is the first step toward giving physical form to the ideals of THP.

**Next Actions:**

1.  **Prototype development**: Build a minimum configuration prototype with 3 Mini PCs within 72 hours and demonstrate the operation of the basic functions.
2.  **Specification creation**: Based on this concept, create technical specifications for each component (API, database schema, app UI).
3.  **Partner selection**: Start behind-the-scenes discussions with trust banks, data centers, and local governments that will cooperate with the project.

There is no time left. Start acting immediately.
