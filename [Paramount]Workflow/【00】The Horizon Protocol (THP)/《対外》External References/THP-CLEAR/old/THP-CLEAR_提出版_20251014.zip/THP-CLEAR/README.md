# THP-CLEAR

[![CI (unit)](https://github.com/elementary-particles-Man/THP-CLEAR/actions/workflows/ci.yml/badge.svg)](https://github.com/elementary-particles-Man/THP-CLEAR/actions/workflows/ci.yml)
[![Integration](https://github.com/elementary-particles-Man/THP-CLEAR/actions/workflows/itest.yml/badge.svg)](https://github.com/elementary-particles-Man/THP-CLEAR/actions/workflows/itest.yml)

THP-CLEAR is a payment infrastructure based on the Fiat Maximum philosophy, aimed at securely distributing legal tender as "use-restricted digital balances." Its layered architecture achieves both strict verification of payment orders and the generation of publicly auditable Witness logs.

## Project Overview

- **Fiat Maximum**: This is the idea of making the constraints on balances and usage transparent, rather than digitally amplifying the value of legal tender. CLEAR prioritizes the normalization and auditability of orders and minimizes the discretion of currency issuers.
- **Layered Structure**: Integrity is ensured by a phased process of Command → Matching → Witness. Each layer is an independent component, allowing for phased degraded operation in the event of a failure.
- **Roles of MQ / WN / DB**:
  - **MQ (Message Queue)**: Loosely couples the API server and backend processing, and delivers encrypted order envelopes.
  - **WN (Worker Node)**: Connects to a horizontal layer (e.g., an EVM-compatible chain), verifies the finality of asset transfers, and generates a Witness payload.
  - **DB**: Maintains the integrity of accounts and orders, and persists the Witness log. Authenticity is guaranteed by the redundancy of signing keys and logs.

```mermaid
graph TD
    subgraph Clients
        A[Operator UI]
        B[Layer0 Integrations]
    end
    A -->|REST/gRPC| C(clear-api)
    B -->|Command API| C
    subgraph Core
        C -->|Encrypted Envelope| D[Message Queue]
        D -->|Dispatch| E[Worker Node]
        E -->|Witness Payload| F[DB Service]
        F -->|Append| G[Witness Log]
    end
    F -->|Query| H[Monitoring]
    G -->|Publish| I[External Auditors]
```

## Implementation Repository Structure

- `cmd/clear-api`: Go API server (payment order and Witness management)
- `configs/`: Execution configuration files (`example.yaml`, `docker.yaml`)
- `internal/`: Domain logic, SQLite adapter, HTTP handlers, etc.
- `pkg/`: Common libraries such as signing and metrics
- `docs/`: Design and operation documents
- `tests/`: Basic tests for the service layer
- `src/`: Legacy configuration (PoC implementation of MQ/WN/DB). Left for verification of future microservice separation.

## Operation with Docker

THP-CLEAR is premised on deployment with Docker. An example setup on Ubuntu 24.04 is as follows.

### 1. Install Docker / Compose

```bash
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker $USER
```

To reflect the group change, please log out and log back in (before re-logging in, execute with `sudo docker ...`).

### 2. Create a directory for persistent data

```bash
mkdir -p data witness_logs
```

The database file (`data/clear.db`), Witness log (`witness_logs/transactions.log`), and private key (`data/private.key`) are saved on the host side.

### 3. Build and start the container

```bash
sudo docker compose up --build -d
```

- `configs/docker.yaml` is the default configuration in the container. If you want to change the port or path, please edit this file and then rebuild.
- Check operation: `sudo docker compose ps`
- Check logs: `sudo docker compose logs -f`
- Health check: `curl http://localhost:8080/healthz`

The API server listens on `8080/tcp` and the metrics on `9100/tcp`.

### 4. Stop/Restart

```bash
sudo docker compose stop        # Stop
sudo docker compose start       # Restart
sudo docker compose down        # Delete the container
```

### 5. Update

```bash
git pull
sudo docker compose build
sudo docker compose up -d
```

The new binary will be reflected in the container.

### 6. Image build / push helpers

- `make docker-build IMAGE_TAG=v0.1.0`
- `make docker-up` / `make docker-down` / `make docker-logs`
- `make docker-push REGISTRY=registry.example.com/team IMAGE_TAG=v0.1.0`

詳しい手順は `docs/docker_usage_jp.md` を参照してください。

## Build and Execution

```bash
make run
```

Please adjust `configs/example.yaml` to your environment. The following will be created automatically on first startup.

- SQLite database `thp-clear.db`
- Witness log `./data/witness.log`
- Ed25519 private key `./data/private.key`

## Test

| Command | Content |
|---|---|
| `make test` | High-speed unit test using memory store (no tag specification required) |
| `make itest` | Integration test using SQLite (`integration` tag) |

To execute directly, use `go test ./tests -v` (unit) or `go test ./tests -tags=integration -v` (integration). Execution with `modernc.org/sqlite` may take time to build depending on the environment.

## KeyHub (KMS-in-DB) 内部モード

- デフォルトで internal モードが有効化され、DB ノード内に KeyHub サブサーバーが起動します。
- 署名 API:  `POST /internal/kms/sign`
- 公開鍵 API: `GET  /internal/kms/pubkey`
- 署名鍵は 10 分ごと（`crypto.keyhub.epoch_seconds`）にローテーションされ、操作ログは `witness_logs/kms_audit.jsonl` に追記されます。

## License

This project is provided under the [Apache License 2.0](LICENSE).
